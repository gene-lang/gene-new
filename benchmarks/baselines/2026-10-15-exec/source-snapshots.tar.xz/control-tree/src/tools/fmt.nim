## Human-friendly source formatter for `gene fmt`.
##
## Unlike the canonical printer (printer.nim — one line per form, fully
## desugared, used by `gene parse` and serde), this module targets people:
##
## - forms wrap at a max width with 2-space indentation and special-form
##   aware layouts (fn/if/match/type/... bodies indent under a head line);
## - reader sugar prints back as sugar: slash paths (`a/b`), quasiquote
##   (`` `x ``) / unquote (`%x`), and `gene/to_str` calls as `$"a${b}c"`;
## - strings containing newlines print as raw multiline strings;
## - comments and blank lines BETWEEN top-level forms are preserved; a form
##   whose span contains interior comments is emitted verbatim (the reader
##   drops comments, so reformatting such a form would delete them).
##
## Formatted output must re-parse to the same canonical forms as the input
## (`tests/test_cli.nim` asserts parse-equivalence and idempotence).

import std/[strutils, tables]
import ../gene/[reader, types, printer]
import ./lsp/analysis as span
import ./source_index

const MaxWidth = 100

# ---------------------------------------------------------------------------
# Raw-span helpers (comment detection + form extents in the original text)
# ---------------------------------------------------------------------------

proc skipStringRaw(src: string, start: int): int =
  var i = start
  if src.continuesWith("\"\"\"", i):
    i += 3
    while i < src.len:
      if src.continuesWith("\"\"\"", i): return i + 3
      inc i
    return src.len
  inc i
  while i < src.len:
    case src[i]
    of '\\': i += 2
    of '"': return i + 1
    else: inc i
  src.len

proc hasInteriorComment(src: string, a, b: int): bool =
  ## Any `# ...` / `#< >#` / `#_` comment strictly inside [a, b)?
  var i = a
  while i < b and i < src.len:
    case src[i]
    of '"': i = skipStringRaw(src, i)
    of '$':
      if i + 1 < src.len and src[i + 1] == '"': i = skipStringRaw(src, i + 1)
      else: inc i
    of '\'':
      # char literal: skip up to closing quote on the same line
      var j = i + 1
      if j < src.len and src[j] == '\\': inc j
      while j < src.len and src[j] notin {'\'', '\n'}: inc j
      i = (if j < src.len and src[j] == '\'': j + 1 else: i + 1)
    of '#':
      if i + 1 < src.len and src[i + 1] == '"': i = skipStringRaw(src, i + 1)
      elif i + 1 < src.len and src[i + 1] == 'B':
        # #B# / #B16# / #B64# byte literal; its '#' is not a comment start.
        let e = span.hashBytesLiteralEnd(src, i)
        i = (if e > 0: e else: i + 1)
      elif i + 1 < src.len and src[i + 1] in {'(', '[', '{'}: inc i
      elif i + 1 < src.len and src[i + 1] == '@': i += 2
      else:
        # Reserved '#' forms are read errors in the reader; this raw span
        # helper stays error-tolerant and treats them like comments.
        return true
    else: inc i
  false

proc formSpan(src: string, startOff: int): int =
  ## Offset just past a top-level form starting at startOff.
  var i = startOff
  while i < src.len and src[i] in {'`', '%'}: inc i
  if i < src.len and src[i] in {'(', '[', '{'}:
    return span.matchingCloseOffset(src, i)
  if i + 1 < src.len and src[i] == '#' and src[i + 1] in {'(', '[', '{'}:
    return span.matchingCloseOffset(src, i)
  if i + 1 < src.len and src[i] == '$' and src[i + 1] == '"':
    return skipStringRaw(src, i + 1)
  if i + 1 < src.len and src[i] == '#' and src[i + 1] == '"':
    i = skipStringRaw(src, i + 1)
    while i < src.len and src[i] in {'A'..'Z', 'a'..'z'}: inc i
    return i
  if i < src.len and src[i] == '"':
    return skipStringRaw(src, i)
  if i < src.len and src[i] == '\'':
    var j = i + 1
    if j < src.len and src[j] == '\\': inc j
    while j < src.len and src[j] notin {'\'', '\n', '\r'}: inc j
    return (if j < src.len and src[j] == '\'': j + 1 else: src.len)
  while i < src.len and src[i] notin {'(', ')', '[', ']', '{', '}', ' ',
      '\t', '\n', '\r', ',', ';', '"'}:
    inc i
  i

# ---------------------------------------------------------------------------
# Sugar-aware single-line rendering
# ---------------------------------------------------------------------------

proc formattingView(value: Value, wraps: Table[uint64, WrapSyntax]): Value =
  ## A source-only rendering tree. Never mutate the canonical reader result or
  ## put a spelling marker into runtime metadata. Captured operands also retain
  ## #@ around forms normalized by the ordinary reader, such as message sends.
  if wraps.len == 0: return value
  if wraps.hasKey(value.bits):
    let syntax = wraps[value.bits]
    return newNode(newSym("#@"), body = @[
      formattingView(syntax.head, wraps), formattingView(syntax.argument, wraps)])
  case value.kind
  of vkNode:
    var props, meta = initPropTable()
    var body: seq[Value]
    for key, item in value.props: props[key] = formattingView(item, wraps)
    for key, item in value.meta: meta[key] = formattingView(item, wraps)
    for item in value.body: body.add formattingView(item, wraps)
    newNode(formattingView(value.head, wraps), props, body, meta,
            immutable = value.nodeImmutable)
  of vkList:
    var items: seq[Value]
    for item in value.listItems: items.add formattingView(item, wraps)
    newList(items, value.listImmutable)
  of vkMap:
    var entries = initPropTable()
    for key, item in value.mapEntries: entries[key] = formattingView(item, wraps)
    newMap(entries, value.mapImmutable)
  of vkHashMap:
    var entries: seq[HashMapEntry]
    for entry in value.hashMapEntries:
      entries.add HashMapEntry(key: formattingView(entry.key, wraps),
                               val: formattingView(entry.val, wraps))
    newHashMap(entries)
  of vkPipeline:
    var stages: seq[PipelineStage]
    for stage in value.pipelineStages:
      var copied = stage
      copied.head = formattingView(stage.head, wraps)
      copied.props = initPropTable()
      copied.meta = initPropTable()
      copied.body = @[]
      for key, item in stage.props: copied.props[key] = formattingView(item, wraps)
      for key, item in stage.meta: copied.meta[key] = formattingView(item, wraps)
      for item in stage.body: copied.body.add formattingView(item, wraps)
      stages.add copied
    newPipeline(formattingView(value.pipelineInitial, wraps), stages,
                value.pipelineImmutable)
  else:
    value

proc oneLine(v: Value): string

proc isSym(v: Value, s: string): bool =
  v.kind == vkSymbol and v.symVal == s

proc pathSegment(v: Value): string =
  ## "" when the segment cannot ride in a slash path.
  case v.kind
  of vkSymbol:
    if '/' in v.symVal or v.symVal.len == 0:
      ""
    elif v.symVal.len > 2 and v.symVal.startsWith("?~"):
      "?." & v.symVal[2 .. ^1]
    elif v.symVal.len > 1 and v.symVal[0] == '~':
      "." & v.symVal[1 .. ^1]
    else:
      v.symVal
  of vkInt: print(v)
  of vkNode:
    if v.head.isSym("unquote") and v.body.len == 1 and v.props.len == 0:
      let inner = pathSegment(v.body[0])
      if inner.len > 0: "%" & inner else: ""
    else: ""
  else: ""

proc resugarPath(v: Value): string =
  ## (path a b c) -> a/b/c, or "" when any segment resists.
  if v.props.len > 0 or v.meta.len > 0 or v.body.len < 2: return ""
  var parts: seq[string]
  for item in v.body:
    let seg = pathSegment(item)
    if seg.len == 0: return ""
    parts.add seg
  # `(path gene x ...)` is what `$x` reads as, so print the sugar back —
  # otherwise a formatted file would no longer round-trip (design §2.1).
  if parts.len >= 2 and parts[0] == "gene":
    return "$" & parts[1 .. ^1].join("/")
  parts.join("/")

proc resugarInterp(v: Value): string =
  ## ($to_str "a" b "c") -> $"a${b}c", or "" when unsafe (a literal `$` in any
  ## string part would re-parse as interpolation).
  if v.props.len > 0 or v.meta.len > 0 or v.body.len == 0: return ""
  var sawStr = false
  for item in v.body:
    if item.kind == vkString:
      sawStr = true
      if '$' in item.strVal or '\n' in item.strVal or
          '\r' in item.strVal or '\0' in item.strVal: return ""
  if not sawStr: return ""
  var sb = "$\""
  for item in v.body:
    if item.kind == vkString:
      for ch in item.strVal:
        case ch
        of '"': sb.add "\\\""
        of '\\': sb.add "\\\\"
        else: sb.add ch
    else:
      let expression = oneLine(item)
      # The surrounding string reader would consume expression quotes/escapes.
      # Keep the ordinary conversion form when interpolation is not lossless.
      if '"' in expression or '\\' in expression or '\n' in expression:
        return ""
      sb.add "${" & expression & "}"
  sb.add '"'
  sb

proc declarationPrefixCount(head: string, body: openArray[Value]): int =
  ## Body items which conventionally precede declaration props/meta. Runtime
  ## nodes store props separately, so their original source position is not
  ## available after reading; the formatter chooses the language convention.
  case head
  of "mod", "ns", "enum", "protocol":
    if body.len > 0 and body[0].kind == vkSymbol: 1 else: 0
  of "type":
    if body.len == 0 or body[0].kind != vkSymbol:
      return 0
    if body.len >= 3 and body[1].isSym(":"): 3 else: 1
  of "fn", "macro", "message", "ctor":
    var n = 0
    if head != "ctor" and n < body.len and body[n].kind == vkSymbol: inc n
    if n < body.len and body[n].kind == vkList: inc n
    if n + 1 < body.len and body[n].isSym(":"): n += 2
    n
  else:
    0

proc headerBodyCount(head: string, body: openArray[Value]): int =
  ## Number of positional items kept on the opening line of a broken form.
  case head
  of "if", "if_yes", "if_not", "while", "when", "elif", "match", "case",
     "let", "var", "const", "set", "spawn":
    1
  of "for", "repeat":
    if body.len >= 3 and body[1].isSym("in"): 3 else: 1
  of "impl":
    if body.len >= 3 and body[1].isSym("for"): 3 else: 1
  of "do", "else", "then", "try", "loop", "supervisor":
    0
  of "fn", "macro", "message", "ctor", "mod", "ns", "type",
     "enum", "protocol":
    declarationPrefixCount(head, body)
  else:
    # Message send keeps `x .msg` on the head line.
    if body.len >= 2 and (body[0].isSym("~") or body[0].isSym("?~")): 2
    else: 0

proc attributePrefixCount(v: Value, head: string): int =
  result = declarationPrefixCount(head, v.body)
  # Data nodes conventionally place metadata after a leading symbolic name.
  if result == 0 and v.meta.len > 0 and v.body.len > 0 and
      v.body[0].kind == vkSymbol:
    result = 1

proc addProps(sb: var string, props: PropTable, sigil: string) =
  for rawKey, val in props:
    # Only `^` props have a quoted-key spelling; `@` meta keys print as is.
    let k = if sigil == "^": propKeyText(rawKey) else: rawKey
    sb.add ' '
    if val.kind == vkBool:
      sb.add sigil & (if val.boolVal: sigil else: "!") & k
    else:
      sb.add sigil & k & " " & oneLine(val)

proc joinItems(items: openArray[Value]): string =
  ## Space-joined, but a bare `,` symbol glues to the previous item.
  var sb = ""
  var glueNext = false
  for item in items:
    if item.isSym(","):
      sb.add ","
      glueNext = false
    elif item.isSym("^") or item.isSym("@"):
      if sb.len > 0: sb.add ' '
      sb.add oneLine(item)
      glueNext = true
    else:
      if sb.len > 0 and not glueNext: sb.add ' '
      sb.add oneLine(item)
      glueNext = false
  sb

proc sendDescriptor(callee: Value, optional: bool): string =
  result = if optional: "?." else: "."
  if callee.kind == vkNode and callee.head.isSym("msg") and
      callee.body.len == 2 and callee.body[1].kind == vkSymbol:
    let qualifier =
      if callee.body[0].kind == vkNode and callee.body[0].head.isSym("path"):
        let path = resugarPath(callee.body[0])
        if path.len > 0: path else: oneLine(callee.body[0])
      else:
        oneLine(callee.body[0])
    result.add qualifier & ":" & callee.body[1].symVal
  elif callee.kind == vkNode and callee.head.isSym("unquote") and
      callee.body.len == 1:
    result.add '%'
    if callee.body[0].kind == vkSymbol:
      result.add callee.body[0].symVal
    else:
      result.add oneLine(callee.body[0])
  elif callee.kind == vkSymbol:
    result.add callee.symVal
  else:
    result.add '%' & oneLine(callee)

proc sendParts(v: Value): tuple[found, leading, optional: bool,
                                  receiver, callee: Value, argsStart: int] =
  if v.kind != vkNode:
    return
  if v.head.kind == vkSymbol and v.head.symVal in ["~", "?~"] and
      v.body.len > 0:
    return (true, true, v.head.symVal == "?~", NIL, v.body[0], 1)
  if v.body.len > 1 and v.body[0].kind == vkSymbol and
      v.body[0].symVal in ["~", "?~"]:
    return (true, false, v.body[0].symVal == "?~", v.head, v.body[1], 2)

proc sendOneLine(v: Value): string =
  let send = sendParts(v)
  if not send.found:
    return
  # Qualified path sends read back as ordinary send nodes. Restore their
  # preferred spelling when it preserves the complete reader value. Bare
  # path sends already pass through resugarPath below.
  if not send.leading and not send.optional and not v.nodeImmutable and
      v.body.len == send.argsStart and v.props.len == 0 and v.meta.len == 0 and
      send.callee.kind == vkNode and send.callee.head.isSym("msg"):
    var receiver = ""
    if send.receiver.kind == vkSymbol and not send.receiver.isSym("super"):
      receiver = send.receiver.symVal
    elif send.receiver.kind == vkNode and send.receiver.head.isSym("path"):
      receiver = resugarPath(send.receiver)
    if receiver.len > 0:
      let short = receiver & "/" & sendDescriptor(send.callee, false)
      try:
        let parsed = readAll(short)
        if parsed.len == 1 and print(parsed[0]) == print(v):
          return short
      except ReadError:
        discard
  result = if v.nodeImmutable: "#(" else: "("
  if not send.leading:
    result.add oneLine(send.receiver)
    addProps(result, v.meta, "@")
    addProps(result, v.props, "^")
    result.add ' '
  result.add sendDescriptor(send.callee, send.optional)
  if send.leading:
    addProps(result, v.meta, "@")
    addProps(result, v.props, "^")
  if v.body.len > send.argsStart:
    result.add ' ' & joinItems(v.body[send.argsStart .. ^1])
  result.add ')'

proc renderPipelineStage(stage: seq[Value]): string =
  if stage.len >= 2 and stage[0].kind == vkSymbol and
      stage[0].symVal in ["~", "?~"]:
    result = sendDescriptor(stage[1], stage[0].symVal == "?~")
    if stage.len > 2:
      result.add ' ' & joinItems(stage[2 .. ^1])
  else:
    result = joinItems(stage)

proc valuePipelineStageLine(stage: PipelineStage): string =
  result = oneLine(stage.head)
  addProps(result, stage.meta, "@")
  addProps(result, stage.props, "^")
  if stage.body.len > 0:
    result.add ' ' & joinItems(stage.body)

proc valuePipelineOneLine(value: Value): string =
  result = if value.pipelineImmutable: "#(" else: "("
  result.add oneLine(value.pipelineInitial)
  for stage in value.pipelineStages:
    result.add " " & pipelineDelimiter(stage.kind) & " " &
      valuePipelineStageLine(stage)
  result.add ')'

proc pipelineParts(v: Value): tuple[base: Value, stages: seq[seq[Value]]] =
  ## Reader pipe folding and explicitly nested receiver sends have the same
  ## value shape. Canonical human style uses pipe sugar for chains of at least
  ## two sends; a single receiver send remains `(value .message ...)`.
  var current = v
  var reversed: seq[seq[Value]]
  while current.kind == vkNode and not current.nodeImmutable and
      current.props.len == 0 and current.meta.len == 0 and
      current.body.len >= 2 and
      (current.body[0].isSym("~") or current.body[0].isSym("?~")):
    reversed.add current.body
    current = current.head
  result.base = current
  if reversed.len >= 2:
    for i in countdown(reversed.high, 0):
      result.stages.add reversed[i]

proc pipelineOneLine(v: Value): string =
  let parts = pipelineParts(v)
  if parts.stages.len < 2:
    return ""
  result = "(" & oneLine(parts.base)
  for i, stage in parts.stages:
    result.add (if i == 0: " " else: "; ")
    result.add renderPipelineStage(stage)
  result.add ')'

proc oneLine(v: Value): string =
  case v.kind
  of vkPipeline:
    valuePipelineOneLine(v)
  of vkNode:
    if v.head.isSym("#@") and v.body.len == 2:
      return "#@ " & oneLine(v.body[0]) & " " & oneLine(v.body[1])
    let pipeline = pipelineOneLine(v)
    if pipeline.len > 0:
      return pipeline
    let send = sendOneLine(v)
    if send.len > 0:
      return send
    if not v.nodeImmutable and v.head.kind == vkNode and
        v.head.head.isSym("path") and v.head.body.len == 2 and
        v.head.body[0].isSym("gene") and v.head.body[1].isSym("to_str"):
      let interpolated = resugarInterp(v)
      if interpolated.len > 0: return interpolated
    if not v.nodeImmutable and v.head.kind == vkSymbol:
      case v.head.symVal
      of "#Ref":
        if v.body.len == 2:
          return "#Ref " & oneLine(v.body[0]) & " " & oneLine(v.body[1])
      of "#Deref":
        if v.body.len == 1: return "#Deref " & oneLine(v.body[0])
      of "path":
        let p = resugarPath(v)
        if p.len > 0: return p
      of "quasiquote":
        if v.body.len == 1 and v.props.len == 0:
          return "`" & oneLine(v.body[0])
      of "unquote":
        if v.body.len == 1 and v.props.len == 0:
          return "%" & oneLine(v.body[0])
      of "...":
        if v.body.len == 1 and v.props.len == 0:
          return oneLine(v.body[0]) & "..."
      else: discard
    var sb = (if v.nodeImmutable: "#(" else: "(") & oneLine(v.head)
    let head = if v.head.kind == vkSymbol: v.head.symVal else: ""
    let start = attributePrefixCount(v, head)
    for i in 0 ..< start:
      sb.add " " & oneLine(v.body[i])
    addProps(sb, v.meta, "@")
    addProps(sb, v.props, "^")
    if v.body.len > start:
      sb.add " " & joinItems(v.body[start .. ^1])
    sb & ")"
  of vkList:
    (if v.listImmutable: "#[" else: "[") & joinItems(v.listItems) & "]"
  of vkMap:
    var sb = if v.mapImmutable: "#{" else: "{"
    var first = true
    for k, val in v.mapEntries:
      if not first: sb.add ' '
      first = false
      if val.kind == vkBool: sb.add (if val.boolVal: "^^" else: "^!") & propKeyText(k)
      else: sb.add "^" & propKeyText(k) & " " & oneLine(val)
    sb & "}"
  of vkHashMap:
    var entries: seq[string]
    for entry in v.hashMapEntries:
      entries.add oneLine(entry.key) & " : " & oneLine(entry.val)
    "{{" & entries.join(" ") & "}}"
  else:
    print(v)

proc hasMultilineString(v: Value): bool =
  case v.kind
  of vkString: '\n' in v.strVal
  of vkNode:
    if hasMultilineString(v.head): return true
    for _, p in v.props:
      if hasMultilineString(p): return true
    for item in v.body:
      if hasMultilineString(item): return true
    false
  of vkPipeline:
    if hasMultilineString(v.pipelineInitial): return true
    for stage in v.pipelineStages:
      if hasMultilineString(stage.head): return true
      for _, item in stage.props:
        if hasMultilineString(item): return true
      for item in stage.body:
        if hasMultilineString(item): return true
      for _, item in stage.meta:
        if hasMultilineString(item): return true
    false
  of vkList:
    for item in v.listItems:
      if hasMultilineString(item): return true
    false
  of vkMap:
    for _, p in v.mapEntries:
      if hasMultilineString(p): return true
    false
  of vkHashMap:
    for entry in v.hashMapEntries:
      if hasMultilineString(entry.key) or hasMultilineString(entry.val): return true
    false
  else: false

# ---------------------------------------------------------------------------
# Multiline layout
# ---------------------------------------------------------------------------

proc fmtValue(v: Value, indent: int): string

proc rawStr(s: string): string =
  ## Prefer the language's explicit triple-quoted spelling for multiline text.
  if '\n' in s and '\0' notin s and '\r' notin s and
      "\"\"\"" notin s and not s.endsWith('"'):
    # Triple strings still interpret escapes. Keep literal backslashes and
    # avoid raw CR bytes or a trailing quote merging into the closing delimiter.
    return "\"\"\"" & s.replace("\\", "\\\\") & "\"\"\""
  ## Fallback for one-line text or content containing a triple delimiter.
  var sb = "\""
  for ch in s:
    case ch
    of '"': sb.add "\\\""
    of '\\': sb.add "\\\\"
    of '\n': sb.add '\n'
    of '\t': sb.add "\\t"
    of '\r': sb.add "\\r"
    of '\0': sb.add "\\0"
    else: sb.add ch
  sb & "\""

proc fits(v: Value, indent: int): bool =
  not hasMultilineString(v) and indent + oneLine(v).len <= MaxWidth

proc prefersMultiline(v: Value): bool =
  if v.kind == vkPipeline:
    return v.pipelineStages.len >= 2
  if v.kind != vkNode:
    return false
  if pipelineParts(v).stages.len >= 2:
    return true
  if v.head.kind != vkSymbol:
    return false
  let head = v.head.symVal
  let bodyCount = v.body.len
  case head
  of "fn", "macro", "message", "ctor":
    bodyCount > headerBodyCount(head, v.body)
  of "protocol", "impl", "ns":
    bodyCount > headerBodyCount(head, v.body)
  of "if":
    if bodyCount >= 3:
      return true
    for item in v.body:
      if item.kind == vkNode and item.head.kind == vkSymbol and
          item.head.symVal in ["then", "elif", "else"]:
        return true
    false
  of "if_yes", "if_not":
    bodyCount > 2
  of "then", "else", "when", "elif":
    bodyCount > 0
  of "match", "try":
    bodyCount > 1
  of "for":
    bodyCount > headerBodyCount(head, v.body)
  of "while", "repeat", "scope", "loop", "do":
    bodyCount > headerBodyCount(head, v.body)
  else:
    false

proc breakNode(v: Value, indent: int): string =
  let pad = repeat(' ', indent + 2)
  let pipeline = pipelineParts(v)
  if pipeline.stages.len >= 2:
    var sb = "(" & oneLine(pipeline.base)
    for index, stage in pipeline.stages:
      sb.add "\n" & pad
      if index > 0: sb.add "; "
      sb.add renderPipelineStage(stage)
    return sb & ")"
  let send = sendParts(v)
  if send.found:
    var sb = if v.nodeImmutable: "#(" else: "("
    if not send.leading:
      sb.add oneLine(send.receiver)
      addProps(sb, v.meta, "@")
      addProps(sb, v.props, "^")
      sb.add ' '
    sb.add sendDescriptor(send.callee, send.optional)
    if send.leading:
      addProps(sb, v.meta, "@")
      addProps(sb, v.props, "^")
    for i in send.argsStart ..< v.body.len:
      sb.add "\n" & pad & fmtValue(v.body[i], indent + 2)
    return sb & ")"
  var sb = (if v.nodeImmutable: "#(" else: "(") & oneLine(v.head)
  let head = if v.head.kind == vkSymbol: v.head.symVal else: ""
  let start = attributePrefixCount(v, head)
  for index in 0 ..< start:
    sb.add " " & oneLine(v.body[index])
  addProps(sb, v.meta, "@")
  addProps(sb, v.props, "^")
  let body = v.body
  var i = start
  let inline = max(headerBodyCount(head, body), start)
  while i < body.len and i < inline:
    sb.add " " & oneLine(body[i])
    inc i
  if head == "try":
    # catch/ensure align with `try`; their bodies remain one level inside.
    let markerPad = repeat(' ', indent)
    while i < body.len:
      if body[i].isSym("catch") and i + 1 < body.len:
        sb.add "\n" & markerPad & "catch " & oneLine(body[i + 1])
        i += 2
      elif body[i].isSym("ensure"):
        sb.add "\n" & markerPad & "ensure"
        inc i
      else:
        sb.add "\n" & pad & fmtValue(body[i], indent + 2)
        inc i
  else:
    # A lone remaining string rides the head line — the common
    # `(db .exec "multiline sql")` / `(var css "...")` shape.
    if i == body.len - 1 and body[i].kind == vkString:
      sb.add " " & (if '\n' in body[i].strVal: rawStr(body[i].strVal)
                    else: fmtValue(body[i], indent + 2))
    else:
      while i < body.len:
        sb.add "\n" & pad & fmtValue(body[i], indent + 2)
        inc i
  sb & ")"

proc fmtValue(v: Value, indent: int): string =
  if fits(v, indent) and not prefersMultiline(v):
    return oneLine(v)
  case v.kind
  of vkString:
    rawStr(v.strVal)
  of vkNode:
    if v.head.isSym("#@") and v.body.len == 2:
      return "#@ " & fmtValue(v.body[0], indent + 3) & "\n" &
        repeat(' ', indent + 2) & fmtValue(v.body[1], indent + 2)
    if v.head.isSym("#Ref") and v.body.len == 2:
      return "#Ref " & oneLine(v.body[0]) & "\n" &
        repeat(' ', indent + 2) & fmtValue(v.body[1], indent + 2)
    # Sugar wrappers stay glued to their (possibly multiline) inner form.
    if not v.nodeImmutable and v.head.kind == vkSymbol and
        v.props.len == 0 and v.body.len == 1:
      case v.head.symVal
      of "quasiquote": return "`" & fmtValue(v.body[0], indent + 1)
      of "unquote": return "%" & fmtValue(v.body[0], indent + 1)
      of "...": return fmtValue(v.body[0], indent) & "..."
      else: discard
    breakNode(v, indent)
  of vkPipeline:
    let pad = repeat(' ', indent + 2)
    var sb = if v.pipelineImmutable: "#(" else: "("
    sb.add oneLine(v.pipelineInitial)
    for stage in v.pipelineStages:
      sb.add "\n" & pad & pipelineDelimiter(stage.kind) & " " &
        valuePipelineStageLine(stage)
    sb & ")"
  of vkList:
    let pad = repeat(' ', indent + 2)
    var sb = if v.listImmutable: "#[" else: "["
    for item in v.listItems:
      sb.add "\n" & pad & fmtValue(item, indent + 2)
    sb & "]"
  of vkMap:
    let pad = repeat(' ', indent + 2)
    var sb = if v.mapImmutable: "#{" else: "{"
    for k, p in v.mapEntries:
      sb.add "\n" & pad
      if p.kind == vkBool: sb.add (if p.boolVal: "^^" else: "^!") & propKeyText(k)
      else: sb.add "^" & propKeyText(k) & " " & fmtValue(p, indent + 2 + k.len + 2)
    sb & "}"
  else:
    oneLine(v)

# ---------------------------------------------------------------------------
# Source-unit formatting with comment preservation
# ---------------------------------------------------------------------------

proc emitGap(sb: var string, gap: string, afterForm: bool) =
  ## Preserve comment lines and (single) blank separations from the raw text
  ## between forms. `afterForm`: the first gap line may hold a trailing
  ## comment belonging to the previous form's last line.
  var lines = gap.split('\n')
  if afterForm:
    let tail = lines[0].strip()
    if tail.len > 0:
      sb.add " " & tail
    lines.delete(0)
  var pendingBlank = false
  for idx, line in lines:
    let t = line.strip()
    if t.len == 0:
      # A blank separation survives (collapsed to one blank line). The final
      # fragment is the next form's own line prefix, not a blank line; and
      # leading blanks at the very top of the file are dropped.
      if idx < lines.high:
        pendingBlank = sb.len > 0
    else:
      if sb.len > 0: sb.add "\n"
      if pendingBlank:
        sb.add "\n"
        pendingBlank = false
      sb.add t
  if pendingBlank:
    sb.add "\n"

proc formatSource*(src: string, sourceName = "<fmt>"): string =
  ## Human-friendly formatting of a whole source unit. Raises ReadError on
  ## unparseable input (same contract as the canonical path).
  let unit = readAllWithLocs(src, sourceName)
  let starts = span.lineStarts(src)
  var sourceEnds = initTable[int, int]()
  if unit.wraps.len > 0:
    # Prefix forms have no closing delimiter. The reader-backed index knows
    # their complete operand ranges, including nested prefixes and comments.
    let indexed = indexSource(src, sourceName)
    for form in indexed.topLevel:
      sourceEnds[form.span.startByte] = form.span.endByte
  var sb = ""
  var prevEnd = 0
  for i in 0 ..< unit.forms.len:
    let startOff = span.byteOffset(starts, unit.formLocs[i].line,
                                   unit.formLocs[i].col)
    # formSpan is a heuristic over raw text; degenerate token streams (a bare
    # `^` manifest prop is its own form) can make it overshoot the next
    # form's start. Never slice backwards.
    if startOff > prevEnd:
      emitGap(sb, src[prevEnd ..< startOff], afterForm = i > 0)
    if sb.len > 0:
      # Forms that shared a source line stay on one line (manifest-style
      # `^name "value"` token runs).
      if i > 0 and unit.formLocs[i].line == unit.formLocs[i - 1].line:
        sb.add " "
      else:
        sb.add "\n"
    let endOff = max(sourceEnds.getOrDefault(startOff, formSpan(src, startOff)), startOff)
    if hasInteriorComment(src, startOff + 1, max(endOff - 1, startOff + 1)):
      # Reformatting would delete comments the reader dropped: keep verbatim.
      sb.add src[startOff ..< endOff]
    else:
      sb.add fmtValue(formattingView(unit.forms[i], unit.wraps), 0)
    prevEnd = endOff
  if src.len > prevEnd:
    emitGap(sb, src[prevEnd ..< src.len], afterForm = unit.forms.len > 0)
  if sb.len == 0 or sb[^1] != '\n':
    sb.add "\n"
  sb
