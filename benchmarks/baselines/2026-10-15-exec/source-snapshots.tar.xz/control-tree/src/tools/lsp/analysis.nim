## LSP document analysis for Gene (docs/workflows.md).
##
## Pure functions from source text to LSP-shaped data: parse diagnostics,
## a hierarchical document-symbol tree, and a flat definition index used by
## go-to-definition / hover / workspace-symbol. Uses the real reader
## (`readAllWithLocs`), so positions come from the tokenizer, not regexes:
## `formLocs` positions every top-level form and `locs` positions every
## nested heap value (nodes, lists), which covers all declaration forms.
##
## Coordinate systems: the reader reports 1-based line and 1-based BYTE
## column; LSP wants 0-based line and 0-based UTF-16 code-unit column.
## Conversions live here so the server never sees reader coordinates.

import std/[strutils, tables, unicode]
import ../../gene/[reader, types]
import ../source_positions
import ../source_index as sourceIndex
export source_positions

const
  # LSP SymbolKind constants (the protocol's numeric encoding).
  skModule* = 2
  skNamespace* = 3
  skClass* = 5
  skMethod* = 6
  skEnum* = 10
  skInterface* = 11
  skFunction* = 12
  skVariable* = 13
  skConstructor* = 9
  skEnumMember* = 22
  skObject* = 19

type
  LspRange* = object
    start*: LspPos
    endPos*: LspPos

  LspDiagnostic* = object
    message*: string
    range*: LspRange

  DocSymbol* = object
    name*: string
    detail*: string
    kind*: int
    range*: LspRange          ## whole form
    selectionRange*: LspRange ## the declared name token
    children*: seq[DocSymbol]

  FlatDef* = object
    name*: string
    containerName*: string
    kind*: int
    range*: LspRange
    selectionRange*: LspRange
    signature*: string        ## opening source line(s) through the name, for hover

  DocAnalysis* = object
    parsed*: bool             ## false => parse error; symbols may be empty
    diagnostics*: seq[LspDiagnostic]
    symbols*: seq[DocSymbol]

# ---------------------------------------------------------------------------
# Raw-text scanning (form extents and name tokens). The scanner respects the
# reader's lexical surface: line comments (# ...), nested block comments
# (#< ... >#), strings ("...", """...""", $"..."), and regex literals (#"...").
# ---------------------------------------------------------------------------

proc skipString(src: string, start: int): int =
  ## `start` is at the opening quote. Returns the offset just past the close.
  var i = start
  if src.continuesWith("\"\"\"", i):
    i += 3
    while i < src.len:
      if src.continuesWith("\"\"\"", i):
        return i + 3
      inc i
    return src.len
  inc i
  while i < src.len:
    case src[i]
    of '\\':
      i += 2
    of '"':
      return i + 1
    else:
      inc i
  src.len

const symbolStop = {'(', ')', '[', ']', '{', '}', ' ', '\t', '\n', '\r',
                    ',', ';', '"', '\'', '`', '#'}

proc charLiteralEnd(src: string, start: int): int =
  ## `start` is at a `'`. Gene's `'` exclusively introduces a char literal
  ## ('a', '\n', '\u{1F600}'). Returns the offset just past the closing
  ## quote, or -1 when this is not a well-formed char literal.
  var i = start + 1
  if i >= src.len or src[i] in {'\n', '\r', '\''}:
    return -1
  if src[i] == '\\':
    inc i
    var guard = 0
    while i < src.len and guard < 12:
      if src[i] == '\'':
        return i + 1
      if src[i] in {'\n', '\r'}:
        return -1
      inc i
      inc guard
    return -1
  i += runeLenAt(src, i)
  if i < src.len and src[i] == '\'':
    return i + 1
  -1

proc hashBytesLiteralEnd*(src: string, start: int): int =
  ## `start` is at a `#`. Recognizes the #B# / #B16# / #B64# byte literals
  ## (src/gene/reader.nim tryScanHashBytesLexeme). Returns the offset past
  ## the token, or -1 when this is not a bytes literal. Without this, the
  ## leading `#` of a byte literal would read as a reserved form and the raw
  ## scanner would swallow the rest of the line, corrupting form ranges.
  if start + 1 >= src.len or src[start] != '#' or src[start + 1] != 'B':
    return -1
  var prefix = '\0'
  var bodyStart = 0
  if start + 3 < src.len and src[start + 2] == '#':
    prefix = '!'
    bodyStart = start + 3
  elif start + 5 < src.len and src[start + 2] == '1' and
       src[start + 3] == '6' and src[start + 4] == '#':
    prefix = 'x'
    bodyStart = start + 5
  elif start + 5 < src.len and src[start + 2] == '6' and
       src[start + 3] == '4' and src[start + 4] == '#':
    prefix = '#'
    bodyStart = start + 5
  else:
    return -1
  let digitOk =
    case prefix
    of '!': src[bodyStart] in {'0', '1'}
    of 'x': src[bodyStart] in {'0'..'9', 'a'..'f', 'A'..'F'}
    of '#': src[bodyStart] in {'A'..'Z', 'a'..'z', '0'..'9', '+', '/', '='}
    else: false
  if not digitOk:
    return -1
  var i = bodyStart + 1
  while i < src.len:
    let c = src[i]
    let isDigit =
      case prefix
      of '!': c in {'0', '1'}
      of 'x': c in {'0'..'9', 'a'..'f', 'A'..'F'}
      of '#': c in {'A'..'Z', 'a'..'z', '0'..'9', '+', '/', '='}
      else: false
    if isDigit:
      inc i
    elif c == '~':
      inc i
      while i < src.len and src[i] in {' ', '\t', '\r', '\n'}:
        inc i
      if i >= src.len:
        return -1   # dangling continuation: error-tolerant
    else:
      return i
  i

proc skipCommentOrAtom(src: string, i: var int): bool =
  ## If `i` sits at a comment or string-ish atom (strings, regexes, char and
  ## bytes literals), advance past it and return true. Otherwise leave `i`
  ## alone and return false.
  if i >= src.len:
    return false
  case src[i]
  of '"':
    i = skipString(src, i)
    true
  of '$':
    if i + 1 < src.len and src[i + 1] == '"':
      i = skipString(src, i + 1)
      true
    else:
      false
  of '\'':
    let e = charLiteralEnd(src, i)
    if e > 0:
      i = e
      true
    else:
      false
  of '#':
    if i + 1 < src.len:
      case src[i + 1]
      of 'B':
        let e = hashBytesLiteralEnd(src, i)
        if e > 0:
          i = e
          true
        else:
          # Reserved '#B…' forms are read errors in the reader; this raw
          # scanner stays error-tolerant and skips them like comments.
          while i < src.len and src[i] != '\n':
            inc i
          true
      of '"':
        i = skipString(src, i + 1)
        true
      of '<':
        var depth = 1
        i += 2
        while i < src.len and depth > 0:
          if src.continuesWith("#<", i):
            inc depth; i += 2
          elif src.continuesWith(">#", i):
            dec depth; i += 2
          else:
            inc i
        true
      of '(', '[', '{', '_', '@':
        false   # delimiter or reader prefix, not a line comment
      else:
        # Whitespace/'!' continuations are real line comments. Reserved '#'
        # forms are read errors in the reader; this raw scanner stays
        # error-tolerant and skips them like comments so span math survives
        # invalid buffers (diagnostics come from the real reader).
        while i < src.len and src[i] != '\n':
          inc i
        true
    else:
      i = src.len
      true
  else:
    false

proc matchingCloseOffset*(src: string, openOffset: int): int =
  ## Balanced scan from an opening (/[/{ to just past its matching close.
  ## Returns src.len when unbalanced (open form at EOF).
  if src.continuesWith("#@", openOffset):
    let indexed = sourceIndex.indexSource(src[openOffset .. ^1])
    if indexed.topLevel.len > 0:
      return openOffset + indexed.topLevel[0].span.endByte
    return src.len
  var i = openOffset
  var depth = 0
  while i < src.len:
    if skipCommentOrAtom(src, i):
      continue
    case src[i]
    of '(', '[', '{':
      inc depth
      inc i
    of ')', ']', '}':
      dec depth
      inc i
      if depth <= 0:
        return i
    else:
      inc i
  src.len

proc tokenEnd(src: string, start: int): int =
  var i = start
  while i < src.len and src[i] notin symbolStop:
    inc i
  if i == start and i < src.len:
    inc i   # single delimiter char
  i

proc nextTokenStart(src: string, start: int): int =
  ## Skip whitespace, commas, and comments; return the next token offset.
  ## Datum comments (`#_ datum`) are spacing per reader semantics: the marker
  ## AND its following datum are skipped, and runs of `#_` stack — so
  ## `(fn #_ old actual [x] ...)` locates `actual` as the declared name.
  var i = start
  var discards = 0
  while i < src.len:
    case src[i]
    of ' ', '\t', '\r', '\n', ',':
      inc i
      continue
    of '#':
      if i + 1 < src.len and src[i + 1] == '_':
        inc discards
        i += 2
        continue
      var j = i
      if skipCommentOrAtom(src, j) and j > i and
          (i + 1 >= src.len or src[i + 1] notin {'(', '[', '{'}):
        i = j
        continue
    else:
      var j = i
      if skipCommentOrAtom(src, j) and j > i and discards > 0:
        # A string/char/bytes atom being discarded by a pending #_.
        i = j
        dec discards
        continue
    # A real token starts here.
    if discards == 0:
      return i
    # Discard one datum, like the reader's parseForm would consume it:
    # quasiquote/unquote prefixes attach to the following form (`old is ONE
    # datum), then a bracketed form (including #(/#[/#{ literals) or a
    # single atom.
    while i < src.len and src[i] in {'`', '%'}:
      inc i
      while i < src.len and src[i] in {' ', '\t', '\r', '\n', ','}:
        inc i
    if i >= src.len:
      break
    if src.continuesWith("#@", i):
      i = matchingCloseOffset(src, i)
    elif src[i] in {'(', '[', '{'} or
        (src[i] == '#' and i + 1 < src.len and src[i + 1] in {'(', '[', '{'}):
      i = matchingCloseOffset(src, i)
    else:
      var j = i
      if skipCommentOrAtom(src, j) and j > i:
        i = j
      else:
        i = tokenEnd(src, i)
    dec discards
  src.len

proc formEnd(src: string, start: int): int =
  if start >= src.len: return src.len
  if src[start] in {'(', '[', '{'} or src.continuesWith("#@", start) or
      (src[start] == '#' and start + 1 < src.len and src[start + 1] in {'(', '[', '{'}):
    return matchingCloseOffset(src, start)
  var last = start
  if skipCommentOrAtom(src, last): return last
  tokenEnd(src, start)

proc afterDeclarationProperties(src: string, start: int): int =
  result = nextTokenStart(src, start)
  while result < src.len and src[result] in {'^', '@'}:
    let sugar = src.continuesWith("^^", result) or src.continuesWith("^!", result)
    result = nextTokenStart(src, tokenEnd(src, result))
    if not sugar:
      result = nextTokenStart(src, formEnd(src, result))

proc nameSelectionRange(src: string, starts: seq[int],
                        formOffset: int): LspRange =
  ## The token after the head symbol — the declared name — as an LSP range.
  ## Falls back to the head token when the form has no name.
  var i = formOffset
  if src.continuesWith("#@", i):
    i += 2
  elif i < src.len and src[i] == '(':
    inc i
  let headStart = nextTokenStart(src, i)
  let headEnd = tokenEnd(src, headStart)
  var nameStart = afterDeclarationProperties(src, headEnd)
  var nameEnd = tokenEnd(src, nameStart)
  if nameStart >= src.len or src[nameStart] in {'(', '[', '{', ')'}:
    nameStart = headStart
    nameEnd = headEnd
  LspRange(start: offsetToLspPos(src, starts, nameStart),
           endPos: offsetToLspPos(src, starts, nameEnd))

proc findTokenRange(src: string, starts: seq[int],
                    fromOffset, toOffset: int, word: string): LspRange =
  ## First standalone occurrence of `word` inside [fromOffset, toOffset).
  ## Zero range at fromOffset when not found.
  var i = fromOffset
  while i < toOffset and i < src.len:
    if skipCommentOrAtom(src, i):
      continue
    if src[i] in symbolStop:
      inc i
      continue
    let e = tokenEnd(src, i)
    if src[i ..< e] == word:
      return LspRange(start: offsetToLspPos(src, starts, i),
                      endPos: offsetToLspPos(src, starts, e))
    i = e
  let p = offsetToLspPos(src, starts, fromOffset)
  LspRange(start: p, endPos: p)

# ---------------------------------------------------------------------------
# Symbol extraction from parsed forms
# ---------------------------------------------------------------------------

proc symName(v: Value): string =
  if v.kind == vkSymbol: v.symVal else: ""

proc signatureSource(src: string, starts: seq[int],
                     r, name: LspRange, generator = false): string =
  ## Usually the opening line. A #@ declaration can put its head or name on
  ## later lines; include those too, without including adjacent declarations.
  let first = lspPosToOffset(src, starts, r.start)
  if generator:
    let params = afterDeclarationProperties(src, lspPosToOffset(src, starts, name.endPos))
    if params < src.len and src[params] == '[':
      var last = afterDeclarationProperties(src, matchingCloseOffset(src, params))
      let colon = last
      if colon < src.len and src[colon] == ':':
        last = afterDeclarationProperties(src,
          formEnd(src, nextTokenStart(src, colon + 1)))
      result = src[first ..< min(last, lspPosToOffset(src, starts, r.endPos))].strip()
      if "^generator" notin result:
        # Properties may appear after executable forms in an unformatted
        # buffer. Still expose the parsed declaration's execution kind.
        let head = nextTokenStart(src, first + (if src.continuesWith("#@", first): 2 else: 1))
        result.insert(" ^^generator", tokenEnd(src, head) - first)
      return
  let lastLine = max(r.start.line, name.endPos.line)
  let lineEnd = starts[lastLine] + lineSlice(src, starts, lastLine).len
  let last = min(lineEnd, lspPosToOffset(src, starts, r.endPos))
  src[first ..< max(first, last)].strip()

proc formRange(src: string, starts: seq[int], loc: SourceLoc): LspRange =
  let startOff = byteOffset(starts, loc.line, loc.col)
  let endOff = matchingCloseOffset(src, startOff)
  LspRange(start: offsetToLspPos(src, starts, startOff),
           endPos: offsetToLspPos(src, starts, endOff))

proc declFromNode(form: Value, loc: SourceLoc, unit: SourceUnit,
                  src: string, starts: seq[int]): seq[DocSymbol]

proc childDecls(parentForm: Value, unit: SourceUnit,
                src: string, starts: seq[int]): seq[DocSymbol] =
  ## Nested declarations (message/ctor/impl inside type/protocol bodies,
  ## anything inside ns bodies). Nested nodes carry entries in unit.locs.
  for item in parentForm.body:
    if item.kind != vkNode:
      continue
    let loc = unit.locs.getOrDefault(item.bits)
    if not loc.hasSourceLoc:
      continue
    result.add declFromNode(item, loc, unit, src, starts)

proc declFromNode(form: Value, loc: SourceLoc, unit: SourceUnit,
                  src: string, starts: seq[int]): seq[DocSymbol] =
  if form.kind != vkNode or form.head.kind != vkSymbol:
    return
  let headName = form.head.symVal
  let range = formRange(src, starts, loc)
  let startOff = byteOffset(starts, loc.line, loc.col)
  let body = form.body

  proc named(kind: int, name: string, detail = ""): DocSymbol =
    DocSymbol(name: name, detail: detail, kind: kind, range: range,
              selectionRange: nameSelectionRange(src, starts, startOff))

  case headName
  of "fn", "macro":
    if body.len > 0 and body[0].kind == vkSymbol:
      let flag = form.props.getOrDefault("generator", NIL)
      result.add named(skFunction, body[0].symVal,
        if headName != "fn": headName
        elif flag.kind == vkBool and flag.boolVal: "generator"
        else: "")
  of "var":
    if body.len > 0 and body[0].kind == vkSymbol:
      result.add named(skVariable, body[0].symVal)
  of "type":
    if body.len > 0 and body[0].kind == vkSymbol:
      var sym = named(skClass, body[0].symVal)
      sym.children = childDecls(form, unit, src, starts)
      result.add sym
  of "enum":
    if body.len > 0 and body[0].kind == vkSymbol:
      var sym = named(skEnum, body[0].symVal)
      let endOff = matchingCloseOffset(src, startOff)
      for i in 1 ..< body.len:
        case body[i].kind
        of vkSymbol:
          # Unit variants are bare symbols with no loc entry: find the token.
          let r = findTokenRange(src, starts, startOff + 1, endOff,
                                 body[i].symVal)
          sym.children.add DocSymbol(name: body[i].symVal, kind: skEnumMember,
                                     range: r, selectionRange: r)
        of vkNode:
          # Tuple variants are nodes: (ok Any)
          if body[i].head.kind == vkSymbol:
            let vloc = unit.locs.getOrDefault(body[i].bits)
            if vloc.hasSourceLoc:
              let vr = formRange(src, starts, vloc)
              sym.children.add DocSymbol(name: body[i].head.symVal,
                                         kind: skEnumMember, range: vr,
                                         selectionRange: vr)
        else:
          discard
      result.add sym
  of "protocol":
    if body.len > 0 and body[0].kind == vkSymbol:
      var sym = named(skInterface, body[0].symVal)
      sym.children = childDecls(form, unit, src, starts)
      result.add sym
  of "impl":
    # (impl P for T body...) or inline (impl P body...) inside a type
    var name = "impl"
    if body.len > 0 and body[0].kind == vkSymbol:
      name = "impl " & body[0].symVal
      if body.len > 2 and symName(body[1]) == "for" and
          body[2].kind == vkSymbol:
        name.add " for " & body[2].symVal
    var sym = named(skObject, name)
    sym.children = childDecls(form, unit, src, starts)
    result.add sym
  of "message":
    if body.len > 0 and body[0].kind == vkSymbol:
      let flag = form.props.getOrDefault("generator", NIL)
      result.add named(skMethod, body[0].symVal,
        if flag.kind == vkBool and flag.boolVal: "generator" else: "")
  of "ctor":
    result.add named(skConstructor, "ctor")
  of "ns":
    if body.len > 0 and body[0].kind == vkSymbol:
      var sym = named(skNamespace, body[0].symVal)
      sym.children = childDecls(form, unit, src, starts)
      result.add sym
  of "mod":
    if body.len > 0 and body[0].kind == vkSymbol:
      result.add named(skModule, body[0].symVal)
  else:
    discard

proc analyze*(src: string, sourceName = "<lsp>"): DocAnalysis =
  ## Parse and extract diagnostics + document symbols. A parse error yields
  ## one diagnostic and no symbols (callers keep the last good symbol tree).
  let starts = lineStarts(src)
  try:
    let unit = readAllWithLocs(src, sourceName)
    result.parsed = true
    for i in 0 ..< unit.forms.len:
      result.symbols.add declFromNode(unit.forms[i], unit.formLocs[i], unit,
                                      src, starts)
  except ReadError as e:
    let start = toLspPos(src, starts, e.line, e.col)
    result.parsed = false
    result.diagnostics.add LspDiagnostic(
      message: e.msg,
      range: LspRange(start: start,
                      endPos: LspPos(line: start.line,
                                     character: start.character + 1)))

proc flattenDefs*(symbols: seq[DocSymbol], src: string,
                  container = ""): seq[FlatDef] =
  ## Flatten a symbol tree into the definition index used by definition,
  ## hover, and workspace/symbol.
  let starts = lineStarts(src)
  for s in symbols:
    result.add FlatDef(name: s.name, containerName: container, kind: s.kind,
                       range: s.range, selectionRange: s.selectionRange,
                       signature: signatureSource(src, starts, s.range,
                                                  s.selectionRange,
                                                  s.detail == "generator"))
    result.add flattenDefs(s.children, src, s.name)

proc wordAt*(src: string, starts: seq[int], pos: LspPos): string =
  ## The symbol token under an LSP position. Slash paths yield the segment
  ## under the cursor; leading quote/property sigils are stripped.
  let line = lineSlice(src, starts, pos.line)
  if line.len == 0:
    return ""
  var col = utf16ColToByte(line, pos.character)
  if col >= line.len:
    col = line.len - 1
  # #@ is its own reader token, including when glued to the head. Neither
  # byte of the marker names the callable (or the preceding adjacent form).
  if (line[col] == '#' and col + 1 < line.len and line[col + 1] == '@') or
      (line[col] == '@' and col > 0 and line[col - 1] == '#'):
    return ""
  if line[col] in symbolStop:
    if col > 0 and line[col - 1] notin symbolStop:
      dec col
    else:
      return ""
  var first = col
  while first > 0 and line[first - 1] notin symbolStop:
    dec first
  var last = col
  while last < line.len and line[last] notin symbolStop:
    inc last
  var word = line[first ..< last]
  # Segment under the cursor for slash paths (a/b/c): compute both segment
  # boundaries against the ORIGINAL word, then slice once — slicing early and
  # indexing with stale offsets was an out-of-bounds Defect on 3+ segments.
  if '/' in word:
    let rel = min(max(col - first, 0), word.len - 1)
    var segStart = 0
    var segEnd = word.len
    for i in 0 ..< word.len:
      if word[i] == '/':
        if i >= rel:
          segEnd = i
          break
        segStart = i + 1
    if segStart <= segEnd:
      word = word[segStart ..< segEnd]
  # The reader expands $name to gene/name. Like other paths, lookup uses
  # the member name, including when the source spells it #@$name.
  while word.len > 0 and word[0] in {'\'', '^', '%', '@', '$'}:
    word = word[1 .. ^1]
  word
