## AST-to-GIR compiler for the MVP execution surface.

import std/[algorithm, monotimes, os, sets, strutils, tables, times]
import ./[equality, gir, printer, reader, types]
import ./error_analysis
export gir.MacroDef, gir.MacroDefault, gir.MacroParam, gir.MacroNamedParam

type
  CompileBudget* = ref object
    remaining*: int64
    runtimeBudget*: EvalBudget # shared counter while executable macro bodies run
    hasDeadline*: bool
    deadline*: MonoTime
    hasMemoryLimit*: bool
    memoryBaseline*: int64
    memoryLimitBytes*: int64
    sampleCountdown*: int

  MacroExecutionSession* = ref object
    runtimeState*: RootRef
    compilerState: RootRef
    hostContext*: RootRef
    rootContext*: MacroDefinitionContext
    expansionDepth*: int
    runtimeDefinitionScope*: Scope # transient, only while matching runtime defaults

  MacroEvaluator* = proc(definition: MacroDef, bindings: Table[string, Value],
                         session: MacroExecutionSession,
                         budget: CompileBudget): Value {.nimcall, gcsafe.}

  KnownFunctionSig = object
    arity: int
    returnType: Value

  StaticWildcardCandidate = object
    importKey: string   # gir.importKey: `^pkg`-aware module dependency key
    exportPath: seq[string]
    category: CompileBindingCategory
    sourceLabel: string

  StaticAliasInterface = object
    importKey: string
    exportPrefix: seq[string]
    namespace: CompileNamespaceInterface

  Compiler = object
    chunk: Chunk
    sourceName: string
    # Source positions are immutable compiler input. Child compilers share the
    # table instead of deep-copying every SourceLoc (and its source-name
    # string) for each function and scoped body.
    sourceLocs: ref Table[uint64, SourceLoc]
    formLocs: seq[SourceLoc]
    # The unit's own text and top-level extents, carried only so an embedded
    # `web_module` block can be quoted back verbatim for its client-only
    # source map. Nothing else reads them.
    unitSource: string
    currentFormIndex: int
    currentLoc: SourceLoc
    selfAvailable: bool
    seenModDecl: bool
    allowYield: bool
    generatorFnNames: Table[string, bool]
    sawNonVoidReturn: bool
    # Enclosing function is declared `: Nil` or `: Void`, so `return` may not
    # carry a value (design.md §7.7). Per-function: a child compiler is built
    # fresh for each `fn`, so this never leaks into a nested one.
    inStatementFn: bool
    inFunction: bool
    inGenerator: bool
    loopDepth: int
    repeatBindings: bool # shared-scope chunks reentered by an enclosing loop
    gensym: ref int   # shared with child compilers; see nextGensym
    useLocalSlots: bool
    localSlots: Table[string, int]
    fastLocalLoads: Table[string, int]
    localTypes: Table[string, Value]
    localFunctionSigs: Table[string, KnownFunctionSig]
    localNames: seq[string]
    inlineBlockPrefix: string
    inlineBlockBindings: HashSet[string]
    parentSlots: seq[Table[string, int]]
    parentFunctionSigs: seq[Table[string, KnownFunctionSig]]
    ffiLibraryNames: Table[string, bool]
    macros: Table[string, MacroDef]
    ownMacroNames: HashSet[string] # definitions/imports in this lexical scope
    ownValueNames: HashSet[string]
    publicMacroNames: HashSet[string]
    macroContext: MacroDefinitionContext
    macroSession: MacroExecutionSession
    macroPhaseCompilation: bool
    dynamicNameLookup: bool # runtime-generated code resolves live caller bindings
    compiledMacroResults: Table[uint64, Value]
    repeatedMacroSites: HashSet[uint64]
    hasMacros: bool
    macroExpansionDepth: int
    allowAmbientImports: bool
    # Cross-module macros (design §11/§15): the module loader pre-loads each
    # top-level `^from "path"` dependency and hands us its macro exports keyed
    # by the raw path string as written in the source. Selections that name a
    # macro are spliced into `macros` at compile time and recorded here so
    # they are not re-exported and not looked up as runtime bindings.
    importedMacroSets: Table[string, Table[string, MacroDef]]
    importedMacroNames: HashSet[string]
    # Names proven to hold ordinary fn values in the current compilation flow.
    # Dynamic parameters/Any bindings are deliberately absent and use the
    # general eager-call path.
    ordinaryFnNames: Table[string, bool]
    # A whole-unit conservative prepass records every syntactic `set` target.
    # A name in this set is not a stable callable proof, including when the
    # mutation appears after a closure that captures the binding.
    mutableBindingNames: HashSet[string]
    # Names bound with `let`/`const` (or a named declaration) in the current
    # lexical scope (design §12.1). A `set` targeting one is a compile error.
    # childCompiler copies the set so a nested `var` shadows an outer `let`
    # without un-marking the outer.
    letNames: HashSet[string]
    # Scalar `let` constants, for typed_native lowering. A numeric kernel names
    # its magic numbers — `(let two32 4294967296.0)` — and a lowered body has
    # no way to *read* a module binding, so without this every such function
    # fell back to the interpreter for want of a constant the compiler already
    # had in its hand.
    #
    # A name bound twice to different values is poisoned with `NIL` rather than
    # resolved, so shadowing loses the optimization instead of substituting the
    # wrong number.
    aotConstants: Table[string, Value]
    # design §12.1's `const` values, for use-site folding. Separate from
    # `aotConstants`, which also holds scalar `let`s and is poisoned on
    # conflict: only a `const` is guaranteed to resolve before runtime, so
    # only a `const` may be substituted at a use site.
    constValues: Table[string, Value]
    # Every name this compiler has bound, slots or not. `localSlots` is empty
    # when a body compiles without slots, so it cannot answer "is this name a
    # binding?"; this set can. It is never pruned on scope exit, which biases
    # the bare-name lint toward under-reporting — a missed site is caught later
    # as an undefined symbol, whereas a false positive would silently rewrite a
    # local into a standard-library reference.
    declaredNames: HashSet[string]
    # Inside a message/ctor body the receiver `self` is reserved: no nested
    # binder may shadow it, so a leading send `(.m)` always means the original
    # receiver (design §10). Inherited by every descendant compiler.
    selfReserved: bool
    # While compiling a type-direct message body, the enclosing type's name, so
    # `(super .m)` resolves it to the type value then its nominal parent at send
    # time (design §10). NIL outside a message body with a parent.
    superType: Value
    importedSyntaxFnSets: Table[string, seq[string]]
    importedInterfaces: Table[string, CompileNamespaceInterface]
    ownCompileInterface: CompileNamespaceInterface
    ## Compile interfaces of the enclosing `ns` levels, innermost first. A
    ## child compiler inherits `ownCompileInterface` unchanged — it is the
    ## module root — so without this a namespace body cannot see its own
    ## declarations, and a function preceding its namespace-local native Type
    ## compiled with no native representation at all.
    localCompileInterfaces: seq[CompileNamespaceInterface]
    importedCompileEntries: Table[string, CompileInterfaceEntry]
    wildcardCandidates: Table[string, seq[StaticWildcardCandidate]]
    aliasInterfaces: Table[string, StaticAliasInterface]
    parameterAliases: Table[string, Value]
    declaredUnitNames: HashSet[string]
    preparedUnitNames: ref HashSet[string] # immutable source-context prepass
    namespacePath: seq[string]
    moduleMacroExports: ref Table[string, MacroDef]
    moduleSyntaxFnExports: ref HashSet[string]
    # Functions whose call scope only their closures keep from pooling;
    # planClosureCaptures decides them once every plan is known.
    closurePoolCandidates: ref seq[FunctionProto]
    # Exact impl-form nodes that are unconditional static module/namespace
    # declarations. Nested control-flow and callable bodies are absent.
    staticTopLevelImpls: HashSet[uint64]
    ## Message names declared by overlay-only impls anywhere in this unit.
    ## Collected up front so the check does not depend on compilation order.
    overlayImplMessages: HashSet[string]
    budget: CompileBudget
    deferErrorChecks: bool
    errorModeOverride: string

  MacroCompilerPreparation = ref object of RootObj
    context: MacroDefinitionContext
    compileInterface: CompileNamespaceInterface
    declaredNames: ref HashSet[string]
    importedEntries: Table[string, CompileInterfaceEntry]
    wildcards: Table[string, seq[StaticWildcardCandidate]]
    aliases: Table[string, StaticAliasInterface]

  MacroCompilerState = ref object of RootObj
    preparations: Table[tuple[context: pointer, path: seq[string]], MacroCompilerPreparation]
    runtimePreparations: Table[pointer, tuple[context: MacroDefinitionContext,
      cache: CompilerPreparationCache]]

  ParamSpecs = object
    positional: seq[string]
    positionalTypes: seq[Value]
    positionalDefaults: seq[ParamDefault]
    rest: string
    restType: Value
    named: seq[NamedParam]

  ParamAdornment = object
    typeExpr: Value
    defaultValue: ParamDefault

  ExpansionProvenance* = object
    ## Provenance for a container created by template expansion. `sourceLoc`
    ## is the call site shown to users; `macroName` is diagnostic context.
    sourceLoc*: SourceLoc
    macroName*: string

  ExpandedSourceUnit* = object
    ## The shared front-end artifact. The original tree remains available to
    ## formatters/LSP consumers while `expanded` is consumed by semantic
    ## backends. Both trees are immutable inputs owned by this value.
    original*: SourceUnit
    expanded*: SourceUnit
    provenance*: Table[uint64, ExpansionProvenance]
    macroExports*: Table[string, MacroDef]
    macroRuntimeLease*: RootRef # released last by `=destroy` below

proc `=destroy`(unit: var ExpandedSourceUnit) =
  ## As for Chunk: expanded runtime Values must be gone before the lease's
  ## destructor tries to retire their definition phase, whatever field order
  ## the Nim release uses.
  for name, field in fieldPairs(unit):
    when name != "macroRuntimeLease":
      `=destroy`(field)
  `=destroy`(unit.macroRuntimeLease)

# The VM installs this immutable dispatch hook to avoid a compiler/VM import
# cycle. Reentrant compilation during a macro invocation shares its session.
var macroEvaluator*: MacroEvaluator
var activeMacroSession* {.threadvar.}: MacroExecutionSession
var activeMacroHostContext* {.threadvar.}: RootRef

proc unitDeclares(c: Compiler, name: string): bool =
  name in c.declaredUnitNames or
    (c.preparedUnitNames != nil and name in c.preparedUnitNames[])

proc macroCompilerState(session: MacroExecutionSession): MacroCompilerState =
  if session.compilerState == nil:
    session.compilerState = MacroCompilerState()
  MacroCompilerState(session.compilerState)

proc newCompileBudget*(maxSteps, maxMemoryMb, timeoutMs: int64): CompileBudget =
  if maxSteps < 0 and maxMemoryMb < 0 and timeoutMs < 0:
    return nil
  result = CompileBudget(
    remaining: if maxSteps < 0: high(int64) else: maxSteps)
  if timeoutMs >= 0:
    result.hasDeadline = true
    result.deadline = getMonoTime() + initDuration(milliseconds = timeoutMs)
  if maxMemoryMb >= 0:
    if maxMemoryMb > high(int64) div (1024 * 1024):
      raise newException(GeneError, "compile memory limit is too large")
    result.hasMemoryLimit = true
    result.memoryBaseline = getOccupiedMem().int64
    result.memoryLimitBytes = maxMemoryMb * 1024 * 1024

proc consumeCompileStep(budget: CompileBudget) =
  if budget == nil:
    return
  if budget.runtimeBudget != nil:
    var current = budget.runtimeBudget
    while current != nil:
      if current.remaining <= 0:
        raise newException(GeneError, "compile max steps exceeded")
      if current.hasDeadline or current.hasMemoryLimit:
        if current.sampleCountdown <= 0:
          current.sampleCountdown = 64
          if current.hasDeadline and getMonoTime() >= current.deadline:
            raise newException(GeneError, "compile timeout exceeded")
          if current.hasMemoryLimit and getOccupiedMem().int64 -
              current.memoryBaseline > current.memoryLimitBytes:
            raise newException(GeneError, "compile memory limit exceeded")
        else:
          dec current.sampleCountdown
      dec current.remaining
      current = current.parent
    budget.remaining = budget.runtimeBudget.remaining
    return
  if budget.remaining <= 0:
    raise newException(GeneError, "compile max steps exceeded")
  if budget.hasDeadline or budget.hasMemoryLimit:
    if budget.sampleCountdown <= 0:
      budget.sampleCountdown = 64
      if budget.hasDeadline and getMonoTime() >= budget.deadline:
        raise newException(GeneError, "compile timeout exceeded")
      if budget.hasMemoryLimit and
          getOccupiedMem().int64 - budget.memoryBaseline >
            budget.memoryLimitBytes:
        raise newException(GeneError, "compile memory limit exceeded")
    else:
      dec budget.sampleCountdown
  dec budget.remaining

proc parseImportSpec*(node: Value): ImportSpec

const MaxMacroExpansionDepth* = 100

const CoreSpecialFormNames* = [
  "do", "if", "if_yes", "if_not", "&&", "||", "??", "!",
  "let", "var", "const", "set", "new",
  "fn", "macro", "quote", "quasiquote", "Path", "path", "msg", "ns",
  "env", "eval", "import", "mod", "match", "while", "loop", "repeat",
  "for", "break", "continue", "yield", "return", "try", "scope",
  "supervisor", "spawn", "await", "fail", "panic", "type", "alias", "enum",
  "protocol", "impl", "derive", "import_impl", "web_module"
]

proc emit(c: var Compiler, op: OpCode, intArg = 0, name = "",
          depth = 0,
          names: seq[string] = @[], flag = false, tail = false): int =
  c.chunk.emit(Instruction(op: op, intArg: intArg, depth: depth,
                           name: name, names: names, flag: flag, tail: tail),
               c.currentLoc)

proc callOpForArity(argCount: int): OpCode =
  case argCount
  of 0: opCall0
  of 1: opCall1
  of 2: opCall2
  else: opCall

proc emitPlainCall(c: var Compiler, argCount: int, tail = false): int =
  let op = callOpForArity(argCount)
  c.emit(op, argCount, tail = tail)

proc hasStableSourceIdentity(v: Value): bool =
  v.kind in {vkList, vkMap, vkSet, vkHashMap, vkNode, vkPipeline}

proc sourceLocFor(c: Compiler, v: Value): SourceLoc =
  if c.sourceLocs != nil and v.hasStableSourceIdentity and
      c.sourceLocs[].hasKey(v.bits):
    return c.sourceLocs[][v.bits]
  if v.kind == vkNode:
    let line = v.meta.getOrDefault("line", NIL)
    let col = v.meta.getOrDefault("col", NIL)
    let source = v.meta.getOrDefault("source", NIL)
    if line.kind == vkInt and col.kind == vkInt:
      return SourceLoc(sourceName: if source.kind == vkString: source.strVal else: "",
                       line: int(line.intVal), col: int(col.intVal))
  c.currentLoc

proc sharedSourceLocs(locs: Table[uint64, SourceLoc]):
    ref Table[uint64, SourceLoc] =
  new(result)
  result[] = locs

proc enableLocalSlots(c: var Compiler) =
  c.useLocalSlots = true
  c.localSlots = initTable[string, int]()
  c.fastLocalLoads = initTable[string, int]()
  c.localTypes = initTable[string, Value]()
  c.localFunctionSigs = initTable[string, KnownFunctionSig]()
  c.localNames = @[]

const reservedStdlibRoots = ["gene", "genex", "geney", "genez"]

# `$err` reads as `(path gene err)`, so it cannot collide with an ordinary
# lexical binding. Catch bodies reserve this otherwise-unspellable slot and
# `compilePath` lowers the special path to that slot. Nested bodies capture it
# through the ordinary parent-slot machinery; outside a catch it remains an
# invalid use rather than a mutable global exception cell.
const CatchErrorBindingName = "$err"

# `~` and `?~` are canonical send markers produced by the reader's dot-syntax
# lowering. Generated AST may contain them, but they may not be bound, set, or
# declared as names.
# `Self` is the receiver's own type in annotation position and the reserved
# value spelling for a type-direct message (`Self:msg`, design §3). Like
# `super` it denotes rather than binds, so a program may not declare it.
const reservedOperatorNames = ["~", "?~", "super", "Self"]

const bareOperatorNames* = [
  # Operators are a closed, language-defined set (design §2.2): a program is not
  # expected to declare them, so pre-binding them costs no name and `($+ 1 2)`
  # would be noise. (Binding one is still accepted today and shadows it, as for
  # any other name.) `//` is the remainder (§7.4).
  # `|` builds a union type expression (design §7.4.1). It is already language
  # syntax in annotation and pattern position, so pre-binding it is what makes
  # `(| A B)` mean one thing everywhere rather than only where a type is
  # expected.
  "+", "-", "*", "/", "//", "<", "<=", ">", ">=", "==", "!=", "|",
]

const bareCoreNames* = [
  # Language-level words rather than library functions. `panic` is the
  # unrecoverable-failure mechanism §9 reserves, and `not`/`same?` are spelled
  # forms of primitive operations (`!` and identity). Deliberately short: every
  # entry here is a name a program can no longer use freely.
  "panic", "not", "same?",
]

proc staysBare*(name: string): bool =
  ## Which names the lexical root keeps when the standard library moves under
  ## the `gene` root (design §2.1). Case is the rule: an uppercase name is a
  ## *type* — a type surface, an error type, or a type's message namespace — and
  ## stays bare because annotations resolve type names structurally, so
  ## `[xs : List]` must keep working. A lowercase name is a library function or
  ## namespace and is reached as `$x`.
  ##
  ## The VM prunes the root with this predicate and the compiler's bare-name
  ## lint reports against it, so both must read the same list.
  if name.len == 0: return false
  if name[0] in {'A'..'Z'}: return true
  name in bareOperatorNames or name in bareCoreNames or
    name in reservedStdlibRoots

proc validateDeclarationCase(kind, name: string) =
  ## Case marks the kind (design §2.1): a type, protocol, or enum is uppercase;
  ## a namespace is lowercase. Enforced on user declarations so the rule the
  ## standard library follows is the rule the language states.
  if name.len == 0 or name[0] == '_':
    return
  let upper = name[0] in {'A'..'Z'}
  if kind == "ns":
    if upper:
      raise newException(GeneError,
        "namespace '" & name & "' must start lowercase; uppercase names are " &
        "types and protocols (design §2.1)")
  elif not upper:
    raise newException(GeneError,
      kind & " '" & name & "' must start uppercase; lowercase names are " &
      "namespaces and functions (design §2.1)")

proc validateBindingName(name: string, allowFexprName = false) =
  if name in reservedStdlibRoots:
    raise newException(GeneError,
      "reserved standard-library root cannot be bound: " & name)
  if name in reservedOperatorNames:
    raise newException(GeneError,
      "'" & name & "' is reserved (send operator / super receiver / Self) " &
      "and cannot be bound (design §3/§10)")
  if name.len > 1 and name.endsWith("!") and not allowFexprName:
    raise newException(GeneError,
      "only a named fexpr may bind a name ending in !: " & name)

proc reserveLocal(c: var Compiler, name: string,
                  allowFexprName = false, importing = false): int =
  validateBindingName(name, allowFexprName)
  # `self` is the compiler-owned receiver and is reserved throughout a message
  # or ctor body, nested scopes included (design §10/§12.1) — otherwise an inner
  # `(fn f [self] ...)` or pattern binding would retarget every later leading
  # send `(.m)`. The injected receiver parameter itself is bound before this
  # flag is set, so only genuine shadowing is rejected.
  if c.selfReserved and name == "self":
    raise newException(GeneError,
      "'self' is the receiver and cannot be rebound in a message body " &
      "(design §10)")
  # D4: same-scope declarations conflict, but ordinary locals/parameters may
  # shadow an inherited macro. Remove that compiler binding before later
  # call-head or value-position lookup can bypass the new local.
  if name in c.ownMacroNames:
    raise newException(GeneError,
      "binding '" & name & "' conflicts with a macro of the same name")
  if c.hasMacros:
    c.macros.del(name)
    var hiddenPaths: seq[string]
    for path in c.macros.keys:
      if path.startsWith(name & "/"): hiddenPaths.add path
    for path in hiddenPaths: c.macros.del(path)
  if not importing: c.aliasInterfaces.del(name)
  c.ordinaryFnNames.del(name)
  c.generatorFnNames.del(name)
  c.declaredNames.incl name
  c.ownValueNames.incl name
  # A fresh binding is rebindable until something says otherwise, so it clears
  # any `let` mark inherited from an outer scope — branch-local `for`/`match`/
  # `catch` bindings and parameters shadow an outer `let` rather than freezing
  # (design §12.1). Callers that bind a `let`-class name re-mark it after.
  c.letNames.excl name
  if not c.useLocalSlots:
    return -1
  let newBlockBinding = c.inlineBlockPrefix.len > 0 and
    name notin c.inlineBlockBindings
  if newBlockBinding:
    c.localTypes.del(name)
    c.fastLocalLoads.del(name)
    c.localFunctionSigs.del(name)
    c.constValues.del(name)
    c.aotConstants.del(name)
  if c.localSlots.hasKey(name) and not newBlockBinding:
    return c.localSlots[name]
  result = c.localNames.len
  c.localSlots[name] = result
  if c.inlineBlockPrefix.len > 0:
    c.inlineBlockBindings.incl name
    c.localNames.add c.inlineBlockPrefix & name
    c.chunk.privateLocalSlots.add result
  else:
    c.localNames.add name

proc localSlot(c: Compiler, name: string): int =
  if c.useLocalSlots and c.localSlots.hasKey(name):
    return c.localSlots[name]
  -1

proc isBareIntType(expr: Value): bool =
  expr.kind == vkSymbol and expr.symVal == "Int"

proc recordLocalType(c: var Compiler, name: string, typeExpr: Value) =
  if c.useLocalSlots and c.localSlots.hasKey(name) and typeExpr.kind != vkNil:
    c.localTypes[name] = typeExpr

proc localType(c: Compiler, name: string): Value =
  if c.useLocalSlots and c.localTypes.hasKey(name):
    return c.localTypes[name]
  NIL

proc typeExcludesFexpr(expr: Value): bool =
  case expr.kind
  of vkSymbol:
    expr.symVal in ["Fn", "Callable", "NativeFn", "Type",
                    "ProtocolMessage", "Path"]
  of vkNode:
    if expr.head.kind != vkSymbol:
      return false
    if expr.head.symVal in ["Fn", "Callable", "NativeFn", "Type",
                            "ProtocolMessage", "Path"]:
      return true
    if expr.head.symVal == "|":
      if expr.body.len == 0:
        return false
      for item in expr.body:
        if not typeExcludesFexpr(item):
          return false
      return true
    false
  else:
    false

proc parentSlot(c: Compiler, name: string): tuple[depth: int, slot: int] =
  for i, slots in c.parentSlots:
    if slots.hasKey(name):
      return (i + 1, slots[name])
  (-1, -1)

proc parentFrames(c: Compiler): seq[Table[string, int]] =
  if c.useLocalSlots:
    result.add c.localSlots
  result.add c.parentSlots

proc parentFunctionSigFrames(c: Compiler): seq[Table[string, KnownFunctionSig]] =
  if c.useLocalSlots:
    result.add c.localFunctionSigs
  result.add c.parentFunctionSigs

proc lexicalFunctionSig(c: Compiler, name: string):
    tuple[found: bool, sig: KnownFunctionSig] =
  let slot = c.localSlot(name)
  if slot >= 0:
    if c.localFunctionSigs.hasKey(name):
      return (true, c.localFunctionSigs[name])
    return
  let outer = c.parentSlot(name)
  if outer.slot >= 0:
    let index = outer.depth - 1
    if index >= 0 and index < c.parentFunctionSigs.len and
        c.parentFunctionSigs[index].hasKey(name):
      return (true, c.parentFunctionSigs[index][name])

proc functionSigFromParts(positionalCount: int, typeParams: openArray[string],
                          returnType: Value):
    tuple[known: bool, sig: KnownFunctionSig] =
  if typeParams.len == 0 and returnType.kind != vkNil:
    return (true, KnownFunctionSig(arity: positionalCount,
                                   returnType: returnType))

proc recordLocalFunctionSig(c: var Compiler, name: string, proto: FunctionProto) =
  if c.useLocalSlots and c.localSlots.hasKey(name) and
      proto.typeParams.len == 0 and proto.hasReturnType:
    c.localFunctionSigs[name] = KnownFunctionSig(arity: proto.params.len,
                                                 returnType: proto.returnType)

proc nativeFastLoadKind(name: string): NativeFastKind =
  case name
  of "+": nfkAdd
  of "-": nfkSub
  of "*": nfkMul
  of "<": nfkLt
  of ">": nfkGt
  of "<=": nfkLe
  of ">=": nfkGe
  # Division, remainder, `==` and `!=` have their fast path for two small Ints
  # only (a zero divisor included in what it declines); every other operand
  # pair reaches the same native function an ordinary call would, so zero
  # checks, Int/Float result rules and structural equality stay in one place.
  of "/": nfkDiv
  of "//": nfkRem
  of "==": nfkEq
  of "!=": nfkNe
  else: nfkNone

proc isSelfEvaluatingFastConst(v: Value): bool =
  case v.kind
  of vkNil, vkBool, vkInt, vkFloat, vkString, vkChar:
    true
  else:
    false

proc ownsResultBindings(value: Value): bool

proc normalizedMacroExpression(c: Compiler, value: Value): Value =
  if value.kind == vkNode and c.compiledMacroResults.hasKey(value.bits):
    return c.normalizedMacroExpression(c.compiledMacroResults[value.bits])
  if value.kind == vkNode and value.head.kind == vkSymbol and
      value.head.symVal == "do" and value.body.len == 1 and
      not ownsResultBindings(value.body[0]):
    return c.normalizedMacroExpression(value.body[0])
  value

proc normalizedMacroTree(c: Compiler, value: Value): Value =
  ## Optimization input uses expansions already compiled at this exact site.
  ## Do not execute a macro twice or flatten a block that changes bindings.
  let normalized = c.normalizedMacroExpression(value)
  if normalized.bits != value.bits: return c.normalizedMacroTree(normalized)
  if value.kind != vkNode or ownsResultBindings(value) or
      (value.head.kind == vkSymbol and value.head.symVal in
        ["quote", "quasiquote", "fn", "macro", "scope"]):
    return value
  var body: seq[Value]
  var changed = false
  for item in value.body:
    let replacement = c.normalizedMacroTree(item)
    changed = changed or replacement.bits != item.bits
    body.add replacement
  if changed:
    newNode(value.head, value.props, body, value.meta, value.nodeImmutable)
  else: value

proc exprKnownBareInt(c: Compiler, v: Value): bool

proc formsKnownBareInt(c: Compiler, forms: openArray[Value], start = 0): bool =
  forms.len > start and c.exprKnownBareInt(forms[forms.high])

proc exprKnownBareInt(c: Compiler, v: Value): bool =
  let normalized = c.normalizedMacroExpression(v)
  if normalized.bits != v.bits:
    return c.exprKnownBareInt(normalized)
  case v.kind
  of vkInt:
    true
  of vkSymbol:
    c.localType(v.symVal).isBareIntType
  of vkNode:
    if v.props.len == 0 and v.head.kind == vkSymbol:
      case v.head.symVal
      of "+", "-", "*", "/", "//":
        # Int division and remainder of two Ints are Ints, or they raise.
        not c.dynamicNameLookup and v.body.len == 2 and c.localSlot(v.head.symVal) < 0 and
          c.parentSlot(v.head.symVal).slot < 0 and
          not (c.macroPhaseCompilation and c.unitDeclares(v.head.symVal)) and
          c.exprKnownBareInt(v.body[0]) and c.exprKnownBareInt(v.body[1])
      of "if":
        if v.body.len >= 2 and v.body[1].kind == vkNode and
            v.body[1].head.kind == vkSymbol and v.body[1].head.symVal == "then":
          var known = c.formsKnownBareInt(v.body[1].body)
          var hasDefault = false
          for i in 2 ..< v.body.len:
            let clause = v.body[i]
            if clause.kind != vkNode or clause.head.kind != vkSymbol:
              continue
            case clause.head.symVal
            of "elif":
              known = known and clause.body.len > 1 and
                c.formsKnownBareInt(clause.body, 1)
            of "else":
              known = known and c.formsKnownBareInt(clause.body)
              hasDefault = true
              break
            else:
              discard
          known and hasDefault
        else:
          v.body.len >= 3 and c.exprKnownBareInt(v.body[1]) and
            c.exprKnownBareInt(v.body[2])
      else:
        let sig = c.lexicalFunctionSig(v.head.symVal)
        sig.found and sig.sig.arity == v.body.len and
          sig.sig.returnType.isBareIntType
    else:
      false
  else:
    false

proc hasLexicalBinding(c: Compiler, name: string): bool
proc exprKnownExactResult(c: Compiler, v: Value, typeName: string): bool

proc formsKnownExactResult(c: Compiler, forms: openArray[Value],
                           typeName: string, start = 0): bool =
  forms.len > start and c.exprKnownExactResult(forms[forms.high], typeName)

proc exprKnownExactResult(c: Compiler, v: Value, typeName: string): bool =
  let normalized = c.normalizedMacroExpression(v)
  if normalized.bits != v.bits:
    return c.exprKnownExactResult(normalized, typeName)
  if typeName == "Any":
    return true
  case v.kind
  of vkInt:
    typeName == "Int"
  of vkFloat:
    typeName == "F64"
  of vkBool:
    typeName == "Bool"
  of vkString:
    typeName == "Str"
  of vkNil:
    typeName == "Nil"
  of vkVoid:
    typeName == "Void"
  of vkSymbol:
    let local = c.localType(v.symVal)
    local.kind == vkSymbol and local.symVal == typeName
  of vkNode:
    if v.props.len != 0 or v.head.kind != vkSymbol:
      return false
    case v.head.symVal
    of "do":
      c.formsKnownExactResult(v.body, typeName)
    of "if":
      if v.body.len >= 2 and v.body[1].kind == vkNode and
          v.body[1].head.kind == vkSymbol and
          v.body[1].head.symVal == "then":
        var known = c.formsKnownExactResult(v.body[1].body, typeName)
        var hasDefault = false
        for i in 2 ..< v.body.len:
          let clause = v.body[i]
          if clause.kind != vkNode or clause.head.kind != vkSymbol:
            continue
          case clause.head.symVal
          of "elif":
            known = known and clause.body.len > 1 and
              c.formsKnownExactResult(clause.body, typeName, 1)
          of "else":
            known = known and
              c.formsKnownExactResult(clause.body, typeName)
            hasDefault = true
            break
          else:
            discard
        known and hasDefault
      else:
        v.body.len >= 3 and
          c.exprKnownExactResult(v.body[1], typeName) and
          c.exprKnownExactResult(v.body[2], typeName)
    of "match":
      var known = v.body.len > 1
      var hasDefault = false
      for i in 1 ..< v.body.len:
        let clause = v.body[i]
        if clause.kind != vkNode or clause.head.kind != vkSymbol:
          return false
        case clause.head.symVal
        of "when":
          known = known and clause.body.len > 1 and
            c.formsKnownExactResult(clause.body, typeName, 1)
        of "else":
          known = known and c.formsKnownExactResult(clause.body, typeName)
          hasDefault = true
        else:
          return false
      known and hasDefault
    of "&&", "||", "??":
      if v.body.len == 0:
        false
      else:
        var known = true
        for item in v.body:
          known = known and c.exprKnownExactResult(item, typeName)
        known
    of "+", "-", "*":
      not c.dynamicNameLookup and typeName in ["Int", "F64"] and v.body.len == 2 and
        not c.hasLexicalBinding(v.head.symVal) and
        not (c.macroPhaseCompilation and c.unitDeclares(v.head.symVal)) and
        c.exprKnownExactResult(v.body[0], typeName) and
        c.exprKnownExactResult(v.body[1], typeName)
    of "!", "==", "<", ">", "<=", ">=":
      not c.dynamicNameLookup and typeName == "Bool" and not c.hasLexicalBinding(v.head.symVal) and
        not (c.macroPhaseCompilation and c.unitDeclares(v.head.symVal))
    else:
      let sig = c.lexicalFunctionSig(v.head.symVal)
      sig.found and sig.sig.arity == v.body.len and
        sig.sig.returnType.kind == vkSymbol and
        sig.sig.returnType.symVal == typeName
  else:
    false

proc hasLexicalBinding(c: Compiler, name: string): bool =
  if c.localSlot(name) >= 0:
    return true
  c.parentSlot(name).slot >= 0

proc importedCandidates(c: Compiler,
                        name: string): seq[StaticWildcardCandidate]
proc importedPathEntry(c: Compiler, value: Value):
    tuple[found: bool, candidate: StaticWildcardCandidate]
proc importedNameError(name: string,
                       candidates: openArray[StaticWildcardCandidate]): ref GeneError
proc calleeKnownOrdinary(c: Compiler, callee: Value): bool =
  case callee.kind
  of vkSymbol:
    if c.importedCandidates(callee.symVal).len > 0:
      return false
    if c.ordinaryFnNames.hasKey(callee.symVal) and
        callee.symVal notin c.mutableBindingNames:
      return true
    let local = c.localType(callee.symVal)
    if local.kind != vkNil and local.typeExcludesFexpr:
      return true
    # These names map to compiler-known ordinary native operators. Every other
    # ambient name can come from a caller-supplied Scope/Env and stays guarded.
    c.allowAmbientImports and not c.dynamicNameLookup and not c.hasLexicalBinding(callee.symVal) and
      not (c.macroPhaseCompilation and c.unitDeclares(callee.symVal)) and
      nativeFastLoadKind(callee.symVal) != nfkNone
  of vkNode:
    callee.head.kind == vkSymbol and callee.head.symVal == "fn"
  else:
    false

proc lexicalCallSlot(c: Compiler, name: string): tuple[op: OpCode, depth: int, slot: int] =
  let slot = c.localSlot(name)
  if slot >= 0:
    return (opCallLocal1, 0, slot)
  let outer = c.parentSlot(name)
  if outer.slot >= 0:
    if outer.depth == 1:
      return (opCallParentLocal1, outer.depth, outer.slot)
    return (opCallOuterLocal1, outer.depth, outer.slot)
  (opCall, -1, -1)

proc lexicalCallSlot0(c: Compiler, name: string): tuple[op: OpCode, depth: int, slot: int] =
  let slot = c.localSlot(name)
  if slot >= 0:
    return (opCallLocal0, 0, slot)
  let outer = c.parentSlot(name)
  if outer.slot >= 0:
    if outer.depth == 1:
      return (opCallParentLocal0, outer.depth, outer.slot)
    return (opCallOuterLocal0, outer.depth, outer.slot)
  (opCall, -1, -1)

# Migration aid for the bare-surface removal (design §2.1). With GENE_LINT_BARE
# set, the compiler reports every symbol that is not lexically bound — i.e.
# every reference that used to reach a root built-in — as `file:line:col name`.
# The compiler is the only thing that can tell those apart from a local, a
# message name, or a property key, so the rewrite is driven from this list.
let lintBareNames* = getEnv("GENE_LINT_BARE").len > 0

proc reportBareName(c: Compiler, name: string) =
  if not lintBareNames or c.hasLexicalBinding(name) or
      name in c.declaredNames or staysBare(name):
    return
  let loc = c.currentLoc
  stderr.writeLine("BARE\t" & loc.sourceName & "\t" & $loc.line & "\t" &
                   $loc.col & "\t" & name)

proc emitLoadBinding(c: var Compiler, name: string) =
  # One name, one meaning: a macro name may not be used in value position
  # (design §11). Macros are compile-time rewriters, not runtime values.
  if c.hasMacros and c.macros.hasKey(name):
    raise newException(GeneError,
      "macro '" & name & "' cannot be used as a value; call it in head position")
  let slot = c.localSlot(name)
  if slot >= 0:
    if c.fastLocalLoads.hasKey(name) and c.fastLocalLoads[name] == slot:
      discard c.emit(opLoadLocalFast, slot, name = name)
    else:
      discard c.emit(opLoadLocal, slot, name = name)
  else:
    let outer = c.parentSlot(name)
    # A `const` resolves before runtime (design §12.1), so a use of one is the
    # value rather than a load of it. **Only when the name resolves at the
    # outermost scope**: `parentSlot` answers the *nearest* enclosing binding,
    # so anything closer than the module is a shadow and must win —
    #     (const K 5) (fn outer [] (var K 9) (fn inner [] K))
    # must see 9. Folding on `constValues.hasKey` alone would see 5.
    #
    # Safe for aggregates only because a `const` aggregate is frozen at
    # definition: every use site pushes the same Value, and nothing can mutate
    # it through one of them.
    if outer.slot >= 0 and outer.depth == c.parentSlots.len and
        c.constValues.hasKey(name):
      discard c.emit(opPushConst, c.chunk.addConst(c.constValues[name]),
                     name = name)
    elif outer.slot >= 0:
      discard c.emit(opLoadOuterLocal, outer.slot, depth = outer.depth, name = name)
    else:
      let imported = c.importedCandidates(name)
      if imported.len > 1:
        raise importedNameError(name, imported)
      if imported.len == 1:
        if imported[0].category == cbcMacro:
          raise newException(GeneError,
            "macro '" & name &
            "' cannot be used as a value; call it in head position")
        discard c.emit(opLoadName, name = name)
        return
      c.reportBareName(name)
      let fastKind = nativeFastLoadKind(name)
      if fastKind != nfkNone and c.allowAmbientImports and not c.dynamicNameLookup and
          not (c.macroPhaseCompilation and c.unitDeclares(name)):
        discard c.emit(opLoadNativeFast, ord(fastKind), name = name)
      else:
        discard c.emit(opLoadName, name = name)

proc intFast2Op(kind: NativeFastKind): OpCode =
  case kind
  of nfkAdd: opIntAdd2
  of nfkSub: opIntSub2
  of nfkMul: opIntMul2
  of nfkLt: opIntLt2
  of nfkGt: opIntGt2
  of nfkLe: opIntLe2
  of nfkGe: opIntGe2
  # No Int-specialized opcode: the generic one still takes its small-Int path.
  of nfkDiv, nfkRem, nfkEq, nfkNe: opNativeFast2
  else: opIntFast2

proc intFastConstOp(kind: NativeFastKind): OpCode =
  case kind
  of nfkAdd: opIntAddConst
  of nfkSub: opIntSubConst
  of nfkMul: opIntMulConst
  of nfkLt: opIntLtConst
  of nfkGt: opIntGtConst
  of nfkLe: opIntLeConst
  of nfkGe: opIntGeConst
  of nfkDiv, nfkRem, nfkEq, nfkNe: opNativeFastConst
  else: opIntFastConst

proc emitDefineBinding(c: var Compiler, name: string, immutable = false,
                       allowFexprName = false) =
  validateBindingName(name, allowFexprName)
  # Record the binding even when this body compiles without slots, so the
  # bare-name lint can tell a declaration from a standard-library reference.
  c.declaredNames.incl name
  # Inside a loop body, one `var` form runs once per iteration. That is a
  # re-execution of a single declaration, not a redeclaration, so it overwrites
  # rather than tripping the duplicate check — which is what `for` bodies
  # already get from their own compiler, and what the web profile already gets
  # from JavaScript block scope. `childCompiler` does not inherit `loopDepth`,
  # so a `fn` defined inside a loop starts fresh and keeps the strict rule.
  let inLoop = c.loopDepth > 0 or c.repeatBindings
  if c.useLocalSlots:
    let slot = c.reserveLocal(name, allowFexprName)
    discard c.emit(if inLoop: opRedefineLocal else: opDefineLocal,
                   slot, name = c.localNames[slot])
  else:
    discard c.emit(if inLoop: opRedefineName else: opDefineName, name = name)
  # Named declarations (fn/type/enum/protocol/ns/macro/alias) are let-class
  # (design §12.1): their bindings are fixed, so `(set name ...)` is a compile
  # error. `var`/loop bindings pass immutable=false and stay rebindable. Marked
  # after reserveLocal, which clears the mark for a fresh binding.
  if immutable: c.letNames.incl name
  else: c.letNames.excl name

proc emitSetBinding(c: var Compiler, name: string) =
  let slot = c.localSlot(name)
  if slot >= 0:
    discard c.emit(opSetLocal, slot, name = c.localNames[slot])
  else:
    let outer = c.parentSlot(name)
    if outer.slot >= 0:
      discard c.emit(opSetOuterLocal, outer.slot, depth = outer.depth, name = name)
    else:
      discard c.emit(opSetName, name = name)

proc emitDeclareType(c: var Compiler, name: string, typeExpr: Value) =
  let slot = c.localSlot(name)
  let storageName = if slot >= 0: c.localNames[slot] else: name
  discard c.emit(opDeclareType, c.chunk.addConst(typeExpr), name = storageName)

proc containsRuntimeSyntaxValue(value: Value, seen: var HashSet[uint64]): bool

proc emitConst(c: var Compiler, value: Value) =
  if not c.macroPhaseCompilation and c.macroSession != nil and
      c.macroSession.runtimeState != nil:
    var seen: HashSet[uint64]
    if containsRuntimeSyntaxValue(value, seen):
      c.chunk.macroRuntimeLease = c.macroSession.runtimeState
  discard c.emit(opPushConst, c.chunk.addConst(value))

proc compileFn(c: var Compiler, node: Value, inferredName = "")

proc emitJump(c: var Compiler, op: OpCode): int =
  c.emit(op, -1)

proc patchJump(c: var Compiler, at: int) =
  c.chunk.patchJump(at, c.chunk.instructions.len)

proc compileBreak(c: var Compiler, node: Value) =
  if node.body.len != 0 or node.props.len != 0:
    raise newException(GeneError, "break expects no arguments")
  if c.loopDepth <= 0:
    raise newException(GeneError, "break is only valid inside a loop")
  discard c.emit(opLoopBreak)

proc compileContinue(c: var Compiler, node: Value) =
  if node.body.len != 0 or node.props.len != 0:
    raise newException(GeneError, "continue expects no arguments")
  if c.loopDepth <= 0:
    raise newException(GeneError, "continue is only valid inside a loop")
  discard c.emit(opLoopContinue)

proc isSymbol(v: Value, name: string): bool =
  v.kind == vkSymbol and v.symVal == name

proc isPath(v: Value, segments: openArray[string]): bool =
  if v.kind != vkNode or not v.head.isSymbol("path") or v.body.len != segments.len:
    return false
  for i, segment in segments:
    if v.body[i].kind != vkSymbol or v.body[i].symVal != segment:
      return false
  true

proc validModuleRefName(name: string): bool =
  if name.len == 0 or name[0] notin {'a'..'z', '_'}:
    return false
  for c in name:
    if c notin {'a'..'z', '0'..'9', '_'}:
      return false
  true

proc compileExpr(c: var Compiler, node: Value, allowModDecl = false,
                 tail = false)
proc visibleMacroBindings(c: Compiler): MacroBindings
proc markStaticImplForms(c: var Compiler, forms: openArray[Value], first = 0)
proc reserveProtocolBindingsFor(c: var Compiler, forms: openArray[Value])
proc prepareStaticImports(c: var Compiler, forms: openArray[Value], first = 0)
proc builtinNamespaceMacros(segments: openArray[string]):
    Table[string, MacroDef]
proc declarationIsPrivate(node: Value): bool
proc importMacro(c: var Compiler, local: string, def: MacroDef)
proc importMacroLocals(c: Compiler, node: Value): HashSet[string]

proc childCompiler(c: Compiler): Compiler =
  Compiler(chunk: newChunk(c.sourceName), sourceName: c.sourceName,
           gensym: c.gensym,
           sourceLocs: c.sourceLocs, currentLoc: c.currentLoc,
           unitSource: c.unitSource,
           selfAvailable: c.selfAvailable,
           allowYield: c.allowYield, inFunction: c.inFunction,
           generatorFnNames: c.generatorFnNames,
           inGenerator: c.inGenerator,
           ffiLibraryNames: c.ffiLibraryNames,
           constValues: c.constValues,
           macros: c.macros, hasMacros: c.hasMacros,
           macroContext: c.macroContext, macroSession: c.macroSession,
           macroPhaseCompilation: c.macroPhaseCompilation,
           dynamicNameLookup: c.dynamicNameLookup,
           macroExpansionDepth: c.macroExpansionDepth,
           allowAmbientImports: c.allowAmbientImports,
           importedMacroSets: c.importedMacroSets,
           importedMacroNames: c.importedMacroNames,
           ordinaryFnNames: c.ordinaryFnNames,
           mutableBindingNames: c.mutableBindingNames,
           letNames: c.letNames,
           declaredNames: c.declaredNames,
           selfReserved: c.selfReserved,
           superType: c.superType,
           importedSyntaxFnSets: c.importedSyntaxFnSets,
           importedInterfaces: c.importedInterfaces,
           ownCompileInterface: c.ownCompileInterface,
           localCompileInterfaces: c.localCompileInterfaces,
           importedCompileEntries: c.importedCompileEntries,
           wildcardCandidates: c.wildcardCandidates,
           aliasInterfaces: c.aliasInterfaces,
           parameterAliases: c.parameterAliases,
           declaredUnitNames: c.declaredUnitNames,
           preparedUnitNames: c.preparedUnitNames,
           namespacePath: c.namespacePath,
           moduleMacroExports: c.moduleMacroExports,
           moduleSyntaxFnExports: c.moduleSyntaxFnExports,
           closurePoolCandidates: c.closurePoolCandidates,
           staticTopLevelImpls: c.staticTopLevelImpls,
           overlayImplMessages: c.overlayImplMessages,
           budget: c.budget)

proc nextGensym(c: var Compiler): int =
  ## Generated names must be unique across a whole compilation, not per chunk:
  ## a `try` or `ensure` body is a child compiler emitting into the *enclosing*
  ## scope, so a per-compiler counter would hand two live bindings one name.
  if c.gensym == nil:
    c.gensym = new(int)
  inc c.gensym[]
  c.gensym[]

proc prepareMacroContext(c: var Compiler, forms: openArray[Value]) =
  if c.macroContext == nil:
    c.macroContext = MacroDefinitionContext(sourceName: c.sourceName,
      forms: @forms,
      locs: if c.sourceLocs == nil: initTable[uint64, SourceLoc]() else: c.sourceLocs[],
      importedMacros: c.importedMacroSets,
      importedSyntaxFns: c.importedSyntaxFnSets,
      importedInterfaces: c.importedInterfaces)
  if c.macroSession == nil:
    c.macroPhaseCompilation = activeMacroSession != nil
    c.macroSession = if activeMacroSession != nil: activeMacroSession
                     else: MacroExecutionSession(hostContext: activeMacroHostContext)
  if c.macroSession.rootContext == nil:
    c.macroSession.rootContext = c.macroContext

proc nextTemp(c: var Compiler, prefix: string): string =
  # Earlier REPL inputs may still own generated bindings in this scope.
  while true:
    result = "__gene_" & prefix & "_" & $c.nextGensym()
    if result notin c.ownValueNames: return

proc containsYield(value: Value): bool =
  case value.kind
  of vkPipeline:
    if containsYield(value.pipelineInitial): return true
    for stage in value.pipelineStages:
      if containsYield(stage.head): return true
      for _, item in stage.props:
        if containsYield(item): return true
      for item in stage.body:
        if containsYield(item): return true
      for _, item in stage.meta:
        if containsYield(item): return true
    false
  of vkNode:
    if value.head.isSymbol("yield"):
      return true
    if value.head.isSymbol("fn") or value.head.isSymbol("quote") or
        value.head.isSymbol("quasiquote"):
      return false
    for _, item in value.props:
      if containsYield(item):
        return true
    for item in value.body:
      if containsYield(item):
        return true
    false
  of vkList:
    for item in value.listItems:
      if containsYield(item):
        return true
    false
  of vkMap:
    for _, item in value.mapEntries:
      if containsYield(item):
        return true
    false
  of vkSet:
    for item in value.setItems:
      if containsYield(item):
        return true
    false
  of vkHashMap:
    for entry in value.hashMapEntries:
      if containsYield(entry.key) or containsYield(entry.val):
        return true
    false
  else:
    false

proc containsAwait(value: Value): bool =
  case value.kind
  of vkPipeline:
    if containsAwait(value.pipelineInitial): return true
    for stage in value.pipelineStages:
      if containsAwait(stage.head): return true
      for _, item in stage.props:
        if containsAwait(item): return true
      for item in stage.body:
        if containsAwait(item): return true
      for _, item in stage.meta:
        if containsAwait(item): return true
    false
  of vkNode:
    if value.head.isSymbol("await"):
      return true
    if value.head.isSymbol("fn") or value.head.isSymbol("quote") or
        value.head.isSymbol("quasiquote"):
      return false
    for _, item in value.props:
      if containsAwait(item):
        return true
    for item in value.body:
      if containsAwait(item):
        return true
    false
  of vkList:
    for item in value.listItems:
      if containsAwait(item):
        return true
    false
  of vkMap:
    for _, item in value.mapEntries:
      if containsAwait(item):
        return true
    false
  of vkSet:
    for item in value.setItems:
      if containsAwait(item):
        return true
    false
  of vkHashMap:
    for entry in value.hashMapEntries:
      if containsAwait(entry.key) or containsAwait(entry.val):
        return true
    false
  else:
    false

proc bodyContainsYield(body: openArray[Value], first: int): bool =
  if first > body.high:
    return false
  for i in first .. body.high:
    if containsYield(body[i]):
      return true
  false

proc bodyContainsAwait(body: openArray[Value], first: int): bool =
  if first > body.high:
    return false
  for i in first .. body.high:
    if containsAwait(body[i]):
      return true
  false

proc isTypedPattern(pat: Value): bool =
  pat.kind == vkNode and pat.head.kind == vkSymbol and pat.body.len > 0 and
    pat.body[0].isSymbol(":")

proc requireTypedPatternShape(pat: Value) =
  if pat.body.len != 2:
    raise newException(GeneError, "typed pattern requires a name and one type")

proc patternBindsSelf(pattern: Value): bool =
  case pattern.kind
  of vkSymbol:
    return pattern.symVal == "self"
  of vkList:
    for item in pattern.listItems:
      if patternBindsSelf(item):
        return true
  of vkMap:
    for _, value in pattern.mapEntries:
      if patternBindsSelf(value):
        return true
  of vkSet:
    for value in pattern.setItems:
      if patternBindsSelf(value):
        return true
  of vkHashMap:
    for entry in pattern.hashMapEntries:
      if patternBindsSelf(entry.key) or patternBindsSelf(entry.val):
        return true
  of vkNode:
    if pattern.isTypedPattern:
      pattern.requireTypedPatternShape()
      return pattern.head.symVal == "self"
    for _, value in pattern.props:
      if patternBindsSelf(value):
        return true
    for item in pattern.body:
      if patternBindsSelf(item):
        return true
  else:
    return false

proc isRestPattern(pat: Value): bool =
  ## Mirrors `vm.nim`'s: the reader spells `xs...` as the symbol `xs...` inside
  ## a list literal and as the spread node `(... xs)` everywhere else, so a
  ## macro-time pattern has to accept both for `(f xs...)` to bind.
  if pat.kind == vkSymbol:
    return pat.symVal.len > 3 and pat.symVal.endsWith("...")
  pat.kind == vkNode and pat.head.isSymbol("...") and pat.body.len == 1 and
    pat.body[0].kind == vkSymbol

proc restPatternName(pat: Value): string =
  if pat.kind == vkSymbol: pat.symVal[0 .. ^4] else: pat.body[0].symVal

proc addPatternBinding(names: var seq[string], seen: var Table[string, bool],
                       name: string) =
  if name.len == 0 or name == "_" or seen.hasKey(name):
    return
  validateBindingName(name)
  seen[name] = true
  names.add name

proc collectPatternBindingNames(pat: Value, names: var seq[string],
                                seen: var Table[string, bool])

proc sameNameSet(a, b: openArray[string]): bool =
  if a.len != b.len:
    return false
  var seen = initTable[string, bool]()
  for name in a:
    seen[name] = true
  for name in b:
    if not seen.hasKey(name):
      return false
  true

proc patternBindingNames(pat: Value): seq[string] =
  var seen = initTable[string, bool]()
  collectPatternBindingNames(pat, result, seen)

proc collectPatternBindingNames(pat: Value, names: var seq[string],
                                seen: var Table[string, bool]) =
  case pat.kind
  of vkSymbol:
    if pat.isRestPattern:
      addPatternBinding(names, seen, pat.symVal[0 .. ^4])
    else:
      addPatternBinding(names, seen, pat.symVal)
  of vkList:
    for item in pat.listItems:
      collectPatternBindingNames(item, names, seen)
  of vkMap:
    for _, valuePat in pat.mapEntries:
      collectPatternBindingNames(valuePat, names, seen)
  of vkNode:
    if pat.head.isSymbol("path"):
      return
    if pat.isTypedPattern:
      pat.requireTypedPatternShape()
      addPatternBinding(names, seen, pat.head.symVal)
      return
    if pat.head.kind == vkSymbol:
      case pat.head.symVal
      of "unquote":
        return
      of "|":
        if pat.body.len == 0:
          return
        let baseline = patternBindingNames(pat.body[0])
        for i in 1 ..< pat.body.len:
          if not sameNameSet(baseline, patternBindingNames(pat.body[i])):
            raise newException(GeneError,
              "alternation pattern alternatives must bind the same names")
        for name in baseline:
          addPatternBinding(names, seen, name)
        return
      of "&":
        for sub in pat.body:
          collectPatternBindingNames(sub, names, seen)
        return
      of "not":
        if pat.body.len == 1 and patternBindingNames(pat.body[0]).len > 0:
          raise newException(GeneError,
            "pattern (not p) must not introduce bindings")
        return
      else:
        discard
    for _, valuePat in pat.props:
      collectPatternBindingNames(valuePat, names, seen)
    for item in pat.body:
      collectPatternBindingNames(item, names, seen)
  else:
    discard

proc knownGeneratorCall(c: Compiler, value: Value): bool =
  if value.kind != vkNode: return false
  let callee = value.head
  if callee.kind == vkSymbol:
    return c.generatorFnNames.hasKey(callee.symVal)
  if callee.kind == vkNode and callee.head.isSymbol("fn"):
    let flag = callee.props.getOrDefault("generator", FALSE)
    return flag.kind == vkBool and flag.boolVal

proc warnDiscardedPipeline(c: var Compiler, value: Value) =
  if value.kind == vkPipeline and value.pipelineStages.len > 0 and
      value.pipelineStages[^1].kind == pstIterate:
    c.chunk.diagnostics.add CompileDiagnostic(
      message: "unused lazy pipeline: item callbacks run only when consumed; " &
        "use -> $each for effects or -> $into [] to collect results",
      loc: value.pipelineStages[^1].sourceLoc)
  elif c.knownGeneratorCall(value):
    c.chunk.diagnostics.add CompileDiagnostic(
      message: "unused generator Stream: the body runs only when consumed; " &
        "use -> $each for effects or -> $into [] to collect results",
      loc: if c.sourceLocs != nil: c.sourceLocs[].getOrDefault(value.bits, c.currentLoc)
           else: c.currentLoc)

proc collectParameterAliases(c: var Compiler, forms: openArray[Value], first = 0) =
  # Only declarations in this lexical body participate. Branch-local aliases
  # do not change a surrounding declaration's callable shape.
  for i in first ..< forms.len:
    let form = forms[i]
    if form.kind == vkNode and form.body.len > 0 and form.body[0].kind == vkSymbol and
        form.head.kind == vkSymbol and form.head.symVal in
          ["alias", "type", "enum", "protocol", "fn", "let", "var", "const"]:
      c.parameterAliases.del(form.body[0].symVal)
  for i in first ..< forms.len:
    let form = forms[i]
    if form.kind == vkNode and form.head.isSymbol("alias") and form.body.len == 2 and
        form.body[0].kind == vkSymbol:
      c.parameterAliases[form.body[0].symVal] = form.body[1]

proc compileBody(c: var Compiler, body: openArray[Value], tail = false) =
  c.collectParameterAliases(body)
  if body.len == 0:
    c.emitConst NIL
    return
  for i in 0 ..< body.len:
    compileExpr(c, body[i], tail = tail and i == body.high)
    if i == body.high and c.inStatementFn:
      c.warnDiscardedPipeline(body[i])
    if i < body.high:
      c.warnDiscardedPipeline(body[i])
      discard c.emit(opPop)

proc compileBodyFrom(c: var Compiler, body: openArray[Value], first: int,
                     tail = false) =
  c.collectParameterAliases(body, first)
  if first > body.high:
    c.emitConst NIL
    return
  for i in first .. body.high:
    compileExpr(c, body[i], tail = tail and i == body.high)
    if i == body.high and c.inStatementFn:
      c.warnDiscardedPipeline(body[i])
    if i < body.high:
      c.warnDiscardedPipeline(body[i])
      discard c.emit(opPop)

proc symbolText(v: Value): string =
  if v.kind == vkSymbol: v.symVal else: ""

proc compileDefaultExpr(c: Compiler, node: Value): Chunk =
  var child = c.childCompiler()
  child.allowYield = false
  child.inGenerator = false
  child.prepareStaticImports(@[node])
  child.reserveProtocolBindingsFor(@[node])
  compileExpr(child, node)
  discard child.emit(opReturn)
  child.chunk

proc chunkNeedsCallScope(chunk: Chunk): bool =
  if chunk.localNames.len > 0 or chunk.subchunks.len > 0 or
      chunk.forLoops.len > 0 or chunk.matches.len > 0 or
      chunk.tries.len > 0:
    return true
  for i, inst in chunk.instructions:
    case inst.op
    of opBindMessage:
      if i + 1 == chunk.instructions.len or chunk.instructions[i + 1].op != opResolveQualifiedMessage:
        return true
    of opLoadOuterLocal, opCallParentLocal0, opCallOuterLocal0,
       opCallParentLocal1, opCallOuterLocal1, opSetOuterLocal, opDefineName,
       opDefineLocal, opSetModuleName, opMakeFn, opPreparePipelineCall,
       opMakeNamespace, opMakeType, opMakeEnum, opMakeProtocol, opMakeImpl,
       opImport, opImportImpl,
       opMatch, opMatchBind, opMatchBindReplace, opForEach, opTry,
       opTaskScope, opSupervisor, opSpawn, opAwait, opYield:
      return true
    of opDefineRuntimeMacro, opInvokeRuntimeMacro, opExecuteRuntimeMacro, opRuntimePipelineStage:
      return true
    else:
      discard
  false

proc chunkHasDeferredImplValidation(chunk: Chunk): bool =
  if chunk == nil:
    return false
  for proto in chunk.typeProtos:
    if proto.staticTopLevel and proto.requiredImplCount > 0:
      return true
  for body in chunk.subchunks:
    if body.chunkHasDeferredImplValidation:
      return true
  for loop in chunk.forLoops:
    if loop.body.chunkHasDeferredImplValidation:
      return true
  for match in chunk.matches:
    for clause in match.clauses:
      if clause.body.chunkHasDeferredImplValidation:
        return true
    if match.elseBody.chunkHasDeferredImplValidation:
      return true
  for attempt in chunk.tries:
    if attempt.body.chunkHasDeferredImplValidation:
      return true
    for clause in attempt.catches:
      if clause.body.chunkHasDeferredImplValidation:
        return true
    if attempt.ensureBody.chunkHasDeferredImplValidation:
      return true
  false

proc chunkCanPoolCallScope(chunk: Chunk, closures = false,
                           nestedLoops = false): bool =
  ## Whether nothing made in `chunk` can hold its call scope. With `closures`,
  ## the closures it makes are left to closuresCopyCaptures. With
  ## `nestedLoops`, a `for` inside is accepted when its own body passes: its
  ## iterations run in children of this scope, and a child is gone when its
  ## loop ends unless something made in the body holds it, which is this same
  ## question asked of that body. Only a loop body asks with `nestedLoops`:
  ## the VM checks again at run time that nothing else owns an iteration scope
  ## before reusing it, while a function's call scope is pooled on this answer
  ## alone.
  if chunk.subchunks.len > 0 or chunk.matches.len > 0 or chunk.tries.len > 0:
    return false
  if chunk.forLoops.len > 0:
    if not nestedLoops:
      return false
    for loop in chunk.forLoops:
      if not chunkCanPoolCallScope(loop.body, nestedLoops = true):
        return false
  for i, inst in chunk.instructions:
    case inst.op
    of opBindMessage:
      # A held message owns the scope in which it was written. Only an
      # immediately resolved send consumes that temporary without escape.
      if i + 1 == chunk.instructions.len or chunk.instructions[i + 1].op != opResolveQualifiedMessage:
        return false
    of opMakeFn:
      if not closures:
        return false
    of opForEach:
      if not nestedLoops:
        return false
    of opPreparePipelineCall, opMakeEnv, opMakeNamespace, opMakeType, opMakeEnum, opMakeProtocol,
       opMakeImpl, opImport, opImportImpl, opMatch, opMatchBind,
       opMatchBindReplace,
       opTry, opTaskScope, opSupervisor, opSpawn, opAwait, opYield:
      return false
    of opDefineRuntimeMacro, opInvokeRuntimeMacro, opExecuteRuntimeMacro, opRuntimePipelineStage:
      return false
    else:
      discard
  true

proc chunkNeedsCallScopeSlotNames(chunk: Chunk): bool =
  for inst in chunk.instructions:
    case inst.op
    of opDeclareType, opSyntaxCall, opDefineRuntimeMacro, opInvokeRuntimeMacro, opExecuteRuntimeMacro, opRuntimePipelineStage:
      # A fexpr receives a borrowed CallerEnv, whose eval/snapshot operations
      # expose this frame's locals by name even when the caller only uses
      # indexed loads itself. Pooling may omit the name map otherwise.
      return true
    else:
      discard
  false

proc chunkMaySetSlot(chunk: Chunk, slot: int): bool =
  if chunk.subchunks.len > 0 or chunk.forLoops.len > 0 or
      chunk.matches.len > 0 or chunk.tries.len > 0:
    return true
  for inst in chunk.instructions:
    if inst.op in {opInvokeRuntimeMacro, opRuntimePipelineStage}: return true
    if inst.op == opSetLocal and inst.intArg == slot:
      return true
  false

proc chunkMutatesOuterScope(chunk: Chunk, localDepth = 0): bool =
  if chunk == nil:
    return false
  for inst in chunk.instructions:
    case inst.op
    of opSetOuterLocal:
      if inst.depth > localDepth:
        return true
    of opSetName:
      return true
    else:
      discard
  for body in chunk.subchunks:
    if chunkMutatesOuterScope(body, localDepth + 1):
      return true
  for loop in chunk.forLoops:
    if chunkMutatesOuterScope(loop.body, localDepth + 1):
      return true
  for match in chunk.matches:
    for clause in match.clauses:
      if chunkMutatesOuterScope(clause.body, localDepth + 1):
        return true
    if chunkMutatesOuterScope(match.elseBody, localDepth + 1):
      return true
  for attempt in chunk.tries:
    if chunkMutatesOuterScope(attempt.body, localDepth):
      return true
    for clause in attempt.catches:
      if chunkMutatesOuterScope(clause.body, localDepth + 1):
        return true
    if chunkMutatesOuterScope(attempt.ensureBody, localDepth):
      return true
  false

proc chunkContainsSpawn(chunk: Chunk): bool =
  if chunk == nil:
    return false
  for inst in chunk.instructions:
    if inst.op == opSpawn:
      return true
  for body in chunk.subchunks:
    if chunkContainsSpawn(body):
      return true
  for loop in chunk.forLoops:
    if chunkContainsSpawn(loop.body):
      return true
  for match in chunk.matches:
    for clause in match.clauses:
      if chunkContainsSpawn(clause.body):
        return true
    if chunkContainsSpawn(match.elseBody):
      return true
  for attempt in chunk.tries:
    if chunkContainsSpawn(attempt.body):
      return true
    for clause in attempt.catches:
      if chunkContainsSpawn(clause.body):
        return true
    if chunkContainsSpawn(attempt.ensureBody):
      return true
  for proto in chunk.functions:
    if chunkContainsSpawn(proto.chunk):
      return true
    for defaultValue in proto.paramDefaults:
      if defaultValue.optional and defaultValue.defaultChunk != nil and
          chunkContainsSpawn(defaultValue.defaultChunk):
        return true
    for param in proto.namedParams:
      if param.defaultValue.optional and
          param.defaultValue.defaultChunk != nil and
          chunkContainsSpawn(param.defaultValue.defaultChunk):
        return true
  false

proc chunkMaySetOuterSlot(chunk: Chunk, depth, slot: int): bool =
  if chunk.subchunks.len > 0 or chunk.forLoops.len > 0 or
      chunk.matches.len > 0 or chunk.tries.len > 0:
    return true
  for inst in chunk.instructions:
    if inst.op == opSetOuterLocal and inst.depth == depth and
        inst.intArg == slot:
      return true
  false

proc canUseTypedIntRecur1(proto: FunctionProto): bool =
  ## A typed unary Int function can use the same recursive call machinery as a
  ## simple call when the parameter slot never needs a runtime type binding.
  proto.typeParams.len == 0 and not proto.checksErrors and
    proto.params.len == 1 and proto.requiredPositional == 1 and
    proto.positionalSlots.len == 1 and proto.positionalSlots[0] >= 0 and
    proto.positionalSlotMaySet.len == 1 and not proto.positionalSlotMaySet[0] and
    proto.restParam.len == 0 and proto.namedParams.len == 0 and
    proto.hasParamTypes and proto.paramTypes.len == 1 and
    proto.paramTypes[0].isBareIntType and proto.hasReturnType and
    proto.returnType.isBareIntType and not proto.isGenerator and
    proto.paramDefaults.len == 1 and not proto.paramDefaults[0].optional

proc canUseSameScopeRecur1(proto: FunctionProto): bool =
  ## Same-scope recursion mutates only the single parameter slot and restores it
  ## when the callee returns. Keep this to the minimal no-local/no-subframe shape.
  (proto.simpleCall or proto.canUseTypedIntRecur1) and proto.localNames.len == 1 and
    proto.positionalSlots[0] == 0 and proto.localNames[0] == proto.params[0] and
    proto.taskFrameKind == tfkNone and proto.chunk.subchunks.len == 0 and
    proto.chunk.forLoops.len == 0 and proto.chunk.matches.len == 0 and
    proto.chunk.tries.len == 0 and proto.chunk.functions.len == 0

proc canUseRecur1(proto: FunctionProto): bool =
  proto.selfParentSlot >= 0 and proto.params.len == 1 and
    proto.requiredPositional == 1 and proto.positionalSlots.len == 1 and
    proto.positionalSlots[0] >= 0 and proto.poolCallScope and
    not proto.callScopeNeedsSlotNames and
    not proto.callScopeNeedsSlotReset and
    (proto.simpleCall or proto.canUseTypedIntRecur1)

proc smallIntConstValue(chunk: Chunk, constIndex: int): tuple[ok: bool, value: int] =
  if constIndex >= 0 and constIndex < chunk.constants.len:
    let v = chunk.constants[constIndex]
    if v.isSmallInt:
      return (true, int(v.smallIntVal))
  (false, 0)

proc rewriteTailReturnGuards(proto: FunctionProto) =
  ## Collapse the tail shape produced for `(if (< x const) x ...)`.
  ## The replacement returns directly on the true branch and skips the four
  ## now-dead condition/then/jump instructions on the false branch. The VM op
  ## keeps a dynamic fallback, so this is also safe for untyped native-fast `<`.
  var i = 0
  while i + 4 < proto.chunk.instructions.len:
    let load = proto.chunk.instructions[i]
    let cmp = proto.chunk.instructions[i + 1]
    let jumpFalse = proto.chunk.instructions[i + 2]
    let trueLoad = proto.chunk.instructions[i + 3]
    let jumpEnd = proto.chunk.instructions[i + 4]
    let loadLocal = load.op == opLoadLocalFast or load.op == opLoadLocal
    let trueLoadLocal = trueLoad.op == opLoadLocalFast or
      trueLoad.op == opLoadLocal
    let cmpLtConst = cmp.op == opIntLtConst or
      (cmp.op == opNativeFastConst and NativeFastKind(cmp.intArg) == nfkLt)
    if loadLocal and cmpLtConst and
        jumpFalse.op == opJumpIfFalse and jumpFalse.intArg == i + 5 and
        trueLoadLocal and trueLoad.intArg == load.intArg and
        jumpEnd.op == opJump and jumpEnd.intArg >= 0 and
        jumpEnd.intArg < proto.chunk.instructions.len and
        proto.chunk.instructions[jumpEnd.intArg].op in {opReturn, opReturnBareInt}:
      let imm = proto.chunk.smallIntConstValue(cmp.depth)
      proto.chunk.instructions[i] = Instruction(
        op: (if imm.ok: opReturnLocalIfIntLtImm else: opReturnLocalIfIntLtConst),
        intArg: load.intArg,
        depth: (if imm.ok: imm.value else: cmp.depth),
        name: load.name, flag: cmp.flag)
      proto.chunk.instructions[i + 1] = Instruction(op: opNoop)
      proto.chunk.instructions[i + 2] = Instruction(op: opNoop)
      proto.chunk.instructions[i + 3] = Instruction(op: opNoop)
      proto.chunk.instructions[i + 4] = Instruction(op: opNoop)
      inc i, 5
    else:
      inc i

proc rewriteBareIntReturnAdds(proto: FunctionProto) =
  ## Collapse the fibonacci-like `(+ (self ...) (self ...))` tail return into
  ## one VM dispatch. Keep this narrower than all Int tail adds: other recursive
  ## shapes can depend on more general frame/stack behavior.
  var i = 0
  while i + 1 < proto.chunk.instructions.len:
    let add = proto.chunk.instructions[i]
    let ret = proto.chunk.instructions[i + 1]
    var sameScopeRecurs = 0
    let scanStart = max(0, i - 6)
    for j in scanStart ..< i:
      if proto.chunk.instructions[j].op in {
          opRecur1LocalIntSubConstSameScope,
          opRecur1LocalIntSubImmSameScope}:
        inc sameScopeRecurs
    if add.op == opIntAdd2 and ret.op == opReturnBareInt and
        sameScopeRecurs >= 2:
      proto.chunk.instructions[i] = Instruction(op: opReturnIntAdd2,
                                                name: add.name)
      proto.chunk.instructions[i + 1] = Instruction(op: opNoop)
      inc i, 2
    else:
      inc i

proc rewriteSelfRecursiveCalls(parent: Chunk) =
  for proto in parent.functions:
    if proto.canUseRecur1 and
        not parent.chunkMaySetSlot(proto.selfParentSlot) and
        not proto.chunk.chunkMaySetOuterSlot(1, proto.selfParentSlot):
      for inst in proto.chunk.instructions.mitems:
        if inst.op == opCallParentLocal1 and inst.intArg == proto.selfParentSlot and
            inst.name == proto.name:
          inst.op = opRecur1
      if proto.canUseTypedIntRecur1 or proto.simpleCall:
        let paramSlot = proto.positionalSlots[0]
        var i = 0
        while i + 2 < proto.chunk.instructions.len:
          let load = proto.chunk.instructions[i]
          let sub = proto.chunk.instructions[i + 1]
          let recur = proto.chunk.instructions[i + 2]
          let loadParam = (load.op == opLoadLocalFast or load.op == opLoadLocal) and
            load.intArg == paramSlot
          let subConst = sub.op == opIntSubConst or
            (sub.op == opNativeFastConst and
             NativeFastKind(sub.intArg) == nfkSub)
          if loadParam and subConst and recur.op == opRecur1 and
              (recur.flag or proto.simpleCall):
            let imm = proto.chunk.smallIntConstValue(sub.depth)
            let fusedOp =
              if imm.ok and proto.canUseSameScopeRecur1:
                opRecur1LocalIntSubImmSameScope
              elif imm.ok:
                opRecur1LocalIntSubImm
              elif proto.canUseSameScopeRecur1:
                opRecur1LocalIntSubConstSameScope
              else:
                opRecur1LocalIntSubConst
            proto.chunk.instructions[i] = Instruction(
              op: fusedOp, intArg: paramSlot,
              depth: (if imm.ok: imm.value else: sub.depth),
              name: load.name, flag: imm.ok)
            proto.chunk.instructions[i + 1] = Instruction(op: opNoop)
            proto.chunk.instructions[i + 2] = Instruction(op: opNoop)
            inc i, 3
          else:
            inc i
      proto.rewriteTailReturnGuards()
    proto.rewriteBareIntReturnAdds()
    proto.chunk.rewriteSelfRecursiveCalls()

proc functionNameAndTypeParams(form: Value): tuple[name: string, typeParams: seq[string]] =
  if form.kind == vkSymbol:
    return (form.symVal, @[])
  if form.kind == vkNode and form.head.kind == vkSymbol:
    result.name = form.head.symVal
    if result.name.len == 0:
      raise newException(GeneError, "generic function requires a name")
    var seen = initTable[string, bool]()
    for arg in form.body:
      if arg.kind != vkSymbol:
        raise newException(GeneError, "generic function type parameters must be names")
      if arg.symVal.len == 0:
        raise newException(GeneError, "generic function type parameter requires a name")
      if seen.hasKey(arg.symVal):
        raise newException(GeneError, "duplicate generic type parameter: " & arg.symVal)
      seen[arg.symVal] = true
      result.typeParams.add arg.symVal
    return
  raise newException(GeneError, "function name must be a symbol or (name type...)")

proc compileSubBody(c: var Compiler, forms: openArray[Value],
                    pattern: Value = NIL, scoped = false,
                    tail = false, repeatBindings = false): Chunk =
  var child = c.childCompiler()
  # try/ensure chunks reuse the caller's scope, including declarations that
  # execute again on the next loop iteration. Fresh scopes and functions
  # keep the default depth so genuine redeclarations remain errors.
  # This concerns bindings only: loop jump targets belong to their own chunk.
  child.repeatBindings = repeatBindings
  child.loopDepth = if scoped: 0 else: c.loopDepth
  if scoped:
    child.enableLocalSlots()
    child.parentSlots = c.parentFrames()
    for name in patternBindingNames(pattern):
      # reserveLocal un-marks an outer `let` of the same name, so a branch-local
      # binding stays rebindable in this arm (§12.1).
      discard child.reserveLocal(name)
      if name == "self":
        child.selfAvailable = true
  elif patternBindsSelf(pattern):
    child.selfAvailable = true
  child.prepareStaticImports(forms)
  child.reserveProtocolBindingsFor(forms)
  compileBody(child, forms, tail = tail) # empty -> nil
  discard child.emit(opReturn)
  c.sawNonVoidReturn = c.sawNonVoidReturn or child.sawNonVoidReturn
  if scoped:
    child.chunk.localNames = child.localNames
  child.chunk

proc isParamTerminator(s: string): bool =
  s.len == 0 or s in [",", "^", "^^"]

proc isRestParam(s: string): bool =
  s.len > 3 and s.endsWith("...")

proc signatureBindingPatterns(paramList: Value): seq[Value] =
  ## Only classify binder positions. The ordinary fn/fexpr parsers own validity,
  ## types and defaults; names inside those expressions are not parameters.
  if paramList.kind != vkList: return
  let items = paramList.listItems
  var i = 0
  while i < items.len:
    let item = items[i]
    inc i
    let spelling = item.symbolText
    if spelling == ",": continue
    if spelling in [":", "="]:
      inc i
      continue
    var pattern = item
    if spelling in ["^", "^^"]:
      if i >= items.len: break
      pattern = items[i]
      inc i
      if i < items.len and items[i].symbolText notin ["^", "^^", ",", ":", "="]:
        pattern = items[i]
        inc i
    if pattern.kind == vkSymbol and pattern.symVal.isRestParam:
      pattern = newSym(pattern.symVal[0 .. ^4])
    result.add pattern

proc signatureCompiler(c: Compiler, paramList: Value): Compiler =
  result = c.childCompiler()
  for pattern in signatureBindingPatterns(paramList):
    for name in patternBindingNames(pattern):
      discard result.reserveLocal(name)

proc typeExprAdmitsNil*(expr: Value): bool =
  ## True when a type expression *explicitly* admits nil — `T?`, `(? ...)`,
  ## `Nil`, or a union with a nil-admitting alternative. Such a type marks an
  ## optional prop-schema field or fixed parameter (omitted binds nil).
  ## `Any` is gradual slack, not an optionality marker: an `Any` field stays
  ## required, which keeps "required but dynamic" expressible.
  if expr.isTypeAlias: return typeExprAdmitsNil(expr.typeAliasExpr)
  case expr.kind
  of vkSymbol:
    let s = expr.symVal
    s == "Nil" or (s.len > 1 and s.endsWith("?"))
  of vkNode:
    if expr.head.isSymbol("?"):
      true
    elif expr.head.isSymbol("|"):
      for item in expr.body:
        if typeExprAdmitsNil(item): return true
      false
    else:
      false
  else:
    false

proc ownInterfaceEntry(c: Compiler, name: string):
    tuple[found: bool, entry: CompileInterfaceEntry]

proc parameterTypeAdmitsNil(c: Compiler, expr: Value, shadowed: openArray[string],
                            depth = 0): bool =
  if depth > 100: raise newException(GeneError, "recursive parameter type alias")
  if typeExprAdmitsNil(expr): return true
  if expr.kind == vkSymbol and expr.symVal notin shadowed:
    if c.parameterAliases.hasKey(expr.symVal):
      return c.parameterTypeAdmitsNil(c.parameterAliases[expr.symVal], shadowed, depth + 1)
    let path = expr.symVal.split('/')
    if path.len > 1:
      if path[0] in shadowed: return false
      var resolved = c.ownInterfaceEntry(path[0])
      if resolved.found:
        for segment in path[1 .. ^1]:
          if resolved.entry.category != cbcNamespace or
              resolved.entry.namespace == nil or
              not resolved.entry.namespace.entries.hasKey(segment):
            return false
          resolved.entry = resolved.entry.namespace.entries[segment]
        let form = resolved.entry.typeForm
        if form.kind == vkNode and form.head.isSymbol("alias") and form.body.len == 2:
          return c.parameterTypeAdmitsNil(form.body[1], shadowed, depth + 1)
        return false
    if c.importedCompileEntries.hasKey(expr.symVal):
      let form = c.importedCompileEntries[expr.symVal].typeForm
      if form.kind == vkNode and form.head.isSymbol("alias") and form.body.len == 2:
        return c.parameterTypeAdmitsNil(form.body[1], shadowed, depth + 1)
  elif expr.kind == vkNode:
    if expr.head.isSymbol("|"):
      for member in expr.body:
        if c.parameterTypeAdmitsNil(member, shadowed, depth + 1): return true
    elif expr.head.isSymbol("path"):
      var path: seq[string]
      for segment in expr.body:
        if segment.kind != vkSymbol: return false
        path.add segment.symVal
      return c.parameterTypeAdmitsNil(newSym(path.join("/")), shadowed, depth + 1)
  false

proc rejectOptionalSuffix(s, what, hint: string): string =
  ## `?`-suffixed declaration names are gone: optionality moved to the type
  ## (`^due T?`, not `^due? T`). Loud error so old code cannot silently mean
  ## "a field literally named due?".
  if s.len > 1 and s.endsWith("?"):
    raise newException(GeneError,
      what & " '" & s & "' may not end in '?'; optionality moved to the " &
      "type: " & hint)
  s

proc parseParamAdornment(c: Compiler, paramList: Value,
                         defaultContext: var ref Compiler, items: openArray[Value],
                         i: var int): ParamAdornment =
  ## Parse type annotations and compile call-time defaults.
  while i < items.len:
    let s = items[i].symbolText
    case s
    of ":":
      inc i
      if i >= items.len:
        raise newException(GeneError, "parameter annotation requires a type")
      result.typeExpr = items[i]
      inc i
    of "=":
      inc i
      if i >= items.len:
        raise newException(GeneError, "parameter default requires a value")
      result.defaultValue.optional = true
      if defaultContext == nil:
        new(defaultContext)
        defaultContext[] = c.signatureCompiler(paramList)
      result.defaultValue.defaultChunk = defaultContext[].compileDefaultExpr(items[i])
      inc i
    else:
      break

proc paramSpecs(c: Compiler, paramList: Value, typeParams: seq[string] = @[]): ParamSpecs =
  ## Extract positional and named parameter bindings from an `[a ^name b]`
  ## vector. The reader preserves vectors as flat tokens, so `^name` appears as
  ## `^` followed by `name`, and rest params appear as symbols like `xs...`.
  if paramList.kind != vkList: return
  var defaultContext: ref Compiler
  let items = paramList.listItems
  var i = 0
  var sawRest = false
  var sawOptionalPositional = false
  while i < items.len:
    let s = items[i].symbolText
    case s
    of "":
      inc i
    of ",":
      inc i
    of "^", "^^":
      if sawRest:
        raise newException(GeneError, "named parameter cannot follow a rest parameter")
      inc i
      if i >= items.len or items[i].kind != vkSymbol:
        raise newException(GeneError, "named parameter requires a name")
      let arg = rejectOptionalSuffix(items[i].symVal, "named parameter",
        "write `^" & items[i].symVal[0 .. ^2] &
        " : T?` — a nil-admitting type is optional (omitted binds nil)")
      if arg.len == 0:
        raise newException(GeneError, "named parameter requires a name")
      inc i
      var local = arg
      if i < items.len:
        let maybeLocal = items[i].symbolText
        if not maybeLocal.isParamTerminator and maybeLocal notin [":", "="]:
          local = rejectOptionalSuffix(maybeLocal, "named parameter local",
            "annotate the named parameter with a nil-admitting type instead")
          if local.len == 0:
            raise newException(GeneError, "named parameter local requires a name")
          inc i
      var adornment = c.parseParamAdornment(paramList, defaultContext, items, i)
      if not adornment.defaultValue.optional and
          c.parameterTypeAdmitsNil(adornment.typeExpr, typeParams & result.positional):
        # ^name : T? — optional named parameter; omitted binds nil (the
        # defaultChunk stays nil, so the runtime default is NIL).
        adornment.defaultValue.optional = true
      result.named.add NamedParam(arg: arg, local: local,
                                  typeExpr: adornment.typeExpr,
                                  defaultValue: adornment.defaultValue)
    of ":", "=":
      raise newException(GeneError, "parameter annotation requires a parameter")
    else:
      if sawRest:
        raise newException(GeneError, "parameter cannot follow a rest parameter")
      if s.isRestParam:
        if sawOptionalPositional:
          raise newException(GeneError, "rest parameter cannot follow an optional positional parameter")
        result.rest = s[0 .. ^4]
        if result.rest.len == 0:
          raise newException(GeneError, "rest parameter requires a name")
        sawRest = true
        inc i
        # A rest parameter may carry a type (`xs... : T`): every gathered
        # argument is boundary-checked against T. It still cannot have a
        # default — a rest binder is always the (possibly empty) tail.
        let restAdornment = c.parseParamAdornment(paramList, defaultContext, items, i)
        if restAdornment.defaultValue.optional:
          raise newException(GeneError, "rest parameter cannot have a default")
        result.restType = restAdornment.typeExpr
        continue
      else:
        # Explicit nil-admitting parameter types supply an implicit nil default.
        let name = rejectOptionalSuffix(s, "parameter",
          "write `" & s[0 .. ^2] & " : T?` for an optional positional parameter")
        if name.len == 0:
          raise newException(GeneError, "parameter requires a name")
        inc i
        var adornment = c.parseParamAdornment(paramList, defaultContext, items, i)
        if c.parameterTypeAdmitsNil(adornment.typeExpr, typeParams & result.positional):
          adornment.defaultValue.optional = true
        if adornment.defaultValue.optional:
          sawOptionalPositional = true
        elif sawOptionalPositional:
          raise newException(GeneError, "required positional parameter cannot follow an optional positional parameter")
        result.positional.add name
        result.positionalTypes.add adornment.typeExpr
        result.positionalDefaults.add adornment.defaultValue
        continue

proc validateMacroParamPattern(pattern: Value) =
  discard patternBindingNames(pattern)

proc macroTypedPattern(pattern, typeExpr: Value): Value =
  if pattern.kind != vkSymbol or pattern.isRestPattern:
    raise newException(GeneError,
      "macro parameter type annotation requires a binding name")
  newNode(pattern, body = @[newSym(":"), typeExpr])

proc macroDefaultExpr(expr: Value): MacroDefault =
  MacroDefault(optional: true, hasExpr: true, defaultExpr: expr)

proc parseMacroFlatAdornment(items: openArray[Value], i: var int,
                             pattern: Value): tuple[pattern: Value,
                                                    defaultValue: MacroDefault] =
  result.pattern = pattern
  while i < items.len:
    case items[i].symbolText
    of ":":
      inc i
      if i >= items.len:
        raise newException(GeneError,
          "macro parameter annotation requires a type")
      if result.pattern.isTypedPattern:
        raise newException(GeneError,
          "macro parameter already has a type annotation")
      result.pattern = macroTypedPattern(result.pattern, items[i])
      inc i
    of "=":
      inc i
      if i >= items.len:
        raise newException(GeneError,
          "macro parameter default requires a value")
      result.defaultValue = macroDefaultExpr(items[i])
      inc i
    else:
      break

proc isMacroNamedTerminator(value: Value): bool =
  value.kind == vkSymbol and value.symVal in [",", "^", "^^"]

proc macroParamDef(c: Compiler, paramList: Value): tuple[params: seq[MacroParam],
                                                         named: seq[MacroNamedParam],
                                                         rest: string] =
  if paramList.kind != vkList:
    return
  let items = paramList.listItems
  var i = 0
  var sawRest = false
  var sawOptionalPositional = false
  while i < items.len:
    let item = items[i]
    let s = item.symbolText
    case s
    of "":
      if sawRest:
        raise newException(GeneError, "parameter cannot follow a rest parameter")
      inc i
      let adornment = parseMacroFlatAdornment(items, i, item)
      if adornment.defaultValue.optional:
        sawOptionalPositional = true
      elif sawOptionalPositional:
        raise newException(GeneError,
          "required positional parameter cannot follow an optional positional parameter")
      validateMacroParamPattern(adornment.pattern)
      result.params.add MacroParam(pattern: adornment.pattern,
                                   defaultValue: adornment.defaultValue)
    of ",":
      inc i
    of "^", "^^":
      if sawRest:
        raise newException(GeneError, "named parameter cannot follow a rest parameter")
      inc i
      if i >= items.len or items[i].kind != vkSymbol:
        raise newException(GeneError, "named parameter requires a name")
      let arg = rejectOptionalSuffix(items[i].symVal, "named parameter",
        "use a default (`^" & items[i].symVal[0 .. ^2] &
        " = nil`) for an optional macro/fexpr parameter")
      if arg.len == 0:
        raise newException(GeneError, "named parameter requires a name")
      var defaultValue = MacroDefault()
      inc i
      var pattern = newSym(arg)
      if i < items.len:
        let maybePattern = items[i]
        let maybeSymbol = maybePattern.symbolText
        if not maybePattern.isMacroNamedTerminator and
            maybeSymbol notin [":", "="]:
          if maybePattern.kind == vkSymbol:
            let localName = rejectOptionalSuffix(maybePattern.symVal,
              "named parameter local", "use a default `= nil` instead")
            if localName.len == 0:
              raise newException(GeneError,
                "named parameter local requires a name")
            pattern = newSym(localName)
          else:
            pattern = maybePattern
          inc i
      let adornment = parseMacroFlatAdornment(items, i, pattern)
      if adornment.defaultValue.optional:
        defaultValue = adornment.defaultValue
      validateMacroParamPattern(adornment.pattern)
      result.named.add MacroNamedParam(arg: arg, pattern: adornment.pattern,
                                       defaultValue: defaultValue)
    of ":":
      raise newException(GeneError,
        "macro parameter annotation requires a parameter")
    of "=":
      raise newException(GeneError,
        "macro parameter default requires a parameter")
    else:
      if sawRest:
        raise newException(GeneError, "parameter cannot follow a rest parameter")
      if s.isRestParam:
        if sawOptionalPositional:
          raise newException(GeneError,
            "rest parameter cannot follow an optional positional parameter")
        result.rest = s[0 .. ^4]
        if result.rest.len == 0:
          raise newException(GeneError, "rest parameter requires a name")
        sawRest = true
        inc i
        if i < items.len and items[i].symbolText in [":", "="]:
          raise newException(GeneError,
            "rest parameter cannot have an annotation or default")
      else:
        let name = rejectOptionalSuffix(s, "parameter",
          "use a default (`" & s[0 .. ^2] &
          " = nil`) for an optional macro/fexpr parameter")
        if name.len == 0:
          raise newException(GeneError, "parameter requires a name")
        var defaultValue = MacroDefault()
        var pattern = newSym(name)
        inc i
        let adornment = parseMacroFlatAdornment(items, i, pattern)
        if adornment.defaultValue.optional:
          defaultValue = adornment.defaultValue
        if defaultValue.optional:
          sawOptionalPositional = true
        elif sawOptionalPositional:
          raise newException(GeneError,
            "required positional parameter cannot follow an optional positional parameter")
        validateMacroParamPattern(adornment.pattern)
        result.params.add MacroParam(pattern: adornment.pattern,
                                     defaultValue: defaultValue)
  result

proc containsRuntimeSyntaxValue(value: Value, seen: var HashSet[uint64]): bool =
  if value.kind > vkPipeline: return true
  if value.kind notin {vkNode, vkList, vkMap, vkSet, vkHashMap, vkPipeline}: return false
  if seen.containsOrIncl(value.bits): return false
  case value.kind
  of vkNode:
    if containsRuntimeSyntaxValue(value.head, seen): return true
    for item in value.body:
      if containsRuntimeSyntaxValue(item, seen): return true
    for _, item in value.props:
      if containsRuntimeSyntaxValue(item, seen): return true
    for _, item in value.meta:
      if containsRuntimeSyntaxValue(item, seen): return true
  of vkList:
    for item in value.listItems:
      if containsRuntimeSyntaxValue(item, seen): return true
  of vkMap:
    for _, item in value.mapEntries:
      if containsRuntimeSyntaxValue(item, seen): return true
  of vkSet:
    for item in value.setItems:
      if containsRuntimeSyntaxValue(item, seen): return true
  of vkHashMap:
    for item in value.hashMapEntries:
      if containsRuntimeSyntaxValue(item.key, seen) or containsRuntimeSyntaxValue(item.val, seen): return true
  of vkPipeline:
    if containsRuntimeSyntaxValue(value.pipelineInitial, seen): return true
    for stage in value.pipelineStages:
      if containsRuntimeSyntaxValue(stage.head, seen): return true
      for item in stage.body:
        if containsRuntimeSyntaxValue(item, seen): return true
      for _, item in stage.props:
        if containsRuntimeSyntaxValue(item, seen): return true
      for _, item in stage.meta:
        if containsRuntimeSyntaxValue(item, seen): return true
  else: discard
  false

proc evaluateMacroValue(c: var Compiler, def: MacroDef,
                        env: Table[string, Value], callName = ""): Value =
  if macroEvaluator == nil:
    raise newException(GeneError, "macro execution requires a Gene VM evaluator")
  if c.macroSession == nil:
    c.prepareMacroContext(@[])
  if c.macroSession.expansionDepth >= MaxMacroExpansionDepth:
    raise newException(GeneError, "macro expansion depth exceeded")
  let previousSession = activeMacroSession
  activeMacroSession = c.macroSession
  inc c.macroSession.expansionDepth
  try:
    result = macroEvaluator(def, env, c.macroSession, c.budget)
    if not c.macroPhaseCompilation:
      var seen: HashSet[uint64]
      if containsRuntimeSyntaxValue(result, seen):
        c.chunk.macroRuntimeLease = c.macroSession.runtimeState
  except GeneError as error:
    let name = if def.name.len > 0: def.name
               elif callName.len > 0: callName else: "<anonymous>"
    var context = "macro '" & name & "'"
    if c.currentLoc.hasSourceLoc:
      context.add " expanded at " & c.currentLoc.sourceName & ":" & $c.currentLoc.line
    if def.sourceLoc.hasSourceLoc:
      context.add " (defined at " & def.sourceLoc.sourceName & ":" & $def.sourceLoc.line & ")"
    # A phase-local error value belongs to the phase Application's Error
    # protocol. Carry the diagnostic, not a foreign runtime value, back into
    # the host compiler (including sandbox/eval compilation).
    let detail =
      if c.budget != nil and error.msg in ["eval max steps exceeded",
          "eval timeout exceeded", "eval memory limit exceeded"]:
        "compile" & error.msg[4 .. ^1]
      else: error.msg
    let failure = newException(GeneError, context & ": " & detail)
    failure.loc = if error.loc.hasSourceLoc: error.loc else: c.currentLoc
    failure.errorKind = error.errorKind
    failure.errorDetail = error.errorDetail
    raise failure
  finally:
    dec c.macroSession.expansionDepth
    activeMacroSession = previousSession

proc macroDefaultSyntax(c: var Compiler, definition: MacroDef, expr: Value,
                        env: Table[string, Value]): Value =
  # Macro arguments/defaults are syntax. Preserve the existing default syntax
  # contract, including references to an earlier parameter and explicit quote
  # or quasiquote construction, without the old template renaming pass.
  if expr.kind == vkSymbol and env.hasKey(expr.symVal):
    return env[expr.symVal]
  if expr.kind == vkNode and
      (expr.head.isSymbol("quote") or expr.head.isSymbol("quasiquote")):
    var expression: MacroDef
    new(expression)
    expression[] = definition[]
    expression.body = @[expr]
    return c.evaluateMacroValue(expression, env)
  expr

proc macroMetaAsMap(target: Value): Value =
  var entries = initPropTable()
  if target.kind == vkNode:
    for key, val in target.meta:
      entries[key] = val
  newMap(entries)

proc macroMatchesTypeExpr(expr, value: Value): bool

proc macroMatchesBuiltinType(name: string, value: Value): tuple[known, ok: bool] =
  case name
  of "Any":
    (true, true)
  of "Never":
    (true, false)
  of "Nil":
    (true, value.kind == vkNil)
  of "Void":
    (true, value.kind == vkVoid)
  of "Bool":
    (true, value.kind == vkBool)
  of "Str", "String":
    (true, value.kind == vkString)
  of "Char":
    (true, value.kind == vkChar)
  of "Sym", "Symbol":
    (true, value.kind == vkSymbol)
  of "Int", "Integer":
    (true, value.kind == vkInt)
  of "Number":
    (true, value.kind in {vkInt, vkFloat})
  of "Float", "F32", "F64":
    (true, value.kind == vkFloat)
  of "List":
    (true, value.kind == vkList)
  of "Set":
    (true, value.kind == vkSet)
  of "Map":
    (true, value.kind in {vkMap, vkHashMap})
  of "PropMap":
    (true, value.kind == vkMap)
  of "HashMap":
    (true, value.kind == vkHashMap)
  of "Bytes":
    (true, value.kind == vkBytes)
  of "Regex":
    (true, value.kind == vkRegex)
  of "Date":
    (true, value.kind == vkDate)
  of "Time":
    (true, value.kind == vkTime)
  of "DateTime":
    (true, value.kind == vkDateTime)
  of "Timezone":
    (true, value.kind == vkTimezone)
  of "Duration":
    (true, value.kind == vkDuration)
  of "Gene", "Node":
    (true, value.kind == vkNode)
  of "Path":
    (true, value.kind == vkNode and value.head.isSymbol("Path"))
  else:
    (false, false)

proc macroMatchesTypeExpr(expr, value: Value): bool =
  case expr.kind
  of vkSymbol:
    let name = expr.symVal
    # `T?` is sugar for `(? T)`; see matchesTypeExpr in vm.nim.
    if name.len > 1 and name[^1] == '?':
      return value.kind == vkNil or
             macroMatchesTypeExpr(newSym(name[0 ..< name.len - 1]), value)
    let builtin = macroMatchesBuiltinType(name, value)
    if builtin.known:
      return builtin.ok
    raise newException(GeneError, "unknown macro type annotation: " & name)
  of vkNode:
    if expr.head.kind == vkSymbol:
      case expr.head.symVal
      of "|":
        for alt in expr.body:
          if macroMatchesTypeExpr(alt, value):
            return true
        return false
      of "?":
        if expr.body.len == 0:
          raise newException(GeneError, "(? T ...) expects at least one macro type")
        if value.kind == vkNil:
          return true
        for alt in expr.body:
          if macroMatchesTypeExpr(alt, value):
            return true
        return false
      of "opt":
        # Legacy internal compatibility only. Public signatures and diagnostics
        # use the canonical `(? T)` spelling.
        if expr.body.len != 1:
          raise newException(GeneError, "(? T) expects one macro type")
        return value.kind == vkNil or macroMatchesTypeExpr(expr.body[0], value)
      of "List":
        if value.kind != vkList:
          return false
        if expr.body.len == 0:
          return true
        if expr.body.len != 1:
          raise newException(GeneError, "(List T) expects one macro item type")
        for item in value.listItems:
          if not macroMatchesTypeExpr(expr.body[0], item):
            return false
        return true
      of "Map", "PropMap":
        if value.kind != vkMap:
          return false
        if expr.body.len == 0:
          return true
        if expr.body.len notin [1, 2]:
          raise newException(GeneError, "(Map K V) expects macro key and value types")
        let valueType = expr.body[^1]
        for key, item in value.mapEntries:
          if expr.body.len == 2 and not macroMatchesTypeExpr(expr.body[0], newSym(key)):
            return false
          if not macroMatchesTypeExpr(valueType, item):
            return false
        return true
      else:
        discard
    raise newException(GeneError, "unsupported macro type annotation")
  else:
    raise newException(GeneError, "unsupported macro type annotation")

proc macroTryMatch(pattern, target: Value,
                   env: var Table[string, Value]): bool

proc macroPatternItems(target: Value): tuple[items: seq[Value], ok: bool] =
  case target.kind
  of vkList:
    for item in target.listItems:
      result.items.add item
    result.ok = true
  of vkNode:
    for item in target.body:
      result.items.add item
    result.ok = true
  else:
    discard

proc macroMatchSequence(patterns, items: seq[Value],
                        env: var Table[string, Value]): bool =
  var ps: seq[Value]
  for pattern in patterns:
    if not pattern.isSymbol(","):
      ps.add pattern
  var restIdx = -1
  for i, pattern in ps:
    if pattern.isRestPattern:
      restIdx = i
      break
  var trial = env
  if restIdx < 0:
    if ps.len != items.len:
      return false
    for i in 0 ..< ps.len:
      if not macroTryMatch(ps[i], items[i], trial):
        return false
    env = trial
    return true
  let before = restIdx
  let after = ps.len - restIdx - 1
  if items.len < before + after:
    return false
  for i in 0 ..< before:
    if not macroTryMatch(ps[i], items[i], trial):
      return false
  let restName = restPatternName(ps[restIdx])
  if restName != "_":
    var rest: seq[Value]
    for i in before ..< items.len - after:
      rest.add items[i]
    trial[restName] = newList(rest)
  for i in 0 ..< after:
    if not macroTryMatch(ps[restIdx + 1 + i],
                         items[items.len - after + i], trial):
      return false
  env = trial
  true

proc macroTryMatch(pattern, target: Value,
                   env: var Table[string, Value]): bool =
  case pattern.kind
  of vkSymbol:
    let name = pattern.symVal
    if name == "_":
      return true
    env[name] = target
    true
  of vkInt, vkFloat, vkString, vkBool, vkChar, vkNil, vkVoid:
    equal(pattern, target)
  of vkList:
    let (items, ok) = macroPatternItems(target)
    if not ok:
      return false
    macroMatchSequence(pattern.listItems, items, env)
  of vkMap:
    var trial = env
    for key, valuePattern in pattern.mapEntries:
      var field: Value
      case target.kind
      of vkMap:
        if not target.mapEntries.hasKey(key):
          return false
        field = target.mapEntries[key]
      of vkNode:
        if not target.props.hasKey(key):
          return false
        field = target.props[key]
      else:
        return false
      if not macroTryMatch(valuePattern, field, trial):
        return false
    env = trial
    true
  of vkNode:
    if pattern.isTypedPattern:
      pattern.requireTypedPatternShape()
      if not macroMatchesTypeExpr(pattern.body[1], target):
        return false
      let name = pattern.head.symVal
      if name != "_":
        env[name] = target
      return true
    if pattern.head.kind == vkSymbol:
      case pattern.head.symVal
      of "unquote":
        if pattern.body.len != 1 or pattern.body[0].kind != vkSymbol:
          raise newException(GeneError, "pattern %name expects a name")
        if not env.hasKey(pattern.body[0].symVal):
          raise newException(GeneError,
            "macro pattern comparison requires an earlier binding: " &
              pattern.body[0].symVal)
        return equal(target, env[pattern.body[0].symVal])
      of "@":
        if pattern.body.len != 2:
          raise newException(GeneError,
            "pattern (@ meta value) expects two patterns")
        var trial = env
        if not macroTryMatch(pattern.body[0], macroMetaAsMap(target), trial):
          return false
        if not macroTryMatch(pattern.body[1], target, trial):
          return false
        env = trial
        return true
      of "|":
        discard patternBindingNames(pattern)
        for sub in pattern.body:
          var trial = env
          if macroTryMatch(sub, target, trial):
            env = trial
            return true
        return false
      of "&":
        var trial = env
        for sub in pattern.body:
          if not macroTryMatch(sub, target, trial):
            return false
        env = trial
        return true
      of "not":
        if pattern.body.len != 1:
          raise newException(GeneError, "pattern (not p) expects one pattern")
        discard patternBindingNames(pattern)
        var throwaway = env
        return not macroTryMatch(pattern.body[0], target, throwaway)
      else:
        discard
    if target.kind != vkNode:
      return false
    if not equal(pattern.head, target.head):
      return false
    var trial = env
    for key, valuePattern in pattern.props:
      if not target.props.hasKey(key):
        return false
      if not macroTryMatch(valuePattern, target.props[key], trial):
        return false
    if not macroMatchSequence(pattern.body, target.body, trial):
      return false
    env = trial
    true
  else:
    false

proc bindMacroPattern(pattern, target: Value,
                      env: var Table[string, Value],
                      what: string) =
  var trial = env
  if not macroTryMatch(pattern, target, trial):
    raise newException(GeneError, "macro " & what & " pattern did not match")
  env = trial

proc requiredMacroParamCount(params: openArray[MacroParam]): int =
  for param in params:
    if param.defaultValue.optional:
      return
    inc result

proc bindMacroImplicitVoid(pattern: Value, env: var Table[string, Value]) =
  for name in patternBindingNames(pattern):
    env[name] = VOID

proc bindMacroDefault(c: var Compiler, definition: MacroDef, pattern: Value,
                      defaultValue: MacroDefault,
                      env: var Table[string, Value],
                      what: string) =
  if defaultValue.hasExpr:
    bindMacroPattern(pattern, c.macroDefaultSyntax(definition, defaultValue.defaultExpr, env),
                     env, what)
  else:
    bindMacroImplicitVoid(pattern, env)

proc matchMacroArguments(c: var Compiler, def: MacroDef, node: Value): Table[string, Value] =
  let args = node.body
  let requiredParams = requiredMacroParamCount(def.params)
  if args.len < requiredParams:
    raise newException(GeneError, "macro expects at least " & $requiredParams &
      " argument(s), got " & $args.len)
  if def.rest.len == 0 and args.len > def.params.len:
    raise newException(GeneError, "macro expects at most " & $def.params.len &
      " argument(s), got " & $args.len)
  var env = initTable[string, Value]()
  for i, param in def.params:
    if i < args.len:
      bindMacroPattern(param.pattern, args[i], env, "argument")
    elif param.defaultValue.optional:
      c.bindMacroDefault(def, param.pattern, param.defaultValue, env, "argument")
  for p in def.named:
    if node.props.hasKey(p.arg):
      bindMacroPattern(p.pattern, node.props[p.arg], env, "named argument")
    elif p.defaultValue.optional:
      c.bindMacroDefault(def, p.pattern, p.defaultValue, env, "named argument")
    else:
      raise newException(GeneError,
        "macro missing named argument: " & p.arg)
  for key, _ in node.props:
    var found = false
    for p in def.named:
      if p.arg == key:
        found = true
        break
    if not found:
      raise newException(GeneError,
        "macro got unexpected named argument: " & key)
  if def.rest.len > 0:
    var rest: seq[Value]
    for i in def.params.len ..< args.len:
      rest.add args[i]
    env[def.rest] = newList(rest)
  env

proc expandMacro(c: var Compiler, def: MacroDef, node: Value): Value =
  c.evaluateMacroValue(def, c.matchMacroArguments(def, node), node.head.print())

proc runtimeExpansionContext(c: Compiler): RuntimeExpansionContext =
  var preparation = CompilerPreparationCache()
  if c.macroSession != nil and c.macroContext != nil:
    let state = c.macroSession.macroCompilerState()
    let key = cast[pointer](c.macroContext)
    if not state.runtimePreparations.hasKey(key):
      state.runtimePreparations[key] = (c.macroContext, preparation)
    preparation = state.runtimePreparations[key].cache
  result = RuntimeExpansionContext(macros: c.visibleMacroBindings(),
    compilerPreparation: preparation,
    sourceContext: c.macroContext, sourceLoc: c.currentLoc,
    namespacePath: c.namespacePath, inFunction: c.inFunction,
    inGenerator: c.inGenerator, inStatementFn: c.inStatementFn,
    selfAvailable: c.selfAvailable, loopDepth: c.loopDepth,
    allowAmbientImports: c.allowAmbientImports)
  for name in c.letNames: result.letNames.add name
  result.letNames.sort()

proc markMacroResult(value: Value): Value =
  var props = if value.kind == vkNode and value.head.isSymbol("do"):
                value.props else: initPropTable()
  props["macro_result"] = TRUE
  if value.kind == vkNode and value.head.isSymbol("do"):
    newNode(value.head, props, value.body, value.meta,
            immutable = value.nodeImmutable)
  else:
    newNode(newSym("do"), props, @[value])

proc validateConditionalClauses(node: Value) =
  if node.body.len < 2 or node.body[1].kind != vkNode or
      not node.body[1].head.isSymbol("then"):
    return
  var sawElse = false
  for i in 2 ..< node.body.len:
    let clause = node.body[i]
    if sawElse or clause.kind != vkNode or clause.head.kind != vkSymbol or
        clause.head.symVal notin ["elif", "else"]:
      raise newException(GeneError,
        "if requires elif/else clauses; macro calls are only expanded in expression positions")
    sawElse = clause.head.isSymbol("else")

proc compileMacroCall(c: var Compiler, node: Value, def: MacroDef,
                      tail = false) =
  if def.runtime:
    let index = c.chunk.runtimeMacroCalls.len
    c.chunk.runtimeMacroCalls.add RuntimeMacroCall(definition: def,
      syntax: node, context: c.runtimeExpansionContext())
    c.chunk.callSites[c.emit(opInvokeRuntimeMacro, index)] = node
    discard c.emit(opExecuteRuntimeMacro, index, tail = tail)
    # Runtime-generated code may assign any visible mutable caller binding.
    c.ordinaryFnNames.clear()
    c.generatorFnNames.clear()
    return
  if c.macroExpansionDepth >= MaxMacroExpansionDepth:
    raise newException(GeneError, "macro expansion depth exceeded")
  inc c.macroExpansionDepth
  try:
    let expanded = c.expandMacro(def, node)
    compileExpr(c, markMacroResult(expanded), tail = tail)
    # Only cache expansions whose bindings remain those of this compiler.
    # Shared syntax can be expanded more than once with different results;
    # such occurrences conservatively stop contributing an AST proof.
    if c.compiledMacroResults.hasKey(node.bits):
      c.compiledMacroResults.del(node.bits)
      c.repeatedMacroSites.incl node.bits
    elif node.bits notin c.repeatedMacroSites and not ownsResultBindings(expanded):
      c.compiledMacroResults[node.bits] = expanded
  finally:
    dec c.macroExpansionDepth

proc compileMacro(c: var Compiler, node: Value) =
  let body = node.body
  if body.len < 2:
    raise newException(GeneError, "macro requires a name and parameter vector")
  if body[0].kind != vkSymbol or body[0].symVal.len == 0:
    raise newException(GeneError, "macro name must be a symbol")
  validateBindingName(body[0].symVal)
  if body[0].symVal in CoreSpecialFormNames:
    raise newException(GeneError, "macro name is reserved syntax: " & body[0].symVal)
  if body[1].kind != vkList:
    raise newException(GeneError, "macro requires a parameter vector")
  let sig = c.macroParamDef(body[1])
  var parameterNames = initHashSet[string]()
  for parameter in sig.params:
    for name in patternBindingNames(parameter.pattern):
      if parameterNames.containsOrIncl(name):
        raise newException(GeneError, "duplicate macro parameter: " & name)
  for parameter in sig.named:
    for name in patternBindingNames(parameter.pattern):
      if parameterNames.containsOrIncl(name):
        raise newException(GeneError, "duplicate macro parameter: " & name)
  if sig.rest.len > 0 and parameterNames.containsOrIncl(sig.rest):
    raise newException(GeneError, "duplicate macro parameter: " & sig.rest)
  if body[0].symVal in c.ownMacroNames:
    raise newException(GeneError, "duplicate macro: " & body[0].symVal)
  if body[0].symVal in c.ownValueNames or c.localSlot(body[0].symVal) >= 0:
    raise newException(GeneError,
      "macro '" & body[0].symVal & "' conflicts with a binding of the same name")
  if not c.hasMacros:
    c.macros = initTable[string, MacroDef]()
  var macroBody: seq[Value]
  for i in 2 ..< body.len:
    macroBody.add body[i]
  c.macros[body[0].symVal] = MacroDef(params: sig.params,
                                      named: sig.named,
                                      rest: sig.rest,
                                      body: macroBody,
                                      name: body[0].symVal,
                                      sourceLoc: c.currentLoc,
                                      context: c.macroContext,
                                      namespacePath: c.namespacePath,
                                      lexicalMacros: c.macros)
  let definition = c.macros[body[0].symVal]
  definition.runtime = c.inFunction or node.bits notin c.staticTopLevelImpls
  c.ownMacroNames.incl body[0].symVal
  if not node.declarationIsPrivate:
    c.publicMacroNames.incl body[0].symVal
  c.hasMacros = true
  if c.moduleMacroExports != nil and node.bits in c.staticTopLevelImpls and
      not node.declarationIsPrivate:
    let path = (c.namespacePath & @[body[0].symVal]).join("/")
    c.moduleMacroExports[][path] = c.macros[body[0].symVal]
  if definition.runtime:
    for name in parameterNames: definition.runtimeParamNames.add name
    definition.runtimeParamNames.sort()
    var parameters: seq[Value]
    for name in definition.runtimeParamNames: parameters.add newSym(name)
    var slot = -1
    if c.useLocalSlots:
      slot = c.localNames.len
      c.localNames.add "\x00gene_macro:" & $c.nextGensym()
      c.chunk.privateLocalSlots.add slot
    compileExpr(c, newNode(newSym("fn"), body = @[newList(parameters)] & macroBody))
    let proto = c.chunk.functions[^1]
    proto.name = "macro " & definition.name
    proto.isMacroBody = true
    proto.fastBindPositionalScalars = false
    proto.needsCallScope = true
    proto.poolCallScope = false
    proto.callScopeNeedsSlotNames = true
    let index = c.chunk.runtimeMacroDefinitions.len
    c.chunk.runtimeMacroDefinitions.add RuntimeMacroDefinition(definition: definition, slot: slot)
    discard c.emit(opDefineRuntimeMacro, index)
  else:
    c.emitConst NIL

proc expansionLoc(unit: SourceUnit, value: Value,
                  fallback: SourceLoc): SourceLoc =
  if value.kind in {vkNode, vkList, vkMap, vkSet, vkHashMap} and
      unit.locs.hasKey(value.bits):
    unit.locs[value.bits]
  else:
    fallback

proc markExpandedContainers(value: Value, loc: SourceLoc, macroName: string,
                            locs: var Table[uint64, SourceLoc],
                            provenance: var Table[uint64,
                                                  ExpansionProvenance]) =
  if value.kind notin {vkNode, vkList, vkMap, vkSet, vkHashMap, vkPipeline}:
    return
  if not locs.hasKey(value.bits):
    locs[value.bits] = loc
    provenance[value.bits] = ExpansionProvenance(sourceLoc: loc,
                                                  macroName: macroName)
  case value.kind
  of vkPipeline:
    markExpandedContainers(value.pipelineInitial, loc, macroName,
                           locs, provenance)
    for stage in value.pipelineStages:
      markExpandedContainers(stage.head, loc, macroName, locs, provenance)
      for _, item in stage.props:
        markExpandedContainers(item, loc, macroName, locs, provenance)
      for item in stage.body:
        markExpandedContainers(item, loc, macroName, locs, provenance)
      for _, item in stage.meta:
        markExpandedContainers(item, loc, macroName, locs, provenance)
  of vkNode:
    markExpandedContainers(value.head, loc, macroName, locs, provenance)
    for _, item in value.meta:
      markExpandedContainers(item, loc, macroName, locs, provenance)
    for _, item in value.props:
      markExpandedContainers(item, loc, macroName, locs, provenance)
    for item in value.body:
      markExpandedContainers(item, loc, macroName, locs, provenance)
  of vkList:
    for item in value.listItems:
      markExpandedContainers(item, loc, macroName, locs, provenance)
  of vkMap:
    for _, item in value.mapEntries:
      markExpandedContainers(item, loc, macroName, locs, provenance)
  of vkSet:
    for item in value.setItems:
      markExpandedContainers(item, loc, macroName, locs, provenance)
  of vkHashMap:
    for entry in value.hashMapEntries:
      markExpandedContainers(entry.key, loc, macroName, locs, provenance)
      markExpandedContainers(entry.val, loc, macroName, locs, provenance)
  else:
    discard

proc rejectPipelineSyntaxStage(c: Compiler, stage: PipelineStage)
proc pathSymbolSegments(value: Value): seq[string]

proc frontendImportMacros(c: var Compiler, node: Value) =
  let spec = parseImportSpec(node)
  let exported =
    if spec.fromModule: c.importedMacroSets.getOrDefault(spec.importKey)
    else: builtinNamespaceMacros(spec.nsSegments)
  if spec.alias.len > 0:
    discard c.reserveLocal(spec.alias)
  for selection in spec.selections:
    if exported.hasKey(selection.name):
      c.importMacro(selection.local, exported[selection.name])
      if spec.reexport: c.publicMacroNames.incl selection.local
    else:
      discard c.reserveLocal(selection.local, allowFexprName = true)
  if spec.wildcard or spec.alias.len > 0:
    let prefix = if spec.wildcardSegments.len > 0:
                   spec.wildcardSegments.join("/") & "/" else: ""
    for path, definition in exported:
      if not path.startsWith(prefix): continue
      let relative = path[prefix.len .. ^1]
      let local = if spec.alias.len > 0: spec.alias & "/" & relative else: relative
      c.importMacro(local, definition)
      if spec.reexport: c.publicMacroNames.incl local

proc expandMacroTree(c: var Compiler, unit: SourceUnit, value: Value,
                    fallback: SourceLoc, locs: var Table[uint64, SourceLoc],
                    provenance: var Table[uint64, ExpansionProvenance],
                    allowSlot = false): Value

proc expandQuotedMacroTree(c: var Compiler, unit: SourceUnit, value: Value,
                          depth: int, fallback: SourceLoc,
                          locs: var Table[uint64, SourceLoc],
                          provenance: var Table[uint64, ExpansionProvenance]): Value =
  let loc = unit.expansionLoc(value, fallback)
  defer:
    if result.kind in {vkNode, vkList, vkMap, vkPipeline}:
      locs[result.bits] = loc
      if provenance.hasKey(value.bits): provenance[result.bits] = provenance[value.bits]
  case value.kind
  of vkPipeline:
    var stages: seq[PipelineStage]
    for stage in value.pipelineStages:
      var expanded = stage
      expanded.head = c.expandQuotedMacroTree(unit, stage.head, depth, loc, locs, provenance)
      expanded.body = @[]
      for item in stage.body:
        expanded.body.add c.expandQuotedMacroTree(unit, item, depth, loc, locs, provenance)
      for key, item in stage.props:
        expanded.props[key] = c.expandQuotedMacroTree(unit, item, depth, loc, locs, provenance)
      for key, item in stage.meta:
        expanded.meta[key] = c.expandQuotedMacroTree(unit, item, depth, loc, locs, provenance)
      stages.add expanded
    newPipeline(c.expandQuotedMacroTree(unit, value.pipelineInitial, depth, loc, locs, provenance),
      stages, value.pipelineImmutable)
  of vkNode:
    if value.head.isSymbol("unquote") and depth == 1:
      var body: seq[Value]
      for item in value.body: body.add c.expandMacroTree(unit, item, loc, locs, provenance)
      return newNode(value.head, value.props, body, value.meta, value.nodeImmutable)
    let next = if value.head.isSymbol("quasiquote"): depth + 1
               elif value.head.isSymbol("unquote"): depth - 1 else: depth
    var props, meta = initPropTable()
    var body: seq[Value]
    for key, item in value.props:
      props[key] = c.expandQuotedMacroTree(unit, item, next, loc, locs, provenance)
    for key, item in value.meta:
      meta[key] = c.expandQuotedMacroTree(unit, item, next, loc, locs, provenance)
    for item in value.body:
      body.add c.expandQuotedMacroTree(unit, item, next, loc, locs, provenance)
    newNode(c.expandQuotedMacroTree(unit, value.head, next, loc, locs, provenance),
      props, body, meta, value.nodeImmutable)
  of vkList:
    var items: seq[Value]
    for item in value.listItems:
      items.add c.expandQuotedMacroTree(unit, item, depth, loc, locs, provenance)
    newList(items, value.listImmutable)
  of vkMap:
    var entries = initPropTable()
    for key, item in value.mapEntries:
      entries[key] = c.expandQuotedMacroTree(unit, item, depth, loc, locs, provenance)
    newMap(entries, value.mapImmutable)
  else: value

proc expandMacroTree(c: var Compiler, unit: SourceUnit, value: Value,
                     fallback: SourceLoc,
                     locs: var Table[uint64, SourceLoc],
                     provenance: var Table[uint64,
                                           ExpansionProvenance],
                     allowSlot: bool): Value =
  consumeCompileStep(c.budget)
  let loc = unit.expansionLoc(value, fallback)
  defer:
    if result.kind in {vkNode, vkList, vkMap, vkSet, vkHashMap, vkPipeline}:
      locs[result.bits] = loc
      if provenance.hasKey(value.bits):
        provenance[result.bits] = provenance[value.bits]
  case value.kind
  of vkPipeline:
    var stages: seq[PipelineStage]
    for stage in value.pipelineStages:
      c.rejectPipelineSyntaxStage(stage)
      var props = initPropTable()
      for key, item in stage.props:
        props[key] = c.expandMacroTree(unit, item, stage.sourceLoc,
                                       locs, provenance, allowSlot = true)
      var body: seq[Value]
      for item in stage.body:
        body.add c.expandMacroTree(unit, item, stage.sourceLoc,
                                   locs, provenance, allowSlot = true)
      let meta = stage.meta
      let head = c.expandMacroTree(unit, stage.head, stage.sourceLoc,
                                  locs, provenance, allowSlot = true)
      let detected = detectPipelineSlot(head, props, body)
      if detected.count > 1:
        raise newException(GeneError,
          "macro expansion produced more than one direct '_' pipeline slot")
      stages.add PipelineStage(
        kind: stage.kind,
        head: head,
        props: props, body: body, meta: meta,
        sourceLoc: stage.sourceLoc, slot: detected.slot)
    result = newPipeline(
      c.expandMacroTree(unit, value.pipelineInitial, loc, locs, provenance),
      stages, value.pipelineImmutable)
  of vkNode:
    let macroName = if value.head.kind == vkSymbol: value.head.symVal
                    else: value.head.pathSymbolSegments.join("/")
    if c.hasMacros and c.macros.hasKey(macroName):
      if c.macros[macroName].runtime: return value
      if c.macroExpansionDepth >= MaxMacroExpansionDepth:
        raise newException(GeneError, "macro expansion depth exceeded")
      inc c.macroExpansionDepth
      try:
        let expanded = c.expandMacro(c.macros[macroName], value)
        if allowSlot and expanded.isSymbol("_"): return expanded
        let marked = markMacroResult(expanded)
        markExpandedContainers(expanded, loc, macroName, locs, provenance)
        markExpandedContainers(marked, loc, macroName, locs, provenance)
        return c.expandMacroTree(unit, marked, loc, locs, provenance)
      finally:
        dec c.macroExpansionDepth
    # Quoted syntax is data; expanding inside it would change the macro
    # language rather than the program that consumes the artifact.
    if value.head.isSymbol("quote"):
      return value
    if value.head.isSymbol("quasiquote"):
      return c.expandQuotedMacroTree(unit, value, 0, loc, locs, provenance)
    if value.head.isSymbol("macro"):
      c.currentLoc = loc
      c.compileMacro(value)
      return if c.macros[value.body[0].symVal].runtime: value else: NIL
    if value.head.isSymbol("import"):
      c.frontendImportMacros(value)
      return value
    let declarationPath = value.head.pathSymbolSegments
    if declarationPath.len == 2 and declarationPath[0] == "ffi" and
        declarationPath[1] in ["library", "fn", "struct", "union", "callback", "signature"]:
      if value.body.len > 0 and value.body[0].kind == vkSymbol:
        discard c.reserveLocal(value.body[0].symVal)
      return value
    if value.head.isSymbol("mod") or value.head.isSymbol("import_impl") or
        value.head.isSymbol("web_module"):
      return value
    if value.head.isSymbol("alias") and value.body.len > 0:
      if value.body[0].kind == vkSymbol: discard c.reserveLocal(value.body[0].symVal)
      return value # aliases retain an unevaluated type expression
    if value.head.kind == vkSymbol and value.head.symVal in ["type", "enum", "protocol"]:
      if value.body.len == 0 or value.body[0].kind != vkSymbol: return value
      let kind = value.head.symVal
      discard c.reserveLocal(value.body[0].symVal)
      var body = value.body
      var first = 1
      if kind == "type" and body.len > 2 and body[1].isSymbol(":"):
        body[2] = c.expandMacroTree(unit, body[2], loc, locs, provenance)
        first = 3
      elif kind == "enum" and body.len > 1 and body[1].kind == vkList:
        first = 2
      for i in first ..< body.len:
        let member = body[i]
        let allowed = member.kind == vkNode and member.head.kind == vkSymbol and
          (member.head.symVal == "message" or
           (kind in ["type", "enum"] and member.head.symVal == "impl") or
           (kind == "type" and member.head.symVal == "ctor") or
           (kind == "protocol" and member.head.symVal == "derive"))
        if allowed:
          body[i] = c.expandMacroTree(unit, member, loc, locs, provenance)
        elif kind != "enum":
          raise newException(GeneError, kind & " body requires member declarations; " &
            "macro calls are only expanded in expression positions")
        # Enum variants and their payload types are declaration data, even
        # when a variant spelling also names an ordinary macro.
      var props = value.props
      let evaluatedList = if kind == "type": "impl" elif kind == "protocol": "inherit" else: ""
      if evaluatedList.len > 0 and props.hasKey(evaluatedList):
        props[evaluatedList] = c.expandMacroTree(unit, props[evaluatedList], loc, locs, provenance)
      if kind == "type" and props.hasKey("derive") and props["derive"].kind == vkList:
        var requests: seq[Value]
        for request in props["derive"].listItems:
          if request.kind == vkNode:
            requests.add newNode(c.expandMacroTree(unit, request.head, loc, locs, provenance),
              request.props, request.body, request.meta, request.nodeImmutable)
          else:
            requests.add c.expandMacroTree(unit, request, loc, locs, provenance)
        props["derive"] = newList(requests, props["derive"].listImmutable)
      return newNode(value.head, props, body, value.meta, value.nodeImmutable)
    if value.head.isSymbol("impl") and value.body.len > 0:
      var body = value.body
      body[0] = c.expandMacroTree(unit, body[0], loc, locs, provenance)
      let first = if body.len >= 3 and body[1].isSymbol("for"): 3 else: 1
      if first == 3:
        body[2] = c.expandMacroTree(unit, body[2], loc, locs, provenance)
      for i in first ..< body.len:
        if body[i].kind != vkNode or not body[i].head.isSymbol("message"):
          raise newException(GeneError, "impl body requires message declarations; " &
            "macro calls are only expanded in expression positions")
        body[i] = c.expandMacroTree(unit, body[i], loc, locs, provenance)
      return newNode(value.head, value.props, body, value.meta, value.nodeImmutable)
    if value.head.isSymbol("ns") and value.body.len > 0 and value.body[0].kind == vkSymbol:
      let name = value.body[0].symVal
      var inner = c.childCompiler()
      inner.namespacePath = c.namespacePath & @[name]
      inner.markStaticImplForms(value.body, 1)
      var body = @[value.body[0]]
      for i in 1 ..< value.body.len:
        body.add inner.expandMacroTree(unit, value.body[i], loc, locs, provenance)
      discard c.reserveLocal(name)
      for local in inner.ownMacroNames:
        let qualified = name & "/" & local
        c.macros[qualified] = inner.macros[local]
        c.hasMacros = true
        c.ownMacroNames.incl qualified
        if local in inner.publicMacroNames and not value.declarationIsPrivate:
          c.publicMacroNames.incl qualified
      return newNode(value.head, value.props, body, value.meta, value.nodeImmutable)
    if value.head.isSymbol("for") and value.body.len >= 3:
      var body = value.body
      body[2] = c.expandMacroTree(unit, body[2], loc, locs, provenance)
      var inner = c.childCompiler()
      for name in patternBindingNames(body[0]): discard inner.reserveLocal(name)
      for i in 3 ..< body.len:
        body[i] = inner.expandMacroTree(unit, body[i], loc, locs, provenance)
      return newNode(value.head, value.props, body, value.meta, value.nodeImmutable)
    if value.head.isSymbol("repeat") and value.body.len >= 3 and value.body[1].isSymbol("in"):
      var body = value.body
      body[2] = c.expandMacroTree(unit, body[2], loc, locs, provenance)
      for name in patternBindingNames(body[0]): discard c.reserveLocal(name)
      for i in 3 ..< body.len:
        body[i] = c.expandMacroTree(unit, body[i], loc, locs, provenance)
      return newNode(value.head, value.props, body, value.meta, value.nodeImmutable)
    if value.head.isSymbol("scope") or value.head.isSymbol("spawn") or
        value.head.isSymbol("supervisor"):
      var inner = c.childCompiler()
      var body: seq[Value]
      for item in value.body:
        body.add inner.expandMacroTree(unit, item, loc, locs, provenance)
      var props = value.props
      if value.head.isSymbol("supervisor"):
        for key, item in value.props:
          if key != "strategy":
            props[key] = c.expandMacroTree(unit, item, loc, locs, provenance)
      return newNode(value.head, props, body, value.meta, value.nodeImmutable)
    if value.head.isSymbol("try"):
      var body: seq[Value]
      var i = 0
      # The try and ensure bodies share their enclosing lexical scope. Each
      # catch owns its bindings. Error type syntax is not an invocation.
      while i < value.body.len and not value.body[i].isSymbol("catch") and
          not value.body[i].isSymbol("ensure"):
        body.add c.expandMacroTree(unit, value.body[i], loc, locs, provenance)
        inc i
      while i < value.body.len and value.body[i].isSymbol("catch"):
        body.add value.body[i]
        inc i
        if i >= value.body.len: break
        body.add value.body[i]
        inc i
        var inner = c.childCompiler()
        discard inner.reserveLocal(CatchErrorBindingName)
        while i < value.body.len and not value.body[i].isSymbol("catch") and
            not value.body[i].isSymbol("ensure"):
          body.add inner.expandMacroTree(unit, value.body[i], loc, locs, provenance)
          inc i
      if i < value.body.len:
        body.add value.body[i]
        inc i
      while i < value.body.len:
        body.add c.expandMacroTree(unit, value.body[i], loc, locs, provenance)
        inc i
      return newNode(value.head, value.props, body, value.meta, value.nodeImmutable)
    if value.head.isSymbol("fn") or value.head.isSymbol("message") or
        value.head.isSymbol("ctor") or value.head.isSymbol("derive"):
      var parameterIndex = 0
      if value.head.isSymbol("message") or
          (value.body.len > 1 and value.body[0].kind in {vkSymbol, vkNode} and
           value.body[1].kind == vkList):
        parameterIndex = 1
      if parameterIndex >= value.body.len or value.body[parameterIndex].kind != vkList:
        return value # normal backend validation reports malformed signatures
      if value.head.isSymbol("fn") and parameterIndex == 1:
        let name = functionNameAndTypeParams(value.body[0]).name
        if name.len > 0: discard c.reserveLocal(name, allowFexprName = true)
      var inner = c.signatureCompiler(value.body[parameterIndex])
      inner.inFunction = true
      if value.head.isSymbol("message") or value.head.isSymbol("ctor"):
        discard inner.reserveLocal("self")
      if value.head.isSymbol("fn") and parameterIndex == 1:
        for name in functionNameAndTypeParams(value.body[0]).typeParams:
          discard inner.reserveLocal(name)
      var body = value.body
      var parameters = value.body[parameterIndex].listItems
      for i in 1 ..< parameters.len:
        if parameters[i - 1].isSymbol("="):
          parameters[i] = inner.expandMacroTree(unit, parameters[i], loc, locs, provenance)
      body[parameterIndex] = newList(parameters, value.body[parameterIndex].listImmutable)
      var first = parameterIndex + 1
      if first < body.len and body[first].isSymbol(":"): first += 2
      for i in first ..< body.len:
        body[i] = inner.expandMacroTree(unit, body[i], loc, locs, provenance)
      result = newNode(value.head, value.props, body, value.meta, value.nodeImmutable)
      locs[result.bits] = loc
      return
    if value.head.isSymbol("if"):
      validateConditionalClauses(value)
      if value.body.len > 1 and value.body[1].kind == vkNode and
          value.body[1].head.isSymbol("then"):
        var body = @[c.expandMacroTree(unit, value.body[0], loc, locs, provenance)]
        for i in 1 ..< value.body.len:
          let clause = value.body[i]
          var forms: seq[Value]
          for item in clause.body:
            forms.add c.expandMacroTree(unit, item, loc, locs, provenance)
          body.add newNode(clause.head, clause.props, forms, clause.meta, clause.nodeImmutable)
        result = newNode(value.head, value.props, body, value.meta, value.nodeImmutable)
        locs[result.bits] = loc
        return
    if value.head.isSymbol("match") and value.body.len > 0:
      var body = @[c.expandMacroTree(unit, value.body[0], loc, locs, provenance)]
      for i in 1 ..< value.body.len:
        let clause = value.body[i]
        if clause.kind != vkNode or clause.head.kind != vkSymbol or
            clause.head.symVal notin ["when", "else"]:
          raise newException(GeneError, "match requires when/else clauses; " &
            "macro calls are only expanded in expression positions")
        var inner = c.childCompiler()
        var forms: seq[Value]
        var first = 0
        if clause.head.isSymbol("when") and clause.body.len > 0:
          forms.add clause.body[0]
          for name in patternBindingNames(clause.body[0]): discard inner.reserveLocal(name)
          first = 1
        for j in first ..< clause.body.len:
          forms.add inner.expandMacroTree(unit, clause.body[j], loc, locs, provenance)
        body.add newNode(clause.head, clause.props, forms, clause.meta, clause.nodeImmutable)
      result = newNode(value.head, value.props, body, value.meta, value.nodeImmutable)
      locs[result.bits] = loc
      return
    if value.head.isSymbol("do"):
      let marked = value.props.getOrDefault("macro_result", FALSE) == TRUE
      var inner = if marked: c.childCompiler() else: c
      var body: seq[Value]
      for item in value.body:
        body.add inner.expandMacroTree(unit, item, loc, locs, provenance)
      if not marked: c = inner
      result = newNode(value.head, value.props, body, value.meta, value.nodeImmutable)
      locs[result.bits] = loc
      return
    if value.head.kind == vkSymbol and value.head.symVal in ["let", "var", "const"] and value.body.len > 0:
      var body = value.body
      let valueIndex = if body.len > 1 and body[1].isSymbol(":"): 3 else: 1
      if valueIndex < body.len:
        body[valueIndex] = c.expandMacroTree(unit, body[valueIndex], loc, locs, provenance)
      for name in patternBindingNames(body[0]): discard c.reserveLocal(name)
      result = newNode(value.head, value.props, body, value.meta, value.nodeImmutable)
      locs[result.bits] = loc
      return
    let meta = value.meta
    var props = initPropTable()
    for key, item in value.props:
      props[key] = c.expandMacroTree(unit, item, loc, locs, provenance)
    let head = c.expandMacroTree(unit, value.head, loc, locs, provenance)
    var body: seq[Value]
    for item in value.body:
      body.add c.expandMacroTree(unit, item, loc, locs, provenance)
    result = newNode(head, props = props, body = body, meta = meta,
                     immutable = value.nodeImmutable)
  of vkList:
    var items: seq[Value]
    for item in value.listItems:
      items.add c.expandMacroTree(unit, item, loc, locs, provenance)
    result = newList(items, immutable = value.listImmutable)
  of vkMap:
    var entries = initPropTable()
    for key, item in value.mapEntries:
      entries[key] = c.expandMacroTree(unit, item, loc, locs, provenance)
    result = newMap(entries, immutable = value.mapImmutable)
  of vkSet:
    var items: seq[Value]
    for item in value.setItems:
      items.add c.expandMacroTree(unit, item, loc, locs, provenance)
    result = newSet(items)
  of vkHashMap:
    var entries: seq[HashMapEntry]
    for entry in value.hashMapEntries:
      entries.add HashMapEntry(
        key: c.expandMacroTree(unit, entry.key, loc, locs, provenance),
        val: c.expandMacroTree(unit, entry.val, loc, locs, provenance))
    result = newHashMap(entries)
  else:
    return value
  locs[result.bits] = loc
  if provenance.hasKey(value.bits):
    provenance[result.bits] = provenance[value.bits]

proc expandSourceUnitMacros*(unit: SourceUnit,
    importedMacros = initTable[string, Table[string, MacroDef]]()):
    ExpandedSourceUnit =
  ## Produce the original+expanded front-end artifact without emitting GIR.
  ## This is the single macro-expansion seam shared by semantic backends; the
  ## VM compiler continues to use the same `expandMacro` implementation.
  result.original = unit
  result.expanded = SourceUnit(sourceName: unit.sourceName,
                               source: unit.source,
                               locs: unit.locs)
  result.provenance = initTable[uint64, ExpansionProvenance]()
  result.macroExports = initTable[string, MacroDef]()
  var c = Compiler(chunk: newChunk(unit.sourceName), sourceName: unit.sourceName,
                   sourceLocs: sharedSourceLocs(unit.locs),
                   formLocs: unit.formLocs, allowAmbientImports: true,
                   ffiLibraryNames: initTable[string, bool](),
                   importedMacroSets: importedMacros)
  c.prepareMacroContext(unit.forms)
  c.markStaticImplForms(unit.forms)
  for i, form in unit.forms:
    let loc = if i < unit.formLocs.len: unit.formLocs[i] else: SourceLoc()
    c.currentLoc = loc
    if form.kind == vkNode and form.head.isSymbol("macro"):
      c.compileMacro(form)
      let name = form.body[0].symVal
      if not form.declarationIsPrivate:
        result.macroExports[name] = c.macros[name]
      continue
    let expanded = c.expandMacroTree(unit, form, loc,
                                     result.expanded.locs,
                                     result.provenance)
    result.expanded.forms.add expanded
    result.expanded.formLocs.add loc
  for name in c.publicMacroNames:
    if c.macros.hasKey(name): result.macroExports[name] = c.macros[name]
  result.macroRuntimeLease = c.chunk.macroRuntimeLease

proc rejectReservedEffects(node: Value) =
  if node.props.hasKey("effects"):
    raise newException(GeneError, "^effects is reserved for a future static effect system")

proc isNeverErrorRowEntry(value: Value): bool =
  value.kind == vkSymbol and value.symVal == "Never"

proc compileErrorRow(c: var Compiler, node: Value, deferred = false): tuple[checks: bool, count: int] =
  rejectReservedEffects(node)
  if not node.props.hasKey("errors"):
    return
  let row = node.props["errors"]
  if row.kind != vkList:
    raise newException(GeneError, "^errors must be a list")
  result.checks = true
  var normalized: seq[Value]
  for errorType in row.listItems:
    if errorType.isNeverErrorRowEntry:
      continue
    var duplicate = false
    for existing in normalized:
      if equal(existing, errorType):
        duplicate = true
        break
    if duplicate:
      continue
    normalized.add errorType
  if deferred: return # Receiver-bearing rows resolve with the signature.
  for errorType in normalized:
    # A nested callable's row uses the enclosing method's annotation context.
    # Self has no value binding for ordinary expression compilation to load.
    if errorType.isSymbol("Self"): c.emitConst(errorType)
    else: compileExpr(c, errorType)
    inc result.count

proc requiredPositionalCount(specs: ParamSpecs): int =
  for i in 0 ..< specs.positional.len:
    if i < specs.positionalDefaults.len and specs.positionalDefaults[i].optional:
      break
    inc result

proc hasOptionalPositional(specs: ParamSpecs): bool =
  for defaultValue in specs.positionalDefaults:
    if defaultValue.optional:
      return true

proc hasComputedPositionalDefault(specs: ParamSpecs): bool =
  for value in specs.positionalDefaults:
    if value.optional and value.defaultChunk != nil: return true

proc nativeScalarType(expr: Value): string =
  if expr.kind != vkSymbol:
    return ""
  case expr.symVal
  of "Int": "Int"
  of "I64": "I64"
  of "F64": "F64"
  else: ""

proc fixedAotType(expr: Value): string =
  if expr.kind != vkSymbol:
    return ""
  case expr.symVal
  of "I64": "I64"
  of "F64": "F64"
  else: ""

proc ffiTypeLabel(expr: Value): string

proc ownInterfaceEntry(c: Compiler, name: string):
    tuple[found: bool, entry: CompileInterfaceEntry] =
  ## Resolve a compile-interface entry from the innermost enclosing namespace
  ## outwards, so a namespace-local declaration wins over a same-named outer
  ## one and is visible to forms that precede it in its own body.
  for iface in c.localCompileInterfaces:
    if iface != nil and iface.entries.hasKey(name):
      return (true, iface.entries[name])
  if c.ownCompileInterface != nil and
      c.ownCompileInterface.entries.hasKey(name):
    return (true, c.ownCompileInterface.entries[name])

proc nativeTypeFor(c: Compiler, expr: Value): NativeTypeProto =
  ## Local lookup for the first typed-native slice. Imported/native-qualified
  ## lookup is added at the compile-interface seam; callers never inspect a
  ## runtime Type value.
  if expr.kind != vkSymbol:
    return nil
  let own = c.ownInterfaceEntry(expr.symVal)
  if own.found:
    result = own.entry.nativeType
  for typeProto in c.chunk.typeProtos:
    if typeProto.name == expr.symVal and typeProto.nativeType != nil:
      if result != nil and
          result.identity != typeProto.nativeType.identity:
        raise newException(GeneError,
          "ambiguous typed_native Type metadata: " & expr.symVal)
      result = typeProto.nativeType
  var imported = false
  if result == nil and c.importedCompileEntries.hasKey(expr.symVal):
    result = c.importedCompileEntries[expr.symVal].nativeType
    imported = result != nil
  if result != nil and result.abi != nil:
    var present = false
    for layout in c.chunk.ffiStructs:
      if layout.identity == result.abi.identity:
        present = true
        break
    if not present:
      # Imported layout descriptors are code-generation dependencies, not
      # runtime declarations. Keeping them on the chunk makes generated C
      # self-contained and lets invalidation compare exact descriptors.
      discard c.chunk.addFfiStruct(result.abi)
    if imported:
      c.chunk.addFfiStructDependency(result.abi.identity)

proc resolvedAotRepr(c: Compiler, expr: Value): AotRepr =
  var nativeExpr = expr
  var nullable = false
  if expr.kind == vkSymbol and expr.symVal.len > 1 and
      expr.symVal.endsWith("?"):
    nativeExpr = newSym(expr.symVal[0 .. ^2])
    nullable = true
  if expr.kind == vkSymbol:
    case expr.symVal
    of "I64":
      return AotRepr(kind: arkI64, typeName: "I64")
    of "I32":
      return AotRepr(kind: arkI32, typeName: "I32")
    of "Str":
      return AotRepr(kind: arkCStr, typeName: "Str")
    of "F64":
      return AotRepr(kind: arkF64, typeName: "F64")
    else:
      discard
  let nativeType = c.nativeTypeFor(nativeExpr)
  if nativeType != nil:
    return AotRepr(kind: arkNativePtr,
                   typeName: nativeType.name,
                   nullable: nullable,
                   nativeType: nativeType)

proc fieldMatchesAotResult(fieldType: Value, resultRepr: AotRepr): bool =
  let label = ffiTypeLabel(fieldType)
  case resultRepr.kind
  of arkI64:
    label in [
      "C/Int8", "C/UInt8", "C/Int16", "C/UInt16", "C/Int32", "C/UInt32",
      "C/Int64", "C/Char", "C/UChar", "C/Short", "C/UShort", "C/Int",
      "C/UInt", "C/Long", "C/PtrDiff"
    ]
  of arkI32:
    ## Exactly the 32-bit-and-narrower C types, so the value is always in
    ## Gene's `I32` range and no check is needed on the way out.
    label in [
      "C/Int8", "C/UInt8", "C/Int16", "C/UInt16", "C/Int32", "C/Char",
      "C/UChar", "C/Short", "C/UShort", "C/Int"
    ]
  of arkCStr:
    label == "C/CStr"
  of arkF64:
    label in ["C/Float", "C/Double"]
  else:
    false

proc fieldAcceptsAotStore(fieldType: Value, valueRepr: AotRepr): bool =
  ## The initial write subset is lossless. Wider/narrower ABI conversions need
  ## an explicit checked lowering before they become eligible.
  let label = ffiTypeLabel(fieldType)
  case valueRepr.kind
  of arkI64:
    label == "C/Int64"
  of arkI32:
    ## An `I32` is in range for any of these by construction, so the store
    ## stays lossless without a runtime check.
    label in ["C/Int32", "C/Int", "C/Int64"]
  of arkCStr:
    label == "C/CStr"
  of arkF64:
    label == "C/Double"
  else:
    false

proc typedNativeField(expr: Value, params: openArray[string],
                      paramReprs: openArray[AotRepr],
                      locals: openArray[AotLocal]):
    tuple[found: bool, nativeType: NativeTypeProto, field: FfiStructField] =
  if expr.kind != vkNode or not expr.head.isSymbol("path") or
      expr.body.len != 2 or expr.body[0].kind != vkSymbol or
      expr.body[1].kind != vkSymbol:
    return
  let base = expr.body[0].symVal
  var baseRepr = AotRepr()
  for i, param in params:
    if base == param and i < paramReprs.len:
      baseRepr = paramReprs[i]
      break
  if baseRepr.kind == arkNone:
    for local in locals:
      if local.name == base:
        baseRepr = local.repr
        break
  if baseRepr.kind != arkNativePtr:
    return
  let nativeType = baseRepr.nativeType
  for field in nativeType.abi.fields:
    if field.name == expr.body[1].symVal:
      return (true, nativeType, field)

proc aotBindingRepr(expr: Value, params: openArray[string],
                    paramReprs: openArray[AotRepr],
                    locals: openArray[AotLocal]): AotRepr =
  if expr.kind != vkSymbol:
    return
  for i, param in params:
    if expr.symVal == param and i < paramReprs.len:
      return paramReprs[i]
  for local in locals:
    if expr.symVal == local.name and not local.outOfScope:
      return local.repr

proc aotMutableBindingRepr(name: string, params: openArray[string],
                           paramReprs: openArray[AotRepr],
                           locals: openArray[AotLocal]): AotRepr =
  for i, param in params:
    if param == name and i < paramReprs.len:
      return paramReprs[i]
  for local in locals:
    if local.name == name and local.mutable:
      return local.repr

proc aotReprAccepts(destination, source: AotRepr): bool =
  ## An I32 widens into an I64 destination: the value is already known to fit,
  ## while intermediate integer arithmetic remains exact. This admission rule
  ## still requires lossless representation edges; checked narrowing is only
  ## emitted at the explicitly supported typed bindings and out-parameters.
  if destination.kind == arkI64 and source.kind == arkI32:
    return true
  if destination.kind != source.kind:
    return false
  if destination.kind != arkNativePtr:
    return destination.kind != arkNone
  destination.nativeType.identity == source.nativeType.identity and
    (destination.nullable or not source.nullable)

proc nativeTypeByIdentity(c: Compiler, identity: string): NativeTypeProto =
  ## Look a native Type up by its stable module-qualified identity rather than
  ## by name. Name lookup is what let a consumer's unrelated `Node` answer for
  ## an imported layout's `Node? next`.
  if identity.len == 0:
    return nil
  for typeProto in c.chunk.typeProtos:
    if typeProto.nativeType != nil and
        typeProto.nativeType.identity == identity:
      return typeProto.nativeType
  if c.ownCompileInterface != nil:
    for _, entry in c.ownCompileInterface.entries:
      if entry.nativeType != nil and entry.nativeType.identity == identity:
        return entry.nativeType
  for _, entry in c.importedCompileEntries:
    if entry.nativeType != nil and entry.nativeType.identity == identity:
      return entry.nativeType

proc nativeFieldAotRepr(c: Compiler, field: FfiStructField): AotRepr =
  ## Preserve the nominal Gene Type carried by a pointer-valued C field. The C
  ## layout owns the machine shape; the target Type supplies the identity and
  ## nullability needed to type-check subsequent direct loads and stores.
  ##
  ## The pointee comes from the identity the *declaring* module recorded, never
  ## from re-resolving `field.typeExpr` here. An identity that is not reachable
  ## from this module means this module genuinely cannot type that pointer, so
  ## the field does not lower — which is the correct answer, and the one that
  ## replaces silently substituting a same-named local type.
  let expr = field.typeExpr
  if expr.kind != vkNode or expr.body.len != 1:
    return
  let head = ffiTypeLabel(expr.head)
  # Const views need a representation-level read-only bit, and an OwnedPtr
  # field needs an explicit ownership operation before it can become a nominal
  # local/result. Do not erase either contract into a plain mutable pointer.
  if head notin ["C/Ptr", "C/NullablePtr"]:
    return
  let nativeType = c.nativeTypeByIdentity(field.pointeeTypeIdentity)
  if nativeType == nil:
    return
  AotRepr(kind: arkNativePtr,
          typeName: nativeType.name,
          nullable: head == "C/NullablePtr",
          nativeType: nativeType)

proc ffiParamMatchesAotRepr(typeExpr: Value, ffiRepr,
                            valueRepr: AotRepr): bool =
  if ffiRepr.kind == arkNativePtr:
    return ffiRepr.aotReprAccepts(valueRepr)
  typeExpr.fieldAcceptsAotStore(valueRepr)

proc ffiResultMatchesAotRepr(typeExpr: Value, ffiRepr,
                             resultRepr: AotRepr): bool =
  if ffiRepr.kind == arkNativePtr:
    return resultRepr.aotReprAccepts(ffiRepr)
  typeExpr.fieldMatchesAotResult(resultRepr)

proc aotLiteralRepr(expr: Value): AotRepr =
  ## The representation a literal argument supplies. An integer takes the
  ## narrowest that holds it, so it satisfies a C `int` parameter as readily as
  ## a 64-bit one without a narrowing check.
  case expr.kind
  of vkString:
    AotRepr(kind: arkCStr, typeName: "Str")
  of vkInt:
    if expr.intFitsInt64 and expr.intVal >= low(int32) and expr.intVal <= high(int32):
      AotRepr(kind: arkI32, typeName: "I32")
    else:
      AotRepr(kind: arkI64, typeName: "I64")
  of vkFloat:
    AotRepr(kind: arkF64, typeName: "F64")
  else:
    AotRepr()

proc aotBindingNamed(name: string, params: openArray[string],
                     locals: openArray[AotLocal]): bool =
  for param in params:
    if param == name:
      return true
  for local in locals:
    if local.name == name:
      return true

proc localAotFunction(c: Compiler, name: string): FunctionProto =
  ## A previously declared function in this compiled unit is callable directly
  ## when its complete machine signature and body have already been proven.
  ## Keeping this source-ordered matches C emission, which has emitted the
  ## callee before making it available to the next function.
  for fn in c.chunk.functions:
    if fn.name == name and fn.aotExpr.kind != vkNil:
      return fn

proc typedNativeSend(expr: Value, params: openArray[string],
                     paramReprs: openArray[AotRepr],
                     locals: openArray[AotLocal]):
    tuple[found: bool, receiverRepr: AotRepr, protocolExpr: Value,
          messageName: string, argsStart: int] =
  if expr.kind != vkNode or expr.props.len != 0 or expr.meta.len != 0 or
      expr.head.kind != vkSymbol or expr.body.len < 2 or
      not expr.body[0].isSymbol("~"):
    return
  let receiverRepr = expr.head.aotBindingRepr(params, paramReprs, locals)
  if receiverRepr.kind != arkNativePtr or receiverRepr.nullable:
    return
  let message = expr.body[1]
  if message.kind == vkSymbol:
    ## Bare `(recv .m)` is type-direct; only a qualified `(recv .P:m)` names
    ## a protocol message (docs/spec/protocols.md). Resolving a bare send against
    ## protocol impls made the C backend call an impl the VM refuses to
    ## dispatch — the interpreter answers "no message 'm' on T" for the same
    ## source. Typed-native lowering has no type-direct message table, so a
    ## bare send is simply not lowerable here.
    return
  if message.kind == vkNode and message.head.isSymbol("msg") and
      message.body.len == 2 and message.body[1].kind == vkSymbol:
    let protocolExpr = message.body[0]
    ## A lexical binding shadowing the protocol name makes the send dynamic.
    ## The typed FFI path already enforces this for shadowed symbols; the send
    ## path must not disagree.
    if protocolExpr.kind == vkSymbol and
        protocolExpr.symVal.aotBindingNamed(params, locals):
      return
    return (true, receiverRepr, protocolExpr, message.body[1].symVal, 2)

proc localAotImplMessage(c: Compiler, receiverRepr: AotRepr,
                         protocolExpr: Value,
                         messageName: string):
    tuple[fn: FunctionProto, protocolExpr, receiverExpr: Value] =
  ## A direct protocol call is allowed only when the winning unconditional
  ## canonical pair is statically known and no overlay is reachable
  ## (docs/spec/protocols.md). An impl that is not a static top-level pair is
  ## overlay-only, and if it declares this message it may win at runtime. We
  ## cannot rank it here, so refuse to lower rather than bake in the canonical
  ## target. Receivers that do not resolve statically are treated as possible
  ## matches for the same reason.
  ##
  ## `overlayImplMessages` covers the whole unit and is order-independent, so
  ## an overlay in a nested function body or written after the send is caught
  ## too. The per-chunk scan below stays because it can also rule out a
  ## *canonical* impl whose receiver does not resolve statically.
  ##
  ## Scope of the guarantee (decided 2026-07-28): the check is module-local.
  ## Another module may install an overlay for this type after this one is
  ## compiled, and compiled code will keep calling the canonical impl while
  ## interpreted code would dispatch to the overlay. That is accepted for the
  ## experimental backend rather than closed over.
  ##
  ## §7 offers the activation-epoch guard for runtimes with loading/reload, and
  ## that is the eventual answer here — not declaring the path closed-world,
  ## which would make the divergence permanent and silent. The guard is
  ## deferred because it needs a boxed dynamic fallback per specialized send,
  ## which only earns its cost once this backend is no longer experimental.
  ## Until then a cross-module overlay over an AOT-compiled type is a known
  ## limitation, documented in docs/workflows.md.
  if messageName in c.overlayImplMessages:
    return (nil, NIL, NIL)
  for impl in c.chunk.implProtos:
    if impl.staticTopLevel and impl.staticOperands:
      continue
    let overlayReceiver = c.resolvedAotRepr(impl.receiverExpr)
    if overlayReceiver.kind == arkNativePtr and
        overlayReceiver.nativeType.identity != receiverRepr.nativeType.identity:
      continue
    for message in impl.messages:
      if message.name == messageName and message.protocolPath.len == 0:
        return (nil, NIL, NIL)
  var matches = 0
  for impl in c.chunk.implProtos:
    if not impl.staticTopLevel or not impl.staticOperands:
      continue
    let implReceiver = c.resolvedAotRepr(impl.receiverExpr)
    if implReceiver.kind != arkNativePtr or
        implReceiver.nativeType.identity != receiverRepr.nativeType.identity:
      continue
    if protocolExpr.kind != vkNil and not equal(impl.protocolExpr, protocolExpr):
      continue
    for message in impl.messages:
      if message.name != messageName or message.protocolPath.len != 0:
        continue
      inc matches
      result = (message.fn, impl.protocolExpr, impl.receiverExpr)
  if matches != 1:
    result = (nil, NIL, NIL)

proc recordAotDirectImpl(c: Compiler, messageName: string,
                         protocolExpr, receiverExpr: Value) =
  for existing in c.chunk.directProtocolCalls:
    if existing.messageName == messageName and
        equal(existing.protocolExpr, protocolExpr) and
        equal(existing.receiverExpr, receiverExpr):
      return
  discard c.chunk.addDirectProtocolCall(DirectProtocolCallSpec(
    messageName: messageName,
    protocolExpr: protocolExpr,
    receiverExpr: receiverExpr))

proc isTypedNativeAotStatement(c: Compiler, statement: Value,
                               params: openArray[string],
                               paramReprs: openArray[AotRepr],
                               ffiFns: openArray[FfiFnProto],
                               locals: var seq[AotLocal]): bool

proc acceptsAotArity(fn: FunctionProto, count: int): bool =
  if fn == nil or count > fn.params.len or count < fn.requiredPositional: return false
  for i in count ..< fn.params.len:
    if i >= fn.paramDefaults.len or not fn.paramDefaults[i].optional or
        fn.paramDefaults[i].defaultChunk != nil or i >= fn.aotParamReprs.len or
        fn.aotParamReprs[i].kind != arkNativePtr or not fn.aotParamReprs[i].nullable:
      return false
  true

proc acceptsNativeFfiArguments(expr: Value, ffiFn: FfiFnProto,
                               params: openArray[string], paramReprs: openArray[AotRepr],
                               locals: seq[AotLocal]): bool =
  if expr.props.len != 0 or expr.meta.len != 0 or ffiFn.params.len != expr.body.len:
    return false
  for i, arg in expr.body:
    var argRepr = arg.aotBindingRepr(params, paramReprs, locals)
    if argRepr.kind == arkNone:
      ## Literals carry their own representation. Without this an FFI
      ## argument had to be a binding, so even `(f ":memory:")` or `(f x 1)`
      ## was unlowerable.
      argRepr = arg.aotLiteralRepr()
    if argRepr.kind == arkNone and arg.kind == vkNil and
        i < ffiFn.paramReprs.len and
        ffiFn.paramReprs[i].kind == arkNativePtr and
        ffiFn.paramReprs[i].nullable:
      ## `nil` takes its representation from the parameter: it is the null
      ## pointer, and only a nullable one admits it.
      argRepr = ffiFn.paramReprs[i]
    if argRepr.kind == arkNone or i >= ffiFn.paramReprs.len or
        not ffiFn.params[i].typeExpr.ffiParamMatchesAotRepr(
          ffiFn.paramReprs[i], argRepr):
      return false
    if ffiFn.params[i].isOut:
      ## The callee writes through this argument, so it must be a mutable
      ## local whose address the emitter can take. A temporary has no
      ## address, and writing through a parameter would not be visible to the
      ## Gene caller (proposal §6.3.1).
      if arg.kind != vkSymbol:
        return false
      var isLocal = false
      for local in locals:
        if local.name == arg.symVal and not local.outOfScope:
          isLocal = local.mutable
          break
      if not isLocal:
        return false
  true

proc isTypedNativeAotExpr(c: Compiler, expr: Value,
                          params: openArray[string],
                          paramReprs: openArray[AotRepr],
                          resultRepr: AotRepr,
                          ffiFns: openArray[FfiFnProto],
                          locals: var seq[AotLocal]): bool =
  ## Static expression subset for native-pointer functions. Start with the gate
  ## promised by the proposal: pointer identity and one scalar foreign-field
  ## read. Unsupported operations are rejected instead of silently boxing.
  if expr.kind == vkSymbol:
    let repr = expr.aotBindingRepr(params, paramReprs, locals)
    if repr.kind != arkNone:
      return resultRepr.aotReprAccepts(repr)
    ## Not a parameter or local — it may still be a scalar `let` constant, in
    ## which case it lowers as the literal it was bound to. Parameters and
    ## locals are checked first, so a binding always shadows a constant of the
    ## same name.
    let constValue = c.aotConstants.getOrDefault(expr.symVal, NIL)
    if constValue.kind == vkNil:
      return false
    return c.isTypedNativeAotExpr(constValue, params, paramReprs, resultRepr,
                                  ffiFns, locals)
  ## Scalar literals. The emitter has always rendered these; without the
  ## matching analysis case even `(+ x 1)` was rejected.
  if expr.kind == vkInt:
    return resultRepr.kind == arkI64
  if expr.kind == vkFloat:
    return resultRepr.kind == arkF64
  ## `nil` is the null pointer, so it only fits a nullable native pointer.
  ## Needed wherever an out-parameter slot is seeded or a nullable result is
  ## produced (proposal §6.3.1).
  if expr.kind == vkNil:
    return resultRepr.kind == arkNativePtr and resultRepr.nullable
  if expr.kind == vkString:
    return resultRepr.kind == arkCStr
  if expr.kind != vkNode or expr.props.len != 0 or expr.meta.len != 0:
    return false
  ## `$math/floor` and friends read as a *path* head, so this is tested before
  ## the symbol-head guard below rather than alongside the other call forms.
  if expr.head.aotMathBuiltinCName.len > 0 and expr.body.len == 1:
    if resultRepr.kind != arkF64:
      return false
    return c.isTypedNativeAotExpr(expr.body[0], params, paramReprs, resultRepr,
                                  ffiFns, locals)
  if expr.head.kind != vkSymbol:
    return false
  ## Admit arithmetic, comparisons and branches with compatible representations.
  ## The checked emitter sequences their evaluation and inserts boundary checks.
  if expr.head.symVal in ["+", "-", "*"] and expr.body.len == 2:
    if resultRepr.kind notin {arkI64, arkF64}:
      return false
    return c.isTypedNativeAotExpr(expr.body[0], params, paramReprs, resultRepr,
                                  ffiFns, locals) and
      c.isTypedNativeAotExpr(expr.body[1], params, paramReprs, resultRepr,
                             ffiFns, locals)
  if expr.head.symVal == "/" and expr.body.len == 2:
    ## Float division by a *statically non-zero literal*, and no other form.
    ##
    ## Gene's `/` raises `division by zero` for floats as well as integers
    ## (`biDiv`), where C yields an infinity and says nothing. Lowering a
    ## general division would therefore turn a catchable Gene error into a
    ## silent `inf` propagating through the rest of the computation. General
    ## division has not yet been given a checked lowering, so admission remains
    ## conservative even though the backend now has an error channel.
    ##
    ## When the divisor is a non-zero literal the divergence cannot arise, so
    ## the lowering is exact. That is not as narrow as it sounds: scaling by a
    ## constant is what division in numeric kernels almost always is, and
    ## `core/exact.gene`'s `wrap32` divides by 2^32.
    if resultRepr.kind != arkF64:
      return false
    ## The divisor is resolved through the constant table first, because
    ## `(/ v two32)` is how this is actually written — the literal is bound to a
    ## name at the top of the module. Checking the syntactic operand alone would
    ## accept the inlined form and reject the idiomatic one.
    var divisor = expr.body[1]
    if divisor.kind == vkSymbol:
      var shadowed = divisor.symVal in params
      for local in locals:
        if local.name == divisor.symVal:
          shadowed = true
      if not shadowed:
        divisor = c.aotConstants.getOrDefault(divisor.symVal, NIL)
    if divisor.kind != vkFloat or divisor.floatVal == 0.0:
      return false
    return c.isTypedNativeAotExpr(expr.body[0], params, paramReprs, resultRepr,
                                  ffiFns, locals)
  if expr.head.symVal in ["<", ">", "<=", ">=", "=="] and expr.body.len == 2:
    ## A C comparison yields int, so the result must be I64; the operands may
    ## be either scalar repr as long as they agree.
    if resultRepr.kind != arkI64:
      return false
    for operand in [AotRepr(kind: arkI64, typeName: "I64"),
                    AotRepr(kind: arkF64, typeName: "F64")]:
      if c.isTypedNativeAotExpr(expr.body[0], params, paramReprs, operand,
                                ffiFns, locals) and
          c.isTypedNativeAotExpr(expr.body[1], params, paramReprs, operand,
                                 ffiFns, locals):
        return true
    return false
  if expr.head.symVal == "if" and expr.body.len == 3:
    ## Both arms must produce the result representation: a C ternary has one
    ## type, and there is no boxing available to reconcile two.
    let condition = AotRepr(kind: arkI64, typeName: "I64")
    return c.isTypedNativeAotExpr(expr.body[0], params, paramReprs, condition,
                                  ffiFns, locals) and
      c.isTypedNativeAotExpr(expr.body[1], params, paramReprs, resultRepr,
                             ffiFns, locals) and
      c.isTypedNativeAotExpr(expr.body[2], params, paramReprs, resultRepr,
                             ffiFns, locals)
  if expr.head.symVal == "path":
    let resolved = expr.typedNativeField(params, paramReprs, locals)
    if not resolved.found:
      return false
    let fieldRepr = c.nativeFieldAotRepr(resolved.field)
    if fieldRepr.kind != arkNone:
      return resultRepr.aotReprAccepts(fieldRepr)
    return resolved.field.typeExpr.fieldMatchesAotResult(resultRepr)
  if expr.head.symVal == "set" and expr.body.len == 2 and
      expr.body[0].kind != vkSymbol:
    let resolved = expr.body[0].typedNativeField(params, paramReprs, locals)
    if not resolved.found or not resolved.nativeType.mutable:
      return false
    var valueRepr = expr.body[1].aotBindingRepr(params, paramReprs, locals)
    if valueRepr.kind == arkNone: valueRepr = resultRepr
    if not c.isTypedNativeAotExpr(expr.body[1], params, paramReprs, valueRepr,
                                  ffiFns, locals):
      return false
    let fieldRepr = c.nativeFieldAotRepr(resolved.field)
    if fieldRepr.kind != arkNone:
      return fieldRepr.aotReprAccepts(valueRepr) and
        resultRepr.aotReprAccepts(valueRepr)
    return resolved.field.typeExpr.fieldAcceptsAotStore(valueRepr) and
      resultRepr.aotReprAccepts(valueRepr)
  if expr.head.symVal == "set" and expr.body.len == 2 and
      expr.body[0].kind == vkSymbol:
    let destination = expr.body[0].symVal.aotMutableBindingRepr(
      params, paramReprs, locals)
    let valueRepr = expr.body[1].aotBindingRepr(params, paramReprs, locals)
    return destination.kind != arkNone and valueRepr.kind != arkNone and
      destination.aotReprAccepts(valueRepr) and
      resultRepr.aotReprAccepts(valueRepr)
  if expr.head.symVal == "do" and expr.body.len > 0:
    for i in 0 ..< expr.body.high:
      if not c.isTypedNativeAotStatement(expr.body[i], params, paramReprs,
                                         ffiFns, locals):
        return false
    return c.isTypedNativeAotExpr(expr.body[^1], params, paramReprs,
                                  resultRepr, ffiFns, locals)
  let send = expr.typedNativeSend(params, paramReprs, locals)
  if send.found:
    let selected = c.localAotImplMessage(send.receiverRepr, send.protocolExpr,
                                         send.messageName)
    let callee = selected.fn
    if callee == nil or callee.aotExpr.kind == vkNil or
        not callee.acceptsAotArity(expr.body.len - send.argsStart + 1) or
        callee.aotParamReprs.len != callee.params.len or
        not callee.aotParamReprs[0].aotReprAccepts(send.receiverRepr):
      return false
    for i in send.argsStart ..< expr.body.len:
      let argRepr = expr.body[i].aotBindingRepr(params, paramReprs, locals)
      let calleeIndex = i - send.argsStart + 1
      if argRepr.kind == arkNone or
          not callee.aotParamReprs[calleeIndex].aotReprAccepts(argRepr):
        return false
    if not resultRepr.aotReprAccepts(callee.aotReturnRepr):
      return false
    c.recordAotDirectImpl(send.messageName, selected.protocolExpr,
                          selected.receiverExpr)
    return true
  if expr.head.symVal.aotBindingNamed(params, locals):
    return false
  let callee = c.localAotFunction(expr.head.symVal)
  if callee != nil:
    if not callee.acceptsAotArity(expr.body.len) or
        callee.aotParamReprs.len != callee.params.len:
      return false
    ## Each argument is checked as an *expression* against the parameter's
    ## representation, not required to be a bare binding.
    ##
    ## Requiring a binding meant a nested call could never be an argument, so
    ## `(mix32 (wrap32 seed))` was unlowerable and every composed numeric
    ## kernel — which is what these functions are — fell back to the
    ## interpreter. The FFI branch below had already been given the same
    ## treatment for literals; this is the direct-call half of it. The emitter
    ## has always recursed through arguments, so only the analysis was
    ## narrower than the code it guards.
    for i, arg in expr.body:
      if not c.isTypedNativeAotExpr(arg, params, paramReprs,
                                    callee.aotParamReprs[i], ffiFns, locals):
        return false
    return resultRepr.aotReprAccepts(callee.aotReturnRepr)
  for ffiFn in ffiFns:
    if ffiFn.name != expr.head.symVal:
      continue
    if not acceptsNativeFfiArguments(expr, ffiFn, params, paramReprs, locals):
      return false
    return ffiFn.returnType.ffiResultMatchesAotRepr(ffiFn.returnRepr,
                                                    resultRepr)
  false

proc isTypedNativeAotStatement(c: Compiler, statement: Value,
                               params: openArray[string],
                               paramReprs: openArray[AotRepr],
                               ffiFns: openArray[FfiFnProto],
                               locals: var seq[AotLocal]): bool =
  ## Statement position: inside `do`, and inside a `while` body. A statement's
  ## value is discarded, so only its effect has to lower.
  if statement.kind != vkNode or statement.head.kind != vkSymbol or
      statement.props.len != 0 or statement.meta.len != 0:
    return false
  if statement.head.isSymbol("let") or statement.head.isSymbol("var"):
    ## Two shapes: `(var x : T init)` states the representation, and
    ## `(var x init)` infers it from the initializer.
    ##
    ## Inference matters more than it looks. Requiring the annotation meant
    ## every loop counter had to be written `(var i : F64 0.0)` to be
    ## lowerable, which no Gene anywhere else is written like — so in practice
    ## no ordinary function lowered, and the restriction read as "loops are not
    ## supported" rather than "loops need an annotation nobody writes".
    let annotated = statement.body.len == 4 and
      statement.body[1].isSymbol(":")
    if not annotated and statement.body.len != 2:
      return false
    if statement.body[0].kind != vkSymbol:
      return false
    let name = statement.body[0].symVal
    if name in params:
      return false
    for local in locals:
      if local.name == name:
        return false
    let initExpr = if annotated: statement.body[3] else: statement.body[1]
    var localRepr =
      if annotated: c.resolvedAotRepr(statement.body[2]) else: AotRepr()
    if annotated:
      if localRepr.kind == arkNone or
          not c.isTypedNativeAotExpr(initExpr, params, paramReprs, localRepr,
                                     ffiFns, locals):
        return false
    else:
      ## Candidates are tried in a fixed order and the first that accepts the
      ## initializer wins. The two are near-disjoint in practice — a float
      ## literal only checks as `F64` and an integer literal only as `I64` — so
      ## this resolves rather than guesses. An initializer that fits neither is
      ## simply not lowerable, which is the pre-existing answer.
      var inferred = false
      for candidate in [AotRepr(kind: arkF64, typeName: "F64"),
                        AotRepr(kind: arkI64, typeName: "I64")]:
        if c.isTypedNativeAotExpr(initExpr, params, paramReprs, candidate,
                                  ffiFns, locals):
          localRepr = candidate
          inferred = true
          break
      if not inferred:
        return false
    locals.add AotLocal(name: name, repr: localRepr,
                        mutable: statement.head.isSymbol("var"))
    return true
  if statement.head.symVal == "set" and statement.body.len == 2 and
      statement.body[0].kind == vkSymbol:
    ## Validate the value against the *target's* representation. Requiring the
    ## value to be a bare binding, as this used to, rejected `(set i (+ i 1))`
    ## and so made counting loops impossible to express.
    let target = statement.body[0].aotBindingRepr(params, paramReprs, locals)
    if target.kind == arkNone:
      return false
    return c.isTypedNativeAotExpr(statement.body[1], params, paramReprs,
                                  target, ffiFns, locals)
  if statement.head.symVal == "set" and statement.body.len == 2 and
      statement.body[0].kind != vkSymbol:
    let valueRepr = statement.body[1].aotBindingRepr(params, paramReprs, locals)
    if valueRepr.kind != arkNone:
      return c.isTypedNativeAotExpr(statement, params, paramReprs, valueRepr,
                                    ffiFns, locals)
    let field = statement.body[0].typedNativeField(params, paramReprs, locals)
    if not field.found: return false
    let pointerRepr = c.nativeFieldAotRepr(field.field)
    var candidates = @[pointerRepr, AotRepr(kind: arkI64, typeName: "I64"),
      AotRepr(kind: arkI32, typeName: "I32"), AotRepr(kind: arkF64, typeName: "F64"),
      AotRepr(kind: arkCStr, typeName: "Str")]
    for candidate in candidates:
      if candidate.kind == arkNone: continue
      var trial = locals
      if c.isTypedNativeAotExpr(statement, params, paramReprs, candidate, ffiFns, trial):
        locals = move trial
        return true
    return false
  if statement.head.symVal == "do" and statement.body.len > 0:
    ## A `do` in statement position is a block: its value is discarded, so
    ## every item is a statement, and its declarations are block-scoped.
    let outerLocals = locals.len
    for item in statement.body:
      if not c.isTypedNativeAotStatement(item, params, paramReprs, ffiFns,
                                         locals):
        return false
    for i in outerLocals ..< locals.len:
      locals[i].outOfScope = true
    return true
  if statement.head.symVal == "while" and statement.body.len >= 2:
    let condition = AotRepr(kind: arkI64, typeName: "I64")
    if not c.isTypedNativeAotExpr(statement.body[0], params, paramReprs,
                                  condition, ffiFns, locals):
      return false
    ## Declarations inside the body leave scope with it, matching the C block
    ## the emitter produces. Without the reset, analysis would keep accepting a
    ## name the emitted code can no longer see.
    let outerLocals = locals.len
    for i in 1 ..< statement.body.len:
      if not c.isTypedNativeAotStatement(statement.body[i], params, paramReprs,
                                         ffiFns, locals):
        return false
    for i in outerLocals ..< locals.len:
      locals[i].outOfScope = true
    return true
  if not statement.head.symVal.aotBindingNamed(params, locals):
    for foreign in ffiFns:
      if foreign.name == statement.head.symVal and
          ffiTypeLabel(foreign.returnType) == "C/Void":
        return acceptsNativeFfiArguments(statement, foreign, params, paramReprs, locals)
  false

proc nativeArithmeticOp(typeName, opName: string): NativeCompileOp =
  case typeName
  of "Int":
    case opName
    of "+": ncoIntAdd
    of "-": ncoIntSub
    of "*": ncoIntMul
    else: ncoNone
  of "I64":
    case opName
    of "+": ncoI64Add
    of "-": ncoI64Sub
    of "*": ncoI64Mul
    else: ncoNone
  of "F64":
    case opName
    of "+": ncoF64Add
    of "-": ncoF64Sub
    of "*": ncoF64Mul
    else: ncoNone
  else:
    ncoNone

proc nativeIdentityOp(typeName: string): NativeCompileOp =
  case typeName
  of "Int": ncoIntIdentity
  of "I64": ncoI64Identity
  of "F64": ncoF64Identity
  else: ncoNone

proc detectNativeCompileOp(specs: ParamSpecs, body: openArray[Value],
                           bodyStart: int, returnType: Value,
                           typeParams: openArray[string],
                           checksErrors, sawYield: bool):
    tuple[op: NativeCompileOp, paramIndex: int] =
  ## Native-compilation slices for small typed scalar shapes. Dynamic function
  ## entry still performs normal boundary checks before these ops run.
  if typeParams.len != 0 or checksErrors or sawYield:
    return (ncoNone, 0)
  if specs.rest.len != 0 or specs.named.len != 0:
    return (ncoNone, 0)
  if specs.hasOptionalPositional or body.len != bodyStart + 1:
    return (ncoNone, 0)
  let typeName = returnType.nativeScalarType
  if typeName.len == 0:
    return (ncoNone, 0)
  for t in specs.positionalTypes:
    if t.nativeScalarType != typeName:
      return (ncoNone, 0)

  let expr = body[bodyStart]
  if expr.kind == vkSymbol:
    for i, param in specs.positional:
      if expr.symVal == param:
        return (nativeIdentityOp(typeName), i)
    return (ncoNone, 0)

  if specs.positional.len != 2:
    return (ncoNone, 0)
  if expr.kind != vkNode or expr.props.len != 0 or expr.meta.len != 0 or
      expr.body.len != 2 or expr.head.kind != vkSymbol:
    return (ncoNone, 0)
  if expr.body[0].kind != vkSymbol or expr.body[1].kind != vkSymbol:
    return (ncoNone, 0)
  if expr.body[0].symVal != specs.positional[0] or
      expr.body[1].symVal != specs.positional[1]:
    return (ncoNone, 0)

  (nativeArithmeticOp(typeName, expr.head.symVal), 0)

proc aotAvailableFunctions(functions: openArray[FunctionProto],
                           typeName: string): Table[string, int] =
  for fn in functions:
    if fn.aotExpr.kind == vkNil or fn.returnType.fixedAotType != typeName:
      continue
    var supported = true
    for t in fn.paramTypes:
      if t.fixedAotType != typeName:
        supported = false
        break
    if supported:
      result[fn.name] = fn.params.len

proc isAotValueExpr(expr: Value, params: openArray[string], typeName: string,
                    available: Table[string, int]): bool

proc isAotBoolExpr(expr: Value, params: openArray[string], typeName: string,
                   available: Table[string, int]): bool =
  if expr.kind != vkNode or expr.props.len != 0 or expr.meta.len != 0 or
      expr.head.kind != vkSymbol:
    return false
  let head = expr.head.symVal
  if head notin ["<", ">", "<=", ">=", "=="]:
    return false
  if expr.body.len != 2:
    return false
  expr.body[0].isAotValueExpr(params, typeName, available) and
    expr.body[1].isAotValueExpr(params, typeName, available)

proc isAotValueExpr(expr: Value, params: openArray[string], typeName: string,
                    available: Table[string, int]): bool =
  case expr.kind
  of vkSymbol:
    expr.symVal in params
  of vkInt:
    typeName == "I64" and expr.intFitsInt64
  of vkFloat:
    typeName == "F64"
  of vkNode:
    if expr.props.len != 0 or expr.meta.len != 0 or expr.head.kind != vkSymbol:
      return false
    let head = expr.head.symVal
    if head in ["+", "-", "*"]:
      if expr.body.len != 2:
        return false
      return expr.body[0].isAotValueExpr(params, typeName, available) and
        expr.body[1].isAotValueExpr(params, typeName, available)
    if head == "if":
      if expr.body.len != 3:
        return false
      return expr.body[0].isAotBoolExpr(params, typeName, available) and
        expr.body[1].isAotValueExpr(params, typeName, available) and
        expr.body[2].isAotValueExpr(params, typeName, available)
    if available.hasKey(head) and available[head] == expr.body.len:
      for arg in expr.body:
        if not arg.isAotValueExpr(params, typeName, available):
          return false
      return true
    false
  else:
    false

proc substituteAotConstants(c: Compiler, expr: Value,
                            params: openArray[string],
                            locals: openArray[AotLocal]): Value =
  ## Inline scalar `let` constants into a body that analysis has already
  ## accepted, so the stored `aotExpr` is self-contained.
  ##
  ## Doing it here rather than in the emitter keeps the emitter free of any
  ## notion of module scope: by the time C is generated, a constant is
  ## indistinguishable from a literal the author wrote out. A name that is a
  ## parameter or any of the function's locals is never substituted, so a
  ## binding always wins over a constant of the same name — the same precedence
  ## the analysis used to accept the body.
  if expr.kind == vkSymbol:
    for param in params:
      if expr.symVal == param:
        return expr
    for local in locals:
      if local.name == expr.symVal:
        return expr
    let constValue = c.aotConstants.getOrDefault(expr.symVal, NIL)
    if constValue.kind in {vkInt, vkFloat}:
      return constValue
    return expr
  if expr.kind != vkNode:
    return expr
  var body: seq[Value]
  for item in expr.body:
    body.add c.substituteAotConstants(item, params, locals)
  var props = initPropTable()
  for key, item in expr.props:
    props[key] = c.substituteAotConstants(item, params, locals)
  newNode(c.substituteAotConstants(expr.head, params, locals),
          props = props, body = body, meta = expr.meta,
          immutable = expr.nodeImmutable)

proc detectAotExpr(c: Compiler, name: string, specs: ParamSpecs,
                   body: openArray[Value],
                   bodyStart: int, returnType: Value,
                   typeParams: openArray[string],
                   checksErrors, sawYield: bool): Value =
  if typeParams.len != 0 or checksErrors or sawYield:
    return NIL
  if specs.rest.len != 0 or specs.named.len != 0 or specs.hasOptionalPositional:
    return NIL
  if body.len != bodyStart + 1:
    return NIL
  let typeName = returnType.fixedAotType
  if typeName.len == 0:
    return NIL
  for t in specs.positionalTypes:
    if t.fixedAotType != typeName:
      return NIL
  var available = aotAvailableFunctions(c.chunk.functions, typeName)
  if name.len > 0:
    available[name] = specs.positional.len
  let expr = body[bodyStart]
  if expr.isAotValueExpr(specs.positional, typeName, available): expr else: NIL

proc generatorMarker(node: Value): bool =
  let flag = node.props.getOrDefault("generator", FALSE)
  if flag.kind != vkBool:
    raise newException(GeneError, "^generator requires a literal Bool")
  flag.boolVal

proc incompatibleGeneratorResult(c: Compiler, annotation: Value,
                                  typeParams: seq[string], depth = 0): bool =
  # Reject only contracts known to exclude Stream. Dynamic annotations and
  # protocol constraints keep their ordinary declaration/invocation checks.
  if depth > 64: return false
  if annotation.kind == vkSymbol:
    let name = annotation.symVal
    if name in typeParams: return false
    if c.parameterAliases.hasKey(name):
      return c.incompatibleGeneratorResult(c.parameterAliases[name], typeParams, depth + 1)
    for declaration in c.chunk.typeProtos:
      if declaration.name == name: return true
    # A lexical value may supply a type dynamically, including a binding that
    # shadows a builtin name. Do not invent a concrete contract for it.
    if c.localSlot(name) >= 0: return false
    let own = c.ownInterfaceEntry(name)
    if own.found and own.entry.category == cbcType:
      let form = own.entry.typeForm
      if form.kind == vkNode and form.head.isSymbol("alias") and form.body.len == 2:
        return c.incompatibleGeneratorResult(form.body[1], typeParams, depth + 1)
      return true
    return name in ["Nil", "Void", "Never", "Bool", "Int", "Float", "F64",
      "F32", "I8", "I16", "I32", "I64", "U8", "U16", "U32", "U64",
      "Char", "Str", "Symbol", "List", "Map", "PropMap", "Set", "HashMap",
      "Node", "Type", "Task", "Channel", "Cell", "AtomicCell", "Buffer",
      "Bytes", "Range", "Callable", "Fn", "Date", "Time", "DateTime", "Duration"]
  if annotation.kind == vkNode and annotation.head.kind == vkSymbol:
    if annotation.head.isSymbol("|"):
      if annotation.body.len == 0: return true
      for member in annotation.body:
        if not c.incompatibleGeneratorResult(member, typeParams, depth + 1): return false
      return true
    return c.incompatibleGeneratorResult(annotation.head, typeParams, depth + 1)
  annotation.kind in {vkVoid, vkBool, vkInt, vkFloat, vkString, vkChar}

proc returnContractRetainsScope(c: Compiler, annotation: Value,
                                 typeParams: seq[string], depth = 0): bool =
  # Deferred views retain the scope that interprets their contracts. A pooled
  # factory activation must not be cleared while its returned view is live.
  if depth > 64: return true
  case annotation.kind
  of vkNil: false
  of vkSymbol:
    let name = annotation.symVal
    if name in typeParams: return true
    if c.parameterAliases.hasKey(name):
      return c.returnContractRetainsScope(c.parameterAliases[name], typeParams, depth + 1)
    if name in ["Any", "Stream"]: return false
    not c.incompatibleGeneratorResult(annotation, typeParams)
  of vkNode:
    if annotation.head.isSymbol("Stream") or annotation.head.isSymbol("Callable") or
        annotation.head.isSymbol("Fn"):
      return true
    for item in annotation.body:
      if c.returnContractRetainsScope(item, typeParams, depth + 1): return true
    false
  else: false

proc buildFunctionProto(c: Compiler, name: string, paramList: Value,
                        body: openArray[Value], bodyStart: int,
                        typeParams: seq[string] = @[],
                        checksErrors = false,
                        errorTypeCount = 0,
                        immutableSelf = false,
                        tailBody = true,
                        aotSelfRepr = AotRepr(),
                        generator = false): FunctionProto =
  var start = bodyStart
  var returnType = NIL
  if start < body.len and body[start].isSymbol(":"):
    inc start
    if start >= body.len:
      raise newException(GeneError, "function return annotation requires a type")
    returnType = body[start]
    inc start

  if generator and c.incompatibleGeneratorResult(returnType, typeParams):
    raise newException(GeneError,
      "generator return annotation must admit Stream, got " & returnType.print())

  var specs = c.paramSpecs(paramList, typeParams)
  # Receiver admission is supplied by dispatch. Retain the annotation's origin
  # so replacement signatures cannot hide forbidden Self through this erasure.
  let receiverSelfAnnotation = immutableSelf and specs.positional.len > 0 and
    specs.positional[0] == "self" and specs.positionalTypes.len > 0 and
    specs.positionalTypes[0].isSymbol("Self")
  if receiverSelfAnnotation:
    specs.positionalTypes[0] = NIL
  var seenLocals = initTable[string, bool]()
  for local in specs.positional:
    if seenLocals.hasKey(local):
      raise newException(GeneError, "duplicate parameter binding: " & local)
    seenLocals[local] = true
  for p in specs.named:
    if seenLocals.hasKey(p.local):
      raise newException(GeneError, "duplicate parameter binding: " & p.local)
    seenLocals[p.local] = true
  if specs.rest.len > 0:
    if seenLocals.hasKey(specs.rest):
      raise newException(GeneError, "duplicate parameter binding: " & specs.rest)
    seenLocals[specs.rest] = true
  var fnCompiler = c.childCompiler()
  fnCompiler.inStatementFn =
    returnType.kind == vkSymbol and returnType.symVal in ["Nil", "Void"]
  fnCompiler.enableLocalSlots()
  fnCompiler.parentSlots = c.parentFrames()
  fnCompiler.parentFunctionSigs = c.parentFunctionSigFrames()
  if name.len > 0 and c.localSlot(name) >= 0 and
      fnCompiler.parentFunctionSigs.len > 0:
    let sig = functionSigFromParts(specs.positional.len, typeParams, returnType)
    if sig.known:
      fnCompiler.parentFunctionSigs[0][name] = sig.sig
  # Parameters are fresh rebindable bindings, so reserveLocal un-marks any outer
  # `let` of the same name inherited into fnCompiler.letNames (§12.1).
  var positionalSlots: seq[int]
  for i, name in specs.positional:
    let slot = fnCompiler.reserveLocal(name)
    positionalSlots.add slot
    if i < specs.positionalTypes.len:
      fnCompiler.recordLocalType(name, specs.positionalTypes[i])
      if specs.positionalTypes[i].isBareIntType:
        fnCompiler.fastLocalLoads[name] = slot
  var namedSlots: seq[int]
  for p in specs.named:
    namedSlots.add fnCompiler.reserveLocal(p.local)
    fnCompiler.recordLocalType(p.local, p.typeExpr)
  var restSlot = -1
  if specs.rest.len > 0:
    restSlot = fnCompiler.reserveLocal(specs.rest)
  # In a message/ctor body the receiver `self` is a compiler-owned immutable
  # binding — `(set self ...)` is a compile error (design §10/§12.1), so it
  # cannot be retargeted mid-body. Re-mark it after the param loop cleared it,
  # and reserve the name so no nested binder can shadow it either.
  if immutableSelf:
    fnCompiler.letNames.incl "self"
    fnCompiler.selfReserved = true
  fnCompiler.allowYield = true
  fnCompiler.inFunction = true
  fnCompiler.inGenerator = generator
  if "self" in specs.positional or specs.rest == "self":
    fnCompiler.selfAvailable = true
  for p in specs.named:
    if p.local == "self":
      fnCompiler.selfAvailable = true
      break
  var flowForms: seq[Value]
  if start <= body.high:
    for i in start .. body.high:
      flowForms.add body[i]
  fnCompiler.prepareStaticImports(flowForms)
  fnCompiler.reserveProtocolBindingsFor(flowForms)
  compileBodyFrom(fnCompiler, body, start, tail = tailBody)
  if generator and start < body.len:
    fnCompiler.warnDiscardedPipeline(body[^1])
  if fnCompiler.inGenerator and fnCompiler.sawNonVoidReturn:
    raise newException(GeneError,
      "generator return value must be void")
  let returnKnownBareInt =
    returnType.isBareIntType and not fnCompiler.inGenerator and
      not fnCompiler.sawNonVoidReturn and
      fnCompiler.formsKnownBareInt(body, start)
  let returnBoundaryRedundant =
    returnType.kind == vkSymbol and
      returnType.symVal in ["Any", "Int", "F64", "Bool", "Str", "Nil", "Void"] and
      not fnCompiler.inGenerator and not fnCompiler.sawNonVoidReturn and
      fnCompiler.formsKnownExactResult(body, returnType.symVal, start)
  discard fnCompiler.emit(if returnKnownBareInt: opReturnBareInt else: opReturn)
  fnCompiler.chunk.localNames = fnCompiler.localNames
  for name in fnCompiler.letNames:
    if name in fnCompiler.localNames: fnCompiler.chunk.immutableBindings.add name
  fnCompiler.chunk.immutableBindings.sort()
  var positionalSlotMaySet: seq[bool]
  var positionalParamsMaySet = false
  for slot in positionalSlots:
    let maySet = fnCompiler.chunk.chunkMaySetSlot(slot)
    positionalSlotMaySet.add maySet
    positionalParamsMaySet = positionalParamsMaySet or maySet

  var hasParamTypes = false
  for t in specs.positionalTypes:
    if t.kind != vkNil:
      hasParamTypes = true
      break
  var hasNamedParamTypes = false
  for p in specs.named:
    if p.typeExpr.kind != vkNil:
      hasNamedParamTypes = true
      break
  let selfParentSlot =
    if name.len > 0: c.localSlot(name)
    else: -1
  let simpleCall = typeParams.len == 0 and not checksErrors and
                   specs.rest.len == 0 and specs.named.len == 0 and
                   not hasParamTypes and not hasNamedParamTypes and
                   returnType.kind == vkNil and not fnCompiler.inGenerator and
                   not specs.hasOptionalPositional
  let needsCallScope = chunkNeedsCallScope(fnCompiler.chunk)
  var defaultsCanCapture = specs.hasOptionalPositional
  if not defaultsCanCapture:
    for p in specs.named:
      if p.defaultValue.optional:
        defaultsCanCapture = true
        break
  let poolableFrame = needsCallScope and not defaultsCanCapture and
                      not c.returnContractRetainsScope(returnType, typeParams)
  let poolCallScope = poolableFrame and chunkCanPoolCallScope(fnCompiler.chunk)
  let callScopeNeedsSlotNames = fnCompiler.chunk.chunkNeedsCallScopeSlotNames()
  let callScopeNeedsSlotReset =
    fnCompiler.localNames.len != specs.positional.len or specs.positional.len > 64
  var normalizedBody = @body
  for i in start ..< normalizedBody.len:
    normalizedBody[i] = fnCompiler.normalizedMacroTree(normalizedBody[i])
  var native = specs.detectNativeCompileOp(normalizedBody, start, returnType,
                                           typeParams, checksErrors,
                                           fnCompiler.inGenerator)
  if c.dynamicNameLookup: native = (ncoNone, 0)
  var aotParamReprs: seq[AotRepr]
  for i, paramType in specs.positionalTypes:
    if i == 0 and specs.positional[i] == "self" and
        aotSelfRepr.kind != arkNone:
      aotParamReprs.add aotSelfRepr
    else:
      aotParamReprs.add c.resolvedAotRepr(paramType)
  let aotReturnRepr = c.resolvedAotRepr(returnType)
  var requiresTypedNative = aotReturnRepr.kind == arkNativePtr
  for paramType in specs.positionalTypes:
    requiresTypedNative = requiresTypedNative or
      c.resolvedAotRepr(paramType).kind == arkNativePtr
  var hasNativeRepr = aotReturnRepr.kind == arkNativePtr
  var allAotParamsRepresentable = true
  for repr in aotParamReprs:
    hasNativeRepr = hasNativeRepr or repr.kind == arkNativePtr
    allAotParamsRepresentable =
      allAotParamsRepresentable and repr.kind != arkNone
  var aotLocals: seq[AotLocal]
  var aotExpr = NIL
  if hasNativeRepr and start >= body.len:
    ## A signature with no body is a declaration, not an executable function —
    ## a protocol message contributing only its interface. There is nothing to
    ## lower, and demanding a lowerable body here made a protocol message
    ## returning a native pointer impossible to declare at all. The native
    ## reprs stay on the proto so impls can be checked against them; `aotExpr`
    ## remains nil, so no C is emitted for the declaration itself.
    aotLocals.setLen(0)
  elif hasNativeRepr:
    ## An ordinary Gene body is a *sequence* of forms, so a multi-form body is
    ## folded into the `do` shape analysis and emission already understand.
    ## Requiring exactly one form here meant every typed-native function with
    ## more than one statement had to be wrapped in an explicit `(do ...)`,
    ## which nothing else in the language asks for.
    let rawLowerBody =
      if body.len == start + 1: normalizedBody[start]
      elif body.len > start + 1:
        newNode(newSym("do"), body = normalizedBody[start .. ^1])
      else: NIL
    let lowerBody = normalizeMessageCallTree(rawLowerBody)
    let cannotLower = typeParams.len != 0 or checksErrors or fnCompiler.inGenerator or
        specs.rest.len != 0 or specs.named.len != 0 or
        specs.hasComputedPositionalDefault or lowerBody.kind == vkNil or
        aotReturnRepr.kind == arkNone or
        not allAotParamsRepresentable or
        aotParamReprs.len != specs.positional.len or
        not c.isTypedNativeAotExpr(lowerBody, specs.positional,
                                   aotParamReprs, aotReturnRepr,
                                   c.chunk.ffiFns, aotLocals)
    if cannotLower:
      if requiresTypedNative:
        raise newException(GeneError,
          "typed_native function " &
          (if name.len > 0: name else: "<anonymous>") &
          " cannot lower its body statically; box explicitly or keep the " &
          "function in dynamic Gene")
      aotLocals.setLen(0)
    else:
      aotExpr = c.substituteAotConstants(lowerBody, specs.positional, aotLocals)
  else:
    ## Scalar functions get the statement lowering too.
    ##
    ## Until now the richer analysis was reachable only through
    ## `hasNativeRepr`, so a function that touched a native pointer could
    ## declare locals and run a `while` loop while a pure-`F64` numeric kernel
    ## — the shape most worth compiling — was restricted to
    ## `detectAotExpr`'s single expression over `+ - *`, `if`, and calls. That
    ## is backwards: nothing about locals or loops depends on a pointer being
    ## in the signature.
    ##
    ## It is attempted first and falls back to `detectAotExpr`, so this can
    ## only widen what lowers. Anything the statement analysis rejects still
    ## gets exactly the answer it got before.
    let scalarLowerable = allAotParamsRepresentable and
      aotReturnRepr.kind in {arkI64, arkF64} and
      aotParamReprs.len == specs.positional.len and
      typeParams.len == 0 and not checksErrors and not fnCompiler.inGenerator and
      specs.rest.len == 0 and specs.named.len == 0 and
      not specs.hasOptionalPositional
    if scalarLowerable and start < body.len:
      let rawLowerBody =
        if body.len == start + 1: normalizedBody[start]
        else: newNode(newSym("do"), body = normalizedBody[start .. ^1])
      let lowerBody = normalizeMessageCallTree(rawLowerBody)
      var scalarLocals: seq[AotLocal]
      if c.isTypedNativeAotExpr(lowerBody, specs.positional, aotParamReprs,
                                aotReturnRepr, c.chunk.ffiFns, scalarLocals):
        aotExpr = c.substituteAotConstants(lowerBody, specs.positional,
                                           scalarLocals)
        aotLocals = scalarLocals
    if aotExpr.kind == vkNil:
      aotExpr = c.detectAotExpr(name, specs, normalizedBody, start, returnType,
                                typeParams, checksErrors, fnCompiler.inGenerator)
  if aotExpr.kind != vkNil and not hasNativeRepr:
    # The original scalar AOT path is representation-homogeneous.
    for i in 0 ..< aotParamReprs.len:
      if aotParamReprs[i].kind == arkNone:
        aotParamReprs[i] = aotReturnRepr
  let aotFrameKind =
    if aotExpr.kind == vkNil: afkNone
    else: afkTypedNative
  let taskFrameKind =
    if fnCompiler.inGenerator: tfkGenerator
    elif bodyContainsAwait(body, start): tfkVm
    else: tfkNone
  var fastBindUnaryInt =
    typeParams.len == 0 and not checksErrors and specs.positional.len == 1 and
    specs.requiredPositionalCount == 1 and positionalSlots.len == 1 and
    positionalSlots[0] >= 0 and specs.rest.len == 0 and specs.named.len == 0 and
    hasParamTypes and specs.positionalTypes.len == 1 and
    specs.positionalTypes[0].isBareIntType and returnType.isBareIntType and
    not fnCompiler.inGenerator and specs.positionalDefaults.len == 1 and
    not specs.positionalDefaults[0].optional
  var fastBindPositionalInt =
    typeParams.len == 0 and not checksErrors and not fnCompiler.inGenerator and
    specs.rest.len == 0 and specs.named.len == 0 and specs.positional.len > 0 and
    specs.requiredPositionalCount == specs.positional.len and
    positionalSlots.len == specs.positional.len and hasParamTypes and
    specs.positionalTypes.len == specs.positional.len and returnType.isBareIntType and
    specs.positionalDefaults.len == specs.positional.len
  if fastBindPositionalInt:
    for i in 0 ..< specs.positional.len:
      if positionalSlots[i] < 0 or not specs.positionalTypes[i].isBareIntType or
          specs.positionalDefaults[i].optional:
        fastBindPositionalInt = false
        break
  var fastBindRequiredNamed =
    typeParams.len == 0 and not fnCompiler.inGenerator and specs.rest.len == 0 and
    specs.named.len > 0 and
    specs.requiredPositionalCount == specs.positional.len and
    specs.positionalDefaults.len == specs.positional.len and
    positionalSlots.len == specs.positional.len and
    namedSlots.len == specs.named.len
  if fastBindRequiredNamed:
    for i in 0 ..< specs.positional.len:
      if positionalSlots[i] < 0 or specs.positionalDefaults[i].optional:
        fastBindRequiredNamed = false
        break
  if fastBindRequiredNamed:
    for i, p in specs.named:
      if namedSlots[i] < 0 or p.defaultValue.optional:
        fastBindRequiredNamed = false
        break
  result = FunctionProto(name: name, sourceLoc: c.currentLoc,
                          receiverSelfAnnotation: receiverSelfAnnotation,
                         typeParams: typeParams,
                         params: specs.positional,
                         localNames: fnCompiler.localNames,
                         positionalSlots: positionalSlots,
                         positionalSlotMaySet: positionalSlotMaySet,
                         positionalParamsMaySet: positionalParamsMaySet,
                         namedSlots: namedSlots,
                         restSlot: restSlot,
                         requiredPositional: specs.requiredPositionalCount,
                         simpleCall: simpleCall,
                         needsCallScope: needsCallScope,
                         poolCallScope: poolCallScope,
                         callScopeNeedsSlotNames: callScopeNeedsSlotNames,
                         callScopeNeedsSlotReset: callScopeNeedsSlotReset,
                         paramTypes: specs.positionalTypes,
                         hasParamTypes: hasParamTypes,
                         paramDefaults: specs.positionalDefaults,
                         restParam: specs.rest, restType: specs.restType,
                         namedParams: specs.named,
                         hasNamedParamTypes: hasNamedParamTypes,
                         returnType: returnType,
                         hasReturnType: returnType.kind != vkNil,
                         returnKnownBareInt: returnKnownBareInt,
                         returnBoundaryRedundant: returnBoundaryRedundant,
                         frameNeedsImplValidation:
                           fnCompiler.chunk.chunkHasDeferredImplValidation,
                         fastBindUnaryInt: fastBindUnaryInt,
                         fastBindPositionalInt: fastBindPositionalInt,
                         fastBindRequiredNamed: fastBindRequiredNamed,
                         isGenerator: fnCompiler.inGenerator,
                         selfParentSlot: selfParentSlot,
                         nativeOp: native.op,
                         nativeParamIndex: native.paramIndex,
                         aotExpr: aotExpr,
                         aotParamReprs: aotParamReprs,
                         aotLocals: aotLocals,
                         aotReturnRepr: aotReturnRepr,
                         aotFrameKind: aotFrameKind,
                         aotFrameCanSuspend: false,
                         taskFrameKind: taskFrameKind,
                         checksErrors: checksErrors,
                         errorTypeCount: errorTypeCount,
                         chunk: fnCompiler.chunk)
  result.chunk.owner = result
  result.fastBindPositionalScalars = result.supportsScalarBinding()
  if c.dynamicNameLookup:
    if requiresTypedNative:
      raise newException(GeneError, "typed_native code cannot assume runtime macro caller bindings")
    result.aotExpr = NIL
    result.aotLocals = @[]
    result.aotFrameKind = afkNone
  if poolableFrame and not poolCallScope and c.closurePoolCandidates != nil and
      fnCompiler.chunk.chunkCanPoolCallScope(closures = true):
    c.closurePoolCandidates[].add result
  deriveScopelessChunk(result)

proc nativeOwnership(value: Value, context: string): NativeOwnership =
  if value.kind != vkSymbol:
    raise newException(GeneError, context & " must be borrow, transfer, or copy")
  case value.symVal
  of "borrow": noBorrow
  of "transfer": noTransfer
  of "copy": noCopy
  else:
    raise newException(GeneError, context & " must be borrow, transfer, or copy")

proc nativeResultSources(expr: Value, params: openArray[string],
                         locals: Table[string, HashSet[int]]): HashSet[int] =
  ## Conservative provenance for pointer results crossing a dynamic entry.
  ## A result reached through a binding, field, or call argument retains every
  ## parameter it may borrow from; transferring such a result would create a
  ## second owner for a wrapper that remains live.
  if expr.kind == vkSymbol:
    for i, param in params:
      if expr.symVal == param:
        result.incl i
        return
    if locals.hasKey(expr.symVal):
      return locals[expr.symVal]
    return
  if expr.kind != vkNode:
    return
  if expr.head.isSymbol("path") and expr.body.len > 0:
    return nativeResultSources(expr.body[0], params, locals)
  if expr.head.kind == vkSymbol and expr.head.symVal == "set" and
      expr.body.len == 2:
    return nativeResultSources(expr.body[1], params, locals)
  if expr.head.isSymbol("do") and expr.body.len > 0:
    var flowLocals = locals
    for i in 0 ..< expr.body.high:
      let statement = expr.body[i]
      if statement.kind != vkNode or statement.head.kind != vkSymbol:
        continue
      if statement.head.symVal in ["let", "var"] and
          statement.body.len == 4 and statement.body[0].kind == vkSymbol:
        flowLocals[statement.body[0].symVal] =
          nativeResultSources(statement.body[3], params, flowLocals)
      elif statement.head.symVal == "set" and statement.body.len == 2 and
          statement.body[0].kind == vkSymbol:
        flowLocals[statement.body[0].symVal] =
          nativeResultSources(statement.body[1], params, flowLocals)
    return nativeResultSources(expr.body[^1], params, flowLocals)
  # Until callees carry a richer ownership signature, assume their pointer
  # result may borrow from any argument. This keeps the dynamic ownership seam
  # safe and can be relaxed when direct calls publish result provenance.
  for arg in expr.body:
    for source in nativeResultSources(arg, params, locals):
      result.incl source

proc nativeEntryMarker(node: Value, fn: FunctionProto): NativeEntryProto =
  if not node.props.hasKey("native_entry"):
    return NativeEntryProto(resultBorrowParam: -1)
  if fn.name.len == 0:
    raise newException(GeneError,
      "^native_entry requires a named typed_native function")
  if fn.aotExpr.kind == vkNil:
    raise newException(GeneError,
      "function " & fn.name & " ^native_entry requires typed_native lowering")
  let marker = node.props["native_entry"]
  if marker.kind != vkMap:
    raise newException(GeneError,
      "function " & fn.name & " ^native_entry must be a map")
  result.enabled = true
  result.resultBorrowParam = -1
  result.paramOwnership = newSeq[NativeOwnership](fn.params.len)
  for key, policyExpr in marker.mapEntries:
    if key == "result":
      if fn.aotReturnRepr.kind != arkNativePtr:
        raise newException(GeneError,
          "function " & fn.name &
          " ^native_entry ^result is only valid for a native-pointer result")
      result.resultOwnership = nativeOwnership(
        policyExpr, "function " & fn.name & " ^native_entry ^result")
      continue
    var paramIndex = -1
    for i, param in fn.params:
      if param == key:
        paramIndex = i
        break
    if paramIndex < 0:
      raise newException(GeneError,
        "function " & fn.name &
        " ^native_entry names no parameter: " & key)
    if paramIndex >= fn.aotParamReprs.len or
        fn.aotParamReprs[paramIndex].kind != arkNativePtr:
      raise newException(GeneError,
        "function " & fn.name & " ^native_entry ^" & key &
        " is only valid for a native-pointer parameter")
    result.paramOwnership[paramIndex] = nativeOwnership(
      policyExpr, "function " & fn.name & " ^native_entry ^" & key)
  for i, repr in fn.aotParamReprs:
    if repr.kind != arkNativePtr:
      continue
    if result.paramOwnership[i] == noNone:
      raise newException(GeneError,
        "function " & fn.name & " ^native_entry requires an ownership " &
        "policy for parameter " & fn.params[i])
    if repr.nativeType == nil or repr.nativeType.wrapperField.len == 0:
      raise newException(GeneError,
        "function " & fn.name & " ^native_entry parameter " & fn.params[i] &
        " requires its native Type to declare ^wrapper")
    if result.paramOwnership[i] == noCopy and
        repr.nativeType.copySymbol.len == 0:
      raise newException(GeneError,
          "function " & fn.name & " ^native_entry copies parameter " &
          fn.params[i] & " but its native Type does not declare ^copy")
    if result.paramOwnership[i] == noCopy and
        repr.nativeType.releaseSymbol.len == 0:
      raise newException(GeneError,
        "function " & fn.name & " ^native_entry copies parameter " &
        fn.params[i] & " but its native Type does not declare ^release")
  if fn.aotReturnRepr.kind == arkNativePtr:
    if result.resultOwnership == noNone:
      raise newException(GeneError,
        "function " & fn.name &
        " ^native_entry requires an ownership policy for its result")
    if fn.aotReturnRepr.nativeType == nil or
        fn.aotReturnRepr.nativeType.wrapperField.len == 0:
      raise newException(GeneError,
        "function " & fn.name &
        " ^native_entry result requires its native Type to declare ^wrapper")
    if result.resultOwnership == noBorrow:
      raise newException(GeneError,
        "function " & fn.name &
        " ^native_entry cannot borrow a native-pointer result; use transfer " &
        "or copy")
    if result.resultOwnership == noTransfer and
        fn.aotReturnRepr.nativeType.releaseSymbol.len == 0:
      raise newException(GeneError,
          "function " & fn.name &
          " ^native_entry transfers its result but its native Type does not " &
          "declare ^release")
    if result.resultOwnership == noTransfer:
      let sources = nativeResultSources(
        fn.aotExpr, fn.params, initTable[string, HashSet[int]]())
      for source in sources:
        if source < result.paramOwnership.len and
            result.paramOwnership[source] == noBorrow:
          raise newException(GeneError,
            "function " & fn.name &
            " ^native_entry cannot transfer a result derived from borrowed " &
            "parameter " & fn.params[source])
    if result.resultOwnership == noCopy:
      if fn.aotReturnRepr.nativeType.copySymbol.len == 0:
        raise newException(GeneError,
          "function " & fn.name &
          " ^native_entry copies its result but its native Type does not " &
          "declare ^copy")
      if fn.aotReturnRepr.nativeType.releaseSymbol.len == 0:
        raise newException(GeneError,
          "function " & fn.name &
          " ^native_entry copies its result but its native Type does not " &
          "declare ^release")

proc compileIfThen(c: var Compiler, node: Value, tail = false) =
  ## (if_yes cond body...) — everything after the condition is the then
  ## branch (implicit do); the whole form is nil when the condition is falsy.
  let body = node.body
  if body.len == 0:
    c.emitConst NIL
    return
  compileExpr(c, body[0])
  let elseJump = c.emitJump(opJumpIfFalse)
  compileBodyFrom(c, body, 1, tail = tail)
  let endJump = c.emitJump(opJump)
  c.patchJump(elseJump)
  c.emitConst NIL
  c.patchJump(endJump)

proc compileIfNot(c: var Compiler, node: Value, tail = false) =
  ## (if_not cond body...) — everything after the condition is the else
  ## branch (implicit do); the whole form is nil when the condition is truthy.
  let body = node.body
  if body.len == 0:
    c.emitConst NIL
    return
  compileExpr(c, body[0])
  let bodyJump = c.emitJump(opJumpIfFalse)
  c.emitConst NIL
  let endJump = c.emitJump(opJump)
  c.patchJump(bodyJump)
  compileBodyFrom(c, body, 1, tail = tail)
  c.patchJump(endJump)

proc compileIf(c: var Compiler, node: Value, tail = false) =
  validateConditionalClauses(node)
  let body = node.body
  if body.len == 0:
    c.emitConst NIL
    return

  if body.len >= 2 and body[1].kind == vkNode and body[1].head.isSymbol("then"):
    compileExpr(c, body[0])
    var nextJump = c.emitJump(opJumpIfFalse)
    compileBody(c, body[1].body, tail = tail)
    var endJumps: seq[int]
    endJumps.add c.emitJump(opJump)
    c.patchJump(nextJump)

    var hasDefault = false
    for i in 2 ..< body.len:
      let clause = body[i]
      if clause.kind != vkNode or clause.head.kind != vkSymbol:
        continue
      case clause.head.symVal
      of "elif":
        if clause.body.len == 0:
          continue
        compileExpr(c, clause.body[0])
        nextJump = c.emitJump(opJumpIfFalse)
        compileBodyFrom(c, clause.body, 1, tail = tail)
        endJumps.add c.emitJump(opJump)
        c.patchJump(nextJump)
      of "else":
        compileBody(c, clause.body, tail = tail)
        hasDefault = true
        break
      else:
        discard

    if not hasDefault:
      c.emitConst NIL
    for at in endJumps:
      c.patchJump(at)
    return

  compileExpr(c, body[0])
  let elseJump = c.emitJump(opJumpIfFalse)
  if body.len >= 2:
    compileExpr(c, body[1], tail = tail)
  else:
    c.emitConst NIL
  let endJump = c.emitJump(opJump)
  c.patchJump(elseJump)
  if body.len >= 3:
    compileExpr(c, body[2], tail = tail)
  else:
    c.emitConst NIL
  c.patchJump(endJump)

# && and || evaluate operands left to right, stop at the first falsy (&&) or
# truthy (||) operand, and yield the last operand evaluated — not a coerced
# Bool — so `(|| maybe-void "default")` works as a default-value form.
proc compileShortCircuit(c: var Compiler, node: Value, op: OpCode,
                         emptyValue: Value, tail = false) =
  let body = node.body
  if body.len == 0:
    c.emitConst emptyValue
    return
  var jumps: seq[int] = @[]
  for i in 0 ..< body.len:
    compileExpr(c, body[i], tail = tail and i == body.high)
    if i < body.len - 1:
      jumps.add c.emitJump(op)
  for at in jumps:
    c.patchJump(at)

proc compileNot(c: var Compiler, node: Value) =
  if node.body.len != 1:
    raise newException(GeneError, "! expects exactly one argument")
  compileExpr(c, node.body[0])
  discard c.emit(opNot)

proc checkBindingProps(node: Value) =
  for key, _ in node.props:
    if key != "private":
      raise newException(GeneError, node.head.symVal & " does not accept ^" & key)

proc checkBindingTail(node: Value, valueIndex: int) =
  if node.body.len <= valueIndex + 1: return
  let form = node.head.symVal
  var message = form &
    " expects a pattern, an optional type annotation, and one value; found " &
    $(node.body.len - valueIndex - 1) & " extra forms"
  for i in valueIndex + 1 ..< node.body.len:
    let extra = node.body[i]
    if (extra.kind == vkNode and extra.head.isSymbol("Path")) or
        (extra.kind == vkSymbol and
         (extra.symVal.startsWith(".") or extra.symVal.startsWith("?."))):
      message.add "; a path or message after ')' is a separate form; " &
        "write (/a (g)) or ((g) .size)"
      break
  raise newException(GeneError, message)

proc compileVar(c: var Compiler, node: Value, immutable = false) =
  checkBindingProps(node)
  let body = node.body
  if body.len == 0:
    let form = if immutable: "let" else: "var"
    raise newException(GeneError, form & " requires a name or pattern")
  let typed = body.len >= 2 and body[1].isSymbol(":")
  if typed and body.len < 3:
    raise newException(GeneError, "var type annotation requires a type")
  let valueIndex = if typed: 3 else: 1
  checkBindingTail(node, valueIndex)
  let generatorValue = body.len > valueIndex and
    ((body[valueIndex].kind == vkSymbol and c.generatorFnNames.hasKey(body[valueIndex].symVal)) or
     (body[valueIndex].kind == vkNode and body[valueIndex].head.isSymbol("fn") and
      body[valueIndex].generatorMarker))
  if c.useLocalSlots and body[0].kind == vkSymbol and body.len > valueIndex and
      body[valueIndex].kind == vkNode and body[valueIndex].head.isSymbol("fn"):
    discard c.reserveLocal(body[0].symVal)
  if body.len > valueIndex:
    if body[0].kind == vkSymbol and body[valueIndex].kind == vkNode and
        body[valueIndex].head.isSymbol("fn"):
      compileFn(c, body[valueIndex], inferredName = body[0].symVal)
    else:
      compileExpr(c, body[valueIndex])
  else:
    c.emitConst NIL
  if typed:
    let where =
      if body[0].kind == vkSymbol: "var '" & body[0].symVal & "'"
      else: "var destructuring"
    discard c.emit(opCheckType, c.chunk.addConst(body[2]), name = where)
  if body[0].kind == vkSymbol:
    c.emitDefineBinding(body[0].symVal)
    if generatorValue: c.generatorFnNames[body[0].symVal] = true
    else: c.generatorFnNames.del(body[0].symVal)
    # Record binding mutability (design §12.1). A later `set` on a `let`
    # name is a compile error; a `var` un-marks a name an outer scope froze.
    if immutable: c.letNames.incl body[0].symVal
    else: c.letNames.excl body[0].symVal
    # Remember scalar `let` values so typed_native lowering can substitute
    # them. A `var`, or a second `let` with a different value, poisons the name
    # — the entry stays but resolves to nothing, so an ambiguous constant costs
    # the optimization rather than producing a wrong one.
    let constName = body[0].symVal
    let constValue =
      if immutable and body.len > valueIndex and
          body[valueIndex].kind in {vkInt, vkFloat}:
        body[valueIndex]
      else: NIL
    if c.aotConstants.hasKey(constName) and
        not equal(c.aotConstants[constName], constValue):
      c.aotConstants[constName] = NIL
    else:
      c.aotConstants[constName] = constValue
    if typed:
      c.recordLocalType(body[0].symVal, body[2])
      c.emitDeclareType(body[0].symVal, body[2])
    if body[0].symVal == "self":
      c.selfAvailable = true
    if body.len > valueIndex and
        ((body[valueIndex].kind == vkSymbol and
          c.ordinaryFnNames.hasKey(body[valueIndex].symVal)) or
         (body[valueIndex].kind == vkNode and
          body[valueIndex].head.isSymbol("fn"))):
      c.ordinaryFnNames[body[0].symVal] = true
  else:
    if c.useLocalSlots:
      for name in patternBindingNames(body[0]):
        discard c.reserveLocal(name)
    for name in patternBindingNames(body[0]):
      if immutable: c.letNames.incl name
      else: c.letNames.excl name
    discard c.emit(opMatchBind, c.chunk.addConst(body[0]))  # destructuring
    if patternBindsSelf(body[0]):
      c.selfAvailable = true

proc isConstantValue(value: Value): bool =
  ## design §12.1's constant subset: a value the compiler holds outright — a
  ## scalar, or an aggregate whose elements are themselves constant. Anything
  ## that can call, read a binding, or observe state is excluded, which is what
  ## makes the value resolvable before runtime.
  ##
  ## **A bare symbol is a binding read, not a literal**, so it is rejected here.
  ## That is the one place this is narrower than the web profile's
  ## `isLiteralConstant` (web.nim), which sees an already-analyzed tree where a
  ## symbol *value* and a name reference are different nodes. Narrower in this
  ## direction is the safe one: everything the VM accepts, the profile accepts.
  case value.kind
  of vkNil, vkVoid, vkBool, vkInt, vkFloat, vkString:
    true
  of vkList:
    for item in value.listItems:
      if not isConstantValue(item):
        return false
    true
  of vkMap:
    # Values only, and that is complete rather than partial: a Map key is not a
    # Value. `PropEntry` holds an interned `keyId: int32` and the reader refuses
    # any entry not written `^name`, so there is no key that could be an
    # aggregate, need validating here, or need freezing in
    # `frozenConstantValue`.
    for _, item in value.mapEntries:
      if not isConstantValue(item):
        return false
    true
  else:
    false

proc frozenConstantValue(value: Value): Value =
  ## A tier-0 constant rebuilt with its aggregates marked immutable. Scalars are
  ## already immutable and come back as they are.
  ##
  ## **This is the one place a `const` differs from a `let` in what the value
  ## does, rather than in what the binding does** (design §12.1): `(let xs
  ## [1 2 3])` hands out a mutable list and anything holding it may push to it;
  ## `(const xs [1 2 3])` does not. It rides on the same flag `#[1 2 3]` already
  ## sets — `newList`/`newMap` take it, and `compileListValue` and the `vkMap`
  ## arm of `compileExpr` already pass it through to `opMakeList`/`opMakeMap` —
  ## so nothing here is a new representation.
  ##
  ## Total on what reaches it: `isConstantValue` admits only scalars and
  ## aggregates of them, which is disjoint from everything `vm.nim`'s
  ## `freezeValue` refuses, so there is no unfreezable constant to diagnose.
  case value.kind
  of vkList:
    var items = newSeq[Value](value.listItems.len)
    for i, item in value.listItems:
      items[i] = frozenConstantValue(item)
    newList(items, immutable = true)
  of vkMap:
    var entries = initPropTable()
    for key, val in value.mapEntries:
      entries[key] = frozenConstantValue(val)
    newMap(entries, immutable = true)
  else:
    value

proc compileConst(c: var Compiler, node: Value) =
  ## `(const NAME value)` / `(const NAME : T value)` — design §12.1's third
  ## binding form. A fixed binding whose value resolves before runtime.
  ##
  ## The initializer is checked against `isConstantValue` rather than evaluated,
  ## so this needs none of §11.2's deferred compile-time evaluation: the value is
  ## already in hand at compile time. What the check buys is that the two
  ## backends mean one thing by the word — a top-level `let` is a runtime slot
  ## here and a literal-only JS `const` in the web profile, and `const` is the
  ## spelling that does not depend on which side you are on.
  # Module and namespace level only. A module-level const has one value for the
  # life of the program, which is what makes a single flat constant table
  # correct and what will let a use site fold; a binding created per call or per
  # iteration does not, and folding that needs a scope-aware table — two
  # mechanisms wearing one word. `let` already covers the body case, where its
  # value is fixed anyway; `const` covers the case `let` cannot state portably.
  checkBindingProps(node)
  if c.inFunction:
    raise newException(GeneError,
      "const is a module-level declaration and cannot appear inside a " &
      "function (design §12.1); use let, whose value in a body is fixed too")
  if c.loopDepth > 0:
    raise newException(GeneError,
      "const is a module-level declaration and cannot appear inside a loop " &
      "body, which runs it once per iteration (design §12.1); use let")
  # `inFunction`/`loopDepth` are not sufficient: a `const` nested in a *branch*
  # at module level clears both, and use-site folding then reads a value the
  # binding may never receive —
  #     (if true (const K 2) (const K 1)) (fn f [] K)   ; f folded 1, K is 2
  # which is one name meaning two things in one program, the exact failure this
  # form exists to remove. `staticTopLevelImpls` is the established "declared
  # unconditionally at top level" marker, and it already treats `do` as
  # transparent grouping, so `(do (const K 1))` stays legal because it really is
  # unconditional. The web profile refuses a top-level `if` outright, so this
  # keeps the VM the narrower of the two — the safe direction.
  if node.bits notin c.staticTopLevelImpls:
    raise newException(GeneError,
      "const must be declared unconditionally at module or namespace level " &
      "(design §12.1): a const nested in a branch has a value that use sites " &
      "resolve before runtime but the binding might never receive; use let")
  let body = node.body
  if body.len == 0:
    raise newException(GeneError, "const requires a name and a constant value")
  if body[0].kind != vkSymbol:
    raise newException(GeneError,
      "const requires a plain name: a destructuring pattern takes its value " &
      "apart at runtime, which is the thing a const has already finished " &
      "doing (design §12.1); use let")
  let name = body[0].symVal
  let typed = body.len >= 2 and body[1].isSymbol(":")
  if typed and body.len < 3:
    raise newException(GeneError, "const type annotation requires a type")
  let valueIndex = if typed: 3 else: 1
  if body.len <= valueIndex:
    # `(var x)` may stand alone and be assigned later; a const has no later.
    raise newException(GeneError,
      "const '" & name & "' requires a value: a const has no later assignment " &
      "that could give it one (design §12.1)")
  let declared = body[valueIndex]
  checkBindingTail(node, valueIndex)
  if not isConstantValue(declared):
    raise newException(GeneError,
      "const '" & name & "' requires a constant value — a scalar, or an " &
      "aggregate of constants. This initializer has to run to produce one, " &
      "and a const resolves before runtime (design §12.1); use let")
  let value = frozenConstantValue(declared)
  compileExpr(c, value)
  if typed:
    discard c.emit(opCheckType, c.chunk.addConst(body[2]),
                   name = "const '" & name & "'")
  c.emitDefineBinding(name)
  # A `set` on this name is a compile error, by the same table `let` uses.
  c.letNames.incl name
  # Recorded for use-site folding (see emitLoadBinding). The frozen value, so
  # every folded use shares one immutable object.
  c.constValues[name] = value
  # Every const is an AOT constant, where a `let` qualifies only as a bare
  # `Int`/`Float` (see compileVar). A non-scalar here costs nothing: two read
  # sites take only `{vkInt, vkFloat}` and the third recurses into the value,
  # where an aggregate matches no lowering case and declines. Declining is the
  # whole safety property — an unlowerable constant loses the optimization
  # rather than emitting wrong C — so it has a test rather than only this note.
  # What it buys is that a kernel naming a constant lowers without the name
  # having to be a bare numeric literal.
  #
  # The poison rule is kept rather than assumed away: if a `let` elsewhere binds
  # the same name to something else, an ambiguous constant should cost the
  # optimization rather than produce a wrong substitution.
  if c.aotConstants.hasKey(name) and not equal(c.aotConstants[name], value):
    c.aotConstants[name] = NIL
  else:
    c.aotConstants[name] = value
  if typed:
    c.recordLocalType(name, body[2])
    c.emitDeclareType(name, body[2])

proc setTargetIsPath(v: Value): bool =
  v.kind == vkNode and (v.head.isSymbol("path") or v.head.isSymbol("Path"))

proc compileSetPath(c: var Compiler, node: Value)

proc compileSet(c: var Compiler, node: Value) =
  let body = node.body
  # The assignment target is `body[0]`. Testing `body[1]` meant only the spaced
  # `(set t /n 2)` got the helpful text, while the glued `(set t/n 2)` — which
  # is what people actually type, and reads as a single `path` node — fell
  # through to the generic arity message.
  if body.len == 2 and setTargetIsPath(body[0]):
    compileSetPath(c, node)
    return
  if body.len == 3 and setTargetIsPath(body[1]):
    raise newException(GeneError,
      "set path assignment requires one glued path and a value")
  if body.len != 2:
    raise newException(GeneError,
      "set requires exactly a target and a value")
  if body[0].kind != vkSymbol:
    raise newException(GeneError, "set requires a name or path and a value")
  validateBindingName(body[0].symVal)
  if body[0].symVal in c.letNames:
    # `self` is compiler-owned, so "use var" is not advice a caller can act on;
    # a named declaration was not written with `let` either. Name the actual
    # binder rather than guessing at one (design §10/§12.1).
    if c.selfReserved and body[0].symVal == "self":
      raise newException(GeneError,
        "'self' is the receiver and cannot be reassigned in a message body " &
        "(design §10)")
    raise newException(GeneError,
      "cannot set '" & body[0].symVal & "': let, const, and named declarations " &
      "(fn, type, enum, protocol, ns, macro, alias) are fixed bindings " &
      "(design §12.1); use var for a rebindable binding")
  compileExpr(c, body[1])
  if c.moduleSyntaxFnExports != nil:
    c.moduleSyntaxFnExports[].excl(
      (c.namespacePath & @[body[0].symVal]).join("/"))
  c.ordinaryFnNames.del(body[0].symVal)
  c.generatorFnNames.del(body[0].symVal)
  c.emitSetBinding(body[0].symVal)

proc compileFn(c: var Compiler, node: Value, inferredName: string) =
  let body = node.body
  var idx = 0
  var name = ""
  var definesName = false
  var typeParams: seq[string]
  if body.len > 0 and (body[0].kind == vkSymbol or body[0].kind == vkNode):
    let nameSpec = functionNameAndTypeParams(body[0])
    name = nameSpec.name
    typeParams = nameSpec.typeParams
    definesName = name.len > 0
    idx = 1
  elif inferredName.len > 0:
    name = inferredName
  if idx >= body.len or body[idx].kind != vkList:
    raise newException(GeneError, "fn requires a parameter vector")

  if definesName and c.useLocalSlots:
    discard c.reserveLocal(name)
  if name.len > 0:
    # Register before compiling the body so recursive ordinary calls can use
    # fused call opcodes. A later `set` removes this proof.
    c.ordinaryFnNames[name] = true
  let errorRow = compileErrorRow(c, node)
  let generator = node.generatorMarker
  if generator and name.len > 0: c.generatorFnNames[name] = true
  let proto = buildFunctionProto(c, name, body[idx], body, idx + 1,
                                 typeParams = typeParams,
                                 checksErrors = errorRow.checks,
                                 errorTypeCount = errorRow.count,
                                 generator = generator)
  let isPublic = definesName and node.bits in c.staticTopLevelImpls and
    not node.declarationIsPrivate
  proto.publicErrorInterface = isPublic
  if node.props.hasKey("errors"):
    proto.signatureErrorExprs = node.props["errors"].listItems
  proto.nativeEntry = nativeEntryMarker(node, proto)
  # Declaration meta (@route ..., @doc ...) rides the proto as raw data so
  # Module/declarations records can expose it (proposal §8 route discovery).
  for key, val in node.meta:
    proto.declMetaKeys.add key
    proto.declMetaValues.add val
  c.recordLocalFunctionSig(name, proto)
  discard c.emit(opMakeFn, c.chunk.addFunction(proto))
  if definesName:
    c.emitDefineBinding(name, immutable = true)
    c.ordinaryFnNames[name] = true
    if generator: c.generatorFnNames[name] = true

proc compileFexpr(c: var Compiler, node: Value) =
  ## `(fn name! [params] body...)` — runtime fexpr / syntax callable (design
  ## §3/§11.1). Parameters bind raw syntax nodes; `caller_env` and
  ## `syntax_call` arrive as implicit leading parameters at syntax_call time,
  ## so the body resolves them like ordinary locals.
  let body = node.body
  if node.generatorMarker:
    raise newException(GeneError, "a fexpr cannot be a generator")
  var idx = 0
  var name = ""
  var definesName = false
  if body.len > 0 and body[0].kind == vkSymbol:
    name = body[0].symVal
    definesName = true
    idx = 1
  if idx >= body.len or body[idx].kind != vkList:
    raise newException(GeneError, "fexpr requires a parameter vector")
  if not definesName or name.len <= 1 or not name.endsWith("!"):
    raise newException(GeneError,
      "fexprs must be named by a trailing-! binding: (fn name! [syntax...] body...)")
  if definesName:
    if c.useLocalSlots:
      discard c.reserveLocal(name, allowFexprName = true)
  let errorRow = compileErrorRow(c, node)
  var params = @[newSym("caller_env"), newSym("syntax_call")]
  for item in body[idx].listItems:
    params.add item
  let proto = buildFunctionProto(c, name, newList(params), body, idx + 1,
                                 checksErrors = errorRow.checks,
                                 errorTypeCount = errorRow.count)
  proto.isSyntaxFn = true
  proto.publicErrorInterface = definesName and node.bits in c.staticTopLevelImpls and
    not node.declarationIsPrivate
  if node.props.hasKey("errors"):
    proto.signatureErrorExprs = node.props["errors"].listItems
  # Syntax calls carry raw nodes and always bind through the general call
  # scope; the fused fast-bind paths assume evaluated arguments.
  proto.simpleCall = false
  proto.needsCallScope = true
  proto.poolCallScope = false
  proto.fastBindUnaryInt = false
  proto.fastBindPositionalInt = false
  proto.fastBindPositionalScalars = false
  proto.fastBindRequiredNamed = false
  discard c.emit(opMakeFn, c.chunk.addFunction(proto))
  if definesName:
    c.emitDefineBinding(name, immutable = true, allowFexprName = true)
    if c.moduleSyntaxFnExports != nil and
        node.bits in c.staticTopLevelImpls and not node.declarationIsPrivate:
      c.moduleSyntaxFnExports[].incl(
        (c.namespacePath & @[name]).join("/"))

proc importSelections(sel: Value): seq[ImportSelection] =
  ## Parse a single name `add` or a `[add, sub : minus]` selection list. The
  ## reader keeps vectors as flat tokens, so `,` and `:` arrive as symbols.
  proc selectionName(value: Value): string =
    if value.kind == vkSymbol:
      return value.symVal
    if value.kind == vkNode and value.head.isSymbol("path"):
      var segments: seq[string]
      for segment in value.body:
        if segment.kind != vkSymbol:
          return ""
        segments.add segment.symVal
      return segments.join("/")
  let single = selectionName(sel)
  if single.len > 0:
    return @[ImportSelection(name: single, local: single)]
  if sel.kind != vkList:
    raise newException(GeneError, "import selection must be a name or [list]")
  let items = sel.listItems
  var i = 0
  while i < items.len:
    let s = selectionName(items[i])
    if s == "," or s == "":
      inc i
      continue
    var local = s
    inc i
    if i < items.len and items[i].symbolText == ":":
      inc i
      if i >= items.len or items[i].kind != vkSymbol:
        raise newException(GeneError, "import alias requires a name")
      local = items[i].symVal
      inc i
    result.add ImportSelection(name: s, local: local)

proc wildcardPath(value: Value,
                  segments: var seq[string]): bool =
  if value.kind == vkSymbol:
    return value.symVal == "*"
  if value.kind != vkNode or not value.head.isSymbol("path") or
      value.body.len == 0 or not value.body[^1].isSymbol("*"):
    return false
  for i in 0 ..< value.body.high:
    if value.body[i].kind != vkSymbol:
      return false
    segments.add value.body[i].symVal
  true

proc nsPathSegments(v: Value): seq[string]

proc parseImportSpec*(node: Value): ImportSpec =
  if node.kind != vkNode or not node.head.isSymbol("import"):
    raise newException(GeneError, "expected import form")
  # Module sources are properties, just like package and export options.
  # Keep the allow-list closed so misspelled options cannot be ignored.
  for key, value in node.props:
    case key
    of "from":
      if value.kind != vkString:
        raise newException(GeneError, "import ^from must be a path string")
      result.fromModule = true
      result.modulePath = value.strVal
    of "export":
      if value.kind != vkBool:
        raise newException(GeneError, "import ^export must be Bool")
      result.reexport = value.boolVal
    of "pkg":
      if value.kind != vkString or value.strVal.len == 0:
        raise newException(GeneError,
          "import ^pkg must be a non-empty package name string")
      result.pkgName = value.strVal
    of "as":
      raise newException(GeneError,
        "import ^as was removed; use `source : alias`")
    else:
      raise newException(GeneError, "import got unexpected option: ^" & key)

  let body = node.body
  if body.len >= 2 and body[^2].isSymbol("from") and
      body[^1].kind == vkString:
    raise newException(GeneError,
      "import: `from` was removed; use `^from \"path\"`")
  if result.fromModule:
    if body.len == 0:
      raise newException(GeneError,
        "import from a module requires a selection or wildcard")
    var segments: seq[string]
    let isWildcard = wildcardPath(body[0], segments)
    if body.len == 1:
      if isWildcard:
        result.wildcard = true
        result.wildcardSegments = segments
      else:
        result.selections = importSelections(body[0])
    elif body.len == 3 and body[1].isSymbol(":") and
        body[2].kind == vkSymbol:
      if isWildcard:
        result.wildcard = true
        result.wildcardSegments = segments
        result.alias = body[2].symVal
      else:
        let selections = importSelections(body[0])
        if selections.len != 1:
          raise newException(GeneError,
            "single-name import alias requires one source name")
        result.selections = @[
          ImportSelection(name: selections[0].name, local: body[2].symVal)]
    else:
      raise newException(GeneError,
        "import ^from requires a selection, wildcard, or `source : alias`")
    result.sourceLabel = result.modulePath
    if result.wildcardSegments.len > 0:
      result.sourceLabel.add "/" & result.wildcardSegments.join("/")
  else:
    if body.len == 0:
      raise newException(GeneError, "import requires a source")
    result.nsSegments = nsPathSegments(body[0])
    if "*" in result.nsSegments:
      raise newException(GeneError,
        "wildcard imports require `^from \"path\"`; a namespace-path import " &
        "has no `*` form")
    if body.len == 2:
      result.selections = importSelections(body[1])
    elif body.len == 3 and body[1].isSymbol(":") and
        body[2].kind == vkSymbol:
      result.alias = body[2].symVal
    else:
      raise newException(GeneError,
        "namespace import requires selections or `source : alias`")
    result.sourceLabel = result.nsSegments.join("/")
  if result.pkgName.len > 0 and not result.fromModule:
    # `^pkg` is valid only on the `^from` form. A bare namespace path never
    # selects a package, so package selection is always explicit.
    raise newException(GeneError,
      "import ^pkg requires `^from \"path\"`; a namespace-path import never " &
      "selects a package")
  if result.pkgName.len > 0:
    result.sourceLabel = result.pkgName & "::" & result.sourceLabel
  if result.wildcard and result.alias.len == 0 and result.reexport:
    raise newException(GeneError,
      "bare wildcards do not re-export; use an alias or explicit selections")
  if result.reexport and not result.fromModule:
    raise newException(GeneError,
      "re-export requires a module-path import")

proc nsPathSegments(v: Value): seq[string] =
  if v.kind == vkSymbol:
    result.add v.symVal
  elif v.kind == vkNode and v.head.isSymbol("path"):
    for seg in v.body:
      if seg.kind != vkSymbol:
        raise newException(GeneError, "import namespace path must be symbols")
      result.add seg.symVal
  else:
    raise newException(GeneError, "import source must be a namespace path or `^from \"path\"`")

proc propLiteral(node: Value, key, defaultValue, context: string): string
proc propInt(node: Value, key: string, defaultValue: int,
             context: string, hasValue: var bool): int
proc parseFfiStructFields(fields: Value): seq[FfiStructField]
proc validateFfiLayout(context, layout: string)

proc newCompileNamespaceInterface*(): CompileNamespaceInterface =
  CompileNamespaceInterface(entries: initTable[string, CompileInterfaceEntry]())

proc declarationIsPrivate(node: Value): bool =
  if not node.props.hasKey("private"):
    return false
  let value = node.props["private"]
  if value.kind != vkBool:
    raise newException(GeneError, "^private must be Bool")
  value.boolVal

proc declaredName(form: Value): string =
  if form.body.len == 0:
    return ""
  let value = form.body[0]
  if value.kind == vkSymbol:
    return value.symVal
  if form.head.isSymbol("fn") and value.kind == vkNode and
      value.head.kind == vkSymbol:
    return value.head.symVal

proc protocolInterfaceMessages(form: Value): seq[string] =
  for i in 1 ..< form.body.len:
    let item = form.body[i]
    if item.kind != vkNode or not item.head.isSymbol("message") or
        item.body.len == 0:
      continue
    let name = item.body[0]
    if name.kind == vkSymbol:
      result.add name.symVal
    elif name.kind == vkNode and
        (name.head.isSymbol("path") or name.head.isSymbol("msg")) and
        name.body.len > 0 and name.body[^1].kind == vkSymbol:
      result.add name.body[^1].symVal

proc collectCompileInterfaceForms(forms: openArray[Value], first: int,
                                  target: CompileNamespaceInterface,
                                  sourceName: string,
                                  namespacePath: seq[string])

proc collectCompileInterfaceForm(form: Value,
                                 target: CompileNamespaceInterface,
                                 sourceName: string,
                                 namespacePath: seq[string]) =
  if form.kind != vkNode:
    return
  var head = ""
  if form.head.kind == vkSymbol:
    head = form.head.symVal
  elif form.head.kind == vkNode and form.head.head.isSymbol("path"):
    var segments: seq[string]
    for segment in form.head.body:
      if segment.kind != vkSymbol:
        return
      segments.add segment.symVal
    head = segments.join("/")
  if head.len == 0:
    return
  case head
  of "mod":
    collectCompileInterfaceForms(form.body, 1, target,
                                 sourceName, namespacePath)
  of "do":
    collectCompileInterfaceForms(form.body, 0, target,
                                 sourceName, namespacePath)
  of "ns":
    let name = form.declaredName
    if name.len == 0:
      return
    var child = newCompileNamespaceInterface()
    if target.entries.hasKey(name) and
        target.entries[name].category == cbcNamespace and
        target.entries[name].namespace != nil:
      child = target.entries[name].namespace
    collectCompileInterfaceForms(form.body, 1, child,
                                 sourceName, namespacePath & @[name])
    if not form.declarationIsPrivate:
      target.entries[name] = CompileInterfaceEntry(
        category: cbcNamespace, namespace: child)
  of "macro":
    let name = form.declaredName
    if name.len > 0 and not form.declarationIsPrivate:
      target.entries[name] = CompileInterfaceEntry(category: cbcMacro)
  of "fn":
    let name = form.declaredName
    if name.len > 1 and name.endsWith("!"):
      if not form.declarationIsPrivate:
        target.entries[name] = CompileInterfaceEntry(category: cbcSyntaxFn)
    elif name.len > 0 and not form.declarationIsPrivate:
      target.entries[name] = CompileInterfaceEntry(category: cbcValue)
  of "web_module":
    let name = form.declaredName
    if name.len > 0 and not form.declarationIsPrivate:
      target.entries[name] = CompileInterfaceEntry(category: cbcValue)
  of "var", "let", "const":
    let name = form.declaredName
    if name.len == 0:
      return
    if not form.declarationIsPrivate:
      target.entries[name] = CompileInterfaceEntry(category: cbcValue)
  of "set":
    let name = form.declaredName
    if name.len > 0:
      if target.entries.hasKey(name):
        var entry = target.entries[name]
        if entry.category == cbcSyntaxFn:
          entry.category = cbcValue
          target.entries[name] = entry
  of "ffi/struct":
    let name = form.declaredName
    if name.len > 0 and form.props.hasKey("fields"):
      var hasSize = false
      var hasAlign = false
      let layout = propLiteral(form, "layout", "C", "ffi/struct")
      validateFfiLayout("ffi/struct", layout)
      target.entries[name] = CompileInterfaceEntry(
        category: cbcValue,
        ffiStruct: FfiStructProto(
          name: name,
          identity: (if sourceName.len > 0: sourceName else: "<memory>") &
            "::" & (namespacePath & @[name]).join("/"),
          layout: layout,
          size: propInt(form, "size", -1, "ffi/struct", hasSize),
          hasSize: hasSize,
          align: propInt(form, "align", -1, "ffi/struct", hasAlign),
          hasAlign: hasAlign,
          fields: parseFfiStructFields(form.props["fields"])))
  of "type":
    let name = form.declaredName
    if name.len > 0 and not form.declarationIsPrivate:
      target.entries[name] = CompileInterfaceEntry(
        category: cbcType,
        nativeSpec: form.props.getOrDefault("native", NIL),
        typeForm: form)
  of "enum", "alias":
    let name = form.declaredName
    if name.len > 0 and not form.declarationIsPrivate:
      target.entries[name] = CompileInterfaceEntry(category: cbcType,
        typeForm: (if form.head.isSymbol("alias"): form else: NIL))
  of "protocol":
    let name = form.declaredName
    if name.len > 0 and not form.declarationIsPrivate:
      target.entries[name] = CompileInterfaceEntry(
        category: cbcProtocol,
        protocolMessages: form.protocolInterfaceMessages)
  else:
    discard

proc collectCompileInterfaceForms(forms: openArray[Value], first: int,
                                  target: CompileNamespaceInterface,
                                  sourceName: string,
                                  namespacePath: seq[string]) =
  if first > forms.high:
    return
  for i in first .. forms.high:
    collectCompileInterfaceForm(forms[i], target,
                                sourceName, namespacePath)

proc isCIdentifier(symbol: string): bool =
  if symbol.len == 0:
    return false
  if not (symbol[0].isAlphaAscii or symbol[0] == '_'):
    return false
  for ch in symbol:
    if not (ch.isAlphaAscii or ch.isDigit or ch == '_'):
      return false
  true

proc validateCSymbol(context, key, symbol: string) =
  ## `^symbol`, `^release`, and `^copy` all name foreign C functions that reach
  ## generated C. `^release`/`^copy` are interpolated into declarations
  ## verbatim, so an unchecked value injects arbitrary C into the build — a
  ## concern because these come from library bindings a program imports.
  ## `^symbol` is passed through `cIdent`, which silently rewrites invalid
  ## characters and yields a name that cannot link. Require a real C
  ## identifier so both failure modes become declaration-time diagnostics.
  if not symbol.isCIdentifier:
    raise newException(GeneError,
      context & " ^" & key & " must be a C identifier, got: " & symbol)

proc validateNativeMarkerShape(marker: Value, name: string) =
  ## Shape rules for `^native`, shared by the compiler and the compile-interface
  ## (header) path. ABI *resolution* necessarily differs between the two — the
  ## compiler searches its chunk and imports, a header only its own interface —
  ## but every other rule must be identical, or a header can admit a
  ## declaration the compiler would reject.
  if marker.kind != vkMap:
    raise newException(GeneError,
      "type " & name & " ^native must be a map")
  for key in marker.mapEntries.keys:
    if key notin ["abi", "lifecycle", "mutable", "wrapper", "release", "copy"]:
      raise newException(GeneError,
        "type " & name & " ^native got unexpected field: " & key)
  if not marker.mapEntries.hasKey("abi"):
    raise newException(GeneError,
      "type " & name & " ^native requires ^abi")
  if marker.mapEntries["abi"].kind != vkSymbol:
    raise newException(GeneError,
      "type " & name & " ^native ^abi must name an ffi/struct")

proc nativeTypeProtoFrom(marker, typeForm: Value, name, identity: string,
                         abi: FfiStructProto): NativeTypeProto =
  ## Normative field validation for `^native`, shared by both paths. Previously
  ## the header path re-derived these fields with no validation at all and
  ## silently skipped anything malformed, so an invalid declaration could look
  ## complete to a dependent module.
  var lifecycle = "manual"
  if marker.mapEntries.hasKey("lifecycle"):
    let value = marker.mapEntries["lifecycle"]
    if value.kind != vkSymbol or value.symVal != "manual":
      raise newException(GeneError,
        "type " & name & " ^native ^lifecycle must be manual")
    lifecycle = value.symVal
  var mutable = false
  if marker.mapEntries.hasKey("mutable"):
    let value = marker.mapEntries["mutable"]
    if value.kind != vkBool:
      raise newException(GeneError,
        "type " & name & " ^native ^mutable must be Bool")
    mutable = value.boolVal
  var wrapperField = ""
  var wrapperFieldSchema = ""
  if marker.mapEntries.hasKey("wrapper"):
    let value = marker.mapEntries["wrapper"]
    if value.kind != vkSymbol:
      raise newException(GeneError,
        "type " & name & " ^native ^wrapper must name a field")
    if typeForm.kind != vkNil:
      if not typeForm.props.hasKey("repr") or
          not typeForm.props["repr"].isSymbol("native_wrapper"):
        raise newException(GeneError,
          "type " & name & " ^native ^wrapper requires ^repr native_wrapper")
      if not typeForm.props.hasKey("props") or
          typeForm.props["props"].kind != vkMap or
          not typeForm.props["props"].mapEntries.hasKey(value.symVal):
        raise newException(GeneError,
          "type " & name & " ^native ^wrapper field is not declared: " &
          value.symVal)
      ## Recorded, not merely validated. The declared prop type is what says
      ## whether the handle is owned, and changing `(C/OwnedPtr CPoint)` to
      ## `(C/Ptr CPoint)` changes what a transfer or copy means to already
      ## compiled code — a change no layout hash can see. The canonical label
      ## carries both the flavor and the ABI struct's name, and it is identical
      ## on the header and artifact paths, which the identity alone would not be.
      wrapperFieldSchema =
        ffiTypeLabel(typeForm.props["props"].mapEntries[value.symVal])
    wrapperField = value.symVal
  var releaseSymbol = ""
  if marker.mapEntries.hasKey("release"):
    let value = marker.mapEntries["release"]
    if value.kind != vkString or value.strVal.len == 0:
      raise newException(GeneError,
        "type " & name & " ^native ^release must be a non-empty Str")
    validateCSymbol("type " & name & " ^native", "release", value.strVal)
    releaseSymbol = value.strVal
  var copySymbol = ""
  if marker.mapEntries.hasKey("copy"):
    let value = marker.mapEntries["copy"]
    if value.kind != vkString or value.strVal.len == 0:
      raise newException(GeneError,
        "type " & name & " ^native ^copy must be a non-empty Str")
    validateCSymbol("type " & name & " ^native", "copy", value.strVal)
    copySymbol = value.strVal
  result = NativeTypeProto(
    name: name,
    identity: identity,
    abiIdentity: abi.identity,
    abi: abi,
    lifecycle: lifecycle,
    mutable: mutable,
    wrapperField: wrapperField,
    wrapperFieldSchema: wrapperFieldSchema,
    releaseSymbol: releaseSymbol,
    copySymbol: copySymbol)
  computeContractFingerprint(result)

proc resolveNativeInterfaceTypes(iface: CompileNamespaceInterface,
                                 sourceName: string,
                                 namespacePath: seq[string]) =
  if iface == nil:
    return
  for name, entryValue in iface.entries.mpairs:
    if entryValue.category == cbcNamespace:
      resolveNativeInterfaceTypes(entryValue.namespace, sourceName,
                                  namespacePath & @[name])
      continue
    if entryValue.category != cbcType or entryValue.nativeSpec.kind == vkNil:
      continue
    let spec = entryValue.nativeSpec
    validateNativeMarkerShape(spec, name)
    ## Only ABI lookup stays best-effort here: a header sees just its own
    ## interface, so a `^abi` naming an imported layout legitimately does not
    ## resolve and the type simply carries no native metadata in this view.
    let abiExpr = spec.mapEntries["abi"]
    if not iface.entries.hasKey(abiExpr.symVal):
      continue
    let abi = iface.entries[abiExpr.symVal].ffiStruct
    if abi == nil:
      continue
    entryValue.nativeType = nativeTypeProtoFrom(
      spec, entryValue.typeForm, name,
      (if sourceName.len > 0: sourceName else: "<memory>") &
        "::" & (namespacePath & @[name]).join("/"),
      abi)

proc isFfiPointerType(expr: Value): bool

proc resolveInterfacePointees(iface: CompileNamespaceInterface) =
  ## The header-only counterpart of `resolveFfiPointeeFields`. A consumer that
  ## only ever sees a dependency's interface must still get pointer fields whose
  ## pointees were resolved in the declaring module, or the same look-alike
  ## substitution reappears through that path.
  ##
  ## Runs after `resolveNativeInterfaceTypes` so `^native` types already carry
  ## their identities.
  if iface == nil:
    return
  proc lookup(name: string): tuple[typeIdentity, abiIdentity: string] =
    if not iface.entries.hasKey(name):
      return
    let entry = iface.entries[name]
    if entry.nativeType != nil:
      return (entry.nativeType.identity, entry.nativeType.abiIdentity)
    if entry.ffiStruct != nil:
      return ("", entry.ffiStruct.identity)
  for _, entryValue in iface.entries.mpairs:
    if entryValue.category == cbcNamespace:
      resolveInterfacePointees(entryValue.namespace)
      continue
    if entryValue.ffiStruct == nil:
      continue
    for field in entryValue.ffiStruct.fields.mitems:
      if not field.typeExpr.isFfiPointerType or
          field.typeExpr.body[0].kind != vkSymbol:
        continue
      let name = field.typeExpr.body[0].symVal
      if name.startsWith("C/"):
        continue
      let resolved = lookup(name)
      field.pointeeTypeIdentity = resolved.typeIdentity
      field.pointeeAbiIdentity = resolved.abiIdentity
  ## Fingerprints last: the layout hash reads the pointee identities just
  ## resolved, and the contract hash nests the layout hash.
  for _, entryValue in iface.entries.mpairs:
    if entryValue.ffiStruct != nil:
      computeLayoutFingerprint(entryValue.ffiStruct)
  for _, entryValue in iface.entries.mpairs:
    if entryValue.nativeType != nil:
      computeContractFingerprint(entryValue.nativeType)

proc buildCompileInterface*(forms: openArray[Value],
                            sourceName = "",
                            namespacePath: seq[string] = @[]):
    CompileNamespaceInterface =
  ## `namespacePath` positions the interface: native Type identities are
  ## namespace-qualified, so a sub-namespace interface built at the root path
  ## would mint identities that never match the compiler's.
  result = newCompileNamespaceInterface()
  collectCompileInterfaceForms(forms, 0, result,
                               sourceName, namespacePath)
  resolveNativeInterfaceTypes(result, sourceName, namespacePath)
  resolveInterfacePointees(result)

proc compileInterfaceAt*(root: CompileNamespaceInterface,
                         segments: openArray[string]): CompileNamespaceInterface =
  result = root
  for segment in segments:
    if result == nil or not result.entries.hasKey(segment):
      return nil
    let entry = result.entries[segment]
    if entry.category != cbcNamespace:
      return nil
    result = entry.namespace

proc runtimeExportNames*(iface: CompileNamespaceInterface): seq[string] =
  if iface == nil:
    return
  for name, entry in iface.entries:
    if entry.category != cbcMacro:
      result.add name
  result.sort()

proc compileInterfacePaths*(iface: CompileNamespaceInterface,
                            category: CompileBindingCategory,
                            prefix: seq[string] = @[]): seq[string] =
  if iface == nil:
    return
  for name, entry in iface.entries:
    let path = prefix & @[name]
    if entry.category == category:
      result.add path.join("/")
    if entry.category == cbcNamespace:
      for nested in compileInterfacePaths(entry.namespace, category, path):
        result.add nested
  result.sort()

proc ffiStructsEqual(a, b: FfiStructProto): bool =
  if a == nil or b == nil:
    return a == b
  if a.identity != b.identity or a.layout != b.layout or
      a.fingerprint != b.fingerprint or
      a.hasSize != b.hasSize or a.size != b.size or
      a.hasAlign != b.hasAlign or a.align != b.align or
      a.fields.len != b.fields.len:
    return false
  for i in 0 ..< a.fields.len:
    let left = a.fields[i]
    let right = b.fields[i]
    if left.name != right.name or not equal(left.typeExpr, right.typeExpr) or
        left.pointeeTypeIdentity != right.pointeeTypeIdentity or
        left.pointeeAbiIdentity != right.pointeeAbiIdentity or
        left.hasOffset != right.hasOffset or left.offset != right.offset:
      return false
  true

proc nativeTypesEqual(a, b: NativeTypeProto): bool =
  if a == nil or b == nil:
    return a == b
  a.name == b.name and a.identity == b.identity and
    a.abiIdentity == b.abiIdentity and a.lifecycle == b.lifecycle and
    a.mutable == b.mutable and a.wrapperField == b.wrapperField and
    a.wrapperFieldSchema == b.wrapperFieldSchema and
    a.abiFingerprint == b.abiFingerprint and
    a.contractFingerprint == b.contractFingerprint and
    a.releaseSymbol == b.releaseSymbol and a.copySymbol == b.copySymbol and
    ffiStructsEqual(a.abi, b.abi)

proc compileInterfacesEqual*(a, b: CompileNamespaceInterface): bool =
  if a == nil or b == nil:
    return a == b
  if a.entries.len != b.entries.len:
    return false
  for name, left in a.entries:
    if not b.entries.hasKey(name):
      return false
    let right = b.entries[name]
    if left.category != right.category or
        left.protocolMessages != right.protocolMessages or
        not ffiStructsEqual(left.ffiStruct, right.ffiStruct) or
        not nativeTypesEqual(left.nativeType, right.nativeType):
      return false
    if left.category == cbcNamespace and
        not compileInterfacesEqual(left.namespace, right.namespace):
      return false
  true

proc compileInterfaceNeedsArtifact*(iface: CompileNamespaceInterface): bool =
  ## Header-only interfaces cannot finish a native Type whose ABI layout comes
  ## from an import. Such a module must be compiled once so its resolved Type
  ## metadata can become the interface consumed downstream.
  if iface == nil:
    return false
  for _, entry in iface.entries:
    if entry.category == cbcNamespace:
      if compileInterfaceNeedsArtifact(entry.namespace):
        return true
    elif entry.category == cbcType and entry.nativeSpec.kind != vkNil and
        entry.nativeType == nil:
      return true

proc collectChunkNativeTypes(chunk: Chunk,
                             found: var Table[string, NativeTypeProto]) =
  for typeProto in chunk.typeProtos:
    if typeProto.nativeType != nil:
      found[typeProto.nativeType.identity] = typeProto.nativeType
  for fn in chunk.functions:
    collectChunkNativeTypes(fn.chunk, found)
  for child in chunk.subchunks:
    collectChunkNativeTypes(child, found)

proc attachCompiledNativeMetadata*(iface: CompileNamespaceInterface,
                                   chunk: Chunk, sourceName: string,
                                   namespacePath: seq[string] = @[]) =
  var compiled = initTable[string, NativeTypeProto]()
  collectChunkNativeTypes(chunk, compiled)
  proc attach(current: CompileNamespaceInterface, path: seq[string]) =
    if current == nil:
      return
    for name, entry in current.entries.mpairs:
      if entry.category == cbcNamespace:
        attach(entry.namespace, path & @[name])
      elif entry.category == cbcType and entry.nativeSpec.kind != vkNil:
        let identity = (if sourceName.len > 0: sourceName else: "<memory>") &
          "::" & (path & @[name]).join("/")
        if compiled.hasKey(identity):
          entry.nativeType = compiled[identity]
  attach(iface, namespacePath)

proc cloneCompileInterface*(source: CompileNamespaceInterface):
    CompileNamespaceInterface =
  if source == nil:
    return nil
  result = newCompileNamespaceInterface()
  result.initializationErrorsKnown = source.initializationErrorsKnown
  result.initializationErrors = source.initializationErrors
  result.errorSummaryVersion = source.errorSummaryVersion
  result.exportedImplsKnown = source.exportedImplsKnown
  result.exportedImpls = source.exportedImpls
  for name, entry in source.entries:
    var copied = entry
    if entry.category == cbcNamespace:
      copied.namespace = cloneCompileInterface(entry.namespace)
    result.entries[name] = copied

proc compileInterfaceEntryAt*(root: CompileNamespaceInterface,
                              segments: openArray[string]):
    tuple[found: bool, entry: CompileInterfaceEntry] =
  if segments.len == 0:
    return
  var current = root
  for i, segment in segments:
    if current == nil or not current.entries.hasKey(segment):
      return
    let entry = current.entries[segment]
    if i == segments.high:
      return (true, entry)
    if entry.category != cbcNamespace:
      return
    current = entry.namespace

proc collectDeclaredUnitNames(form: Value, names: var HashSet[string]) =
  if form.kind != vkNode or form.head.kind != vkSymbol:
    return
  case form.head.symVal
  of "var", "let", "const", "fn", "macro", "type", "enum", "protocol",
     "ns", "alias", "web_module":
    let name = form.declaredName
    if name.len > 0:
      names.incl name
    # Callable/type/namespace bodies create their own declaration units.
  of "import":
    let spec = parseImportSpec(form)
    if spec.alias.len > 0:
      names.incl spec.alias
    for selection in spec.selections:
      names.incl selection.local
  of "quote", "quasiquote":
    discard
  else:
    for item in form.body:
      collectDeclaredUnitNames(item, names)

proc collectRuntimeDeclaredUnitNames(c: Compiler, form: Value,
                                     names: var HashSet[string]) =
  if form.kind != vkNode or form.head.kind != vkSymbol:
    return
  case form.head.symVal
  of "var", "let", "const", "fn", "type", "enum", "protocol", "ns",
     "alias", "web_module":
    let name = form.declaredName
    if name.len > 0:
      names.incl name
  of "macro", "quote", "quasiquote":
    discard
  of "import":
    let spec = parseImportSpec(form)
    if spec.alias.len > 0:
      names.incl spec.alias
    let macroLocals = c.importMacroLocals(form)
    for selection in spec.selections:
      if selection.local notin macroLocals:
        names.incl selection.local
  else:
    for item in form.body:
      c.collectRuntimeDeclaredUnitNames(item, names)

proc addAliasedCompileEntries(c: var Compiler, alias: string,
                              iface: CompileNamespaceInterface,
                              prefix: seq[string] = @[]) =
  if iface == nil:
    return
  for name, entry in iface.entries:
    let path = prefix & @[name]
    c.importedCompileEntries[alias & "/" & path.join("/")] = entry
    if entry.category == cbcNamespace:
      c.addAliasedCompileEntries(alias, entry.namespace, path)

proc prepareStaticImportForm(c: var Compiler, form: Value) =
  if form.kind != vkNode or form.head.kind != vkSymbol:
    return
  case form.head.symVal
  of "mod":
    c.prepareStaticImports(form.body, 1)
  of "do":
    c.prepareStaticImports(form.body, 0)
  of "import":
    let spec = parseImportSpec(form)
    if not spec.fromModule or
        not c.importedInterfaces.hasKey(spec.importKey):
      return
    let rootInterface = c.importedInterfaces[spec.importKey]
    for selection in spec.selections:
      let resolved = compileInterfaceEntryAt(
        rootInterface, selection.name.split('/'))
      if resolved.found:
        c.importedCompileEntries[selection.local] = resolved.entry
    if not spec.wildcard:
      return
    let iface = compileInterfaceAt(rootInterface,
                                   spec.wildcardSegments)
    if iface == nil:
      return
    if spec.alias.len > 0:
      c.aliasInterfaces[spec.alias] = StaticAliasInterface(
        importKey: spec.importKey,
        exportPrefix: spec.wildcardSegments,
        namespace: iface)
      c.addAliasedCompileEntries(spec.alias, iface)
    else:
      for name, entry in iface.entries:
        let candidate = StaticWildcardCandidate(
          importKey: spec.importKey,
          exportPath: spec.wildcardSegments & @[name],
          category: entry.category,
          sourceLabel: spec.sourceLabel)
        # Dedup by (modulePath, exportPath) so re-importing the same
        # wildcard (or two overlapping wildcards that reach the same export)
        # collapses to one candidate — otherwise an identical repeat import
        # would spuriously read as ambiguous, while the runtime fallback
        # (addWildcardFallback) already dedups by source. Same-module
        # different-subtree collisions keep distinct exportPaths and stay
        # ambiguous, which is correct.
        let bucket = c.wildcardCandidates.mgetOrPut(name, @[])
        var duplicate = false
        for existing in bucket:
          if existing.importKey == candidate.importKey and
              existing.exportPath == candidate.exportPath:
            duplicate = true
            break
        if not duplicate:
          c.wildcardCandidates[name].add candidate
  else:
    discard

proc prepareStaticImports(c: var Compiler, forms: openArray[Value], first: int) =
  if first > forms.high:
    return
  var runtimeNames = initHashSet[string]()
  for i in first .. forms.high:
    collectDeclaredUnitNames(forms[i], c.declaredUnitNames)
    c.collectRuntimeDeclaredUnitNames(forms[i], runtimeNames)
  for i in first .. forms.high:
    c.prepareStaticImportForm(forms[i])
  for name, candidates in c.wildcardCandidates:
    if candidates.len != 1 or c.unitDeclares(name):
      continue
    let candidate = candidates[0]
    if not c.importedInterfaces.hasKey(candidate.importKey):
      continue
    let resolved = compileInterfaceEntryAt(
      c.importedInterfaces[candidate.importKey], candidate.exportPath)
    if resolved.found:
      c.importedCompileEntries[name] = resolved.entry
  if c.useLocalSlots:
    for name in runtimeNames:
      if c.wildcardCandidates.hasKey(name):
        let candidates = c.wildcardCandidates[name]
        let importsFexpr = candidates.len == 1 and
          candidates[0].category == cbcSyntaxFn
        discard c.reserveLocal(name, allowFexprName = importsFexpr,
                               importing = c.aliasInterfaces.hasKey(name))

proc importedCandidates(c: Compiler,
                        name: string): seq[StaticWildcardCandidate] =
  if c.unitDeclares(name) or c.hasLexicalBinding(name):
    return
  result = c.wildcardCandidates.getOrDefault(name)

proc importedNameError(name: string,
                       candidates: openArray[StaticWildcardCandidate]): ref GeneError =
  var sources: seq[string]
  for candidate in candidates:
    if candidate.sourceLabel notin sources:
      sources.add candidate.sourceLabel
  newException(GeneError,
    "ambiguous imported name '" & name & "' from " & sources.join(", "))

proc pathSymbolSegments(value: Value): seq[string] =
  if value.kind == vkSymbol:
    if '/' in value.symVal:
      return value.symVal.split('/')
    return
  if value.kind != vkNode or not value.head.isSymbol("path"):
    return
  # Validate before allocating the spelling list. Nim 2.2.4 lowers `return @[]`
  # after appending to `result` as a bare overwrite, leaking that partial seq
  # and its strings on numeric/dynamic Paths.
  for segment in value.body:
    if segment.kind != vkSymbol:
      return
  for segment in value.body:
    result.add segment.symVal

proc importedPathEntry(c: Compiler, value: Value):
    tuple[found: bool, candidate: StaticWildcardCandidate] =
  let segments = pathSymbolSegments(value)
  if segments.len < 2 or not c.aliasInterfaces.hasKey(segments[0]):
    return
  let alias = c.aliasInterfaces[segments[0]]
  let relative = segments[1 .. ^1]
  let resolved = compileInterfaceEntryAt(alias.namespace, relative)
  if not resolved.found:
    return
  (true, StaticWildcardCandidate(
    importKey: alias.importKey,
    exportPath: alias.exportPrefix & relative,
    category: resolved.entry.category,
    sourceLabel: segments[0]))

proc importedHeadCandidates(c: Compiler,
                            value: Value): seq[StaticWildcardCandidate] =
  if value.kind == vkSymbol:
    return c.importedCandidates(value.symVal)
  let path = c.importedPathEntry(value)
  if path.found:
    result.add path.candidate

proc importedMacroForHead(c: Compiler, value: Value):
    tuple[found: bool, def: MacroDef] =
  let localPath = value.pathSymbolSegments.join("/")
  if localPath.len > 0 and c.macros.hasKey(localPath):
    return (true, c.macros[localPath])
  if value.kind == vkSymbol and
      (c.localSlot(value.symVal) >= 0 or c.parentSlot(value.symVal).slot >= 0):
    return
  let candidates = c.importedHeadCandidates(value)
  if candidates.len > 1:
    let name =
      if value.kind == vkSymbol: value.symVal
      else: pathSymbolSegments(value).join("/")
    raise importedNameError(name, candidates)
  if candidates.len != 1 or candidates[0].category != cbcMacro:
    return
  let candidate = candidates[0]
  if not c.importedMacroSets.hasKey(candidate.importKey):
    raise newException(GeneError,
      "missing compile-time macro artifact for " & candidate.sourceLabel)
  let path = candidate.exportPath.join("/")
  let definitions = c.importedMacroSets[candidate.importKey]
  if not definitions.hasKey(path):
    raise newException(GeneError,
      "module compile interface marked a missing macro: " & path)
  (true, definitions[path])

proc visibleMacroBindings(c: Compiler): MacroBindings =
  result = MacroBindings(definitions: c.macros)
  for name in c.wildcardCandidates.keys:
    if c.localSlot(name) >= 0 or c.parentSlot(name).slot >= 0: continue
    let candidates = c.importedCandidates(name)
    if candidates.len != 1 or candidates[0].category != cbcMacro: continue
    let found = c.importedMacroForHead(newSym(name))
    if found.found: result.definitions[name] = found.def
  for name, alias in c.aliasInterfaces:
    if not c.importedMacroSets.hasKey(alias.importKey): continue
    let prefix = if alias.exportPrefix.len > 0: alias.exportPrefix.join("/") & "/" else: ""
    for path, definition in c.importedMacroSets[alias.importKey]:
      if path.startsWith(prefix):
        result.definitions[name & "/" & path[prefix.len .. ^1]] = definition
  for name in c.localSlots.keys:
    result.hiddenNames.add name
  for frame in c.parentSlots:
    for name in frame.keys:
      if name notin result.hiddenNames: result.hiddenNames.add name
  for name in c.publicMacroNames:
    if result.definitions.hasKey(name): result.exportedNames.add name
  for name in c.ownMacroNames:
    if result.definitions.hasKey(name): result.ownedNames.add name
  result.hiddenNames.sort()
  result.exportedNames.sort()
  result.ownedNames.sort()

proc addMacroContext(c: var Compiler): int =
  result = c.chunk.macroContexts.len
  c.chunk.macroContexts.add c.visibleMacroBindings()

proc reserveProtocolBindings(c: var Compiler, forms: openArray[Value])

proc importMacroLocals(c: Compiler, node: Value): HashSet[string] =
  ## Local names an import binds as compile-time macros rather than runtime
  ## slots. The forward-reference prepass must not reserve a slot for these:
  ## compileImport strips macro selections from the runtime spec and hands
  ## them to importMacro, which rejects a name that already owns a slot.
  ## Mirrors compileImport's macro detection.
  let spec = parseImportSpec(node)
  var exported: Table[string, MacroDef]
  if spec.fromModule:
    if c.importedMacroSets.hasKey(spec.importKey):
      exported = c.importedMacroSets[spec.importKey]
  else:
    exported = builtinNamespaceMacros(spec.nsSegments)
  if exported.len == 0:
    return
  for sel in spec.selections:
    if exported.hasKey(sel.name):
      result.incl sel.local

proc reserveProtocolBinding(c: var Compiler, value: Value) =
  if not c.useLocalSlots or value.kind != vkNode or
      value.head.kind != vkSymbol:
    return
  case value.head.symVal
  of "protocol":
    if value.body.len > 0 and value.body[0].kind == vkSymbol:
      discard c.reserveLocal(value.body[0].symVal)
  of "import":
    let macroLocals = c.importMacroLocals(value)
    let spec = parseImportSpec(value)
    for selection in spec.selections:
      if selection.local notin macroLocals:
        let importsFexpr = spec.fromModule and
          c.importedSyntaxFnSets.hasKey(spec.importKey) and
          selection.name in c.importedSyntaxFnSets[spec.importKey]
        discard c.reserveLocal(selection.local,
                               allowFexprName = importsFexpr, importing = true)
  of "do", "if", "if_yes", "if_not", "&&", "||", "??", "while", "loop",
     "repeat":
    c.reserveProtocolBindings(value.body)
  of "try":
    var i = 0
    var attempt: seq[Value]
    while i < value.body.len and not
        (value.body[i].isSymbol("catch") or value.body[i].isSymbol("ensure")):
      attempt.add value.body[i]
      inc i
    c.reserveProtocolBindings(attempt)
    while i < value.body.len and not value.body[i].isSymbol("ensure"):
      inc i
    if i < value.body.len:
      inc i
      var cleanup: seq[Value]
      while i < value.body.len:
        cleanup.add value.body[i]
        inc i
      c.reserveProtocolBindings(cleanup)
  else:
    # Other compound heads (notably `match` arms) are not descended for slot
    # reservation. A protocol declared inside a `match` arm still receives a
    # flow ref but no reserved slot, so its unqualified sends fall to the
    # runtime name path rather than the compiled candidate slot — acceptable
    # because declaring a protocol inside a match arm is degenerate.
    discard

proc reserveProtocolBindings(c: var Compiler, forms: openArray[Value]) =
  for form in forms:
    c.reserveProtocolBinding(form)

proc reserveProtocolBindingsFor(c: var Compiler, forms: openArray[Value]) =
  ## Hoist protocol and import bindings so a forward reference in the same unit
  ## resolves. This is all that survives of the candidate-set pass: unqualified
  ## sends are type-direct only, so no flow analysis is needed (design §3).
  c.reserveProtocolBindings(forms)

proc literalName(v: Value, context: string): string =
  case v.kind
  of vkString:
    v.strVal
  of vkSymbol:
    v.symVal
  of vkNode:
    if v.head.isSymbol("path"):
      var segments: seq[string]
      for segment in v.body:
        if segment.kind != vkSymbol:
          raise newException(GeneError, context & " must be a string, symbol, or symbol path")
        segments.add segment.symVal
      segments.join("/")
    else:
      raise newException(GeneError, context & " must be a string, symbol, or symbol path")
  else:
    raise newException(GeneError, context & " must be a string, symbol, or symbol path")

proc propLiteral(node: Value, key, defaultValue, context: string): string =
  if not node.props.hasKey(key):
    return defaultValue
  literalName(node.props[key], context & " ^" & key)

proc propInt(node: Value, key: string, defaultValue: int,
             context: string, hasValue: var bool): int =
  if not node.props.hasKey(key):
    hasValue = false
    return defaultValue
  let value = node.props[key]
  if value.kind != vkInt:
    raise newException(GeneError, context & " ^" & key & " must be an Int")
  hasValue = true
  int(value.intVal)

proc propBool(node: Value, key: string, defaultValue: bool,
              context: string): bool =
  if not node.props.hasKey(key):
    return defaultValue
  let value = node.props[key]
  if value.kind != vkBool:
    raise newException(GeneError, context & " ^" & key & " must be a Bool")
  value.boolVal

proc parseFfiParams(params: Value, context = "ffi/fn"): seq[FfiParam] =
  if params.kind != vkList:
    raise newException(GeneError, context & " parameters must be a [list]")
  let items = params.listItems
  var i = 0
  while i < items.len:
    if items[i].isSymbol(","):
      inc i
      continue
    if items[i].kind != vkSymbol:
      raise newException(GeneError, context & " parameter must start with a name")
    let name = items[i].symVal
    inc i
    if i >= items.len or not items[i].isSymbol(":"):
      raise newException(GeneError, context & " parameter '" & name & "' requires a type")
    inc i
    if i >= items.len:
      raise newException(GeneError, context & " parameter '" & name & "' is missing a type")
    result.add FfiParam(name: name, typeExpr: items[i])
    inc i

proc parseFfiReturn(body: seq[Value], idx: var int, context: string): Value =
  result = newSym("C/Void")
  if idx < body.len:
    if not body[idx].isSymbol(":"):
      raise newException(GeneError, context & " return type must follow `:`")
    inc idx
    if idx >= body.len:
      raise newException(GeneError, context & " return type is missing")
    result = body[idx]
    inc idx

proc ffiTypeLabel(expr: Value): string =
  case expr.kind
  of vkSymbol:
    expr.symVal
  of vkNode:
    if expr.head.kind == vkSymbol and expr.head.symVal == "path":
      var segments: seq[string]
      for item in expr.body:
        if item.kind == vkSymbol:
          segments.add item.symVal
        else:
          segments.add ffiTypeLabel(item)
      segments.join("/")
    else:
      var parts = @[ffiTypeLabel(expr.head)]
      for item in expr.body:
        parts.add ffiTypeLabel(item)
      "(" & parts.join(" ") & ")"
  else:
    $expr.kind

proc ffiAggregateTypeHead(expr: Value): string =
  case expr.kind
  of vkSymbol:
    expr.symVal
  of vkNode:
    if expr.head.kind == vkSymbol:
      expr.head.symVal
    elif expr.head.kind == vkNode and expr.head.head.isSymbol("path"):
      literalName(expr.head, "FFI aggregate field type")
    else:
      ""
  else:
    ""

proc ffiAggregateTypeDescription(expr: Value): string =
  ffiTypeLabel(expr)

proc validateFfiAggregateFieldType(context, fieldName: string, expr: Value) =
  const scalarFields = [
    "C/Int8", "C/UInt8", "C/Int16", "C/UInt16", "C/Int32", "C/UInt32",
    "C/Int64", "C/UInt64", "C/Char", "C/UChar", "C/Short", "C/UShort",
    "C/Int", "C/UInt", "C/Long", "C/ULong", "C/Size", "C/PtrDiff",
    "C/Float", "C/Double", "C/Bool", "C/CStr"
  ]
  const pointerFields = [
    "C/Ptr", "C/NullablePtr", "C/ConstPtr", "C/NullableConstPtr", "C/OwnedPtr"
  ]
  let head = ffiAggregateTypeHead(expr)
  if expr.kind == vkSymbol and head in scalarFields:
    return
  if expr.kind == vkNode and head in pointerFields and expr.body.len == 1:
    return
  raise newException(GeneError,
    context & " field '" & fieldName & "' type must be a scalar, C/CStr, " &
    "or pointer-like ABI type, got " & ffiAggregateTypeDescription(expr))

proc isFfiScalarOrCStrLabel(label: string): bool =
  label in [
    "C/Int8", "C/UInt8", "C/Int16", "C/UInt16", "C/Int32", "C/UInt32",
    "C/Int64", "C/UInt64", "C/Char", "C/UChar", "C/Short", "C/UShort",
    "C/Int", "C/UInt", "C/Long", "C/ULong", "C/Size", "C/PtrDiff",
    "C/Float", "C/Double", "C/Bool", "C/CStr"
  ]

proc ffiCompositeHead(expr: Value): string =
  if expr.kind == vkNode:
    ffiTypeLabel(expr.head)
  else:
    ""

proc isFfiPointerType(expr: Value): bool =
  expr.kind == vkNode and expr.body.len == 1 and
    ffiCompositeHead(expr) in [
      "C/Ptr", "C/NullablePtr", "C/ConstPtr", "C/NullableConstPtr",
      "C/OwnedPtr"
    ]

proc isFfiBufferArgType(expr: Value): bool =
  expr.kind == vkNode and expr.body.len == 1 and
    ffiCompositeHead(expr) in ["C/Slice", "Buffer"]

proc validateFfiFnParamType(context, paramName: string, expr: Value) =
  let label = ffiTypeLabel(expr)
  if isFfiScalarOrCStrLabel(label) or isFfiPointerType(expr) or
      isFfiBufferArgType(expr):
    return
  raise newException(GeneError,
    context & " parameter '" & paramName & "' has unsupported C wrapper type " &
    label)

proc validateFfiFnReturnType(context: string, expr: Value, release: string) =
  let label = ffiTypeLabel(expr)
  if label == "C/Void" or isFfiScalarOrCStrLabel(label) or
      isFfiPointerType(expr):
    if label.startsWith("(C/OwnedPtr ") and release.len == 0:
      raise newException(GeneError,
        context & " return type " & label & " requires ^release")
    if release.len > 0 and not label.startsWith("(C/OwnedPtr "):
      raise newException(GeneError,
        context & " ^release is only valid for C/OwnedPtr results")
    return
  raise newException(GeneError,
    context & " return type has unsupported C wrapper type " & label)

proc validateFfiCallingConvention(context, calling: string) =
  case calling.toLowerAscii
  of "c", "cdecl", "stdcall":
    discard
  else:
    raise newException(GeneError,
      context & " ^calling must be C, cdecl, or stdcall")

proc validateFfiAbi(context, abi: string) =
  if abi.toLowerAscii != "c":
    raise newException(GeneError, context & " ^abi must be C")

proc validateFfiLayout(context, layout: string) =
  if layout.toLowerAscii != "c":
    raise newException(GeneError, context & " ^layout must be C")

proc parseFfiAggregateFields(context: string, fields: Value,
                             allowOffsets: bool): seq[FfiStructField] =
  if fields.kind != vkList:
    raise newException(GeneError, context & " ^fields must be a [list]")
  for field in fields.listItems:
    if field.kind != vkList:
      raise newException(GeneError, context & " field must be a [field Type] list")
    let items = field.listItems
    if items.len < 2 or items[0].kind != vkSymbol:
      raise newException(GeneError, context & " field must be [name Type]")
    let validLen =
      if allowOffsets: items.len in [2, 5]
      else: items.len == 2
    if not validLen:
      raise newException(GeneError,
        if allowOffsets:
          context & " field must be [name Type] or [name Type ^offset Int]"
        else:
          context & " field must be [name Type]")
    var hasOffset = false
    var offset = -1
    if items.len == 5:
      if items[2].symbolText notin ["^", "^^"] or
          items[3].symbolText != "offset" or items[4].kind != vkInt:
        raise newException(GeneError,
          context & " field offset must be written as ^offset Int")
      hasOffset = true
      offset = int(items[4].intVal)
    validateFfiAggregateFieldType(context, items[0].symVal, items[1])
    result.add FfiStructField(name: items[0].symVal, typeExpr: items[1],
                              offset: offset, hasOffset: hasOffset)

proc parseFfiStructFields(fields: Value): seq[FfiStructField] =
  parseFfiAggregateFields("ffi/struct", fields, allowOffsets = true)

proc parseFfiUnionFields(fields: Value): seq[FfiStructField] =
  parseFfiAggregateFields("ffi/union", fields, allowOffsets = false)

proc compileFfiLibrary(c: var Compiler, node: Value) =
  let body = node.body
  if body.len != 1 or body[0].kind != vkSymbol:
    raise newException(GeneError, "ffi/library requires a name")
  let name = body[0].symVal
  if c.ffiLibraryNames.hasKey(name):
    raise newException(GeneError, "duplicate ffi/library: " & name)
  for key, _ in node.props:
    if key notin ["linux", "macos", "windows"]:
      raise newException(GeneError,
        "ffi/library has unsupported property ^" & key)
  let proto = FfiLibraryProto(
    name: name,
    linux: propLiteral(node, "linux", "", "ffi/library"),
    macos: propLiteral(node, "macos", "", "ffi/library"),
    windows: propLiteral(node, "windows", "", "ffi/library"))
  if proto.linux.len == 0 and proto.macos.len == 0 and proto.windows.len == 0:
    raise newException(GeneError,
      "ffi/library requires at least one target library name")
  c.ffiLibraryNames[name] = true
  discard c.chunk.addFfiLibrary(proto)
  c.emitConst(newSym(proto.name))
  c.emitDefineBinding(proto.name)

proc compileFfiFn(c: var Compiler, node: Value) =
  let body = node.body
  if body.len < 2 or body[0].kind != vkSymbol:
    raise newException(GeneError, "ffi/fn requires a name and parameter list")
  let name = body[0].symVal
  if body[1].kind != vkList:
    raise newException(GeneError, "ffi/fn requires a parameter list")
  var ret = newSym("C/Void")
  var idx = 2
  if idx < body.len:
    if not body[idx].isSymbol(":"):
      raise newException(GeneError, "ffi/fn return type must follow `:`")
    inc idx
    if idx >= body.len:
      raise newException(GeneError, "ffi/fn return type is missing")
    ret = body[idx]
    inc idx
  if idx < body.len:
    raise newException(GeneError, "ffi/fn has unexpected body forms")
  let symbol = propLiteral(node, "symbol", name, "ffi/fn")
  validateCSymbol("ffi/fn", "symbol", symbol)
  let library = propLiteral(node, "library", "", "ffi/fn")
  if node.props.hasKey("library") and library.len == 0:
    raise newException(GeneError, "ffi/fn ^library must not be empty")
  let release = propLiteral(node, "release", "", "ffi/fn")
  if node.props.hasKey("release") and release.len == 0:
    raise newException(GeneError, "ffi/fn ^release must not be empty")
  if release.len > 0:
    validateCSymbol("ffi/fn", "release", release)
  let proto = FfiFnProto(name: name,
                         library: library,
                         libraryDeclared: library.len > 0 and
                           c.ffiLibraryNames.hasKey(library),
                         symbol: symbol,
                         abi: propLiteral(node, "abi", "C", "ffi/fn"),
                         calling: propLiteral(node, "calling", "C", "ffi/fn"),
                         params: parseFfiParams(body[1]),
                         returnType: ret,
                         release: release)
  ## `^out name` or `^out [a b]` marks out-parameters (proposal §6.3.1). It is
  ## metadata: the parameter keeps its value type, and the marker is what adds
  ## an indirection to the declaration and passes an address at the call.
  if node.props.hasKey("out"):
    var outNames: seq[string]
    let value = node.props["out"]
    case value.kind
    of vkSymbol:
      outNames.add value.symVal
    of vkList:
      for item in value.listItems:
        if item.kind != vkSymbol:
          raise newException(GeneError,
            "ffi/fn ^out entries must be parameter names")
        outNames.add item.symVal
    else:
      raise newException(GeneError,
        "ffi/fn ^out must be a parameter name or a [list] of them")
    for outName in outNames:
      var found = false
      for i, param in proto.params:
        if param.name == outName:
          if proto.params[i].isOut:
            raise newException(GeneError,
              "ffi/fn ^out repeats parameter: " & outName)
          proto.params[i].isOut = true
          found = true
          break
      if not found:
        raise newException(GeneError,
          "ffi/fn ^out names a parameter that does not exist: " & outName)
  for param in proto.params:
    let repr = c.resolvedAotRepr(param.typeExpr)
    proto.paramReprs.add repr
    if repr.kind != arkNativePtr:
      validateFfiFnParamType("ffi/fn", param.name, param.typeExpr)
  proto.returnRepr = c.resolvedAotRepr(proto.returnType)
  if proto.returnRepr.kind != arkNativePtr:
    validateFfiFnReturnType("ffi/fn", proto.returnType, proto.release)
  validateFfiAbi("ffi/fn", proto.abi)
  validateFfiCallingConvention("ffi/fn", proto.calling)
  discard c.chunk.addFfiFn(proto)
  c.emitConst(newNativeFn(name, nil))
  c.emitDefineBinding(name, immutable = true)

proc ffiPointeeIdentities(c: Compiler, typeExpr: Value):
    tuple[typeIdentity, abiIdentity: string] =
  ## Resolve a pointer field's pointee *in the module that declares the layout*.
  ##
  ## This is the whole fix for imported pointer fields: the resolution used to
  ## happen wherever the field was later read, so an imported `Node? next` bound
  ## to whatever `Node` the consuming module declared — silently producing a
  ## pointer to a different layout.
  ##
  ## Three outcomes, and only the first two resolve. A pointee naming an
  ## ordinary C type or an undeclared opaque foreign tag is legitimate and
  ## carries no identity; requiring one would reject `(C/Ptr C/Void)` and every
  ## opaque handle.
  if not typeExpr.isFfiPointerType or typeExpr.body[0].kind != vkSymbol:
    return
  let name = typeExpr.body[0].symVal
  if name.startsWith("C/"):
    return
  let own = c.ownInterfaceEntry(name)
  if own.found:
    if own.entry.nativeType != nil:
      return (own.entry.nativeType.identity, own.entry.nativeType.abiIdentity)
    if own.entry.ffiStruct != nil:
      return ("", own.entry.ffiStruct.identity)
  if c.importedCompileEntries.hasKey(name):
    let entry = c.importedCompileEntries[name]
    if entry.nativeType != nil:
      return (entry.nativeType.identity, entry.nativeType.abiIdentity)
    if entry.ffiStruct != nil:
      return ("", entry.ffiStruct.identity)
  for layout in c.chunk.ffiStructs:
    if layout.name == name:
      return ("", layout.identity)

proc resolveFfiPointeeFields(c: Compiler, fields: var seq[FfiStructField]) =
  for field in fields.mitems:
    let resolved = c.ffiPointeeIdentities(field.typeExpr)
    field.pointeeTypeIdentity = resolved.typeIdentity
    field.pointeeAbiIdentity = resolved.abiIdentity

proc compileFfiStruct(c: var Compiler, node: Value) =
  let body = node.body
  if body.len != 1 or body[0].kind != vkSymbol:
    raise newException(GeneError, "ffi/struct requires a name")
  if not node.props.hasKey("fields"):
    raise newException(GeneError, "ffi/struct requires ^fields")
  var hasSize = false
  var hasAlign = false
  let layout = propLiteral(node, "layout", "C", "ffi/struct")
  validateFfiLayout("ffi/struct", layout)
  let proto = FfiStructProto(
    name: body[0].symVal,
    identity: (if c.sourceName.len > 0: c.sourceName else: "<memory>") &
      "::" & (c.namespacePath & @[body[0].symVal]).join("/"),
    layout: layout,
    size: propInt(node, "size", -1, "ffi/struct", hasSize),
    hasSize: hasSize,
    align: propInt(node, "align", -1, "ffi/struct", hasAlign),
    hasAlign: hasAlign,
    fields: parseFfiStructFields(node.props["fields"]))
  ## After pointee resolution, never before: the layout hash includes each
  ## pointer field's pointee ABI identity.
  c.resolveFfiPointeeFields(proto.fields)
  computeLayoutFingerprint(proto)
  var present = false
  for existing in c.chunk.ffiStructs:
    if existing.identity == proto.identity:
      present = true
      break
  if not present:
    discard c.chunk.addFfiStruct(proto)
  c.emitConst(newSym(proto.name))
  c.emitDefineBinding(proto.name)

proc compileFfiUnion(c: var Compiler, node: Value) =
  let body = node.body
  if body.len != 1 or body[0].kind != vkSymbol:
    raise newException(GeneError, "ffi/union requires a name")
  if not node.props.hasKey("fields"):
    raise newException(GeneError, "ffi/union requires ^fields")
  var hasSize = false
  var hasAlign = false
  let layout = propLiteral(node, "layout", "C", "ffi/union")
  validateFfiLayout("ffi/union", layout)
  let proto = FfiUnionProto(
    name: body[0].symVal,
    layout: layout,
    size: propInt(node, "size", -1, "ffi/union", hasSize),
    hasSize: hasSize,
    align: propInt(node, "align", -1, "ffi/union", hasAlign),
    hasAlign: hasAlign,
    fields: parseFfiUnionFields(node.props["fields"]))
  discard c.chunk.addFfiUnion(proto)
  c.emitConst(newSym(proto.name))
  c.emitDefineBinding(proto.name)

proc compileFfiSignature(c: var Compiler, node: Value,
                         kind: FfiSignatureKind) =
  let context =
    if kind == fskCallback: "ffi/callback"
    else: "ffi/signature"
  let body = node.body
  if body.len < 2 or body[0].kind != vkSymbol:
    raise newException(GeneError, context & " requires a name and parameter list")
  if body[1].kind != vkList:
    raise newException(GeneError, context & " requires a parameter list")
  var idx = 2
  let ret = parseFfiReturn(body, idx, context)
  if idx < body.len:
    raise newException(GeneError, context & " has unexpected body forms")
  let proto = FfiSignatureProto(
    name: body[0].symVal,
    kind: kind,
    abi: propLiteral(node, "abi", "C", context),
    params: parseFfiParams(body[1], context),
    returnType: ret,
    escaping: propBool(node, "escaping", false, context),
    runtimeConstructible: kind == fskDynamic)
  validateFfiAbi(context, proto.abi)
  if kind == fskCallback:
    if proto.escaping:
      raise newException(GeneError,
        "ffi/callback ^^escaping is not supported yet")
    for param in proto.params:
      validateFfiFnParamType(context, param.name, param.typeExpr)
    validateFfiFnReturnType(context, proto.returnType, "")
  discard c.chunk.addFfiSignature(proto)
  c.emitConst(newSym(proto.name))
  c.emitDefineBinding(proto.name)

proc builtinLogMacro(level: string): MacroDef =
  ## Built-in namespace macros use the same template representation as
  ## file-module macros; only their delivery is compiler-known.
  MacroDef(
    params: @[
      MacroParam(pattern: newSym("logger")),
      MacroParam(pattern: newSym("message"))
    ],
    named: @[
      MacroNamedParam(arg: "payload", pattern: newSym("payload"),
        defaultValue: MacroDefault(optional: true, hasExpr: true,
                                   defaultExpr: newMap()))
    ],
    body: @[read("`(scope (do " &
      "(var generated_logger %logger) " &
      "(if (generated_logger .enabled? gene/log/LogLevel/" & level & ") " &
      "  (generated_logger .emit gene/log/LogLevel/" & level &
      "    %message ^payload %payload) " &
      "  nil)))")]
  )

proc builtinCssDeclMacro(): MacroDef =
  ## Keep the declaration name as syntax so `(decl border_radius value)` can
  ## distinguish symbol sugar from `(decl "--raw-name" value)`. The runtime
  ## constructor receives the quoted Symbol/Str and stores it as ordered data.
  MacroDef(
    params: @[
      MacroParam(pattern: newSym("name")),
      MacroParam(pattern: newSym("value"))
    ],
    body: @[read(
      "`(gene/css/decl_value (quote %name) %value)")]
  )

proc builtinTestMacro(name: string): MacroDef =
  new(result)
  ## Testing declarations are ordinary template macros. The runtime receives
  ## closures, never borrowed caller syntax/environments.
  result.rest = "body"
  if name in ["describe", "context"]:
    result.params = @[MacroParam(pattern: newSym("description"))]
    result.body = @[read(
      "`(gene/test/register_group %description (fn [] %body...))")]
  else:
    if name == "it":
      result.params.add MacroParam(pattern: newSym("description"))
      result.named = @[MacroNamedParam(arg: "skip", pattern: newSym("skip"),
        defaultValue: MacroDefault(optional: true, hasExpr: true,
                                   defaultExpr: VOID))]
    result.params.add MacroParam(pattern: newSym("params"))
    let templateSource =
      if name == "it":
        "`(gene/test/register_example %description (quote %params) " &
          "(fn %params %body...) (quote %skip))"
      else:
        "`(gene/test/register_hook \"" & name & "\" (quote %params) " &
          "(fn %params %body...))"
    result.body = @[read(templateSource)]

proc builtinNamespaceMacros(segments: openArray[string]):
    Table[string, MacroDef] =
  result = initTable[string, MacroDef]()
  if (segments.len == 1 and segments[0] == "log") or
      (segments.len == 2 and segments[0] == "gene" and
       segments[1] == "log"):
    for level in ["error", "warn", "info", "debug", "trace"]:
      result["log_" & level] = builtinLogMacro(level)
  elif (segments.len == 1 and segments[0] == "css") or
      (segments.len == 2 and segments[0] == "gene" and
       segments[1] == "css"):
    result["decl"] = builtinCssDeclMacro()
  elif (segments.len == 1 and segments[0] == "test") or
      (segments.len == 2 and segments[0] == "gene" and
       segments[1] == "test"):
    for name in ["describe", "context", "it", "before_each", "after_each"]:
      result[name] = builtinTestMacro(name)

proc importMacro(c: var Compiler, local: string, def: MacroDef) =
  validateBindingName(local)
  if local in c.ownMacroNames:
    raise newException(GeneError, "duplicate macro: " & local)
  if local in c.ownValueNames or c.localSlot(local) >= 0:
    raise newException(GeneError,
      "macro '" & local & "' conflicts with a binding of the same name")
  if not c.hasMacros:
    c.macros = initTable[string, MacroDef]()
    c.hasMacros = true
  c.macros[local] = def
  c.ownMacroNames.incl local
  c.importedMacroNames.incl local

proc compileImport(c: var Compiler, node: Value) =
  if not c.allowAmbientImports:
    raise newException(GeneError, "eval cannot use import; add imports to Env")
  var spec = parseImportSpec(node)
  if spec.alias.len > 0:
    validateBindingName(spec.alias)
  for selection in spec.selections:
    let importsFexpr = spec.fromModule and
      c.importedSyntaxFnSets.hasKey(spec.importKey) and
      selection.name in c.importedSyntaxFnSets[spec.importKey]
    validateBindingName(selection.local,
                        allowFexprName = importsFexpr)
  if (spec.wildcard or spec.alias.len > 0 or spec.reexport) and
      node.bits notin c.staticTopLevelImpls:
    raise newException(GeneError,
      "wildcard, alias, and re-export imports must be unconditional " &
      "top-level forms")
  if spec.fromModule and (spec.wildcard or spec.alias.len > 0):
    if not c.importedInterfaces.hasKey(spec.importKey):
      if spec.alias.len == 0:
        raise newException(GeneError,
          "bare wildcard import requires module-loader compilation: " &
          spec.sourceLabel)
    else:
      let iface = compileInterfaceAt(c.importedInterfaces[spec.importKey],
                                     spec.wildcardSegments)
      if iface == nil:
        raise newException(GeneError,
          "module compile interface has no namespace: " & spec.sourceLabel)
      if spec.wildcard:
        spec.wildcardNames = runtimeExportNames(iface)
  # Cross-module macros: selections that name a macro exported by the target
  # module become compile-time definitions here and are stripped from the
  # runtime spec (macros are not runtime namespace bindings). The opImport
  # still runs so the module executes and its impls become visible.
  if spec.fromModule and c.importedMacroSets.hasKey(spec.importKey):
    let exported = c.importedMacroSets[spec.importKey]
    var runtimeSelections: seq[ImportSelection]
    for sel in spec.selections:
      if exported.hasKey(sel.name):
        c.importMacro(sel.local, exported[sel.name])
        if spec.reexport: c.publicMacroNames.incl sel.local
      else:
        runtimeSelections.add sel
    spec.selections = runtimeSelections
  elif not spec.fromModule:
    let exported = builtinNamespaceMacros(spec.nsSegments)
    if exported.len > 0:
      var runtimeSelections: seq[ImportSelection]
      for sel in spec.selections:
        if exported.hasKey(sel.name):
          c.importMacro(sel.local, exported[sel.name])
          if spec.reexport: c.publicMacroNames.incl sel.local
        else:
          runtimeSelections.add sel
      spec.selections = runtimeSelections
  # Macro path selections were stripped above; a value selection that still
  # names a nested path (`[ops/add]`) has no leaf local name and opImport would
  # look up the literal "ops/add" key and fail with a confusing runtime error.
  # Reject it at compile time — nested exports are reached with `n/*` or
  # qualified access, not selection lists.
  for sel in spec.selections:
    if '/' in sel.name:
      raise newException(GeneError,
        "import selection '" & sel.name & "' names a nested path; import the " &
        "namespace with `n/*` (optionally `: alias`) and use qualified access")
  if c.useLocalSlots:
    if spec.alias.len > 0:
      discard c.reserveLocal(spec.alias, importing = true)
    for sel in spec.selections:
      let importsFexpr = spec.fromModule and
        c.importedSyntaxFnSets.hasKey(spec.importKey) and
        sel.name in c.importedSyntaxFnSets[spec.importKey]
      discard c.reserveLocal(sel.local, allowFexprName = importsFexpr, importing = true)
  if spec.reexport and spec.fromModule and
      c.importedMacroSets.hasKey(spec.importKey) and (spec.wildcard or spec.alias.len > 0):
    let prefix = if spec.wildcardSegments.len > 0:
                   spec.wildcardSegments.join("/") & "/" else: ""
    for path in c.importedMacroSets[spec.importKey].keys:
      if path.startsWith(prefix):
        let relative = path[prefix.len .. ^1]
        c.publicMacroNames.incl(if spec.alias.len > 0: spec.alias & "/" & relative else: relative)
  if not spec.reexport:
    if spec.alias.len > 0:
      c.chunk.exportExcludedNames.add spec.alias
    for sel in spec.selections:
      c.chunk.exportExcludedNames.add sel.local
  discard c.emit(opImport, c.chunk.addImport(spec))

proc compileImportImpl(c: var Compiler, node: Value) =
  if not c.allowAmbientImports:
    raise newException(GeneError,
      "eval cannot use import_impl; add policy impls to the surrounding scope")
  for key in node.props.keys:
    if key != "from":
      raise newException(GeneError,
        "import_impl got unexpected option: ^" & key)
  if node.body.len >= 2 and node.body[^2].isSymbol("from") and
      node.body[^1].kind == vkString:
    raise newException(GeneError,
      "import_impl: `from` was removed; use `^from \"path\"`")
  if node.body.len != 3 or not node.body[1].isSymbol("for") or
      not node.props.hasKey("from"):
    raise newException(GeneError,
      "import_impl requires: (import_impl Protocol for Receiver ^from \"path\")")
  if node.props["from"].kind != vkString:
    raise newException(GeneError, "import_impl ^from must be a path string")
  compileExpr(c, node.body[0])
  compileExpr(c, node.body[2])
  discard c.emit(opImportImpl, c.chunk.addImportImpl(
    ImportImplSpec(modulePath: node.props["from"].strVal)))

proc markStaticImplForm(c: var Compiler, form: Value) =
  if form.kind == vkNode:
    c.staticTopLevelImpls.incl form.bits
    # `do` is a transparent grouping form: the compile-interface collectors,
    # static-import prepass, and the "unconditional top-level" checks all
    # recurse into it, so its child declarations are unconditional too. Mark
    # them, or a macro/^private/wildcard inside a top-level `do` would be
    # advertised by the interface yet fail its own static-membership gate.
    if form.head.isSymbol("do"):
      for child in form.body:
        c.markStaticImplForm(child)

proc markStaticImplForms(c: var Compiler, forms: openArray[Value], first: int) =
  if first <= forms.high:
    for i in first .. forms.high:
      c.markStaticImplForm(forms[i])

proc collectOverlayImplMessages(c: var Compiler, form: Value) =
  ## Record every message name declared by an impl that is *not* an
  ## unconditional top-level declaration, anywhere in the unit.
  ##
  ## Such an impl is overlay-only and may win at runtime, so a typed_native
  ## send of that message cannot be lowered to a direct call
  ## (docs/spec/protocols.md). Scanning up front rather than during
  ## compilation is what makes it order-independent: an impl inside a function
  ## body lives in a subchunk, and one written after the send has not been
  ## compiled yet, so neither is visible to a check made at the send.
  ##
  ## Must run after `markStaticImplForms`, which decides what counts as
  ## unconditional.
  if form.kind != vkNode:
    return
  if form.head.isSymbol("impl") and form.bits notin c.staticTopLevelImpls:
    for item in form.body:
      if item.kind == vkNode and item.head.isSymbol("message") and
          item.body.len > 0 and item.body[0].kind == vkSymbol:
        c.overlayImplMessages.incl item.body[0].symVal
  for item in form.body:
    c.collectOverlayImplMessages(item)

proc collectOverlayImplMessages(c: var Compiler, forms: openArray[Value]) =
  for form in forms:
    c.collectOverlayImplMessages(form)

proc compileMod(c: var Compiler, node: Value, allowModDecl: bool) =
  ## A file/source unit already has a loader-created Module; `(mod name @meta
  ## body...)` names that module, stores its metadata, and runs the body in the
  ## current module scope.
  if not allowModDecl:
    raise newException(GeneError, "mod must be a top-level form")
  if c.seenModDecl:
    raise newException(GeneError, "duplicate module declaration")
  if node.body.len == 0 or node.body[0].kind != vkSymbol:
    raise newException(GeneError, "mod requires a name")
  validateBindingName(node.body[0].symVal)
  c.seenModDecl = true
  if node.props.hasKey("errors_mode"):
    let mode = node.props["errors_mode"]
    if mode.kind != vkSymbol or mode.symVal notin ["dynamic", "warn", "strict"]:
      raise newException(GeneError, "^errors_mode must be dynamic, warn, or strict")
    c.chunk.errorsMode = case mode.symVal
      of "warn": ecmWarn
      of "strict": ecmStrict
      else: ecmDynamic
  var meta = initPropTable()
  for key, val in node.meta:
    meta[key] = val
  discard c.emit(opSetModuleName, c.chunk.addConst(newMap(meta)),
                 name = node.body[0].symVal)
  if node.body.len > 1:
    c.markStaticImplForms(node.body, 1)
    discard c.emit(opPop)
    compileBodyFrom(c, node.body, 1)

proc compileNs(c: var Compiler, node: Value) =
  let body = node.body
  if body.len == 0 or body[0].kind != vkSymbol:
    raise newException(GeneError, "ns requires a name")
  let name = body[0].symVal
  validateDeclarationCase("ns", name)
  var nsCompiler = c.childCompiler()
  nsCompiler.enableLocalSlots()
  nsCompiler.parentSlots = c.parentFrames()
  nsCompiler.markStaticImplForms(body, 1)
  var nsForms: seq[Value]
  for i in 1 ..< body.len:
    nsForms.add body[i]
  nsCompiler.namespacePath = c.namespacePath & @[name]
  ## Make this namespace's own declarations visible inside its body, innermost
  ## first. The interface is taken from the parent's rather than rebuilt so
  ## native Type identities keep their namespace-qualified spelling; a private
  ## namespace is absent there, so build one at this path as a fallback.
  var nsInterface = compileInterfaceAt(c.ownCompileInterface, [name])
  if nsInterface == nil:
    nsInterface = buildCompileInterface(nsForms, c.sourceName,
                                        nsCompiler.namespacePath)
  nsCompiler.localCompileInterfaces =
    @[nsInterface] & c.localCompileInterfaces
  nsCompiler.prepareStaticImports(nsForms)
  nsCompiler.reserveProtocolBindingsFor(nsForms)
  compileBodyFrom(nsCompiler, body, 1)
  discard nsCompiler.emit(opReturn)
  nsCompiler.chunk.localNames = nsCompiler.localNames
  nsCompiler.chunk.mirrorSlots = true
  nsCompiler.chunk.finalMacroContext = nsCompiler.visibleMacroBindings()
  discard c.reserveLocal(name)
  for macroName in nsCompiler.ownMacroNames:
    let qualified = name & "/" & macroName
    c.macros[qualified] = nsCompiler.macros[macroName]
    c.hasMacros = true
    c.ownMacroNames.incl qualified
    if macroName in nsCompiler.publicMacroNames and not node.declarationIsPrivate:
      c.publicMacroNames.incl qualified
  # A named declaration is let-class (design §12.1): `(set N ...)` is an error.
  c.letNames.incl name
  let idx = c.chunk.addSubchunk(nsCompiler.chunk)
  discard c.emit(opMakeNamespace, idx, name = name,
                 flag = node.bits in c.staticTopLevelImpls)

proc compileEnv(c: var Compiler, node: Value) =
  if node.body.len != 0:
    raise newException(GeneError, "env does not take positional arguments")
  for key, _ in node.props:
    if key notin ["bindings", "parent", "imports", "module", "policy"]:
      raise newException(GeneError, "env unknown option: ^" & key)
  if node.props.hasKey("bindings"):
    compileExpr(c, node.props["bindings"])
  else:
    c.emitConst newMap()
  if node.props.hasKey("parent"):
    compileExpr(c, node.props["parent"])
  else:
    c.emitConst NIL
  if node.props.hasKey("imports"):
    compileExpr(c, node.props["imports"])
  else:
    c.emitConst newList()
  if node.props.hasKey("module"):
    compileExpr(c, node.props["module"])
  else:
    c.emitConst NIL
  if node.props.hasKey("policy"):
    compileExpr(c, node.props["policy"])
  else:
    c.emitConst NIL
  discard c.emit(opMakeEnv, c.addMacroContext())

proc compileEval(c: var Compiler, node: Value) =
  if node.body.len != 1:
    raise newException(GeneError, "eval expects one node")
  if not node.props.hasKey("in"):
    raise newException(GeneError, "eval requires ^in Env")
  for key, _ in node.props:
    if key != "in":
      raise newException(GeneError, "eval unknown option: ^" & key)
  compileExpr(c, node.body[0])
  compileExpr(c, node.props["in"])
  discard c.emit(opEval)

proc compileQuasiTemplate(c: var Compiler, value: Value, depth: int)

proc quasiSpliceExpr(value: Value, depth: int): tuple[splice: bool, expr: Value] =
  if depth != 1 or value.kind != vkNode or not value.head.isSymbol("unquote"):
    return
  if value.body.len != 1:
    raise newException(GeneError, "unquote requires one expression")
  let inner = value.body[0]
  if inner.kind == vkNode and inner.head.isSymbol("..."):
    if inner.body.len != 1:
      raise newException(GeneError, "splice requires one expression")
    return (true, inner.body[0])

proc compileQuasiMap(c: var Compiler, value: Value, depth: int) =
  var keys: seq[string]
  for key, item in value.mapEntries:
    keys.add key
    compileQuasiTemplate(c, item, depth)
  discard c.emit(opMakeMap, keys.len, names = keys, flag = value.mapImmutable)

proc compileQuasiList(c: var Compiler, value: Value, depth: int) =
  var splices: seq[bool]
  var hasSplice = false
  for item in value.listItems:
    let splice = item.quasiSpliceExpr(depth)
    if splice.splice:
      compileExpr(c, splice.expr)
      splices.add true
      hasSplice = true
    else:
      compileQuasiTemplate(c, item, depth)
      splices.add false
  if hasSplice:
    let idx = c.chunk.addListBuild(ListBuildProto(splices: splices,
                                                  immutable: value.listImmutable))
    discard c.emit(opMakeListSplice, idx)
  else:
    discard c.emit(opMakeList, value.listItems.len, flag = value.listImmutable)

proc compileQuasiNodeParts(c: var Compiler, node: Value, depth: int) =
  compileQuasiTemplate(c, node.head, depth)
  var metaNames: seq[string]
  for key, item in node.meta:
    metaNames.add key
    compileQuasiTemplate(c, item, depth)
  var propNames: seq[string]
  for key, item in node.props:
    propNames.add key
    compileQuasiTemplate(c, item, depth)
  var bodySplices: seq[bool]
  var hasBodySplice = false
  for item in node.body:
    let splice = item.quasiSpliceExpr(depth)
    if splice.splice:
      compileExpr(c, splice.expr)
      bodySplices.add true
      hasBodySplice = true
    else:
      compileQuasiTemplate(c, item, depth)
      bodySplices.add false
  let idx = c.chunk.addNodeBuild(NodeBuildProto(metaNames: metaNames,
                                                propNames: propNames,
                                                bodyCount: node.body.len,
                                                bodySplices:
                                                  (if hasBodySplice: bodySplices else: @[]),
                                                immutable: node.nodeImmutable))
  discard c.emit(opMakeNode, idx)

proc compileQuasiNode(c: var Compiler, node: Value, depth: int) =
  if node.head.isSymbol("unquote"):
    if node.body.len != 1:
      raise newException(GeneError, "unquote requires one expression")
    if depth == 1:
      compileExpr(c, node.body[0])
      return
    compileQuasiNodeParts(c, node, depth - 1)
  elif node.head.isSymbol("quasiquote"):
    if node.body.len != 1:
      raise newException(GeneError, "quasiquote expects one template")
    compileQuasiNodeParts(c, node, depth + 1)
  else:
    compileQuasiNodeParts(c, node, depth)

proc compileQuasiPipeline(c: var Compiler, value: Value, depth: int) =
  compileQuasiTemplate(c, value.pipelineInitial, depth)
  var stages: seq[PipelineStageBuildProto]
  for stage in value.pipelineStages:
    compileQuasiTemplate(c, stage.head, depth)
    var metaNames: seq[string]
    for key, item in stage.meta:
      metaNames.add key
      compileQuasiTemplate(c, item, depth)
    var propNames: seq[string]
    for key, item in stage.props:
      propNames.add key
      compileQuasiTemplate(c, item, depth)
    for item in stage.body:
      if item.quasiSpliceExpr(depth).splice:
        raise newException(GeneError,
          "quasiquoted pipeline stages do not support body splices")
      compileQuasiTemplate(c, item, depth)
    stages.add PipelineStageBuildProto(
      kind: stage.kind,
      metaNames: metaNames, propNames: propNames,
      bodyCount: stage.body.len, sourceLoc: stage.sourceLoc,
      slot: stage.slot)
  let index = c.chunk.addPipelineBuild(PipelineBuildProto(
    stages: stages, immutable: value.pipelineImmutable))
  discard c.emit(opMakePipeline, index)

proc compileQuasiTemplate(c: var Compiler, value: Value, depth: int) =
  case value.kind
  of vkPipeline:
    compileQuasiPipeline(c, value, depth)
  of vkNode:
    compileQuasiNode(c, value, depth)
  of vkList:
    compileQuasiList(c, value, depth)
  of vkMap:
    compileQuasiMap(c, value, depth)
  else:
    c.emitConst value

proc compileQuasiquote(c: var Compiler, node: Value) =
  if node.body.len != 1:
    raise newException(GeneError, "quasiquote expects one template")
  compileQuasiTemplate(c, node.body[0], 1)

proc pathSegmentValue(part: Value): Value =
  if part.kind != vkSymbol:
    return part
  let name = part.symVal
  if name.startsWith("?~"):
    newStr("?." & name[2 .. ^1])
  elif name.startsWith("~"):
    newStr("." & name[1 .. ^1])
  else:
    newStr(name)

proc selectorLiteral(parts: openArray[Value],
                     props: PropTable): Value =
  var body = newSeq[Value](parts.len)
  for i, part in parts:
    body[i] = part
  newNode(newSym("Path"), props = props, body = body)

proc isUnquoteSegment(v: Value): bool =
  v.kind == vkNode and v.head.isSymbol("unquote")

proc pathQualifiedMessageExpr(part: Value): Value =
  if part.kind != vkString or
      (not part.strVal.startsWith(".") and
       not part.strVal.startsWith("?.")):
    return NIL
  let optional = part.strVal.startsWith("?.")
  let name = part.strVal[(if optional: 2 else: 1) .. ^1]
  let at = qualifiedMessageSplit(name)
  if at <= 0:
    return NIL
  let qualifier = desugarPath(name[0 ..< at])
  let message = newNode(newSym("msg"),
    body = @[qualifier, newSym(name[at + 1 .. ^1])])
  let dynamic = newNode(newSym("unquote"), body = @[message])
  if not optional:
    return dynamic
  var props = initPropTable()
  props["optional"] = TRUE
  newNode(newSym("Path"), props = props, body = @[dynamic])

proc compileSelector(c: var Compiler, node: Value) =
  var parts = newSeq[Value](node.body.len)
  for i, part in node.body:
    let qualified = pathQualifiedMessageExpr(part)
    parts[i] = if qualified.kind == vkNil: part else: qualified
  var dynamic = false
  for part in parts:
    if part.isUnquoteSegment or part.kind == vkSymbol or
        part.kind == vkNode:
      dynamic = true
      break
  if not dynamic and node.props.len == 0:
    c.emitConst selectorLiteral(parts, node.props)
    return

  if node.props.len == 0:
    for part in parts:
      if part.isUnquoteSegment:
        if part.body.len != 1:
          raise newException(GeneError, "Path unquote requires one expression")
        compileExpr(c, part.body[0])
      elif part.kind in {vkSymbol, vkNode}:
        compileExpr(c, part)
      else:
        c.emitConst part
    discard c.emit(opMakeSelector, parts.len)
    return

  c.emitConst newSym("Path")
  var propNames: seq[string]
  for key, value in node.props:
    propNames.add key
    compileExpr(c, value)
  for part in parts:
    if part.isUnquoteSegment:
      if part.body.len != 1:
        raise newException(GeneError, "Path unquote requires one expression")
      compileExpr(c, part.body[0])
    elif part.kind in {vkSymbol, vkNode}:
      compileExpr(c, part)
    else:
      c.emitConst part
  let idx = c.chunk.addNodeBuild(NodeBuildProto(propNames: propNames,
                                                bodyCount: parts.len))
  discard c.emit(opMakeNode, idx)

proc compileSelectorParts(c: var Compiler, parts: openArray[Value]) =
  var body = newSeq[Value](parts.len)
  for i, part in parts:
    if part.kind == vkSymbol and
        (part.symVal.startsWith("~%") or part.symVal.startsWith("?~%")):
      let optional = part.symVal.startsWith("?~%")
      let name = part.symVal[(if optional: 3 else: 2) .. ^1]
      let source = if name.startsWith("$"):
                     desugarPath("gene/" & name[1 .. ^1])
                   else: newSym(name)
      let dynamic = newNode(newSym("unquote"), body = @[source])
      if optional:
        var props = initPropTable()
        props["optional"] = TRUE
        body[i] = newNode(newSym("Path"), props = props, body = @[dynamic])
      else:
        body[i] = dynamic
    else:
      body[i] = pathSegmentValue(part)
  compileSelector(c, newNode(newSym("Path"), body = body))

proc validateMessageName(name: string)

type PathSendSegment = object
  found: bool
  optional: bool
  dynamic: bool
  name: string

proc pathSendSegment(part: Value): PathSendSegment =
  ## The reader lowers `/.name`, `/?.name`, `/.%m`, and `/?.%m` to compact
  ## internal path markers. Keeping them inside `path` avoids allocating an
  ## intermediate call tree on this hot reader/compiler seam.
  if part.kind != vkSymbol:
    return
  var rest: string
  if part.symVal.len > 2 and part.symVal.startsWith("?~"):
    result.optional = true
    rest = part.symVal[2 .. ^1]
  elif part.symVal.len > 1 and part.symVal[0] == '~':
    rest = part.symVal[1 .. ^1]
  else:
    return
  result.found = true
  if rest.len > 1 and rest[0] == '%':
    result.dynamic = true
    result.name = rest[1 .. ^1]
  else:
    result.name = rest

proc isPathSendSegment(part: Value): bool =
  part.pathSendSegment.found

proc compilePathSend(c: var Compiler, part, site: Value) =
  let segment = part.pathSendSegment
  if not segment.found or segment.name.len == 0:
    raise newException(GeneError, "path message segment requires a name")
  let shortCircuit =
    if segment.optional: c.emitJump(opJumpIfAbsent)
    else: -1
  if segment.dynamic:
    if segment.name.len > 1 and segment.name[0] == '$':
      compileExpr(c, desugarPath("gene/" & segment.name[1 .. ^1]))
    else:
      c.emitLoadBinding(segment.name)
    discard c.emit(opResolveQualifiedMessage, name = "%" & segment.name)
  elif qualifiedMessageSplit(segment.name) > 0:
    let split = qualifiedMessageSplit(segment.name)
    let qualifier = desugarPath(segment.name[0..<split])
    let message = newSym(segment.name[split + 1..^1])
    compileExpr(c, newNode(newSym("msg"), body = @[qualifier, message]))
    discard c.emit(opResolveQualifiedMessage, name = segment.name)
  else:
    validateMessageName(segment.name)
    discard c.emit(opResolveMessage, name = segment.name)
  c.chunk.callSites[c.emitPlainCall(1)] = site
  if shortCircuit >= 0:
    c.patchJump(shortCircuit)


proc compilePathSuffix(c: var Compiler, parts: seq[Value], start: int,
                       site: Value) =
  # Static path messages use the ordinary VM call path, so Gene message
  # bodies can suspend without a nested synchronous invocation. Property
  # traversal still stops the complete path when a segment produces void.
  # Dynamic segments are resolved before any traversal by the Path contract;
  # retain the complete selector for those paths rather than interleave them
  # with message calls.
  for i in start ..< parts.len:
    let part = parts[i]
    if (part.kind == vkNode and part.head.isSymbol("unquote")) or
        part.pathSendSegment.dynamic:
      compileSelectorParts(c, parts.toOpenArray(start, parts.high))
      discard c.emit(opApplySelectorTop)
      return
  var first = start
  var missingJumps: seq[int]
  for i in start ..< parts.len:
    if not parts[i].isPathSendSegment:
      continue
    if i > first:
      compileSelectorParts(c, parts.toOpenArray(first, i - 1))
      discard c.emit(opApplySelectorTop)
      let missing = c.emitJump(opJumpIfAbsent)
      c.chunk.instructions[missing].flag = true
      missingJumps.add missing
    c.compilePathSend(parts[i], site)
    first = i + 1
    if first < parts.len:
      let missing = c.emitJump(opJumpIfAbsent)
      c.chunk.instructions[missing].flag = true
      missingJumps.add missing
  if first < parts.len:
    compileSelectorParts(c, parts.toOpenArray(first, parts.high))
    discard c.emit(opApplySelectorTop)
  for missing in missingJumps:
    c.patchJump(missing)

proc compilePath(c: var Compiler, node: Value) =
  let parts = node.body
  if parts.len == 0:
    c.emitConst VOID
    return
  if parts.len >= 2 and parts[0].isSymbol("gene") and parts[1].isSymbol("ex"):
    raise newException(GeneError, "$ex was renamed to $err")
  if parts.len >= 2 and parts[0].isSymbol("gene") and
      parts[1].isSymbol("err_msg"):
    if c.localSlot(CatchErrorBindingName) < 0 and
        c.parentSlot(CatchErrorBindingName).slot < 0:
      raise newException(GeneError,
        "$err_msg is only available inside a catch body")
    # The built-in shorthand has a proven Error:message contract. Keep its
    # direct send so strict error analysis sees that proof. User suffixes, if
    # present, traverse the resulting Str after this base is evaluated.
    c.emitLoadBinding(CatchErrorBindingName)
    c.compilePathSend(newSym("~Error:message"), node)
    if parts.len > 2:
      c.compilePathSuffix(parts, 2, node)
    return
  if parts.len >= 2 and parts[0].isSymbol("gene") and
      parts[1].isSymbol("err"):
    if c.localSlot(CatchErrorBindingName) < 0 and
        c.parentSlot(CatchErrorBindingName).slot < 0:
      raise newException(GeneError,
        "$err is only available inside a catch body")
    c.emitLoadBinding(CatchErrorBindingName)
    if parts.len > 2:
      c.compilePathSuffix(parts, 2, node)
    return
  if parts.len == 1:
    compileExpr(c, parts[0])
    return
  let imported = c.importedPathEntry(node)
  if imported.found and imported.candidate.category == cbcMacro:
    var spelling: seq[string]
    for part in parts:
      spelling.add part.symbolText
    raise newException(GeneError,
      "macro '" & spelling.join("/") &
      "' cannot be used as a value; call it in head position")
  if parts[0].isSymbol("gene") and node.props.len == 0 and
      not c.dynamicNameLookup:
    var segments: seq[Value]
    var plain = true
    for i in 1 ..< parts.len:
      if parts[i].kind != vkSymbol:
        plain = false
        break
      let segment = pathSegmentValue(parts[i])
      if segment.kind != vkString or segment.strVal.startsWith(".") or
          segment.strVal.startsWith("?.") or
          segment.strVal in ["this_mod", "this_pkg", "err", "err_msg"]:
        plain = false
        break
      segments.add segment
    if plain:
      let selector = selectorLiteral(segments, initPropTable())
      let offset = c.chunk.stdlibCacheSlots
      c.chunk.stdlibCacheSlots += segments.len + 1 # header plus namespace guards
      discard c.emit(opLoadStdlibPath, c.chunk.addConst(selector),
                     name = "gene", depth = offset)
      return
  compileExpr(c, parts[0])
  c.compilePathSuffix(parts, 1, node)

proc compileSetPath(c: var Compiler, node: Value) =
  ## `(set path value)` — checked in-place assignment (design §12.1). A symbol
  ## target rebinds a lexical `var`; a path target updates the addressed slot.
  let body = node.body
  if body.len != 2:
    raise newException(GeneError,
      "set requires exactly a target and a value")
  let target = body[0]
  if target.kind == vkSymbol:
    raise newException(GeneError,
      "set path assignment requires a path")
  if target.kind != vkNode or not target.head.isSymbol("path") or
      target.body.len < 2:
    raise newException(GeneError,
      "set path assignment requires a path")
  let parts = target.body
  if parts[0].isSymbol("gene") and parts[1].isSymbol("err_msg"):
    raise newException(GeneError, "$err_msg is a read-only expression")
  compileExpr(c, parts[0])
  for i in 1 ..< parts.len:
    let seg = parts[i]
    if seg.isPathSendSegment:
      raise newException(GeneError,
        "set cannot assign through a message segment")
    if seg.kind == vkNode and seg.head.isSymbol("unquote"):
      # Dynamic segments are key-only: ordinary selector evaluation *applies*
      # a callable segment, which is incoherent as an assignment target, so the
      # value is checked at run time and never applied.
      if seg.body.len != 1:
        raise newException(GeneError,
          "set path segment must be a Sym, Str, or Int")
      compileExpr(c, seg.body[0])
    elif seg.kind in {vkSymbol, vkString, vkInt}:
      c.emitConst seg
    else:
      raise newException(GeneError,
        "set path segment must be a Sym, Str, or Int")
  compileExpr(c, body[1])
  discard c.emit(opSetPath, parts.len - 1)

proc isDotMessageDescriptor*(name: string): bool =
  (name.len > 1 and name[0] == '.' and not name.startsWith("..")) or
    (name.len > 2 and name.startsWith("?."))

proc hasDotMessageQualifier(node: Value): bool =
  if node.kind != vkNode or not node.head.isSymbol("msg") or
      node.body.len == 0:
    return false
  let qualifier = node.body[0]
  if qualifier.kind == vkSymbol:
    return qualifier.symVal.isDotMessageDescriptor
  qualifier.kind == vkNode and qualifier.head.isSymbol("path") and
    qualifier.body.len > 0 and qualifier.body[0].kind == vkSymbol and
    qualifier.body[0].symVal.isDotMessageDescriptor

proc compileMessageValue(c: var Compiler, node: Value) =
  ## `Proto:msg` / `Self:msg` in value position (design §3): a **message
  ## value**, not a function and not a closure.
  ##
  ## It carries the scope it was written in. That is what makes a message usable
  ## in a higher-order position at all: applying one has no send site, so there
  ## is no reaching scope to resolve impls against — which is exactly why the
  ## first attempt at this failed. Resolving in the scope where the value was
  ## *authored* is the send-site rule, evaluated one step earlier.
  ##
  ## `Self:msg` names no qualifier, so it binds NIL and dispatches bare.
  if node.hasDotMessageQualifier:
    raise newException(GeneError,
      "a dot message descriptor requires a receiver; write (x .Proto:message)")
  if node.body.len == 2 and node.body[0].isSymbol("Self"):
    c.emitConst NIL
  else:
    compileExpr(c, node.body[0])
  let name =
    if node.body.len == 2 and node.body[1].kind == vkSymbol:
      node.body[1].symVal
    else: ""
  if name.len == 0:
    raise newException(GeneError, "a message name must be a symbol")
  discard c.emit(opBindMessage, 0, name = name)

proc valueSpreadExpr(value: Value): tuple[spread: bool, expr: Value] =
  case value.kind
  of vkSymbol:
    if value.symVal.len > 3 and value.symVal.endsWith("..."):
      return (true, desugarPath(value.symVal[0..^4]))
  of vkNode:
    if value.head.isSymbol("..."):
      if value.props.len != 0 or value.meta.len != 0 or value.body.len != 1:
        raise newException(GeneError, "spread requires one expression")
      return (true, value.body[0])
  else:
    discard
  (false, NIL)

proc isStandaloneSpreadMarker(value: Value): bool =
  value.kind == vkSymbol and value.symVal == "..."

proc compileEvaluatedListItem(c: var Compiler, item: Value) =
  if item.kind == vkSymbol and item.symVal != "/" and '/' in item.symVal:
    compileExpr(c, desugarPath(item.symVal))
  else:
    compileExpr(c, item)

proc compileSpreadPart(c: var Compiler, item: Value, forList: bool) =
  if forList:
    compileEvaluatedListItem(c, item)
  else:
    compileExpr(c, item)

proc compileSpreadValues(c: var Compiler, values: openArray[Value], start: int,
                         forList: bool, splices: var seq[bool],
                         hasSplice: var bool) =
  var i = start
  while i < values.len:
    let item = values[i]
    if item.isStandaloneSpreadMarker:
      raise newException(GeneError, "spread marker requires a preceding value")
    if i + 1 < values.len and values[i + 1].isStandaloneSpreadMarker:
      compileSpreadPart(c, item, forList)
      splices.add true
      hasSplice = true
      i += 2
      continue
    let spread = item.valueSpreadExpr
    if spread.spread:
      compileExpr(c, spread.expr)
      splices.add true
      hasSplice = true
    else:
      compileSpreadPart(c, item, forList)
      splices.add false
    inc i

proc hasValueSpread(values: openArray[Value]): bool =
  var i = 0
  while i < values.len:
    if values[i].isStandaloneSpreadMarker:
      return true
    if i + 1 < values.len and values[i + 1].isStandaloneSpreadMarker:
      return true
    if values[i].valueSpreadExpr.spread:
      return true
    inc i

proc compileListValue(c: var Compiler, value: Value) =
  var splices: seq[bool]
  var hasSplice = false
  compileSpreadValues(c, value.listItems, 0, forList = true, splices, hasSplice)
  if hasSplice:
    let idx = c.chunk.addListBuild(ListBuildProto(splices: splices,
                                                  immutable: value.listImmutable))
    discard c.emit(opMakeListSplice, idx)
  else:
    discard c.emit(opMakeList, value.listItems.len, flag = value.listImmutable)

proc compileHashMapValue(c: var Compiler, value: Value) =
  for entry in value.hashMapEntries:
    compileExpr(c, entry.key)
    compileExpr(c, entry.val)
  discard c.emit(opMakeHashMap, value.hashMapEntries.len)

proc compileCall(c: var Compiler, node: Value, allowSyntax = true,
                 tail = false)

proc sendCalleeName(callee: Value): string =
  ## Display name for a non-bare send callee, used in diagnostics only.
  if callee.kind == vkSymbol:
    callee.symVal
  elif callee.kind == vkNode and callee.head.isSymbol("path"):
    var parts: seq[string]
    for segment in callee.body:
      parts.add (if segment.kind == vkSymbol: segment.symVal else: $segment)
    parts.join("/")
  elif callee.kind == vkNode and callee.head.isSymbol("msg"):
    var parts: seq[string]
    for segment in callee.body:
      parts.add (if segment.kind == vkSymbol: segment.symVal else: $segment)
    parts.join(":")
  elif callee.kind == vkNode and callee.head.isSymbol("unquote") and
      callee.body.len == 1 and callee.body[0].kind == vkSymbol:
    "%" & callee.body[0].symVal
  else:
    "message"

proc sendMessageExpr(c: var Compiler, node, callee: Value): Value =
  ## The expression yielding the message value for a non-bare send. Pre-resolved
  ## `^protocol`/`^receiver` metadata names the message through its protocol
  ## value (message names are not lexical bindings, docs/spec/protocols.md); `%m` reads
  ## as `(unquote m)`, so unwrap it to the held value `m`.
  if node.props.hasKey("protocol") or node.props.hasKey("receiver"):
    if not (node.props.hasKey("protocol") and node.props.hasKey("receiver")):
      raise newException(GeneError,
        "direct protocol call metadata requires ^protocol and ^receiver")
    if callee.kind != vkSymbol:
      raise newException(GeneError,
        "direct protocol call metadata requires a message name")
    discard c.chunk.addDirectProtocolCall(DirectProtocolCallSpec(
      messageName: callee.symVal,
      protocolExpr: node.props["protocol"],
      receiverExpr: node.props["receiver"]))
    # `^protocol`/`^receiver` names the message through its protocol; that is a
    # qualifier plus a name, which is what `msg` carries.
    return newNode(newSym("msg"), body = @[node.props["protocol"], callee])
  if callee.kind == vkNode and callee.head.isSymbol("unquote") and
      callee.body.len == 1:
    return callee.body[0]
  callee

proc emitOptionalReceiverGuard(c: var Compiler, optional: bool): int =
  ## Guarded dot sends jump past the whole send when the receiver is absent,
  ## keeping it on the stack as the result. Returns -1 for an ordinary send, so the
  ## non-optional path emits nothing at all.
  if optional: c.emitJump(opJumpIfAbsent) else: -1

proc compileSend(c: var Compiler, node: Value, receiver: Value,
                 sendName: string, argsStart: int, messageExpr = NIL,
                 qualifierExpr = NIL, optional = false, tail = false) =
  ## Message send (docs/spec/protocols.md): the dot descriptor resolves
  ## receiver-first at runtime. Stack shape matches ordinary calls:
  ## [callee, named..., receiver, args...]. `messageExpr` carries a qualified or
  ## dynamic callee (`%m` or an expression); it must evaluate to a message
  ## value, and its impl is resolved here rather than by lowering the send to an
  ## ordinary call — so a message value never reaches a call opcode.
  validateMessageName(sendName)
  var names: seq[string]
  var shortCircuit = -1
  let isSuper = receiver.kind == vkSymbol and receiver.symVal == "super"
  if isSuper:
    # (super .m) dispatches m from the enclosing type's parent, but calls
    # it with `self` (design §10). The parent identity is stamped onto this
    # body's chunk when the type is created, so only `self` is pushed here — no
    # user-visible name is resolved, and a body-local cannot redirect the
    # delegation. Only bare-name messages are supported.
    if optional:
      raise newException(GeneError,
        "an optional dot send short-circuits an absent receiver, but super " &
        "is never absent; use (super .message)")
    if c.superType.kind == vkNil:
      raise newException(GeneError,
        "super is only valid in a type message body with a parent")
    if messageExpr.kind != vkNil:
      # A *dynamic* callee still cannot be delegated: super's whole point is
      # that the target is fixed statically, and an expression yielding a
      # message value cannot be checked against the parent at compile time.
      # A qualified callee is fine and handled below.
      raise newException(GeneError,
        "super delegates to a statically named message: '" & sendName &
        "' is a dynamic callee, which is not supported")
    compileExpr(c, newSym("self"))
    if qualifierExpr.kind != vkNil:
      # `(super .P:m)` — the protocol names the message and the nominal parent
      # selects the impl, so both reach the opcode. Selection already keeps
      # providers at the nearest applicable receiver depth
      # (`docs/spec/protocols.md`), so resolving from the parent *is*
      # "continue the walk from above the enclosing type".
      compileExpr(c, qualifierExpr)
      discard c.emit(opSuperQualifiedSend, 0, name = sendName)
    else:
      discard c.emit(opSuperSend, 0, name = sendName)
  elif qualifierExpr.kind != vkNil:
    # `(x .P:msg)` — push the *protocol*, not a member of it. The protocol
    # names the message and dispatch remains on the receiver. The name travels
    # in the instruction; a non-protocol qualifier is rejected at runtime.
    compileExpr(c, receiver)
    shortCircuit = c.emitOptionalReceiverGuard(optional)
    compileExpr(c, qualifierExpr)
    discard c.emit(opQualifiedSend, 0, name = sendName)
  elif messageExpr.kind != vkNil:
    compileExpr(c, receiver)
    shortCircuit = c.emitOptionalReceiverGuard(optional)
    compileExpr(c, messageExpr)
    discard c.emit(opResolveQualifiedMessage, 0, name = sendName)
  else:
    compileExpr(c, receiver)
    # `?~` decides on the receiver alone: an absent one yields itself without
    # resolving the message or evaluating a single argument form.
    shortCircuit = c.emitOptionalReceiverGuard(optional)
    # Resolve before every send argument, so a failed resolution does not run
    # named or positional argument forms.
    discard c.emit(opResolveMessage, 0, name = sendName)
  for k, value in node.props:
    if k in ["types", "protocol", "receiver"]:
      continue
    names.add k
    compileExpr(c, value)
  if names.len > 0:
    discard c.emit(opPlaceSendReceiver, names.len)
  var splices = @[false]
  var hasSplice = false
  compileSpreadValues(c, node.body, argsStart, forList = false, splices,
                      hasSplice)
  if hasSplice:
    let idx = c.chunk.addListBuild(ListBuildProto(splices: splices))
    c.chunk.callSites[c.emit(opCallSplice, idx, names = names,
                             tail = tail)] = node
  else:
    let argCount = node.body.len - argsStart + 1
    let callIndex =
      if names.len == 0:
        c.emitPlainCall(argCount, tail = tail)
      else:
        c.emit(opCall, argCount, names = names, tail = tail)
    c.chunk.callSites[callIndex] = node
  if shortCircuit >= 0:
    # Both paths leave exactly one value: the call's result, or the absent
    # receiver the guard preserved.
    c.patchJump(shortCircuit)

proc compileCall(c: var Compiler, node: Value, allowSyntax = true,
                 tail = false) =
  let directSend = normalizeMessageHeadCall(node)
  if directSend.bits != node.bits:
    let firstInstruction = c.chunk.instructions.len
    compileCall(c, directSend, allowSyntax = false, tail = tail)
    for instruction, site in c.chunk.callSites.mpairs:
      if instruction >= firstInstruction and site.bits == directSend.bits:
        site = node
    return
  if node.body.len > 1 and node.body[0].kind == vkSymbol and
      (node.body[0].symVal == "~" or node.body[0].symVal == "?~"):
    # (x .f a) — infix message send (docs/spec/protocols.md). The optional marker is the same
    # send with one added rule: an absent receiver yields itself.
    let optional = node.body[0].symVal == "?~"
    if node.body[1].kind == vkSymbol and
        not node.props.hasKey("protocol") and
        not node.props.hasKey("receiver") and
        not node.props.hasKey("types"):
      compileSend(c, node, node.head, node.body[1].symVal, 2,
                  optional = optional, tail = tail)
      return
    # A selector callee in generated canonical AST is a projection, not a
    # message; it keeps the flipped-call lowering. Every other non-bare callee —
    # a qualified path (x .P:m), `%m`, an expression, or `^protocol`/`^receiver`
    # metadata — must evaluate to a message value and is dispatched by
    # opResolveQualifiedMessage, so a dot send can never invoke an ordinary function
    # (design §3/§8).
    if node.body[1].kind == vkNode and node.body[1].head.isSymbol("Path"):
      if optional:
        raise newException(GeneError,
          "an optional dot descriptor guards a message send; Paths are " &
          "ordinary callables — write (/name x) and use ?? if needed")
      var args = newSeqOfCap[Value](node.body.len - 1)
      args.add node.head
      for i in 2 ..< node.body.len:
        args.add node.body[i]
      compileCall(c, newNode(node.body[1], node.props, args, node.meta),
                  allowSyntax = false, tail = tail)
      return
    # `(x .Q:msg)` — the qualifier names the message and never selects the
    # impl, so dispatch is on the receiver either way (design §3, decision 5).
    # `Self` declines to name a type at all, which makes it exactly the bare
    # send; any other qualifier is a value whose kind decides at run time.
    if node.body[1].kind == vkNode and node.body[1].head.isSymbol("msg") and
        node.body[1].body.len == 2 and
        node.body[1].body[1].kind == vkSymbol and
        not node.props.hasKey("protocol") and
        not node.props.hasKey("receiver") and
        not node.props.hasKey("types"):
      let qualifier = node.body[1].body[0]
      let messageName = node.body[1].body[1].symVal
      # `(super .Self:m)` names no qualifier at all, so it is exactly the bare
      # super send — same as for an ordinary receiver.
      if qualifier.isSymbol("Self"):
        compileSend(c, node, node.head, messageName, 2,
                    optional = optional, tail = tail)
      else:
        compileSend(c, node, node.head, messageName, 2,
                    qualifierExpr = qualifier, optional = optional,
                    tail = tail)
      return
    let resolved = sendMessageExpr(c, node, node.body[1])
    if resolved.kind == vkNode and resolved.head.isSymbol("msg") and
        resolved.body.len == 2 and resolved.body[1].kind == vkSymbol:
      compileSend(c, node, node.head, resolved.body[1].symVal, 2,
                  qualifierExpr = resolved.body[0], optional = optional,
                  tail = tail)
    else:
      compileSend(c, node, node.head, sendCalleeName(node.body[1]), 2,
                  messageExpr = resolved, optional = optional, tail = tail)
    return
  let explicitSyntaxHead = node.head.kind == vkSymbol and
    node.head.symVal.len > 1 and node.head.symVal.endsWith("!")
  if explicitSyntaxHead:
    if not allowSyntax:
      compileExpr(c, node.head)
      discard c.emit(opRejectSyntaxSend)
      return
    # Explicit fexpr callee (design §3 step 4): props/body stay raw syntax nodes;
    # no argument evaluation happens.
    compileExpr(c, node.head)
    c.emitConst node
    c.chunk.callSites[c.emit(opSyntaxCall, c.addMacroContext())] = node
    return
  let knownOrdinary = c.calleeKnownOrdinary(node.head)
  if knownOrdinary and node.props.len == 0 and
      node.head.kind == vkSymbol and node.body.len == 0:
    let direct = c.lexicalCallSlot0(node.head.symVal)
    if direct.slot >= 0:
      c.chunk.callSites[c.emit(direct.op, direct.slot,
                               name = node.head.symVal,
                               depth = direct.depth, tail = tail)] = node
      return
    if not c.hasLexicalBinding(node.head.symVal):
      c.reportBareName(node.head.symVal)
      c.chunk.callSites[c.emit(opCallName0, name = node.head.symVal,
                               tail = tail)] = node
      return
  if knownOrdinary and node.props.len == 0 and
      node.head.kind == vkSymbol and node.body.len == 2:
    let fastKind = nativeFastLoadKind(node.head.symVal)
    if fastKind != nfkNone and not c.hasLexicalBinding(node.head.symVal):
      compileExpr(c, node.body[0])
      if node.body[1].isSelfEvaluatingFastConst:
        let constIndex = c.chunk.addConst(node.body[1])
        # Fast-const opcodes use flag to mean the RHS constant is a small Int.
        let constIsSmallInt = node.body[1].isSmallInt
        if c.exprKnownBareInt(node.body[0]) and node.body[1].kind == vkInt:
          discard c.emit(intFastConstOp(fastKind), ord(fastKind), name = node.head.symVal,
                         depth = constIndex, flag = constIsSmallInt)
        else:
          discard c.emit(opNativeFastConst, ord(fastKind), name = node.head.symVal,
                         depth = constIndex, flag = constIsSmallInt)
      else:
        compileExpr(c, node.body[1])
        if c.exprKnownBareInt(node.body[0]) and c.exprKnownBareInt(node.body[1]):
          discard c.emit(intFast2Op(fastKind), ord(fastKind), name = node.head.symVal)
        else:
          discard c.emit(opNativeFast2, ord(fastKind), name = node.head.symVal)
      return
  if knownOrdinary and node.props.len == 0 and
      node.head.kind == vkSymbol and node.body.len == 1:
    let direct = c.lexicalCallSlot(node.head.symVal)
    if direct.slot >= 0:
      let argKnownBareInt = c.exprKnownBareInt(node.body[0])
      compileExpr(c, node.body[0])
      c.chunk.callSites[c.emit(direct.op, direct.slot, name = node.head.symVal,
                               depth = direct.depth,
                               flag = argKnownBareInt, tail = tail)] = node
      return
    if not c.hasLexicalBinding(node.head.symVal):
      let argKnownBareInt = c.exprKnownBareInt(node.body[0])
      compileExpr(c, node.body[0])
      c.reportBareName(node.head.symVal)
      c.chunk.callSites[c.emit(opCallName1, name = node.head.symVal,
                               flag = argKnownBareInt, tail = tail)] = node
      return
  if knownOrdinary and node.props.len == 0 and
      node.head.kind == vkSymbol and node.body.len > 1 and
      not node.body.hasValueSpread:
    let slot = c.localSlot(node.head.symVal)
    if slot >= 0:
      var argsKnownBareInt = true
      for arg in node.body:
        argsKnownBareInt = argsKnownBareInt and c.exprKnownBareInt(arg)
        compileExpr(c, arg)
      c.chunk.callSites[c.emit(opCallLocalN, slot, name = node.head.symVal,
                               depth = node.body.len,
                               flag = argsKnownBareInt, tail = tail)] = node
      return
    if not c.hasLexicalBinding(node.head.symVal):
      var argsKnownBareInt = true
      for arg in node.body:
        argsKnownBareInt = argsKnownBareInt and c.exprKnownBareInt(arg)
        compileExpr(c, arg)
      c.reportBareName(node.head.symVal)
      c.chunk.callSites[c.emit(opCallNameN, name = node.head.symVal,
                               depth = node.body.len,
                               flag = argsKnownBareInt, tail = tail)] = node
      return
  if node.props.hasKey("types") and node.head.kind == vkSymbol:
    let types = node.props["types"]
    if types.kind != vkList:
      raise newException(GeneError, "call ^types must be a list")
    discard c.chunk.addMonomorphization(MonomorphizationSpec(
      functionName: node.head.symVal,
      typeArgs: types.listItems))
  if node.props.hasKey("protocol") or node.props.hasKey("receiver"):
    # `(m ^protocol P ^receiver T recv args...)` is the pre-resolved spelling of
    # `(recv .P:m args...)`, so dispatch it as a send. A message identity is
    # not callable in head position (design §3), and routing it here keeps the
    # message value out of the ordinary call opcodes.
    let messageExpr = sendMessageExpr(c, node, node.head)
    if node.body.len == 0:
      raise newException(GeneError,
        "direct protocol call metadata requires a receiver argument")
    compileSend(c, node, node.body[0], node.head.symVal, 1,
                messageExpr = messageExpr, tail = tail)
    return
  compileExpr(c, node.head)
  # Every ordinary call evaluates its arguments. Syntax-preserving calls are
  # selected solely by a trailing `!` on a lexical head above, never by
  # inspecting a runtime callee value.
  if not allowSyntax:
    discard c.emit(opRejectSyntaxSend)
  var names: seq[string]
  for k, value in node.props:
    if k in ["types", "protocol", "receiver"]:
      continue
    names.add k
    compileExpr(c, value)
  var splices: seq[bool]
  var hasSplice = false
  compileSpreadValues(c, node.body, 0, forList = false, splices, hasSplice)
  if hasSplice:
    let idx = c.chunk.addListBuild(ListBuildProto(splices: splices))
    c.chunk.callSites[c.emit(opCallSplice, idx, names = names,
                             tail = tail)] = node
  else:
    let callIndex =
      if names.len == 0:
        c.emitPlainCall(node.body.len, tail = tail)
      else:
        c.emit(opCall, node.body.len, names = names, tail = tail)
    c.chunk.callSites[callIndex] = node

proc compileNew(c: var Compiler, node: Value) =
  ## `new` is a core form, not a binding. Evaluate the type first, followed by
  ## named and positional constructor arguments, then let opNew perform the
  ## constructor lookup and invocation.
  if node.body.len == 0:
    raise newException(GeneError, "new expects a Type argument")
  compileExpr(c, node.body[0])
  var names: seq[string]
  for name, value in node.props:
    names.add name
    compileExpr(c, value)
  var splices: seq[bool]
  var hasSplice = false
  compileSpreadValues(c, node.body, 1, forList = false, splices, hasSplice)
  let instruction =
    if hasSplice:
      let listIndex = c.chunk.addListBuild(ListBuildProto(splices: splices))
      c.emit(opNew, listIndex, names = names, flag = true)
    else:
      c.emit(opNew, node.body.len - 1, names = names)
  c.chunk.callSites[instruction] = node

proc compileLeadingSelfCall(c: var Compiler, node: Value, optional = false,
                            tail = false) =
  # (.f a) => (self .f a): message send to lexical self (docs/spec/protocols.md).
  # `(?.f a)` is the guarded form, which matters inside an `impl P for Nil`
  # body where lexical self is itself absent.
  let spelling = if optional: "?.message" else: ".message"
  if node.body.len == 0:
    raise newException(GeneError, "`" & spelling & "` requires a callable")
  if not c.selfAvailable:
    raise newException(GeneError,
      "leading `" & spelling & "` requires lexical self")
  if node.body[0].kind == vkSymbol and
      not node.props.hasKey("protocol") and
      not node.props.hasKey("receiver") and
      not node.props.hasKey("types"):
    compileSend(c, node, newSym("self"), node.body[0].symVal, 1,
                optional = optional, tail = tail)
    return
  # A selector callee projects the receiver rather than naming a message, so it
  # keeps the flipped-call lowering; everything else must be a message value and
  # goes through the same qualified-send path as `(x ....)` (design §3/§8).
  if node.body[0].kind == vkNode and node.body[0].head.isSymbol("Path"):
    if optional:
      raise newException(GeneError,
        "an optional dot descriptor guards a message send; Paths are " &
        "ordinary callables — write (/name self) and use ?? if needed")
    var args = newSeqOfCap[Value](node.body.len)
    args.add newSym("self")
    for i in 1 ..< node.body.len:
      args.add node.body[i]
    compileCall(c, newNode(node.body[0], node.props, args, node.meta),
                allowSyntax = false, tail = tail)
    return
  let resolved = sendMessageExpr(c, node, node.body[0])
  if resolved.kind == vkNode and resolved.head.isSymbol("msg") and
      resolved.body.len == 2 and resolved.body[1].kind == vkSymbol:
    # `(.P:m)` is `(self .P:m)`: same qualifier path as an explicit receiver.
    if resolved.body[0].isSymbol("Self"):
      compileSend(c, node, newSym("self"), resolved.body[1].symVal, 1,
                  optional = optional, tail = tail)
    else:
      compileSend(c, node, newSym("self"), resolved.body[1].symVal, 1,
                  qualifierExpr = resolved.body[0], optional = optional,
                  tail = tail)
  else:
    compileSend(c, node, newSym("self"), sendCalleeName(node.body[0]), 1,
                messageExpr = resolved, optional = optional, tail = tail)

proc compileMatch(c: var Compiler, node: Value, tail = false) =
  let body = node.body
  if body.len < 2:
    raise newException(GeneError, "match requires a value and at least one arm")
  var requireExhaustive = true
  for key, value in node.props:
    if key != "exhaustive":
      raise newException(GeneError, "match only accepts ^exhaustive")
    if value.kind != vkBool:
      raise newException(GeneError, "match ^exhaustive requires a literal Bool")
    requireExhaustive = value.boolVal
  compileExpr(c, body[0])
  let mp = MatchProto(clauses: @[], elseBody: nil, tailResult: tail)
  var hasCatchAll = false
  for i in 1 ..< body.len:
    let clause = body[i]
    if clause.kind != vkNode or clause.head.kind != vkSymbol:
      raise newException(GeneError, "match clauses must be (when ...) or (else ...)")
    case clause.head.symVal
    of "when":
      if clause.body.len == 0:
        raise newException(GeneError, "when requires a pattern")
      if clause.body[0].kind == vkSymbol:
        hasCatchAll = true
      var branchBody: seq[Value]
      for j in 1 ..< clause.body.len:
        branchBody.add clause.body[j]
      mp.clauses.add MatchClause(pattern: clause.body[0],
                                  body: c.compileSubBody(branchBody,
                                                         clause.body[0],
                                                         scoped = true,
                                                         tail = tail))
    of "else":
      if i != body.high:
        raise newException(GeneError, "match else must be the final arm")
      mp.elseBody = c.compileSubBody(clause.body, scoped = true, tail = tail)
      break
    else:
      raise newException(GeneError, "match requires when/else clauses; " &
        "macro calls are only expanded in expression positions (got " & clause.head.symVal & ")")
  if requireExhaustive and mp.elseBody == nil and not hasCatchAll:
    raise newException(GeneError,
      "match is not exhaustive; add (else ...), a binding arm, or ^!exhaustive")
  discard c.emit(opMatch, c.chunk.addMatch(mp))

proc compileWhile(c: var Compiler, node: Value) =
  let body = node.body
  if body.len == 0:
    raise newException(GeneError, "while requires a condition")
  let enter = c.emit(opLoopEnter)
  let start = c.chunk.instructions.len
  c.chunk.instructions[enter].depth = start
  inc c.loopDepth
  compileExpr(c, body[0])
  let exitJump = c.emitJump(opJumpIfFalse)
  compileBodyFrom(c, body, 1)
  discard c.emit(opPop)                     # discard each iteration's body value
  discard c.emit(opJump, start)             # loop back to the condition
  c.patchJump(exitJump)
  c.chunk.instructions[enter].intArg = c.chunk.instructions.len
  discard c.emit(opLoopLeave)
  dec c.loopDepth
  c.emitConst NIL                           # while evaluates to nil

proc compileLoop(c: var Compiler, node: Value) =
  if node.props.len != 0:
    raise newException(GeneError, "loop does not accept props")
  let body = node.body
  if body.len == 0:
    raise newException(GeneError, "loop requires a body")
  let enter = c.emit(opLoopEnter)
  let start = c.chunk.instructions.len
  c.chunk.instructions[enter].depth = start
  inc c.loopDepth
  compileBodyFrom(c, body, 0)
  discard c.emit(opPop)                     # discard each iteration's body value
  discard c.emit(opJump, start)
  c.chunk.instructions[enter].intArg = c.chunk.instructions.len
  discard c.emit(opLoopLeave)
  dec c.loopDepth
  c.emitConst NIL

proc compileRepeat(c: var Compiler, node: Value) =
  let body = node.body
  if node.props.len != 0:
    raise newException(GeneError, "repeat does not accept props")
  if body.len == 0:
    raise newException(GeneError, "repeat requires a count")

  if body.len >= 2 and body[1].isSymbol("in"):
    if body.len < 3:
      raise newException(GeneError, "repeat requires an index, in, and a count")
    if body[0].kind != vkSymbol:
      raise newException(GeneError, "repeat index must be a local name")
    let indexName = body[0].symVal
    let limitName = c.nextTemp("repeat_limit")
    compileExpr(c, body[2])
    c.emitDefineBinding(limitName)
    c.emitConst newInt(0)
    c.emitDefineBinding(indexName)

    let enter = c.emit(opLoopEnter)
    let start = c.chunk.instructions.len
    c.emitLoadBinding(indexName)
    c.emitLoadBinding(limitName)
    discard c.emit(opNativeFast2, ord(nfkLt), name = "<")
    let exitJump = c.emitJump(opJumpIfFalse)

    inc c.loopDepth
    compileBodyFrom(c, body, 3)
    discard c.emit(opPop)                   # discard each iteration's body value
    c.chunk.instructions[enter].depth = c.chunk.instructions.len
    c.emitLoadBinding(indexName)
    c.emitConst newInt(1)
    discard c.emit(opNativeFast2, ord(nfkAdd), name = "+")
    c.emitSetBinding(indexName)
    discard c.emit(opPop)                   # discard set result
    discard c.emit(opJump, start)
    c.patchJump(exitJump)
    c.chunk.instructions[enter].intArg = c.chunk.instructions.len
    discard c.emit(opLoopLeave)
    dec c.loopDepth
    c.emitConst NIL
    return

  let remainingName = c.nextTemp("repeat_remaining")
  compileExpr(c, body[0])
  c.emitDefineBinding(remainingName)

  let enter = c.emit(opLoopEnter)
  let start = c.chunk.instructions.len
  c.emitLoadBinding(remainingName)
  c.emitConst newInt(0)
  discard c.emit(opNativeFast2, ord(nfkGt), name = ">")
  let exitJump = c.emitJump(opJumpIfFalse)

  inc c.loopDepth
  compileBodyFrom(c, body, 1)
  discard c.emit(opPop)                     # discard each iteration's body value
  c.chunk.instructions[enter].depth = c.chunk.instructions.len
  c.emitLoadBinding(remainingName)
  c.emitConst newInt(1)
  discard c.emit(opNativeFast2, ord(nfkSub), name = "-")
  c.emitSetBinding(remainingName)
  discard c.emit(opPop)                     # discard set result
  discard c.emit(opJump, start)
  c.patchJump(exitJump)
  c.chunk.instructions[enter].intArg = c.chunk.instructions.len
  discard c.emit(opLoopLeave)
  dec c.loopDepth
  c.emitConst NIL

proc compileFor(c: var Compiler, node: Value) =
  let body = node.body
  if body.len < 3:
    raise newException(GeneError, "for requires a pattern, in, and an iterable")
  if body[1].kind != vkSymbol or body[1].symVal != "in":
    raise newException(GeneError, "for requires 'in' after the pattern")
  if c.allowYield and body.bodyContainsYield(3):
    let iterName = c.nextTemp("iter")
    compileExpr(c, body[2])                   # iterable on the stack
    discard c.emit(opMakeIterator)
    c.emitDefineBinding(iterName)

    let enter = c.emit(opLoopEnter)
    let start = c.chunk.instructions.len
    c.chunk.instructions[enter].depth = start
    inc c.loopDepth
    c.emitLoadBinding(iterName)
    discard c.emit(opIteratorHasNext)
    let exitJump = c.emitJump(opJumpIfFalse)

    c.emitLoadBinding(iterName)
    discard c.emit(opIteratorNext)
    discard c.emit(opMatchBindReplace, c.chunk.addConst(body[0]))
    discard c.emit(opPop)                     # discard the matched item
    compileBodyFrom(c, body, 3)
    discard c.emit(opPop)                     # discard each iteration's body value
    discard c.emit(opJump, start)
    c.patchJump(exitJump)
    c.chunk.instructions[enter].intArg = c.chunk.instructions.len
    discard c.emit(opLoopLeave)
    dec c.loopDepth
    c.emitLoadBinding(iterName)
    discard c.emit(opIteratorClose)
    c.emitConst NIL
    return

  compileExpr(c, body[2])                   # iterable on the stack
  var bodyCompiler = c.childCompiler()
  bodyCompiler.loopDepth = c.loopDepth + 1
  bodyCompiler.enableLocalSlots()
  bodyCompiler.parentSlots = c.parentFrames()
  for name in patternBindingNames(body[0]):
    discard bodyCompiler.reserveLocal(name)
    if name == "self":
      bodyCompiler.selfAvailable = true
  if patternBindsSelf(body[0]):
    bodyCompiler.selfAvailable = true
  var forForms: seq[Value]
  for i in 3 ..< body.len:
    forForms.add body[i]
  bodyCompiler.prepareStaticImports(forForms)
  bodyCompiler.reserveProtocolBindingsFor(forForms)
  compileBodyFrom(bodyCompiler, body, 3)
  discard bodyCompiler.emit(opReturn)
  bodyCompiler.chunk.localNames = bodyCompiler.localNames
  let fp = ForProto(pattern: body[0], body: bodyCompiler.chunk,
    reuseScope: chunkCanPoolCallScope(bodyCompiler.chunk, nestedLoops = true))
  discard c.emit(opForEach, c.chunk.addForLoop(fp))

proc compileYield(c: var Compiler, node: Value) =
  if not c.allowYield:
    raise newException(GeneError, "yield is only valid inside fn")
  if not c.inGenerator:
    raise newException(GeneError, "yield requires an explicit ^^generator declaration")
  if node.props.len != 0 or node.body.len != 1:
    raise newException(GeneError, "yield expects one value")
  compileExpr(c, node.body[0])
  discard c.emit(opYield)

proc compileReturn(c: var Compiler, node: Value) =
  if not c.inFunction:
    raise newException(GeneError, "return is only valid inside fn")
  if node.props.len != 0 or node.body.len > 1:
    raise newException(GeneError, "return expects zero or one value")
  if c.inGenerator and node.body.len == 1 and node.body[0].kind != vkVoid:
    raise newException(GeneError,
      "generator return value must be void")
  # A `: Nil` / `: Void` function yields the declared unit, so an explicit
  # returned value could only be silently discarded. Rejecting it keeps the
  # signature the single source of truth about what a call produces.
  if c.inStatementFn and node.body.len == 1 and
      node.body[0].kind notin {vkNil, vkVoid}:
    raise newException(GeneError,
      "return in a Nil/Void function takes no value; use (return) or (return nil)")
  if node.body.len == 1 and node.body[0].kind != vkVoid:
    c.sawNonVoidReturn = true
  if node.body.len == 0:
    c.emitConst VOID
  else:
    compileExpr(c, node.body[0], tail = true)
  discard c.emit(opExplicitReturn)

proc compileTry(c: var Compiler, node: Value) =
  ## (try body... catch ErrorType recovery... [catch ...] [ensure cleanup...]) — the
  ## `catch`/`ensure` markers are bare symbols in the flat body.
  let body = node.body
  var i = 0
  var tryForms: seq[Value]
  while i < body.len and not (body[i].isSymbol("catch") or body[i].isSymbol("ensure")):
    tryForms.add body[i]
    inc i
  let tp = TryProto(body: c.compileSubBody(tryForms,
    repeatBindings = c.loopDepth > 0 or c.repeatBindings))
  while i < body.len and body[i].isSymbol("catch"):
    inc i
    if i >= body.len:
      raise newException(GeneError, "catch requires an error type")
    let errorType = body[i]
    if errorType.kind in {vkNil, vkVoid, vkBool, vkInt, vkFloat, vkString,
                          vkChar, vkList, vkMap, vkSet, vkHashMap} or
        errorType.isSymbol("_") or
        (errorType.kind == vkNode and errorType.props.len > 0):
      raise newException(GeneError,
        "catch requires an error type; use Any to catch every recoverable error")
    let pattern = newNode(newSym(CatchErrorBindingName),
      body = @[newSym(":"), errorType])
    inc i
    var recovery: seq[Value]
    while i < body.len and not (body[i].isSymbol("catch") or body[i].isSymbol("ensure")):
      recovery.add body[i]
      inc i
    tp.catches.add CatchClause(errorType: errorType, pattern: pattern,
                               body: c.compileSubBody(recovery, pattern,
                                                      scoped = true))
  if i < body.len and body[i].isSymbol("ensure"):
    inc i
    var ensureForms: seq[Value]
    while i < body.len:
      ensureForms.add body[i]
      inc i
    tp.ensureBody = c.compileSubBody(ensureForms,
      repeatBindings = c.loopDepth > 0 or c.repeatBindings)
  discard c.emit(opTry, c.chunk.addTry(tp))

proc compileTaskScope(c: var Compiler, node: Value) =
  if node.props.len != 0:
    raise newException(GeneError, "scope does not accept named arguments")
  let body = c.compileSubBody(node.body, scoped = true)
  discard c.emit(opTaskScope, c.chunk.addSubchunk(body))

proc compileSupervisor(c: var Compiler, node: Value) =
  for key in node.props.keys:
    if key notin ["strategy", "events", "dead_letter", "max_restarts",
                  "within_ms"]:
      raise newException(GeneError,
        "supervisor got unexpected named argument: " & key)
  if not node.props.hasKey("strategy"):
    raise newException(GeneError, "supervisor requires ^strategy")
  let strategyExpr = node.props["strategy"]
  if strategyExpr.kind != vkSymbol:
    raise newException(GeneError, "supervisor ^strategy must be a name")
  let strategy = strategyExpr.symVal
  if strategy notin ["restart", "stop", "escalate"]:
    raise newException(GeneError,
      "unsupported supervisor strategy: " & strategy)
  # Options are compiled in a fixed order; opSupervisor pops them in reverse.
  var optionNames: seq[string]
  for option in ["events", "dead_letter", "max_restarts", "within_ms"]:
    if node.props.hasKey(option):
      compileExpr(c, node.props[option])
      optionNames.add option
  let body = c.compileSubBody(node.body, scoped = true)
  discard c.emit(opSupervisor, c.chunk.addSubchunk(body), name = strategy,
                 names = optionNames)

proc compileSpawn(c: var Compiler, node: Value) =
  if node.body.len != 1:
    raise newException(GeneError,
      "spawn expects one expression and optional ^lane root")
  var rootLane = false
  for name, value in node.props:
    if name != "lane":
      raise newException(GeneError,
        "spawn got unexpected property ^" & name & "; expected ^lane root")
    if value.kind != vkSymbol or value.symVal != "root":
      raise newException(GeneError, "spawn ^lane currently accepts only root")
    rootLane = true
  let body = c.compileSubBody(node.body, scoped = true)
  discard c.emit(opSpawn, c.chunk.addSubchunk(body),
                 flag = not rootLane and
                   not body.chunkMutatesOuterScope() and
                   not body.chunkContainsSpawn())

proc compileAwait(c: var Compiler, node: Value) =
  if node.props.len != 0 or node.body.len != 1:
    raise newException(GeneError, "await expects one Task")
  compileExpr(c, node.body[0])
  discard c.emit(opAwait)

proc compileFail(c: var Compiler, node: Value) =
  if node.props.len != 0 or node.body.len != 1:
    raise newException(GeneError, "fail expects one Error value")
  compileExpr(c, node.body[0])
  discard c.emit(opFail)

proc compilePanic(c: var Compiler, node: Value) =
  if node.props.len != 0 or node.body.len > 1:
    raise newException(GeneError, "panic expects zero or one value")
  if node.body.len == 0:
    c.emitConst newStr("panic")
  else:
    compileExpr(c, node.body[0])
  discard c.emit(opPanic)

proc deriveProtocolExpr(request: Value): Value =
  if request.kind == vkNode:
    request.head
  else:
    request

proc parseTypeBodySchema(schema: Value): seq[TypeBodyField] =
  if schema.kind != vkList:
    raise newException(GeneError, "type ^body must be a list")
  var sawRest = false
  for item in schema.listItems:
    if item.isSymbol(","):
      continue
    if sawRest:
      raise newException(GeneError,
        "type ^body rest field must be the final body field")
    if item.kind == vkSymbol and item.symVal.endsWith("..."):
      let name = item.symVal[0 .. ^4]
      if name.len == 0:
        raise newException(GeneError, "type ^body rest field requires a type")
      result.add TypeBodyField(rest: true, typeExpr: newSym(name))
      sawRest = true
    else:
      result.add TypeBodyField(typeExpr: item)

proc rejectUnknownTypeProps(node: Value) =
  for key in node.props.keys:
    if key in ["props", "body", "impl", "derive", "private", "repr",
               "native"]:
      continue
    if key == "sealed":
      raise newException(GeneError,
        "type ^sealed is reserved for future native layout optimization")
    raise newException(GeneError,
      "type got unexpected named argument: " & key)

proc typeReprMarker(node: Value, name: string): TypeRepr =
  ## `^repr native_wrapper` (design §16.6). The marker is a compile-time symbol,
  ## not an expression: it decides whether construction paths reject the type,
  ## so it must be knowable wherever the declaration is read — including by the
  ## compiler, before any value exists.
  if not node.props.hasKey("repr"):
    return trOrdinary
  let marker = node.props["repr"]
  if marker.kind != vkSymbol or marker.symVal != "native_wrapper":
    raise newException(GeneError,
      "type " & name & " ^repr must be the symbol native_wrapper")
  trNativeWrapper

proc nativeTypeMarker(c: Compiler, node: Value,
                      name: string): NativeTypeProto =
  ## Resolve `^native` entirely in the compiler metadata plane. The ABI name
  ## denotes a previously declared ffi/struct layout; evaluating its runtime
  ## symbol binding would lose the descriptor and create a fourth namespace.
  if not node.props.hasKey("native"):
    return nil
  let marker = node.props["native"]
  validateNativeMarkerShape(marker, name)
  let abiExpr = marker.mapEntries["abi"]
  var abi: FfiStructProto
  for candidate in c.chunk.ffiStructs:
    if candidate.name == abiExpr.symVal:
      if abi != nil:
        raise newException(GeneError,
          "type " & name & " ^native ^abi is ambiguous: " & abiExpr.symVal)
      abi = candidate
  if abi == nil:
    let own = c.ownInterfaceEntry(abiExpr.symVal)
    if own.found:
      abi = own.entry.ffiStruct
  var importedAbi = false
  if abi == nil and c.importedCompileEntries.hasKey(abiExpr.symVal):
    abi = c.importedCompileEntries[abiExpr.symVal].ffiStruct
    importedAbi = abi != nil
  if abi == nil:
    raise newException(GeneError,
      "type " & name & " ^native ^abi does not resolve to an ffi/struct: " &
      abiExpr.symVal)
  if importedAbi:
    c.chunk.addFfiStructDependency(abi.identity)
    var present = false
    for candidate in c.chunk.ffiStructs:
      if candidate.identity == abi.identity:
        present = true
        break
    if not present:
      discard c.chunk.addFfiStruct(abi)
  nativeTypeProtoFrom(marker, node, name,
    (if c.sourceName.len > 0: c.sourceName else: "<memory>") &
      "::" & (c.namespacePath & @[name]).join("/"),
    abi)

proc validateMessageName(name: string) =
  if '/' in name:
    raise newException(GeneError,
      "message names may not contain '/'; qualify a protocol as .ns/Proto:message " &
      "or send a held message with .%message")
  if name.len > 1 and name.endsWith("!"):
    raise newException(GeneError,
      "message names may not end in !; trailing ! is reserved for fexpr calls: " &
      name)

proc messageNameParts(node: Value): tuple[protocolPath: seq[string], name: string] =
  ## A message name is a simple symbol, or a qualified path in impl bodies for
  ## disambiguating same-named closure messages (docs/spec/protocols.md):
  ## `Protocol/name`, or `ns/Protocol/name` for namespace-qualified owners.
  if node.kind != vkNode or not node.head.isSymbol("message"):
    raise newException(GeneError, "protocol/impl body must contain message declarations")
  if node.body.len < 2 or node.body[1].kind != vkList:
    raise newException(GeneError, "message requires a name and parameter vector")
  let nameForm = node.body[0]
  if nameForm.kind == vkSymbol:
    validateMessageName(nameForm.symVal)
    return (@[], nameForm.symVal)
  # `Protocol:name` is the message spelling; `path` is still accepted for a
  # namespace-qualified owner, where the leading segments are a namespace path
  # and only the last two are `Protocol`/`name`.
  if nameForm.kind == vkNode and
      (nameForm.head.isSymbol("path") or nameForm.head.isSymbol("msg")) and
      nameForm.body.len >= 2:
    var segments: seq[string]
    for segment in nameForm.body:
      if segment.kind == vkSymbol:
        segments.add segment.symVal
      elif segment.kind == vkNode and segment.head.isSymbol("path"):
        # `ns/Proto:name` puts the namespace path in the qualifier slot.
        for part in segment.body:
          if part.kind != vkSymbol:
            raise newException(GeneError,
              "message requires a name and parameter vector")
          segments.add part.symVal
      else:
        raise newException(GeneError,
          "message requires a name and parameter vector")
    validateMessageName(segments[^1])
    return (segments[0 ..^ 2], segments[^1])
  raise newException(GeneError, "message requires a name and parameter vector")

proc messageName(node: Value): string =
  let parts = messageNameParts(node)
  if parts.protocolPath.len > 0:
    raise newException(GeneError,
      "qualified message names are only valid in impl bodies: " &
      parts.protocolPath.join("/") & "/" & parts.name)
  parts.name

proc messageParamVector(paramList: Value): Value =
  ## `self` is implicit in a message body (design §10). Inject it as the receiver
  ## parameter unless the (legacy) vector already begins with `self`, so both
  ## `(message m [x] ...)` and `(message m [self x] ...)` bind `self` as the
  ## receiver and enable leading sends `(.m)`.
  if paramList.kind == vkList and paramList.listItems.len > 0 and
      paramList.listItems[0].isSymbol("self"):
    return paramList
  var items = @[newSym("self")]
  if paramList.kind == vkList:
    for item in paramList.listItems:
      items.add item
  newList(items)

proc literalOverride(node: Value): bool =
  if not node.props.hasKey("override"):
    return false
  let flag = node.props["override"]
  if flag.kind != vkBool:
    raise newException(GeneError, "^override requires a literal Bool")
  flag.boolVal

proc legacyImplOverride(c: var Compiler, node: Value): bool =
  result = literalOverride(node)
  if node.props.hasKey("override"):
    c.chunk.diagnostics.add CompileDiagnostic(
      message: "deprecated impl-level ^override: omitted messages now inherit " &
        "ancestor bodies automatically; remove the flag",
      loc: c.sourceLocFor(node))

proc implMessageProto(c: var Compiler, node: Value,
                      aotSelfRepr = AotRepr(),
                      typeDirect = false): ImplMessageProto =
  let savedLoc = c.currentLoc
  c.currentLoc = c.sourceLocFor(node)
  defer: c.currentLoc = savedLoc
  if not typeDirect and node.props.hasKey("override"):
    raise newException(GeneError,
      "^override belongs on the impl, not on a protocol message")
  let declaresOverride = if typeDirect: literalOverride(node) else: false
  let parts = messageNameParts(node)
  let displayName =
    if parts.protocolPath.len > 0: parts.protocolPath.join("/") & "/" & parts.name
    else: parts.name
  let errorRow = compileErrorRow(c, node, deferred = true)
  let fn = buildFunctionProto(c, displayName,
                              messageParamVector(node.body[1]),
                              node.body, 2,
                              checksErrors = errorRow.checks,
                              errorTypeCount = errorRow.count,
                              immutableSelf = true,
                              aotSelfRepr = aotSelfRepr,
                              generator = node.generatorMarker)
  if node.props.hasKey("errors") and node.props["errors"].kind == vkList:
    fn.signatureErrorExprs = node.props["errors"].listItems
  ImplMessageProto(name: parts.name,
                   declaresOverride: declaresOverride,
                   protocolPath: parts.protocolPath,
                   fn: fn)

proc protocolMessageHasDefault(node: Value): bool =
  ## A protocol message declaration ends after its parameter vector and
  ## optional return annotation. Any remaining form is its shared default body.
  var bodyStart = 2
  if bodyStart < node.body.len and node.body[bodyStart].isSymbol(":"):
    bodyStart += 2
  bodyStart < node.body.len

proc compileAlias(c: var Compiler, node: Value) =
  ## (alias Name TypeExpr): bind Name as a transparent type alias (design
  ## §7.4.1). TypeExpr is stored unevaluated and expands wherever Name appears
  ## in type position, against the use-site scope. An alias is not a nominal
  ## type and is not constructible.
  let body = node.body
  if body.len != 2 or body[0].kind != vkSymbol:
    raise newException(GeneError,
      "alias requires a name and one type expression: (alias Name TypeExpr)")
  for key in node.props.keys:
    if key != "private":
      raise newException(GeneError,
        "alias got unexpected named argument: ^" & key)
  c.parameterAliases[body[0].symVal] = body[1]
  c.emitConst(body[1])
  discard c.emit(opMakeAlias, name = body[0].symVal)
  c.emitDefineBinding(body[0].symVal, immutable = true)

proc compileType(c: var Compiler, node: Value) =
  ## (type Name : Parent ^props {...} ^body [...] ^impl [P] ^derive [P]
  ##  (message name [self] ...) ...) —
  ## field annotations and protocol references are checked at runtime. Derive
  ## requests are passed to protocol-local derive forms after the type is created.
  ## Body items after the name are type-direct messages (docs/spec/protocols.md).
  let body = node.body
  if body.len == 0 or body[0].kind != vkSymbol:
    raise newException(GeneError, "type requires a name")
  rejectUnknownTypeProps(node)
  let name = body[0].symVal
  var parentExpr = NIL
  var memberStart = 1
  if body.len > 1 and body[1].isSymbol(":"):
    if body.len < 3:
      raise newException(GeneError, "type ':' requires a parent type")
    parentExpr = body[2]
    memberStart = 3
  validateDeclarationCase("type", name)
  let repr = typeReprMarker(node, name)
  let nativeType = c.nativeTypeMarker(node, name)
  let nativeSelfRepr =
    if nativeType == nil: AotRepr()
    else: AotRepr(kind: arkNativePtr, typeName: nativeType.name,
                  nativeType: nativeType)
  var messageNodes: seq[Value]
  var implNodes: seq[Value]
  var ctorNode = NIL
  for i in memberStart ..< body.len:
    let item = body[i]
    if item.kind == vkNode and item.head.isSymbol("message"):
      messageNodes.add item
    elif item.kind == vkNode and item.head.isSymbol("impl"):
      implNodes.add item
    elif item.kind == vkNode and item.head.isSymbol("ctor"):
      if item.generatorMarker:
        raise newException(GeneError, "a constructor cannot be a generator")
      if ctorNode.kind != vkNil:
        raise newException(GeneError, "type " & name & " defines more than one ctor")
      ctorNode = item
    else:
      raise newException(GeneError,
        "type body items must be ctor, message, or impl declarations")
  # The ctor compiles first so its ^errors row sits deepest on the stack;
  # opMakeType pops it after the message error rows (design §7.1.1).
  var ctorFn: FunctionProto
  if ctorNode.kind != vkNil:
    rejectReservedEffects(ctorNode)
    if ctorNode.body.len == 0 or ctorNode.body[0].kind != vkList:
      raise newException(GeneError, "ctor requires a parameter vector")
    let errorRow = compileErrorRow(c, ctorNode, deferred = true)
    # `self` is the pre-created in-progress instance (design §7.1.1); it binds
    # like a message receiver, as an implicit leading parameter.
    var ctorParams = @[newSym("self")]
    for item in ctorNode.body[0].listItems:
      ctorParams.add item
    ctorFn = buildFunctionProto(c, name & "/ctor", newList(ctorParams),
                                ctorNode.body, 1,
                                checksErrors = errorRow.checks,
                                errorTypeCount = errorRow.count,
                                immutableSelf = true,
                                tailBody = false)
    if ctorNode.props.hasKey("errors"):
      ctorFn.signatureErrorExprs = ctorNode.props["errors"].listItems
  var messages: seq[ImplMessageProto]
  var seenMessages = initTable[string, bool]()
  # Type-direct message bodies can delegate to `(super .m)` (design §10). Store the
  # *enclosing type name* (resolved at send time to the type value, then to its
  # nominal parent), not the raw parent expression — so a message-body local that
  # happens to shadow the parent's spelling cannot redirect the delegation.
  let savedSuperType = c.superType
  c.superType = if parentExpr.kind != vkNil: newSym(name) else: NIL
  for item in messageNodes:
    rejectReservedEffects(item)
    let mp = implMessageProto(c, item, nativeSelfRepr, typeDirect = true)
    if mp.protocolPath.len > 0:
      raise newException(GeneError,
        "type-direct message names must be simple: " &
        mp.protocolPath.join("/") & "/" & mp.name)
    if seenMessages.hasKey(mp.name):
      raise newException(GeneError, "duplicate type message: " & mp.name)
    seenMessages[mp.name] = true
    messages.add mp
  # NB: `c.superType` stays set through the inline-impl loop below. An inline
  # impl's receiver *is* the enclosing type (docs/spec/protocols.md), so `super` means
  # the same thing in its message bodies as in a type-direct one; restoring
  # here left `(impl P (message m [] (super .P:m)))` unable to see the parent.
  # Inline impls (docs/spec/protocols.md): (impl P (message ...) ...) with the
  # receiver implied — the enclosing type. Each impl emits its message error
  # rows and then its protocol expression, in declaration order.
  var inlineImpls: seq[InlineImplProto]
  for item in implNodes:
    if item.body.len == 0:
      raise newException(GeneError, "inline impl requires a protocol")
    var implMessages: seq[ImplMessageProto]
    var seenImplMessages = initTable[string, bool]()
    for j in 1 ..< item.body.len:
      let msgNode = item.body[j]
      if msgNode.kind != vkNode or not msgNode.head.isSymbol("message"):
        raise newException(GeneError,
          "inline impl body items must be message declarations — no `for`, " &
          "no receiver: the enclosing type is the receiver")
      let mp = implMessageProto(c, msgNode, nativeSelfRepr)
      let key = mp.protocolPath.join("/") & "/" & mp.name
      if seenImplMessages.hasKey(key):
        raise newException(GeneError, "duplicate impl message: " & mp.name)
      seenImplMessages[key] = true
      implMessages.add mp
    compileExpr(c, item.body[0])
    inlineImpls.add InlineImplProto(messages: implMessages,
                                    protocolExpr: item.body[0],
                                    inheritBodies: legacyImplOverride(c, item),
                                    loc: c.sourceLocFor(item))
  c.superType = savedSuperType
  var fields: seq[TypeField]
  if node.props.hasKey("props"):
    let schema = node.props["props"]
    if schema.kind != vkMap:
      raise newException(GeneError, "type ^props must be a map")
    for key, _ in schema.mapEntries:
      discard rejectOptionalSuffix(key, "type field",
        "write `^" & (if key.len > 1: key[0 .. ^2] else: key) &
        " T?` — a nil-admitting type marks the field optional")
      # A field whose type explicitly admits nil (T?, (? T), (| ... Nil))
      # may be omitted at construction; absent reads as void. `Any` stays
      # required — gradual slack is not an optionality marker.
      fields.add TypeField(name: key,
                           optional: typeExprAdmitsNil(schema.mapEntries[key]),
                           typeExpr: schema.mapEntries[key])
  var bodyFields: seq[TypeBodyField]
  if node.props.hasKey("body"):
    bodyFields = parseTypeBodySchema(node.props["body"])
  var requiredImplCount = 0
  if node.props.hasKey("impl"):
    let required = node.props["impl"]
    if required.kind != vkList:
      raise newException(GeneError, "type ^impl must be a list")
    for protocolExpr in required.listItems:
      # List items keep glued slash paths as symbols (p/A); desugar like
      # ordinary evaluated list items so namespace-qualified protocols work.
      compileEvaluatedListItem(c, protocolExpr)
      inc requiredImplCount
  var deriveProtocolCount = 0
  var deriveRequests: seq[Value]
  if node.props.hasKey("derive"):
    let derived = node.props["derive"]
    if derived.kind != vkList:
      raise newException(GeneError, "type ^derive must be a list")
    for request in derived.listItems:
      let protocolExpr = deriveProtocolExpr(request)
      if protocolExpr.kind == vkNil or protocolExpr.kind == vkVoid:
        raise newException(GeneError, "type ^derive entries must name protocols")
      compileEvaluatedListItem(c, protocolExpr)
      deriveRequests.add request
      inc deriveProtocolCount
  if parentExpr.kind != vkNil:
    compileExpr(c, parentExpr)               # parent type value
  else:
    c.emitConst NIL
  discard c.emit(opMakeType,
                 c.chunk.addType(TypeProto(name: name,
                                           staticTopLevel:
                                             node.bits in c.staticTopLevelImpls,
                                           repr: repr,
                                           nativeType: nativeType,
                                           fields: fields,
                                           bodyFields: bodyFields,
                                           requiredImplCount: requiredImplCount,
                                           deriveProtocolCount: deriveProtocolCount,
                                           deriveRequests: deriveRequests,
                                           messages: messages,
                                           inlineImpls: inlineImpls,
                                           ctorFn: ctorFn)))
  c.emitDefineBinding(name, immutable = true)

proc compileEnum(c: var Compiler, node: Value) =
  let body = node.body
  if body.len == 0 or body[0].kind != vkSymbol:
    raise newException(GeneError, "enum requires a name")
  for key, _ in node.props:
    if key != "backing":
      raise newException(GeneError, "unknown enum prop: ^" & key)
  let name = body[0].symVal
  validateDeclarationCase("enum", name)
  var typeParams: seq[string]
  var start = 1
  if start < body.len and body[start].kind == vkList:
    for item in body[start].listItems:
      if item.kind != vkSymbol:
        raise newException(GeneError, "enum type parameters must be symbols")
      typeParams.add item.symVal
    inc start

  var variantNodes: seq[Value]
  var messageNodes: seq[Value]
  var implNodes: seq[Value]
  for i in start ..< body.len:
    let item = body[i]
    if item.kind == vkNode and item.head.isSymbol("message"):
      messageNodes.add item
    elif item.kind == vkNode and item.head.isSymbol("impl"):
      implNodes.add item
    else:
      variantNodes.add item

  var messages: seq[ImplMessageProto]
  var seenMessages = initTable[string, bool]()
  const reservedReflection = ["variants", "names", "name", "ordinal",
                              "from_name", "from_ordinal", "backing",
                              "from_backing"]
  for item in messageNodes:
    rejectReservedEffects(item)
    let mp = implMessageProto(c, item, typeDirect = true)
    if mp.protocolPath.len > 0:
      raise newException(GeneError,
        "enum type-direct message names must be simple: " &
        mp.protocolPath.join("/") & "/" & mp.name)
    if mp.name in reservedReflection:
      raise newException(GeneError,
        "enum message name is reserved for reflection: " & mp.name)
    if seenMessages.hasKey(mp.name):
      raise newException(GeneError, "duplicate enum message: " & mp.name)
    seenMessages[mp.name] = true
    messages.add mp

  var inlineImpls: seq[InlineImplProto]
  for item in implNodes:
    if item.body.len == 0:
      raise newException(GeneError, "inline impl requires a protocol")
    var implMessages: seq[ImplMessageProto]
    var seenImplMessages = initTable[string, bool]()
    for j in 1 ..< item.body.len:
      let msgNode = item.body[j]
      if msgNode.kind != vkNode or not msgNode.head.isSymbol("message"):
        raise newException(GeneError,
          "inline impl body items must be message declarations — no `for`, " &
          "no receiver: the enclosing enum is the receiver")
      let mp = implMessageProto(c, msgNode)
      let key = mp.protocolPath.join("/") & "/" & mp.name
      if seenImplMessages.hasKey(key):
        raise newException(GeneError, "duplicate impl message: " & mp.name)
      seenImplMessages[key] = true
      implMessages.add mp
    compileExpr(c, item.body[0])
    inlineImpls.add InlineImplProto(messages: implMessages,
                                    protocolExpr: item.body[0],
                                    inheritBodies: legacyImplOverride(c, item),
                                    loc: c.sourceLocFor(item))

  let hasBacking = node.props.hasKey("backing")
  let backingType = if hasBacking: node.props["backing"] else: NIL
  var variants: seq[EnumVariantProto]
  var seenVariants = initTable[string, bool]()
  for item in variantNodes:
    var variantName: string
    var payloadTypes: seq[Value]
    var backing = NIL
    var variantHasBacking = false
    case item.kind
    of vkSymbol:
      variantName = item.symVal
      if hasBacking:
        raise newException(GeneError,
          "enum variant '" & variantName & "' requires a backing value")
    of vkNode:
      if item.head.kind != vkSymbol:
        raise newException(GeneError, "enum variant name must be a symbol")
      if item.props.len != 0 or item.meta.len != 0:
        raise newException(GeneError, "enum variant declarations do not accept props or meta")
      variantName = item.head.symVal
      if hasBacking:
        if item.body.len != 1:
          raise newException(GeneError,
            "backed enum variant '" & variantName & "' requires one backing value")
        backing = item.body[0]
        variantHasBacking = true
      else:
        payloadTypes = item.body
    else:
      raise newException(GeneError, "enum variants must be symbols or tuple forms")
    if seenVariants.hasKey(variantName):
      raise newException(GeneError, "duplicate enum variant: " & variantName)
    seenVariants[variantName] = true
    variants.add EnumVariantProto(name: variantName,
                                  payloadTypes: payloadTypes,
                                  hasBacking: variantHasBacking,
                                  backing: backing)
  if variants.len == 0:
    raise newException(GeneError, "enum requires at least one variant")

  discard c.emit(opMakeEnum,
                 c.chunk.addEnum(EnumProto(name: name,
                                           staticTopLevel:
                                             node.bits in c.staticTopLevelImpls,
                                           typeParams: typeParams,
                                           backingType: backingType,
                                           variants: variants,
                                           messages: messages,
                                           inlineImpls: inlineImpls)))
  c.emitDefineBinding(name, immutable = true)

proc collectWebModuleLocs(c: Compiler, value: Value,
                          into: var seq[tuple[bits: uint64, loc: SourceLoc]],
                          seen: var HashSet[uint64]) =
  ## Copy out the positions of every container inside the block. The synthetic
  ## unit the runtime builds gets exactly these, so a diagnostic, a source-map
  ## entry, and a conformance report all name the line the author wrote —
  ## which printing the tree back to text and re-reading it would destroy.
  if value.kind notin {vkNode, vkList, vkMap, vkSet, vkHashMap}:
    return
  if value.bits notin seen:
    seen.incl value.bits
    if c.sourceLocs != nil and c.sourceLocs[].hasKey(value.bits):
      into.add (value.bits, c.sourceLocs[][value.bits])
  case value.kind
  of vkPipeline:
    c.collectWebModuleLocs(value.pipelineInitial, into, seen)
    for stage in value.pipelineStages:
      c.collectWebModuleLocs(stage.head, into, seen)
      for _, item in stage.meta: c.collectWebModuleLocs(item, into, seen)
      for _, item in stage.props: c.collectWebModuleLocs(item, into, seen)
      for item in stage.body: c.collectWebModuleLocs(item, into, seen)
  of vkNode:
    c.collectWebModuleLocs(value.head, into, seen)
    for _, item in value.meta: c.collectWebModuleLocs(item, into, seen)
    for _, item in value.props: c.collectWebModuleLocs(item, into, seen)
    for item in value.body: c.collectWebModuleLocs(item, into, seen)
  of vkList:
    for item in value.listItems: c.collectWebModuleLocs(item, into, seen)
  of vkMap:
    for _, item in value.mapEntries: c.collectWebModuleLocs(item, into, seen)
  of vkSet:
    for item in value.setItems: c.collectWebModuleLocs(item, into, seen)
  of vkHashMap:
    for entry in value.hashMapEntries:
      c.collectWebModuleLocs(entry.key, into, seen)
      c.collectWebModuleLocs(entry.val, into, seen)
  else: discard

proc offsetOfPosition(source: string, line, col: int): int =
  ## Byte offset of a 1-based (line, col). Only embedded web blocks ask for
  ## this, so scanning beats keeping a line index on every compile.
  if line <= 0: return 0
  var currentLine = 1
  var i = 0
  while currentLine < line and i < source.len:
    if source[i] == '\n': inc currentLine
    inc i
  result = min(source.len, i + max(0, col - 1))

proc redactedBlockSource(source: string, startLine, startCol,
                         limitLine, limitCol: int): string =
  ## The block's own characters, with everything before it replaced by spaces
  ## and newlines. Line *and* column stay exact, so the map needs no padding
  ## fixups — and no byte of the surrounding server module can reach a browser,
  ## by construction rather than by scrubbing after the fact.
  ##
  ## The end is the start of the next top-level form (or EOF); only whitespace
  ## and comments can sit between, so trimming those off the tail lands on the
  ## block's own last character.
  if source.len == 0 or startLine <= 0: return ""
  let start = offsetOfPosition(source, startLine, startCol)
  var stop =
    if limitLine > 0: offsetOfPosition(source, limitLine, limitCol)
    else: source.len
  if stop <= start: return ""
  while stop > start:
    # Drop trailing blank space, then any whole comment line that followed the
    # block. A comment *on* the block's last line is not line-leading and stays
    # — it is as much the author's block as the parenthesis beside it.
    while stop > start and source[stop - 1] in {' ', '\t', '\r', '\n'}:
      dec stop
    var lineStart = stop
    while lineStart > start and source[lineStart - 1] != '\n': dec lineStart
    var probe = lineStart
    while probe < stop and source[probe] in {' ', '\t'}: inc probe
    if probe < stop and source[probe] == '#':
      stop = lineStart
    else:
      break
  result = newStringOfCap(stop + 1)
  for i in 0 ..< stop:
    if i >= start: result.add source[i]
    elif source[i] == '\n': result.add '\n'
    else: result.add ' '
  result.add '\n'

proc compileWebModule(c: var Compiler, node: Value) =
  ## `(web_module name form...)` — a web-profile source unit written inside an
  ## ordinary module. The forms are captured, never compiled for this VM: they
  ## target a different backend, and the runtime turns them into an asset while
  ## the containing module loads.
  let body = node.body
  if body.len == 0 or body[0].kind != vkSymbol:
    raise newException(GeneError, "web_module requires a name")
  let name = body[0].symVal
  if name.len > 0 and name[0] in {'A'..'Z'}:
    raise newException(GeneError,
      "web_module '" & name & "' must start lowercase; uppercase names are " &
      "types and protocols (design §2.1)")
  validateBindingName(name)
  for key in node.props.keys:
    # The binding is an ordinary immutable module member — exportable and
    # importable, so two pages in different modules can place one asset — and
    # `^private` keeps it local like any other declaration.
    if key != "private":
      raise newException(GeneError,
        "web_module got unexpected named argument: " & key)
  if body.len == 1:
    raise newException(GeneError, "web_module " & name & " has an empty body")
  if node.bits notin c.staticTopLevelImpls:
    # The block is compiled once per module version while that module loads.
    # A conditional or nested one would have no such moment, and its asset
    # would have to appear and disappear under a running server.
    raise newException(GeneError,
      "web_module must be an unconditional top-level declaration")
  var forms: seq[Value]
  var formLocs: seq[SourceLoc]
  var nestedLocs: seq[tuple[bits: uint64, loc: SourceLoc]]
  var seen = initHashSet[uint64]()
  for i in 1 ..< body.len:
    forms.add body[i]
    formLocs.add c.sourceLocFor(body[i])
    c.collectWebModuleLocs(body[i], nestedLocs, seen)
  let blockLoc = c.sourceLocFor(node)
  let nextLoc =
    if c.currentFormIndex + 1 < c.formLocs.len:
      c.formLocs[c.currentFormIndex + 1]
    else: SourceLoc()
  let identity =
    (if c.sourceName.len > 0: c.sourceName else: "<unit>") & "#" & name
  discard c.emit(opWebModule,
                 c.chunk.addWebModule(WebModuleProto(
                   name: name, identity: identity, forms: forms,
                   formLocs: formLocs, nestedLocs: nestedLocs,
                   source: redactedBlockSource(c.unitSource, blockLoc.line,
                                               blockLoc.col, nextLoc.line,
                                               nextLoc.col),
                   loc: blockLoc)),
                 name = name)
  c.emitDefineBinding(name, immutable = true)

proc compileProtocol(c: var Compiler, node: Value) =
  let body = node.body
  if body.len == 0 or body[0].kind != vkSymbol:
    raise newException(GeneError, "protocol requires a name")
  let name = body[0].symVal
  validateDeclarationCase("protocol", name)
  for key in node.props.keys:
    if key notin ["inherit", "universal", "private"]:
      raise newException(GeneError,
        "protocol got unexpected named argument: " & key)
  let universal =
    if node.props.hasKey("universal"):
      if node.props["universal"].kind != vkBool:
        raise newException(GeneError, "protocol ^universal must be Bool")
      node.props["universal"].boolVal
    else:
      false
  var messages: seq[ProtocolMessageProto]
  var seen = initTable[string, bool]()
  var deriveFn: FunctionProto
  for i in 1 ..< body.len:
    if body[i].kind == vkNode and body[i].head.isSymbol("derive"):
      if deriveFn != nil:
        raise newException(GeneError, "protocol has duplicate derive form")
      if body[i].body.len == 0 or body[i].body[0].kind != vkList:
        raise newException(GeneError, "derive requires a parameter vector")
      deriveFn = buildFunctionProto(c, name & "/derive", body[i].body[0],
                                    body[i].body, 1)
      continue
    let message = messageName(body[i])
    rejectReservedEffects(body[i])
    if seen.hasKey(message):
      raise newException(GeneError, "duplicate protocol message: " & message)
    seen[message] = true
    let implProto = implMessageProto(c, body[i])
    messages.add ProtocolMessageProto(name: message, fn: implProto.fn,
                                      hasDefault: protocolMessageHasDefault(body[i]))
  var parentCount = 0
  if node.props.hasKey("inherit"):
    let parents = node.props["inherit"]
    if parents.kind != vkList:
      raise newException(GeneError, "protocol ^inherit must be a list")
    for parentExpr in parents.listItems:
      # List items keep glued slash paths as symbols (p/A); desugar like
      # ordinary evaluated list items so namespace-qualified parents work.
      compileEvaluatedListItem(c, parentExpr)
      inc parentCount
  # Message names are deliberately not bound in the enclosing scope
  # (docs/spec/protocols.md, OQ-I): messages are reached via their `Protocol:name`
  # value spelling and sends only.
  let idx = c.chunk.addProtocol(ProtocolProto(name: name,
                                              messages: messages,
                                              deriveFn: deriveFn,
                                              parentCount: parentCount,
                                              universal: universal))
  discard c.emit(opMakeProtocol, idx)
  c.emitDefineBinding(name, immutable = true)

proc isStaticBindingPath(value: Value): bool =
  if value.kind == vkSymbol:
    return true
  # A resolved type/protocol identity is the most static operand possible: it
  # never appears in user source (which only spells names), only in impl forms
  # synthesized by `^derive`/macro substitution. Accepting it lets a co-located
  # top-level derive result classify canonically (proposal §"Inline impls and
  # successful ^derive results on a top-level type are canonical") instead of
  # falling to overlay; classifyStandaloneImpl still decides canonical vs scoped
  # by the same co-location rule on the substituted value.
  if value.kind in {vkType, vkProtocol}:
    return true
  if value.kind != vkNode or not value.head.isSymbol("path") or
      value.body.len == 0:
    return false
  for segment in value.body:
    if segment.kind != vkSymbol:
      return false
  true

proc compileImpl(c: var Compiler, node: Value) =
  ## (impl Protocol for Receiver (message ...) ...) — the `for` keyword
  ## separates the protocol from the receiver type.
  let body = node.body
  if body.len < 3 or not body[1].isSymbol("for"):
    raise newException(GeneError,
      "impl requires a protocol and receiver type: " &
      "(impl Protocol for Receiver ...)")
  for key in node.props.keys:
    if key notin ["export", "override"]:
      raise newException(GeneError,
        "impl got unexpected named argument: " & key)
  var exported = false
  if node.props.hasKey("export"):
    if node.props["export"].kind != vkBool:
      raise newException(GeneError, "impl ^export must be Bool")
    exported = node.props["export"].boolVal
  let staticTopLevel = node.bits in c.staticTopLevelImpls
  let staticOperands = body[0].isStaticBindingPath and
                       body[2].isStaticBindingPath
  if staticTopLevel and not staticOperands:
    let operand =
      if not body[0].isStaticBindingPath: "protocol"
      else: "receiver"
    c.chunk.diagnostics.add CompileDiagnostic(
      message: "top-level impl has a non-static " & operand &
        " operand; it is overlay-only and is not visible to other modules",
      loc: c.currentLoc)
  compileExpr(c, body[0])
  compileExpr(c, body[2])
  var messages: seq[ImplMessageProto]
  var seen = initTable[string, bool]()
  # `(impl P for T …)` names its receiver, so `super` in a message body has the
  # same meaning it has inside `T`'s own body: delegate from `T`'s parent.
  # The name is stored, not the resolved type, so a body-local that shadows the
  # parent's spelling cannot redirect the delegation — same rule as a type body.
  let savedSuperType = c.superType
  c.superType = if body[2].kind == vkSymbol: body[2] else: NIL
  let nativeSelfRepr = c.resolvedAotRepr(body[2])
  for i in 3 ..< body.len:
    let mp = implMessageProto(c, body[i], nativeSelfRepr)
    let key = mp.protocolPath.join("/") & "/" & mp.name
    if seen.hasKey(key):
      raise newException(GeneError, "duplicate impl message: " & mp.name)
    seen[key] = true
    messages.add mp
  c.superType = savedSuperType
  let idx = c.chunk.addImpl(ImplProto(protocolExpr: body[0],
                                      receiverExpr: body[2],
                                      messages: messages,
                                      staticTopLevel: staticTopLevel,
                                      staticOperands: staticOperands,
                                      exported: exported,
                                      inheritBodies: legacyImplOverride(c, node),
                                      loc: c.sourceLocFor(node)))
  discard c.emit(opMakeImpl, idx)

proc moduleRefName(node: Value, expectedBodyLen: int): string =
  if node.props.len != 0 or node.meta.len != 0 or
      node.body.len != expectedBodyLen or node.body[0].kind != vkSymbol:
    raise newException(GeneError,
      "module reference form requires a literal name" &
      (if expectedBodyLen == 2: " and one value" else: ""))
  result = node.body[0].symVal
  if not validModuleRefName(result):
    raise newException(GeneError,
      "module reference name must be a simple snake_case symbol")

proc compileModuleRefDefinition(c: var Compiler, node: Value,
                                readerForm: bool) =
  let name = moduleRefName(node, 2)
  if c.inFunction:
    raise newException(GeneError,
      (if readerForm: "#Ref" else: "$ref") &
      " is only valid during module-level initialization")

  # The initializer runs inside an internal try/ensure. Success resolves before
  # the ensure executes (so abort is a no-op); every error/return path reaches
  # abort while the entry is still resolving. This reuses the VM's established
  # structured-unwind machinery instead of adding an ad-hoc exception guard.
  discard c.emit(opRefBegin, name = name)
  var bodyCompiler = c.childCompiler()
  compileExpr(bodyCompiler, node.body[1])
  discard bodyCompiler.emit(opRefFinish, name = name)
  discard bodyCompiler.emit(opReturn)
  var ensureCompiler = c.childCompiler()
  discard ensureCompiler.emit(opRefAbort, name = name)
  ensureCompiler.emitConst NIL
  discard ensureCompiler.emit(opReturn)
  let tp = TryProto(body: bodyCompiler.chunk,
                    ensureBody: ensureCompiler.chunk)
  discard c.emit(opTry, c.chunk.addTry(tp))

proc compileModuleRefGet(c: var Compiler, node: Value, structural: bool) =
  let name = moduleRefName(node, 1)
  # A reader spelling executed after initialization is an ordinary module-ref
  # load, not a persistent graph slot. This also keeps internal placeholders
  # out of function arguments and locals entirely.
  discard c.emit(if structural and not c.inFunction:
                   opRefGetStructural else: opRefGet,
                 name = name)

proc isMacroResult(node: Value): bool =
  node.kind == vkNode and node.head.isSymbol("do") and
    node.props.hasKey("macro_result") and
    node.props["macro_result"].kind == vkBool and
    node.props["macro_result"].boolVal

proc quasiOwnsResultBindings(value: Value, depth: int): bool =
  case value.kind
  of vkNode:
    if value.head.isSymbol("unquote"):
      if depth == 1:
        for expression in value.body:
          if ownsResultBindings(expression): return true
        return false
      for expression in value.body:
        if quasiOwnsResultBindings(expression, depth - 1): return true
      return false
    let nextDepth = if value.head.isSymbol("quasiquote"): depth + 1 else: depth
    if quasiOwnsResultBindings(value.head, nextDepth): return true
    for _, item in value.props:
      if quasiOwnsResultBindings(item, nextDepth): return true
    for _, item in value.meta:
      if quasiOwnsResultBindings(item, nextDepth): return true
    for item in value.body:
      if quasiOwnsResultBindings(item, nextDepth): return true
  of vkList:
    for item in value.listItems:
      if quasiOwnsResultBindings(item, depth): return true
  of vkMap:
    for _, item in value.mapEntries:
      if quasiOwnsResultBindings(item, depth): return true
  else:
    discard

proc ownsResultBindings(value: Value): bool =
  case value.kind
  of vkNode:
    if value.isMacroResult: return false # nested marked block owns its names
    if value.head.kind == vkSymbol:
      case value.head.symVal
      of "quote": return false
      of "quasiquote":
        for item in value.body:
          if quasiOwnsResultBindings(item, 1): return true
        return false
      of "let", "var", "const", "type", "protocol", "enum", "alias",
         "ns", "macro", "import", "impl", "import_impl":
        return true
      of "fn":
        return value.body.len > 1 and
          value.body[0].kind in {vkSymbol, vkNode} and
          value.body[1].kind == vkList
      of "for":
        return value.body.len > 2 and ownsResultBindings(value.body[2])
      of "match":
        return value.body.len > 0 and ownsResultBindings(value.body[0])
      of "scope", "supervisor", "spawn":
        for _, item in value.props:
          if ownsResultBindings(item): return true
        return false
      of "try":
        var recovery = false
        for item in value.body:
          if item.isSymbol("catch"): recovery = true
          elif item.isSymbol("ensure"): recovery = false
          elif not recovery and ownsResultBindings(item): return true
        return false
      of "repeat":
        return true # both spellings create a loop index/count binding
      else: discard
    if ownsResultBindings(value.head): return true
    for _, item in value.props:
      if ownsResultBindings(item): return true
    for item in value.body:
      if ownsResultBindings(item): return true
  of vkList:
    for item in value.listItems:
      if ownsResultBindings(item): return true
  of vkMap:
    for _, item in value.mapEntries:
      if ownsResultBindings(item): return true
  of vkHashMap:
    for item in value.hashMapEntries:
      if ownsResultBindings(item.key) or ownsResultBindings(item.val): return true
  of vkSet:
    for item in value.setItems:
      if ownsResultBindings(item): return true
  of vkPipeline:
    return true # pipeline lowering creates private storage for the stage input
  else: discard

proc macroResultNeedsScope*(node: Value): bool =
  if not node.isMacroResult: return false
  for form in node.body:
    if ownsResultBindings(form): return true

proc resultCanUseFrameSlots(c: Compiler, value: Value): bool =
  case value.kind
  of vkNode:
    if value.isMacroResult: return false
    if value.head.kind == vkSymbol:
      let head = value.head.symVal
      if head == "quote": return true
      if head in ["fn", "macro", "type", "protocol", "enum", "alias", "ns",
          "impl", "import", "import_impl", "env", "eval", "try", "match",
          "for", "scope", "supervisor", "spawn", "await", "yield"] or
          head.endsWith("!") or (c.hasMacros and c.macros.hasKey(head)):
        return false
      if head in ["let", "var", "const"] and
          (value.body.len != 2 or value.body[0].kind != vkSymbol):
        # Annotation checks can resolve local type values by name. Keep their
        # lexical environment real until those references have indexed plans.
        return false
    if c.importedMacroForHead(value.head).found: return false
    let path = value.head.pathSymbolSegments
    if path.len > 1 and builtinNamespaceMacros(path.toOpenArray(0, path.high - 1)).hasKey(path[^1]):
      return false
    if not c.resultCanUseFrameSlots(value.head): return false
    for _, item in value.props:
      if not c.resultCanUseFrameSlots(item): return false
    for item in value.body:
      if not c.resultCanUseFrameSlots(item): return false
  of vkList:
    for item in value.listItems:
      if not c.resultCanUseFrameSlots(item): return false
  of vkMap:
    for _, item in value.mapEntries:
      if not c.resultCanUseFrameSlots(item): return false
  of vkHashMap, vkSet, vkPipeline:
    return false
  else: discard
  true

proc compileMacroResult(c: var Compiler, node: Value, tail: bool) =
  var needsScope = false
  var inlineSlots = c.useLocalSlots
  for form in node.body:
    needsScope = needsScope or ownsResultBindings(form)
    inlineSlots = inlineSlots and c.resultCanUseFrameSlots(form)
  if not needsScope:
    compileBody(c, node.body, tail = tail)
  elif inlineSlots:
    # Lexical visibility changes, but ordinary local access stays in this
    # function's frame. Physical slot labels keep mirrored module scopes and
    # name-based reflection from publishing these block-local declarations.
    let previousLocalCount = c.localNames.len
    var inner = c
    inner.inlineBlockPrefix = BlockBindingPrefix & $c.nextGensym() & ":"
    inner.inlineBlockBindings = initHashSet[string]()
    inner.ownMacroNames = initHashSet[string]()
    inner.ownValueNames = initHashSet[string]()
    inner.staticTopLevelImpls = initHashSet[uint64]()
    let start = c.chunk.instructions.len
    compileBody(inner, node.body, tail = tail)
    c.localNames = inner.localNames
    c.sawNonVoidReturn = c.sawNonVoidReturn or inner.sawNonVoidReturn
    for i in start ..< c.chunk.instructions.len:
      let instruction = c.chunk.instructions[i]
      if instruction.op == opSetLocal and instruction.intArg < previousLocalCount:
        c.ordinaryFnNames.del(instruction.name)
        c.generatorFnNames.del(instruction.name)
        c.mutableBindingNames.incl instruction.name
  else:
    var inner = c.childCompiler()
    inner.loopDepth = c.loopDepth
    inner.enableLocalSlots()
    inner.parentSlots = c.parentFrames()
    inner.parentFunctionSigs = c.parentFunctionSigFrames()
    inner.staticTopLevelImpls = initHashSet[uint64]()
    inner.prepareStaticImports(node.body)
    inner.reserveProtocolBindingsFor(node.body)
    compileBody(inner, node.body, tail = tail)
    discard inner.emit(opReturn)
    inner.chunk.localNames = inner.localNames
    c.sawNonVoidReturn = c.sawNonVoidReturn or inner.sawNonVoidReturn
    discard c.emit(opBlockScope, c.chunk.addSubchunk(inner.chunk), tail = tail)

proc compileNode(c: var Compiler, node: Value, allowModDecl: bool,
                 tail = false) =
  let h = node.head
  if h.kind == vkSymbol and h.symVal in CoreSpecialFormNames and
      h.symVal notin ["path", "msg", "quasiquote"]:
    let name = h.symVal
    if c.hasLexicalBinding(name) or name in c.declaredNames or
        c.unitDeclares(name) or c.importedCandidates(name).len > 0:
      raise newException(GeneError,
        name & " is a special form, but a binding named " & name &
        " is in scope; a call (" & name &
        " ...) would not call it. Rename the binding or import it under an " &
        "alias such as [" & name & " : other_name]")
  if node.props.hasKey("private"):
    if h.kind != vkSymbol or h.symVal notin
        ["var", "let", "const", "fn", "macro", "type", "alias", "enum",
         "protocol", "ns", "web_module"]:
      raise newException(GeneError,
        "^private is only valid on a named declaration " &
        "(let, var, const, fn, macro, type, alias, enum, protocol, ns, " &
        "web_module)")
    if node.declarationIsPrivate:
      if node.bits notin c.staticTopLevelImpls:
        raise newException(GeneError,
          "^private declarations must be unconditional module/namespace forms")
      let name = node.declaredName
      if name.len == 0:
        raise newException(GeneError, "^private declaration requires a name")
      c.chunk.exportExcludedNames.add name
  if h.isPath(["ffi", "library"]):
    compileFfiLibrary(c, node)
    return
  if h.isPath(["ffi", "fn"]):
    compileFfiFn(c, node)
    return
  if h.isPath(["ffi", "struct"]):
    compileFfiStruct(c, node)
    return
  if h.isPath(["ffi", "union"]):
    compileFfiUnion(c, node)
    return
  if h.isPath(["ffi", "callback"]):
    compileFfiSignature(c, node, fskCallback)
    return
  if h.isPath(["ffi", "signature"]):
    compileFfiSignature(c, node, fskDynamic)
    return
  if h.isPath(["gene", "ref"]):
    compileModuleRefDefinition(c, node, readerForm = false)
    return
  if h.isPath(["gene", "deref"]):
    compileModuleRefGet(c, node, structural = false)
    return
  if h.kind == vkSymbol:
    case h.symVal
    of "#Ref":
      compileModuleRefDefinition(c, node, readerForm = true)
      return
    of "#Deref":
      compileModuleRefGet(c, node, structural = true)
      return
    of "do":
      if node.isMacroResult:
        compileMacroResult(c, node, tail)
      else:
        compileBody(c, node.body, tail = tail)
      return
    of "if":
      compileIf(c, node, tail = tail)
      return
    of "if_yes":
      compileIfThen(c, node, tail = tail)
      return
    of "if_not":
      compileIfNot(c, node, tail = tail)
      return
    of "&&":
      compileShortCircuit(c, node, opJumpIfFalseOrPop, TRUE, tail = tail)
      return
    of "||":
      compileShortCircuit(c, node, opJumpIfTrueOrPop, NIL, tail = tail)
      return
    of "??":
      # Absence-coalescing: yield the first present (non-nil, non-void)
      # operand, else the last. Short-circuits like ||, but tests absence
      # rather than falsiness, so a stored `false`/`0`/`""` is kept.
      compileShortCircuit(c, node, opJumpIfPresentOrPop, NIL, tail = tail)
      return
    of "!":
      compileNot(c, node)
      return
    of "var":
      compileVar(c, node)
      return
    of "let":
      compileVar(c, node, immutable = true)
      return
    of "const":
      compileConst(c, node)
      return
    of "set":
      compileSet(c, node)
      return
    of "set!":
      raise newException(GeneError,
        "set! was removed; use set for both lexical and path assignment")
    of "new":
      compileNew(c, node)
      return
    of "~":
      compileLeadingSelfCall(c, node, tail = tail)
      return
    of "?~":
      compileLeadingSelfCall(c, node, optional = true, tail = tail)
      return
    of "fn":
      if node.body.len > 0 and node.body[0].kind == vkSymbol and
          node.body[0].symVal.endsWith("!"):
        compileFexpr(c, node)
      else:
        compileFn(c, node)
      return
    of "fn!":
      raise newException(GeneError,
        "fn! was removed; define a named fexpr with fn: (fn name! [syntax...] body...)")
    of "macro":
      compileMacro(c, node)
      return
    of "quote":
      c.emitConst(if node.body.len >= 1: node.body[0] else: NIL)
      return
    of "quasiquote":
      compileQuasiquote(c, node)
      return
    of "Path":
      compileSelector(c, node)
      return
    of "select":
      if not c.hasLexicalBinding("select") and
          not c.unitDeclares("select") and
          (not c.hasMacros or not c.macros.hasKey("select")) and
          c.importedCandidates("select").len == 0:
        raise newException(GeneError,
          "select was removed; use Path with quoted property names, " &
          "for example (Path \"name\")")
    of "path":
      compilePath(c, node)
      return
    of "msg":
      compileMessageValue(c, node)
      return
    of "ns":
      compileNs(c, node)
      return
    of "env":
      compileEnv(c, node)
      return
    of "eval":
      compileEval(c, node)
      return
    of "import":
      compileImport(c, node)
      return
    of "mod":
      compileMod(c, node, allowModDecl)
      return
    of "match":
      compileMatch(c, node, tail = tail)
      return
    of "while":
      compileWhile(c, node)
      return
    of "loop":
      compileLoop(c, node)
      return
    of "repeat":
      compileRepeat(c, node)
      return
    of "for":
      compileFor(c, node)
      return
    of "break":
      compileBreak(c, node)
      return
    of "continue":
      compileContinue(c, node)
      return
    of "yield":
      compileYield(c, node)
      return
    of "return":
      compileReturn(c, node)
      return
    of "try":
      compileTry(c, node)
      return
    of "scope":
      compileTaskScope(c, node)
      return
    of "supervisor":
      compileSupervisor(c, node)
      return
    of "spawn":
      compileSpawn(c, node)
      return
    of "await":
      compileAwait(c, node)
      return
    of "fail":
      compileFail(c, node)
      return
    of "panic":
      compilePanic(c, node)
      return
    of "type":
      compileType(c, node)
      return
    of "alias":
      compileAlias(c, node)
      return
    of "enum":
      compileEnum(c, node)
      return
    of "web_module":
      compileWebModule(c, node)
      return
    of "protocol":
      compileProtocol(c, node)
      return
    of "impl":
      compileImpl(c, node)
      return
    of "import_impl":
      compileImportImpl(c, node)
      return
    of "derive":
      raise newException(GeneError,
        "derive is only valid inside a protocol declaration")
    else:
      if c.hasMacros and c.macros.hasKey(h.symVal):
        compileMacroCall(c, node, c.macros[h.symVal], tail = tail)
        return
  let importedMacro = c.importedMacroForHead(h)
  if importedMacro.found:
    compileMacroCall(c, node, importedMacro.def, tail = tail)
    return
  let builtinPath = h.pathSymbolSegments
  if builtinPath.len > 1:
    let definitions = builtinNamespaceMacros(
      builtinPath.toOpenArray(0, builtinPath.high - 1))
    let name = builtinPath[^1]
    if definitions.hasKey(name):
      compileMacroCall(c, node, definitions[name], tail = tail)
      return
  compileCall(c, node, tail = tail)

proc pipelineMacroForHead(c: Compiler, head: Value): tuple[
    found: bool, def: MacroDef] =
  if head.kind == vkSymbol and c.hasMacros and c.macros.hasKey(head.symVal):
    return (true, c.macros[head.symVal])
  let imported = c.importedMacroForHead(head)
  if imported.found:
    return imported
  let path = head.pathSymbolSegments
  if path.len > 1:
    let definitions = builtinNamespaceMacros(
      path.toOpenArray(0, path.high - 1))
    if definitions.hasKey(path[^1]):
      return (true, definitions[path[^1]])

proc expandDirectPipelineMacro(c: var Compiler, value: Value): Value =
  if value.kind != vkNode:
    return value
  let macroDef = c.pipelineMacroForHead(value.head)
  if not macroDef.found:
    return value
  if macroDef.def.runtime:
    return value
  if c.macroExpansionDepth >= MaxMacroExpansionDepth:
    raise newException(GeneError, "macro expansion depth exceeded")
  inc c.macroExpansionDepth
  try:
    let expanded = c.expandDirectPipelineMacro(c.expandMacro(macroDef.def, value))
    result = if expanded.isSymbol("_"): expanded else: markMacroResult(expanded)
  finally:
    dec c.macroExpansionDepth

proc rejectPipelineSyntaxStage(c: Compiler, stage: PipelineStage) =
  if stage.slot.kind == pskHead:
    return

  var rejected = false
  let builtinPath = stage.head.pathSymbolSegments
  var name =
    if builtinPath.len > 0: builtinPath.join("/")
    else: "computed stage head"
  if stage.head.kind == vkSymbol:
    name = stage.head.symVal
    rejected = name in CoreSpecialFormNames or name.endsWith("!") or
      (c.hasMacros and c.macros.hasKey(name))

  let imported = c.importedHeadCandidates(stage.head)
  if imported.len > 1:
    raise importedNameError(name, imported)
  if imported.len == 1 and
      imported[0].category in {cbcMacro, cbcSyntaxFn}:
    rejected = true

  if builtinPath.len > 1:
    let definitions = builtinNamespaceMacros(
      builtinPath.toOpenArray(0, builtinPath.high - 1))
    if definitions.hasKey(builtinPath[^1]):
      rejected = true

  if rejected:
    raise newException(GeneError,
      "pipeline stages must be eager calls or dot sends; syntax head '" &
      name & "' has no pipeline evaluation contract")

proc expandDirectPipelineStage(c: var Compiler,
                               stage: PipelineStage): PipelineStage =
  result = stage
  result.head = c.expandDirectPipelineMacro(stage.head)
  result.props = initPropTable()
  for key, value in stage.props:
    result.props[key] = c.expandDirectPipelineMacro(value)
  result.body = @[]
  for value in stage.body:
    result.body.add c.expandDirectPipelineMacro(value)
  let detected = detectPipelineSlot(result.head, result.props, result.body)
  if detected.count > 1:
    raise newException(GeneError,
      "macro expansion produced more than one direct '_' pipeline slot")
  result.slot = detected.slot

proc rejectLeadingPipelineSend(stage: PipelineStage) =
  if stage.slot.kind != pskHead and stage.head.kind == vkSymbol and
      stage.head.symVal.isDotMessageDescriptor:
    raise newException(GeneError,
      "leading '" & stage.head.symVal & "' in a pipeline stage has no " &
      "receiver; use a head slot: (a -> _ " & stage.head.symVal & ")")

proc compilePreparedPipelineCall(c: var Compiler, stage: PipelineStage,
                                 immutable: bool) =
  ## Compile the target/dispatch using ordinary instructions. Only argument
  ## layout preparation is new: it happens now, including all symbol reads and
  ## spread expansion, rather than on each invocation of the retained callback.
  let item = newSym(PipelineItemName)
  let call = normalizeMessageHeadCall(
    materializePipelineStage(stage, item, immutable))
  let publicSite = materializePipelineStage(stage, newSym("_"), immutable)
  if call.props.hasKey("types") and call.head.kind == vkSymbol:
    let types = call.props["types"]
    if types.kind != vkList:
      raise newException(GeneError, "call ^types must be a list")
    discard c.chunk.addMonomorphization(MonomorphizationSpec(
      functionName: call.head.symVal, typeArgs: types.listItems))
  var target = call.head
  var descriptor = NIL
  var sendName = ""
  var resolveOp = opNoop
  var optional = false
  var argsStart = 0
  if call.body.len > 1 and
      (call.body[0].isSymbol("~") or call.body[0].isSymbol("?~")):
    optional = call.body[0].isSymbol("?~")
    argsStart = 2
    let message = call.body[1]
    if message.kind == vkSymbol and
        not call.props.hasKey("protocol") and
        not call.props.hasKey("receiver"):
      sendName = message.symVal
      resolveOp = opResolveMessage
    else:
      let resolved = c.sendMessageExpr(call, message)
      sendName = sendCalleeName(message)
      if resolved.kind == vkNode and resolved.head.isSymbol("msg") and
          resolved.body.len == 2 and resolved.body[1].kind == vkSymbol:
        sendName = resolved.body[1].symVal
        if resolved.body[0].isSymbol("Self"):
          resolveOp = opResolveMessage
        else:
          descriptor = resolved.body[0]
          resolveOp = opQualifiedSend
      else:
        descriptor = resolved
        resolveOp = opResolveQualifiedMessage
  elif call.props.hasKey("protocol") or call.props.hasKey("receiver"):
    let resolved = c.sendMessageExpr(call, call.head)
    if call.body.len == 0:
      raise newException(GeneError,
        "direct protocol call metadata requires a receiver argument")
    target = call.body[0]
    argsStart = 1
    descriptor = resolved.body[0]
    sendName = resolved.body[1].symVal
    resolveOp = opQualifiedSend

  let isSend = resolveOp != opNoop
  if isSend:
    validateMessageName(sendName)
  let isSuper = isSend and target.isSymbol("super")
  if isSuper:
    if optional:
      raise newException(GeneError,
        "an optional dot send short-circuits an absent receiver, but super " &
        "is never absent; use (super .message)")
    if c.superType.kind == vkNil:
      raise newException(GeneError,
        "super is only valid in a type message body with a parent")
    if resolveOp == opResolveQualifiedMessage:
      raise newException(GeneError,
        "super delegates to a statically named message")
    target = newSym("self")
    resolveOp = if resolveOp == opQualifiedSend:
      opSuperQualifiedSend else: opSuperSend

  # The first two preparation values are always target and descriptor. A slot
  # is represented only in the plan; NIL here is never substituted into a call.
  if target.isSymbol(PipelineItemName): c.emitConst NIL
  else: compileExpr(c, target)
  if descriptor.isSymbol(PipelineItemName): c.emitConst NIL
  else: compileExpr(c, descriptor)
  var plan = PipelineCallProto(bodySlot: -1, namedSlot: -1)
  for name, value in call.props:
    if name in ["types", "protocol", "receiver"]:
      continue
    if value.isSymbol(PipelineItemName):
      plan.namedSlot = plan.namedNames.len
      c.emitConst NIL
    else:
      compileExpr(c, value)
    plan.namedNames.add name
  for index in argsStart ..< call.body.len:
    let value = call.body[index]
    if value.isSymbol(PipelineItemName):
      plan.bodySlot = plan.bodySplices.len
      c.emitConst NIL
      plan.bodySplices.add false
    else:
      var hasSplice = false
      compileSpreadValues(c, @[value], 0, forList = false,
                          plan.bodySplices, hasSplice)

  var callback = c.childCompiler()
  callback.inFunction = true
  callback.enableLocalSlots()
  let itemSlot = callback.reserveLocal(PipelineItemName)
  template loadComponent(value: Value, captureName: string) =
    if value.isSymbol(PipelineItemName):
      discard callback.emit(opLoadLocal, itemSlot, name = PipelineItemName)
    else:
      discard callback.emit(opLoadName, name = captureName)
  loadComponent(target, PipelineTargetName)
  let guard = callback.emitOptionalReceiverGuard(optional)
  if isSend:
    if resolveOp in {opQualifiedSend, opResolveQualifiedMessage,
                     opSuperQualifiedSend}:
      loadComponent(descriptor, PipelineMessageName)
    discard callback.emit(resolveOp, name = sendName)
  discard callback.emit(opLoadName, name = PipelineArgumentsName)
  discard callback.emit(opLoadLocal, itemSlot, name = PipelineItemName)
  let invoke = callback.emit(opCallPrepared, flag = isSend, tail = true)
  callback.chunk.callSites[invoke] = publicSite
  if guard >= 0:
    callback.patchJump(guard)
  discard callback.emit(opReturn)
  callback.chunk.localNames = @[PipelineItemName]
  let proto = FunctionProto(
    name: "pipeline item", sourceLoc: c.currentLoc,
    params: @[PipelineItemName], localNames: @[PipelineItemName],
    positionalSlots: @[itemSlot], positionalSlotMaySet: @[false],
    requiredPositional: 1, simpleCall: true, needsCallScope: true,
    preparedPipelineItem: true,
    poolCallScope: true, paramTypes: @[NIL], restSlot: -1,
    restType: NIL, returnType: NIL, aotExpr: NIL, chunk: callback.chunk)
  proto.chunk.owner = proto
  plan.functionIndex = c.chunk.addFunction(proto)
  let planIndex = c.chunk.pipelineCalls.len
  c.chunk.pipelineCalls.add plan
  discard c.emit(opPreparePipelineCall, planIndex)

proc hasRuntimePipelineMacro(c: Compiler, stage: PipelineStage): bool =
  proc dynamic(value: Value): bool =
    if value.kind != vkNode: return false
    let found = c.pipelineMacroForHead(value.head)
    found.found and found.def.runtime
  if dynamic(stage.head): return true
  for _, value in stage.props:
    if dynamic(value): return true
  for value in stage.body:
    if dynamic(value): return true

proc compileRuntimePipelineStage(c: var Compiler, stage: PipelineStage,
                                 immutable, tail: bool) =
  ## An ordinary helper frame builds syntax only. The following execute opcode
  ## compiles that syntax back in the original caller's control-flow context.
  var helper = c.childCompiler()
  helper.inFunction = true
  helper.enableLocalSlots()
  let inputName = "\x00gene_macro_pipeline_input"
  let inputSlot = helper.reserveLocal(inputName)
  helper.emitConst newSym("quote")
  discard helper.emit(opLoadLocal, inputSlot, name = inputName)
  discard helper.emit(opMakeNode, helper.chunk.addNodeBuild(NodeBuildProto(bodyCount: 1)))
  let context = c.runtimeExpansionContext()
  template component(value: Value) =
    block:
      let found = if value.kind == vkNode: c.pipelineMacroForHead(value.head)
                  else: (false, MacroDef(nil))
      if found[0] and found[1].runtime:
        let index = helper.chunk.runtimeMacroCalls.len
        helper.chunk.runtimeMacroCalls.add RuntimeMacroCall(definition: found[1],
          syntax: value, context: context)
        discard helper.emit(opInvokeRuntimeMacro, index)
        discard helper.emit(opExecuteRuntimeMacro, index, flag = true)
      else:
        helper.emitConst value
  component(stage.head)
  var metaNames, propNames: seq[string]
  for name, value in stage.meta:
    metaNames.add name
    helper.emitConst value
  for name, value in stage.props:
    propNames.add name
    component(value)
  for value in stage.body: component(value)
  helper.chunk.pipelineBuilds.add PipelineBuildProto(immutable: immutable,
    stages: @[PipelineStageBuildProto(kind: stage.kind, metaNames: metaNames,
      propNames: propNames, bodyCount: stage.body.len, sourceLoc: stage.sourceLoc)])
  discard helper.emit(opMakePipeline, 0)
  discard helper.emit(opReturn)
  helper.chunk.localNames = helper.localNames
  let proto = FunctionProto(name: "macro pipeline", params: @[inputName],
    localNames: helper.localNames, positionalSlots: @[inputSlot],
    positionalSlotMaySet: @[false], requiredPositional: 1, simpleCall: true,
    needsCallScope: true, isMacroBody: true, callScopeNeedsSlotNames: true,
    paramTypes: @[NIL], restSlot: -1, chunk: helper.chunk)
  proto.chunk.owner = proto
  discard c.emit(opRuntimePipelineStage, c.chunk.addFunction(proto))
  let index = c.chunk.runtimeMacroCalls.len
  c.chunk.runtimeMacroCalls.add RuntimeMacroCall(context: context, pipeline: true)
  discard c.emit(opExecuteRuntimeMacro, index, tail = tail)
  c.ordinaryFnNames.clear()
  c.generatorFnNames.clear()

proc compilePipeline(c: var Compiler, pipeline: Value, tail: bool) =
  if pipeline.pipelineStages.len == 0:
    compileExpr(c, pipeline.pipelineInitial, tail = tail)
    return
  let tempName = "\x00gene_pipeline_" & $c.nextGensym()
  let tempSlot =
    if c.useLocalSlots: c.reserveLocal(tempName)
    else: -1

  proc defineTemp(c: var Compiler) =
    if tempSlot >= 0:
      discard c.emit(opRedefineLocal, tempSlot, name = tempName)
    else:
      discard c.emit(opRedefineName, name = tempName)

  proc setTemp(c: var Compiler) =
    if tempSlot >= 0:
      discard c.emit(opSetLocal, tempSlot, name = tempName)
    else:
      discard c.emit(opSetName, name = tempName)

  compileExpr(c, pipeline.pipelineInitial)
  c.defineTemp()
  discard c.emit(opPop)
  let tempExpr = newSym(tempName)
  for i, sourceStage in pipeline.pipelineStages:
    let savedLoc = c.currentLoc
    if sourceStage.sourceLoc.hasSourceLoc:
      c.currentLoc = sourceStage.sourceLoc
    c.rejectPipelineSyntaxStage(sourceStage)
    sourceStage.rejectLeadingPipelineSend()
    var stage = c.expandDirectPipelineStage(sourceStage)
    c.rejectPipelineSyntaxStage(stage)
    stage.rejectLeadingPipelineSend()
    if c.hasRuntimePipelineMacro(stage):
      compileExpr(c, tempExpr)
      c.compileRuntimePipelineStage(stage, pipeline.pipelineImmutable,
        tail and i == pipeline.pipelineStages.high)
      c.currentLoc = savedLoc
      if i < pipeline.pipelineStages.high:
        c.setTemp()
        discard c.emit(opPop)
      continue
    var expr, publicSite: Value
    case stage.kind
    of pstCall:
      expr = materializePipelineStage(stage, tempExpr,
                                      pipeline.pipelineImmutable)
      publicSite = materializePipelineStage(stage, newSym("_"),
                                            pipeline.pipelineImmutable)
    of pstIterate:
      compileExpr(c, tempExpr)
      c.compilePreparedPipelineCall(stage, pipeline.pipelineImmutable)
      discard c.emit(opMakePipelineStream)
      c.currentLoc = savedLoc
      if i < pipeline.pipelineStages.high:
        c.setTemp()
        discard c.emit(opPop)
      continue
    let firstInstruction = c.chunk.instructions.len
    compileExpr(c, expr, tail = tail and i == pipeline.pipelineStages.high)
    for instruction, site in c.chunk.callSites.mpairs:
      if instruction >= firstInstruction and site.bits == expr.bits:
        site = publicSite
    c.currentLoc = savedLoc
    if i < pipeline.pipelineStages.high:
      c.setTemp()
      discard c.emit(opPop)
  if not c.inFunction:
    # Module, namespace, and REPL scopes survive after evaluation. The result
    # remains on the operand stack; overwrite only the inaccessible scratch
    # binding so it cannot retain the last stage input for the application.
    c.emitConst NIL
    c.setTemp()
    discard c.emit(opPop)

proc compileExpr(c: var Compiler, node: Value, allowModDecl = false,
                 tail = false) =
  consumeCompileStep(c.budget)
  let savedLoc = c.currentLoc
  let exprLoc = c.sourceLocFor(node)
  if exprLoc.hasSourceLoc:
    c.currentLoc = exprLoc
  defer:
    let failure = getCurrentException()
    if failure != nil and failure of GeneError:
      let error = cast[ref GeneError](failure)
      if not error.loc.hasSourceLoc:
        error.loc = c.currentLoc
    c.currentLoc = savedLoc
  case node.kind
  of vkSymbol:
    if node.symVal.isDotMessageDescriptor:
      raise newException(GeneError,
        "a dot message descriptor requires a receiver; write (x " &
          node.symVal & ") or use it as (.message) for lexical self")
    c.emitLoadBinding(node.symVal)
  of vkNode:
    compileNode(c, node, allowModDecl, tail = tail)
  of vkPipeline:
    compilePipeline(c, node, tail)
  of vkList:
    compileListValue(c, node)
  of vkMap:
    var keys: seq[string]
    for k, value in node.mapEntries:
      keys.add k
      compileExpr(c, value)
    discard c.emit(opMakeMap, keys.len, names = keys, flag = node.mapImmutable)
  of vkHashMap:
    compileHashMapValue(c, node)
  else:
    c.emitConst node

proc collectMutableBindingNames(value: Value,
                                names: var HashSet[string]) =
  ## Conservatively collect mutation targets across nested closures before any
  ## call site is lowered. Quoted/generated syntax may produce false positives,
  ## which only disables an optimization; missing a later captured mutation
  ## could leave a direct-call opcode targeting a binding whose value changed.
  case value.kind
  of vkPipeline:
    collectMutableBindingNames(value.pipelineInitial, names)
    for stage in value.pipelineStages:
      collectMutableBindingNames(stage.head, names)
      for _, item in stage.props:
        collectMutableBindingNames(item, names)
      for item in stage.body:
        collectMutableBindingNames(item, names)
      for _, item in stage.meta:
        collectMutableBindingNames(item, names)
  of vkNode:
    if value.head.isSymbol("set") and value.body.len > 0 and
        value.body[0].kind == vkSymbol:
      names.incl value.body[0].symVal
    collectMutableBindingNames(value.head, names)
    for _, item in value.props:
      collectMutableBindingNames(item, names)
    for item in value.body:
      collectMutableBindingNames(item, names)
    for _, item in value.meta:
      collectMutableBindingNames(item, names)
  of vkList:
    for item in value.listItems:
      collectMutableBindingNames(item, names)
  of vkMap:
    for _, item in value.mapEntries:
      collectMutableBindingNames(item, names)
  of vkHashMap:
    for entry in value.hashMapEntries:
      collectMutableBindingNames(entry.key, names)
      collectMutableBindingNames(entry.val, names)
  else:
    discard

proc topLevelFormInfo(form: Value, loc: SourceLoc): TopLevelFormInfo =
  result.loc = loc
  case form.kind
  of vkSymbol:
    result.label = form.symVal
  of vkNode:
    result.nodeLike = true
    if form.head.kind == vkSymbol:
      result.label = form.head.symVal
    else:
      result.label = "expression"
  of vkPipeline:
    result.nodeLike = true
    result.label = "pipeline"
  of vkList: result.label = "[…]"
  of vkMap: result.label = "{…}"
  of vkHashMap: result.label = "{{…}}"
  else: result.label = $form.kind

proc collectModuleRefNames(value: Value, names: var seq[string],
                           seen: var HashSet[string], inFunction = false) =
  ## Predeclare source-unit references before the first initializer executes.
  ## Runtime $deref is intentionally not a declaration; #Deref is, because it
  ## is the structural forward-use form.
  case value.kind
  of vkPipeline:
    collectModuleRefNames(value.pipelineInitial, names, seen, inFunction)
    for stage in value.pipelineStages:
      collectModuleRefNames(stage.head, names, seen, inFunction)
      for _, item in stage.props:
        collectModuleRefNames(item, names, seen, inFunction)
      for item in stage.body:
        collectModuleRefNames(item, names, seen, inFunction)
      for _, item in stage.meta:
        collectModuleRefNames(item, names, seen, inFunction)
  of vkNode:
    if value.head.isSymbol("quote") or value.head.isSymbol("quasiquote"):
      return
    let declares = not inFunction and
      (value.head.isSymbol("#Ref") or value.head.isSymbol("#Deref") or
       value.head.isPath(["gene", "ref"]))
    if declares and value.body.len > 0 and value.body[0].kind == vkSymbol:
      let name = value.body[0].symVal
      if validModuleRefName(name) and not seen.containsOrIncl(name):
        names.add name
    let childInFunction = inFunction or value.head.isSymbol("fn")
    collectModuleRefNames(value.head, names, seen, inFunction)
    for _, item in value.props:
      collectModuleRefNames(item, names, seen, childInFunction)
    for item in value.body:
      collectModuleRefNames(item, names, seen, childInFunction)
    for _, item in value.meta:
      collectModuleRefNames(item, names, seen, childInFunction)
  of vkList:
    for item in value.listItems:
      collectModuleRefNames(item, names, seen, inFunction)
  of vkMap:
    for _, item in value.mapEntries:
      collectModuleRefNames(item, names, seen, inFunction)
  of vkHashMap:
    for entry in value.hashMapEntries:
      collectModuleRefNames(entry.key, names, seen, inFunction)
      collectModuleRefNames(entry.val, names, seen, inFunction)
  else:
    discard

# Closure capture planning (vm-reliability.md, VM-2). A closure created inside
# function, loop, match, or catch activations copies the values it reads when
# they are bound once and never rebound, and links the copy to the first
# static scope (module, program, namespace). It then holds none of those
# activation scopes, so storing it in one of their bindings closes no cycle.
# The plan is computed from finished bytecode, where every outer reference is
# visible; anything it cannot account for leaves the closure holding its
# defining scope as before.

type
  CaptureLevel = object
    activation: bool
    unsafe: bool              # the scope may be reached by name or owns work
    slotNames: seq[string]
    byName: HashSet[string]   # bound by name here (try/ensure bodies)
    loopSlots: HashSet[int]   # defined inside a loop that reuses this scope

  CaptureRefs = object
    slots: seq[tuple[level, slot: int]]
    sets: seq[tuple[level, slot: int]]
    names: HashSet[string]
    setNames: HashSet[string]

const
  captureUnsafeOps = {opDefineRuntimeMacro, opInvokeRuntimeMacro, opExecuteRuntimeMacro, opRuntimePipelineStage,
                     opMakeEnv, opEval, opImport, opImportImpl, opMakeType,
                      opMakeEnum, opMakeProtocol, opMakeImpl, opDeclareType,
                      opTaskScope, opSupervisor}
  captureDepthOps = {opLoadOuterLocal, opCallParentLocal0, opCallOuterLocal0,
                     opCallParentLocal1, opCallOuterLocal1}
  captureNameOps = {opLoadName, opLoadStdlibPath, opCallName0, opCallName1, opCallNameN,
                    opSetName, opDefineName}

iterator nestedChunks(chunk: Chunk): tuple[body: Chunk, scoped: bool] =
  ## Every chunk nested directly in `chunk`, and whether it runs in a scope of
  ## its own (a try or ensure body shares the enclosing one).
  for body in chunk.subchunks: yield (body, true)
  for loop in chunk.forLoops: yield (loop.body, true)
  for match in chunk.matches:
    for clause in match.clauses: yield (clause.body, true)
    if match.elseBody != nil: yield (match.elseBody, true)
  for attempt in chunk.tries:
    yield (attempt.body, false)
    for clause in attempt.catches: yield (clause.body, true)
    if attempt.ensureBody != nil: yield (attempt.ensureBody, false)
  for proto in chunk.functions:
    yield (proto.chunk, true)
    for param in proto.paramDefaults:
      if param.optional and param.defaultChunk != nil:
        yield (param.defaultChunk, true)
    for param in proto.namedParams:
      if param.defaultValue.optional and param.defaultValue.defaultChunk != nil:
        yield (param.defaultValue.defaultChunk, true)

proc collectSymbolNames(v: Value, names: var HashSet[string]) =
  case v.kind
  of vkSymbol: names.incl v.symVal
  of vkList:
    for item in v.listItems: collectSymbolNames(item, names)
  of vkNode:
    collectSymbolNames(v.head, names)
    for _, item in v.props: collectSymbolNames(item, names)
    for item in v.body: collectSymbolNames(item, names)
  of vkMap:
    for _, item in v.mapEntries: collectSymbolNames(item, names)
  else: discard

proc collectAnnotationNames(proto: FunctionProto, names: var HashSet[string]) =
  ## Type annotations are resolved by name in the call scope's chain.
  for expr in proto.paramTypes: collectSymbolNames(expr, names)
  collectSymbolNames(proto.restType, names)
  collectSymbolNames(proto.returnType, names)
  for expr in proto.signatureErrorExprs: collectSymbolNames(expr, names)
  for param in proto.namedParams: collectSymbolNames(param.typeExpr, names)

proc collectCaptureRefs(chunk: Chunk, localDepth: int, refs: var CaptureRefs) =
  ## Outer references of a closure body, as levels of its defining scope chain
  ## (level 1 is the scope it is created in). Quoted syntax counts by name: an
  ## fexpr argument or quoted code evaluates in the caller's scope.
  if chunk == nil:
    return
  for inst in chunk.instructions:
    if inst.op in captureDepthOps:
      if inst.depth > localDepth:
        refs.slots.add (inst.depth - localDepth, inst.intArg)
    elif inst.op == opSetOuterLocal:
      if inst.depth > localDepth:
        refs.sets.add (inst.depth - localDepth, inst.intArg)
    elif inst.op in captureNameOps:
      refs.names.incl inst.name
      if inst.op == opSetName:
        refs.setNames.incl inst.name
  for constant in chunk.constants:
    collectSymbolNames(constant, refs.names)
  for proto in chunk.functions:
    collectAnnotationNames(proto, refs.names)
  for (body, scoped) in nestedChunks(chunk):
    collectCaptureRefs(body, localDepth + (if scoped: 1 else: 0), refs)

proc chunkReachesScopesByName(chunk: Chunk,
                              memo: var Table[pointer, bool]): bool =
  ## Whether a chunk tree may reify, eval in, declare types or impls in, or
  ## own tasks through the scopes above it. Copied captures cannot follow that.
  if chunk == nil:
    return false
  let key = cast[pointer](chunk)
  if memo.hasKey(key):
    return memo[key]
  memo[key] = false
  var found = false
  for inst in chunk.instructions:
    if inst.op in captureUnsafeOps or
        (inst.op in captureNameOps and
         inst.name in ["eval", "env", "caller_env"]):
      found = true
      break
  if not found:
    for (body, scoped) in nestedChunks(chunk):
      if chunkReachesScopesByName(body, memo):
        found = true
        break
  memo[key] = found
  found

proc collectByNameBindings(chunk: Chunk, names: var HashSet[string]) =
  ## Names a scope binds by name: its own chunk and the try and ensure bodies
  ## that share it.
  if chunk == nil:
    return
  for inst in chunk.instructions:
    if inst.op == opDefineName:
      names.incl inst.name
  for attempt in chunk.tries:
    collectByNameBindings(attempt.body, names)
    collectByNameBindings(attempt.ensureBody, names)

proc collectRebindNames(chunk: Chunk, names: var HashSet[string]) =
  ## Every name any assignment in the unit targets, after macro expansion.
  if chunk == nil:
    return
  for inst in chunk.instructions:
    if inst.op == opInvokeRuntimeMacro:
      let context = chunk.runtimeMacroCalls[inst.intArg].context.macros
      if context != nil:
        for name in context.hiddenNames: names.incl name
    if inst.name.len > 0 and ($inst.op).startsWith("opSet"):
      names.incl inst.name
  for (body, scoped) in nestedChunks(chunk):
    collectRebindNames(body, names)

proc captureLevelFor(chunk: Chunk, activation, forceUnsafe: bool,
                     memo: var Table[pointer, bool]): CaptureLevel =
  result.activation = activation
  result.unsafe = forceUnsafe or chunkReachesScopesByName(chunk, memo)
  result.slotNames = chunk.localNames
  collectByNameBindings(chunk, result.byName)
  # A backward jump marks a loop that runs again in this same scope; a slot
  # defined inside it is rebound on every pass.
  for index, inst in chunk.instructions:
    if ($inst.op).startsWith("opJump") and inst.intArg < index:
      for i in inst.intArg .. index:
        let target = chunk.instructions[i]
        if ($target.op).contains("DefineLocal"):
          result.loopSlots.incl target.intArg

proc planCapture(proto: FunctionProto, levels: seq[CaptureLevel],
                 rebound: HashSet[string]): CapturePlan =
  if proto.isSyntaxFn or proto.isMacroBody:
    return nil
  var a = 0
  while a < levels.len and levels[a].activation:
    inc a
  if a == 0:
    return nil
  for i in 0 ..< a:
    if levels[i].unsafe:
      return nil
  var refs: CaptureRefs
  collectAnnotationNames(proto, refs.names)
  collectCaptureRefs(proto.chunk, 0, refs)
  for param in proto.paramDefaults:
    if param.optional and param.defaultChunk != nil:
      collectCaptureRefs(param.defaultChunk, 0, refs)
  for param in proto.namedParams:
    if param.defaultValue.optional and param.defaultValue.defaultChunk != nil:
      collectCaptureRefs(param.defaultValue.defaultChunk, 0, refs)
  var captured = newSeq[HashSet[int]](a)
  var keepDepth = false
  for (level, slot) in refs.sets:
    if level <= a:
      return nil
    keepDepth = true
  for (level, slot) in refs.slots:
    if level <= a:
      captured[level - 1].incl slot
    else:
      keepDepth = true
  var byName = false
  for name in refs.names:
    for i in 0 ..< a:
      if name in levels[i].byName:
        return nil
      let index = levels[i].slotNames.find(name)
      if index >= 0:
        if name in refs.setNames:
          return nil
        captured[i].incl index
        byName = true
  var mirrorLevels = 0
  for i in 0 ..< a:
    for slot in captured[i]:
      if slot >= levels[i].slotNames.len or slot in levels[i].loopSlots or
          levels[i].slotNames[slot] in rebound:
        return nil
    if captured[i].len > 0:
      mirrorLevels = i + 1
  result = CapturePlan(activationLevels: a, mirrorLevels: mirrorLevels,
                       keepDepth: keepDepth)
  for i in 0 ..< mirrorLevels:
    var slots: seq[int]
    for slot in captured[i]:
      slots.add slot
    slots.sort()
    var names: seq[string]
    for slot in slots:
      names.add levels[i].slotNames[slot]
    result.slots.add slots
    result.names.add names
    var slotNames: seq[string]
    if byName and slots.len > 0:
      slotNames.setLen(slots[^1] + 1)
      for k, slot in slots:
        slotNames[slot] = names[k]
    result.slotNames.add slotNames

proc closuresCopyCaptures(proto: FunctionProto): bool =
  ## Whether no closure `proto` makes is expected to hold its call scope: each
  ## has a plan the VM can apply, the scope binds nothing by name, and every
  ## call-scope slot a plan copies is bound before the closure is made. Only a
  ## runtime fallback (holdCallScope) then keeps a pooled scope from recycling.
  if proto.isSyntaxFn:
    return false
  let chunk = proto.chunk
  var bound = initHashSet[int]()
  for slot in proto.positionalSlots:
    bound.incl slot
  for slot in proto.namedSlots:
    bound.incl slot
  bound.incl proto.restSlot
  for inst in chunk.instructions:
    case inst.op
    of opDefineName, opRedefineName:
      return false
    of opDefineLocal, opRedefineLocal:
      bound.incl inst.intArg
    of opMakeFn:
      let plan = chunk.functions[inst.intArg].capturePlan
      if plan == nil or plan.activationLevels > MaxCaptureLevels:
        return false
      if plan.mirrorLevels > 0:
        for slot in plan.slots[0]:
          if slot notin bound:
            return false
    else:
      discard
  true

proc planClosureCaptures(root: Chunk, rebound: HashSet[string],
                         poolCandidates: seq[FunctionProto]) =
  var memo = initTable[pointer, bool]()
  # The candidates list holds each proto, so no other can share its address.
  var candidates = initHashSet[pointer]()
  for proto in poolCandidates:
    candidates.incl cast[pointer](proto)
  var allRebound = rebound
  collectRebindNames(root, allRebound)
  proc walk(chunk: Chunk, levels: seq[CaptureLevel])
  proc visitScope(chunk: Chunk, activation, forceUnsafe: bool,
                  outer: seq[CaptureLevel]) =
    if chunk == nil:
      return
    walk(chunk, @[captureLevelFor(chunk, activation, forceUnsafe, memo)] & outer)
  proc walk(chunk: Chunk, levels: seq[CaptureLevel]) =
    for proto in chunk.functions:
      proto.capturePlan = planCapture(proto, levels, allRebound)
      visitScope(proto.chunk, true, false, levels)
      # Its closures are planned now; if they copy, none holds the call scope.
      if cast[pointer](proto) in candidates and proto.closuresCopyCaptures():
        proto.poolCallScope = true
    for body in chunk.subchunks:
      # Namespace bodies are static; other subchunks (task scopes,
      # supervisors, spawned bodies) own work reached through the chain.
      visitScope(body, not body.mirrorSlots, not body.mirrorSlots, levels)
    for loop in chunk.forLoops:
      visitScope(loop.body, true, false, levels)
    for match in chunk.matches:
      for clause in match.clauses:
        visitScope(clause.body, true, false, levels)
      visitScope(match.elseBody, true, false, levels)
    for attempt in chunk.tries:
      walk(attempt.body, levels)
      for clause in attempt.catches:
        visitScope(clause.body, true, false, levels)
      if attempt.ensureBody != nil:
        walk(attempt.ensureBody, levels)
  visitScope(root, false, false, @[]) # a unit root is static

proc compileFormsInto(c: var Compiler, forms: openArray[Value],
                      useLocalSlots: bool): Chunk =
  c.prepareMacroContext(forms)
  if c.closurePoolCandidates == nil:
    new(c.closurePoolCandidates)
  # A top-level-form label only adds information for a multi-form source unit.
  # Keep the overwhelmingly common one-form compile path allocation-free.
  if forms.len > 1 and c.formLocs.len > 0:
    for i, form in forms:
      if i < c.formLocs.len:
        c.chunk.topLevelForms.add topLevelFormInfo(form, c.formLocs[i])
  c.collectParameterAliases(forms)
  for form in forms:
    collectMutableBindingNames(form, c.mutableBindingNames)
  var seenModuleRefs = initHashSet[string]()
  for form in forms:
    collectModuleRefNames(form, c.chunk.moduleRefNames, seenModuleRefs)
  if c.ownCompileInterface == nil:
    c.ownCompileInterface = buildCompileInterface(forms, c.sourceName)
  if useLocalSlots:
    c.enableLocalSlots()
  c.markStaticImplForms(forms)
  c.collectOverlayImplMessages(forms)
  c.prepareStaticImports(forms)
  c.reserveProtocolBindingsFor(forms)
  if forms.len == 0:
    c.emitConst NIL
  else:
    for i in 0 ..< forms.len:
      let savedLoc = c.currentLoc
      c.currentFormIndex = i
      if i < c.formLocs.len and c.formLocs[i].hasSourceLoc:
        c.currentLoc = c.formLocs[i]
      else:
        c.currentLoc = c.sourceLocFor(forms[i])
      try:
        compileExpr(c, forms[i], allowModDecl = true)
        c.warnDiscardedPipeline(forms[i])
        if i < forms.high:
          discard c.emit(opPop)
      except GeneError as e:
        if not e.loc.hasSourceLoc:
          e.loc = c.currentLoc
        raise
      c.currentLoc = savedLoc
  discard c.emit(opReturn)
  if useLocalSlots:
    c.chunk.localNames = c.localNames
    c.chunk.mirrorSlots = true
  c.chunk.finalMacroContext = c.visibleMacroBindings()
  if not useLocalSlots and c.sourceName == "<repl>":
    c.chunk.finalMacroContext.history = c.macroContext.forms
  for name in c.letNames: c.chunk.immutableBindings.add name
  c.chunk.immutableBindings.sort()
  c.chunk.rewriteSelfRecursiveCalls()
  planClosureCaptures(c.chunk, c.mutableBindingNames, c.closurePoolCandidates[])
  if c.errorModeOverride.len > 0:
    c.chunk.errorsMode = parseErrorMode(c.errorModeOverride)
  if c.chunk.errorsMode != ecmDynamic and not c.deferErrorChecks:
    let checked = analyzeErrorEffects(c.chunk, c.importedInterfaces)
    for diagnostic in checked.diagnostics: c.chunk.diagnostics.add diagnostic
    if c.chunk.errorsMode == ecmStrict and checked.diagnostics.len > 0:
      let failure = newException(GeneError, checked.diagnostics[0].message)
      failure.loc = checked.diagnostics[0].loc
      raise failure
    c.chunk.errorChecksComplete = true
  c.chunk

proc compileForms*(forms: openArray[Value],
                   allowAmbientImports = true,
                   useLocalSlots = true): Chunk =
  var c = Compiler(chunk: newChunk(), allowAmbientImports: allowAmbientImports,
                   ffiLibraryNames: initTable[string, bool](),
                   sourceLocs:
                     sharedSourceLocs(initTable[uint64, SourceLoc]()))
  compileFormsInto(c, forms, useLocalSlots)

proc compileSourceUnit*(unit: SourceUnit,
                        allowAmbientImports = true,
                        useLocalSlots = true, errorsMode = "",
                        macros: MacroBindings = nil,
                        history: seq[Value] = @[],
                        existingValues: seq[string] = @[],
                        persistentMacros = false): Chunk =
  var c = Compiler(chunk: newChunk(unit.sourceName),
                   sourceName: unit.sourceName,
                   sourceLocs: sharedSourceLocs(unit.locs),
                   formLocs: unit.formLocs,
                   unitSource: unit.source,
                   errorModeOverride: errorsMode,
                   allowAmbientImports: allowAmbientImports,
                   ffiLibraryNames: initTable[string, bool]())
  if macros != nil:
    c.macros = macros.definitions
    c.hasMacros = c.macros.len > 0
    if persistentMacros:
      for name in macros.ownedNames: c.ownMacroNames.incl name
  for name in existingValues: c.ownValueNames.incl name
  c.prepareMacroContext(unit.forms)
  if history.len > 0:
    c.macroContext.forms = history & unit.forms
  compileFormsInto(c, unit.forms, useLocalSlots)

proc compileFormsWithMacros*(forms: openArray[Value],
    importedMacros: Table[string, Table[string, MacroDef]],
    importedSyntaxFns = initTable[string, seq[string]](),
    importedInterfaces = initTable[string, CompileNamespaceInterface](),
    budget: CompileBudget = nil, deferErrorChecks = false):
    tuple[chunk: Chunk, macroExports: Table[string, MacroDef],
          syntaxFnExports: seq[string]] =
  ## Module-loader entry point (design §11/§15): compile a source unit with the
  ## macro exports of its `^from "path"` dependencies available (keyed by the
  ## raw path string), and return this unit's own macro definitions — imported
  ## macros are usable but not re-exported. Fexpr names travel the same way so
  ## importers retain their declaration metadata; the fexpr values remain
  ## ordinary runtime bindings.
  var moduleMacroExports: ref Table[string, MacroDef]
  new(moduleMacroExports)
  moduleMacroExports[] = initTable[string, MacroDef]()
  var moduleSyntaxFnExports: ref HashSet[string]
  new(moduleSyntaxFnExports)
  moduleSyntaxFnExports[] = initHashSet[string]()
  var c = Compiler(chunk: newChunk(), allowAmbientImports: true,
                   ffiLibraryNames: initTable[string, bool](),
                   sourceLocs:
                     sharedSourceLocs(initTable[uint64, SourceLoc]()),
                   importedMacroSets: importedMacros,
                   importedSyntaxFnSets: importedSyntaxFns,
                   importedInterfaces: importedInterfaces,
                   moduleMacroExports: moduleMacroExports,
                   moduleSyntaxFnExports: moduleSyntaxFnExports,
                   budget: budget, deferErrorChecks: deferErrorChecks)
  result.chunk = compileFormsInto(c, forms, useLocalSlots = true)
  result.macroExports = moduleMacroExports[]
  for name in moduleSyntaxFnExports[]:
    result.syntaxFnExports.add name
  result.syntaxFnExports.sort()

proc compileFormsWithMacros*(unit: SourceUnit,
    importedMacros: Table[string, Table[string, MacroDef]],
    importedSyntaxFns = initTable[string, seq[string]](),
    importedInterfaces = initTable[string, CompileNamespaceInterface](),
    budget: CompileBudget = nil, deferErrorChecks = false, errorsMode = "",
    moduleIdentity = "", moduleSourcePath = ""):
    tuple[chunk: Chunk, macroExports: Table[string, MacroDef],
          syntaxFnExports: seq[string]] =
  var moduleMacroExports: ref Table[string, MacroDef]
  new(moduleMacroExports)
  moduleMacroExports[] = initTable[string, MacroDef]()
  var moduleSyntaxFnExports: ref HashSet[string]
  new(moduleSyntaxFnExports)
  moduleSyntaxFnExports[] = initHashSet[string]()
  var c = Compiler(chunk: newChunk(unit.sourceName),
                   sourceName: unit.sourceName,
                   sourceLocs: sharedSourceLocs(unit.locs),
                   formLocs: unit.formLocs,
                   unitSource: unit.source,
                   allowAmbientImports: true,
                   ffiLibraryNames: initTable[string, bool](),
                   importedMacroSets: importedMacros,
                   importedSyntaxFnSets: importedSyntaxFns,
                   importedInterfaces: importedInterfaces,
                   moduleMacroExports: moduleMacroExports,
                   moduleSyntaxFnExports: moduleSyntaxFnExports,
                   budget: budget, deferErrorChecks: deferErrorChecks,
                   errorModeOverride: errorsMode)
  c.prepareMacroContext(unit.forms)
  c.macroContext.moduleIdentity = moduleIdentity
  c.macroContext.moduleSourcePath = moduleSourcePath
  result.chunk = compileFormsInto(c, unit.forms, useLocalSlots = true)
  result.macroExports = moduleMacroExports[]
  for name in moduleSyntaxFnExports[]:
    result.syntaxFnExports.add name
  result.syntaxFnExports.sort()

proc compileForm*(form: Value): Chunk =
  let forms = @[form]
  compileForms(forms)

proc macroNamespaceBody(forms: openArray[Value], name: string): seq[Value]

proc prepareMacroCompiler(context: MacroDefinitionContext,
                          path: seq[string] = @[]): MacroCompilerPreparation =
  var c = Compiler(importedMacroSets: context.importedMacros,
    importedSyntaxFnSets: context.importedSyntaxFns,
    importedInterfaces: context.importedInterfaces)
  c.prepareStaticImports(context.forms)
  var forms = context.forms
  for namespace in path:
    forms = macroNamespaceBody(forms, namespace)
    c.prepareStaticImports(forms)
  result = MacroCompilerPreparation(context: context,
    compileInterface: buildCompileInterface(context.forms, context.sourceName),
    importedEntries: move c.importedCompileEntries,
    wildcards: move c.wildcardCandidates, aliases: move c.aliasInterfaces)
  new(result.declaredNames)
  result.declaredNames[] = move c.declaredUnitNames

proc useMacroPreparation(c: var Compiler, prepared: MacroCompilerPreparation) =
  c.ownCompileInterface = prepared.compileInterface
  c.preparedUnitNames = prepared.declaredNames
  c.importedCompileEntries = prepared.importedEntries
  c.wildcardCandidates = prepared.wildcards
  c.aliasInterfaces = prepared.aliases

proc macroExecutionCompiler(context: MacroDefinitionContext,
                            definitions: Table[string, MacroDef],
                            session: MacroExecutionSession,
                            budget: CompileBudget,
                            namespacePath: seq[string] = @[]): Compiler =
  result = Compiler(chunk: newChunk(), allowAmbientImports: true,
    ffiLibraryNames: initTable[string, bool](),
    sourceLocs: sharedSourceLocs(initTable[uint64, SourceLoc]()),
    macros: definitions, hasMacros: definitions.len > 0,
    macroContext: context, macroSession: session, macroPhaseCompilation: true,
    budget: budget)
  if context != nil:
    result.sourceName = context.sourceName
    result.chunk.sourceName = context.sourceName
    result.sourceLocs = sharedSourceLocs(context.locs)
    result.importedMacroSets = context.importedMacros
    result.importedSyntaxFnSets = context.importedSyntaxFns
    result.importedInterfaces = context.importedInterfaces
    let state = session.macroCompilerState()
    let key = (cast[pointer](context), namespacePath)
    if not state.preparations.hasKey(key):
      state.preparations[key] = prepareMacroCompiler(context, namespacePath)
    result.useMacroPreparation(state.preparations[key])

proc macroNamespaceBody(forms: openArray[Value], name: string): seq[Value] =
  for form in forms:
    if form.kind != vkNode: continue
    if form.head.isSymbol("ns") and form.body.len > 0 and
        form.body[0].isSymbol(name):
      return form.body[1 .. ^1]
    if form.head.isSymbol("do") or form.head.isSymbol("mod"):
      result = macroNamespaceBody(form.body, name)
      if result.len > 0: return

proc compileMacroBody*(definition: MacroDef, names: seq[string],
                       definitions: Table[string, MacroDef],
                       session: MacroExecutionSession,
                       budget: CompileBudget = nil): Chunk =
  ## Compile an ordinary function over already matched syntax arguments.
  var c = macroExecutionCompiler(definition.context, definitions, session, budget,
    definition.namespacePath)
  c.dynamicNameLookup = session.runtimeDefinitionScope != nil
  c.currentLoc = definition.sourceLoc
  c.namespacePath = definition.namespacePath
  if definition.name.len > 0:
    c.macros[definition.name] = definition
    c.hasMacros = true
  var parameters: seq[Value]
  for name in names:
    parameters.add newSym(name)
  let function = newNode(newSym("fn"),
    body = @[newList(parameters)] & definition.body)
  compileFormsInto(c, @[function], useLocalSlots = false)

proc compileMacroPhaseForm*(context: MacroDefinitionContext, form: Value,
                           definitions: Table[string, MacroDef],
                           session: MacroExecutionSession,
                           budget: CompileBudget = nil,
                           namespacePath: seq[string] = @[],
                           ownedNames: seq[string] = @[]):
    tuple[chunk: Chunk, macros: Table[string, MacroDef]] =
  ## An on-demand module instance initializes source forms in execution order.
  ## Name-based top-level bindings let successive chunks share that instance.
  var c = macroExecutionCompiler(context, definitions, session, budget)
  c.namespacePath = namespacePath
  for name in ownedNames:
    c.ownMacroNames.incl name
  c.currentLoc = c.sourceLocFor(form)
  result.chunk = compileFormsInto(c, @[form], useLocalSlots = false)
  result.macros = result.chunk.finalMacroContext.definitions

proc compileEvalForm*(form: Value, macros: MacroBindings = nil,
                      budget: CompileBudget = nil): Chunk =
  ## Eval code receives only explicit Env bindings/imports/module context. It
  ## must not use source-level imports to acquire ambient module-loader authority.
  var c = Compiler(chunk: newChunk("<eval>"), sourceName: "<eval>",
    allowAmbientImports: false, budget: budget,
    sourceLocs: sharedSourceLocs(initTable[uint64, SourceLoc]()),
    ffiLibraryNames: initTable[string, bool]())
  if macros != nil:
    c.macros = macros.definitions
    c.hasMacros = c.macros.len > 0
  compileFormsInto(c, @[form], useLocalSlots = true)

proc runtimeExpansionCompiler(context: RuntimeExpansionContext,
                              budget: CompileBudget): Compiler =
  result = Compiler(chunk: newChunk(context.sourceLoc.sourceName),
    sourceName: context.sourceLoc.sourceName, currentLoc: context.sourceLoc,
    sourceLocs: sharedSourceLocs(initTable[uint64, SourceLoc]()),
    ffiLibraryNames: initTable[string, bool](), dynamicNameLookup: true,
    inFunction: context.inFunction, inGenerator: context.inGenerator,
    inStatementFn: context.inStatementFn, selfAvailable: context.selfAvailable,
    loopDepth: context.loopDepth, allowYield: context.inGenerator,
    allowAmbientImports: context.allowAmbientImports,
    macroContext: context.sourceContext, namespacePath: context.namespacePath,
    budget: budget)
  if context.macros != nil:
    result.macros = context.macros.definitions
    result.hasMacros = result.macros.len > 0
  for name in context.letNames: result.letNames.incl name
  if context.sourceContext != nil:
    result.importedMacroSets = context.sourceContext.importedMacros
    result.importedSyntaxFnSets = context.sourceContext.importedSyntaxFns
    result.importedInterfaces = context.sourceContext.importedInterfaces
    var prepared: MacroCompilerPreparation
    if context.compilerPreparation != nil:
      if context.compilerPreparation.state == nil:
        context.compilerPreparation.state = prepareMacroCompiler(context.sourceContext)
      prepared = MacroCompilerPreparation(context.compilerPreparation.state)
    else:
      prepared = prepareMacroCompiler(context.sourceContext)
    result.useMacroPreparation(prepared)

proc runtimeMacroDiagnostic(call: RuntimeMacroCall): string =
  let definition = call.definition
  result = if definition == nil: "runtime macro pipeline"
           else: "macro '" & definition.name & "'"
  let loc = call.context.sourceLoc
  if loc.hasSourceLoc:
    result.add " expanded at " & loc.sourceName & ":" & $loc.line
  if definition != nil and definition.sourceLoc.hasSourceLoc:
    let source = definition.sourceLoc
    result.add " (defined at " & source.sourceName & ":" & $source.line & ")"

proc bindRuntimeMacroArguments*(call: RuntimeMacroCall, definitionScope: Scope,
                                budget: CompileBudget = nil): seq[Value] =
  var c = runtimeExpansionCompiler(call.context, budget)
  c.macroSession = MacroExecutionSession(runtimeDefinitionScope: definitionScope,
    hostContext: definitionScope.application)
  try:
    let bindings = c.matchMacroArguments(call.definition, call.syntax)
    for name in call.definition.runtimeParamNames:
      result.add bindings.getOrDefault(name, VOID)
  except GeneError as error:
    error.msg = call.runtimeMacroDiagnostic() & ": " & error.msg
    raise

proc runtimePipelineMacroResult*(value: Value, context: RuntimeExpansionContext): Value =
  if value.isSymbol("_"): return value
  # A direct macro can return another direct macro call. Leave that call for
  # the next expansion before slot classification, just like the static path.
  let c = runtimeExpansionCompiler(context, nil)
  if value.kind == vkNode and c.pipelineMacroForHead(value.head).found:
    return value
  markMacroResult(value)

proc compileRuntimeMacroResult*(value: Value, call: RuntimeMacroCall,
                               tail = false, budget: CompileBudget = nil,
                               hostContext: RootRef = nil): Chunk =
  ## No eval overlay: name-based accesses use the actual caller activation.
  ## Marked declarations allocate their own lexical scope through the usual rule.
  try:
    var c = runtimeExpansionCompiler(call.context, budget)
    c.macroSession = MacroExecutionSession(hostContext: hostContext)
    c.prepareMacroContext(@[value])
    c.chunk.runtimeMacroExpansion = true
    compileExpr(c, markMacroResult(value), tail = tail)
    discard c.emit(opReturn)
    planClosureCaptures(c.chunk, c.mutableBindingNames, @[])
    result = c.chunk
  except GeneError as error:
    error.msg = call.runtimeMacroDiagnostic() & ": " & error.msg
    raise

proc compileEvalSource*(src: string, useLocalSlots = true,
                        sourceName = "<eval>", errorsMode = "",
                        macros: MacroBindings = nil,
                        history: seq[Value] = @[],
                        existingValues: seq[string] = @[],
                        persistentMacros = false): Chunk =
  ## REPL and language-level eval receive source text but still use explicit
  ## Env authority rules. The `gene eval` CLI compiles as an in-memory module.
  compileSourceUnit(readAllWithLocs(src, sourceName),
                    allowAmbientImports = false,
                    useLocalSlots = useLocalSlots, errorsMode = errorsMode,
                    macros = macros, history = history, existingValues = existingValues,
                    persistentMacros = persistentMacros)

proc compileReplSource*(src: string, macros: MacroBindings = nil,
                        history: seq[Value] = @[],
                        existingValues: seq[string] = @[]): Chunk =
  ## A REPL is a sequence of declaration-bearing inputs, including imports.
  ## Ordinary eval retains its explicit Env import contract.
  compileSourceUnit(readAllWithLocs(src, "<repl>"),
                    allowAmbientImports = true, useLocalSlots = false,
                    macros = macros, history = history,
                    existingValues = existingValues, persistentMacros = true)

proc compileSource*(src: string, sourceName = "",
                    useLocalSlots = true, errorsMode = ""): Chunk =
  ## `useLocalSlots = false` binds by name instead of by slot index, which is
  ## what lets several independently compiled chunks accumulate in one scope:
  ## each slot layout numbers its locals from zero, so two of them in the same
  ## scope would alias. Unlike `compileEvalSource` this keeps ambient import
  ## authority, so an embedder can run successive sources that import.
  compileSourceUnit(readAllWithLocs(src, sourceName),
                    useLocalSlots = useLocalSlots, errorsMode = errorsMode)
