## Canonical value / node model for Gene (design Section 1).
##
## Values are represented as a 64-bit NaN-box (`Value.bits`):
##
##   * `bits == 0`                      -> `nil` (so a zero-initialized Value is nil)
##   * top 16 bits < 0xFFF1             -> an IEEE float64 stored directly
##   * top 16 bits in 0xFFF1..0xFFF6    -> a void/bool/small-int/char/+0.0/symbol
##                                         immediate (no allocation)
##   * top 16 bits >= 0xFFF7            -> a *managed* heap pointer (cycle-tracked
##                                         object, string, list, map, node,
##                                         function, native function, large int,
##                                         or opaque object) carried in
##                                         the low 48 bits
##
## Managed objects are manually heap-allocated and reference counted. Each starts
## with a `refCount` header; `Value`'s `=copy`/`=sink`/`=dup`/`=destroy` hooks
## drive retain/release automatically, so acyclic values free at count 0 — no
## global table, no per-read lock. (Adopted from the older Gene runtime.)
##
## Cycles: the `scope -> closure -> scope` case is broken with weak captured-scope
## edges (see `Scope`/`GeneFunction`). Direct mutable Cell/Env object cycles
## reached through a `Value` (e.g. a self-referential `cell`) are reclaimed by a
## conservative trial-deletion pass, because ORC cannot directly trace through
## NaN-boxed payload bits. Env-bound functions created in the Env's owner scope
## use the same weak-scope storage and are strengthened when the Env escapes.
## See `tests/test_rc.nim`.
##
## Values crossing a `Send` boundary, plus captured values published to spawned
## fibers, are marked shared; in threaded builds manual RC objects then use atomic
## inc/dec while thread-local objects stay on the cheap non-atomic path. Generic
## ORC objects also carry the marker. The threaded worker lane is therefore
## built and tested under `--mm:atomicArc --threads:on`, with eligible spawned
## fibers running against isolated captured-scope snapshots while unsafe
## shared-scope work stays on the cooperative root lane.

import std/[locks, monotimes, sets, strutils, sysatomics, tables, times,
            unicode]
import ./pending_exception
when defined(geneAtomicGenerationRetirementProbe):
  import ./retirement_native_gate

when not defined(geneWasm):
  import std/re as nre
  type CompiledRegex = nre.Regex
else:
  type CompiledRegex = ref object

# Manual reference counting (below) relies on ARC/ORC move semantics and runs
# =copy/=sink/=dup/=destroy over raw alloc0 objects holding GC-managed fields.
# A --mm:refc build would mismanage those fields, so fail fast instead.
when not (defined(gcOrc) or defined(gcArc) or defined(gcAtomicArc)):
  {.error: "gene/types requires --mm:orc, --mm:arc or --mm:atomicArc (see nim.cfg)".}

type
  SourceLoc* = object
    ## Nim-side source location. `line` and `col` are 1-based; zero means
    ## unknown. This intentionally stays out of `Value`.
    sourceName*: string
    line*, col*: int

  GeneErrorKind* = enum
    gekGeneral
    gekUndefinedSymbol

  GeneError* = object of CatchableError
    ## Recoverable Gene error. `errVal` carries a `fail`ed Gene value (e.g. an
    ## error node); `hasErrVal` distinguishes that from a plain internal error.
    errVal*: Value
    hasErrVal*: bool
    loc*: SourceLoc
    errorKind*: GeneErrorKind
    errorDetail*: string
  MatchError* = object of GeneError    ## pattern match / destructuring failure
  GenePanic* = object of CatchableError
    ## Unrecoverable failure (`panic`). Not caught by `try/catch`.
    errVal*: Value
    hasErrVal*: bool
  GeneCancel* = object of CatchableError
    ## Cooperative task cancellation. Not caught by ordinary Gene `try/catch`.

  ValueKind* = enum
    vkNil       ## explicit absence (`nil` : Nil)
    vkVoid      ## no-value / skip / delete (`void` : Void)
    vkBool
    vkInt       ## mathematical Int; fixnums/int64 fast paths, bigint on overflow
    vkFloat     ## Unannotated runtime float; represented as F64.
    vkString    ## immutable UTF-8 string
    vkBytes     ## immutable byte string
    vkRegex     ## immutable compiled PCRE regular expression
    vkRange     ## immutable integer range
    vkDate      ## immutable calendar date
    vkTime      ## immutable wall-clock time, optionally timezone annotated
    vkDateTime  ## immutable date + time, optionally timezone annotated
    vkTimezone  ## immutable fixed-offset or named timezone annotation
    vkDuration  ## immutable signed duration, stored as microseconds
    vkChar      ## one Unicode scalar value
    vkSymbol    ## interned simple symbol (Sym)
    vkList      ## pure body / list
    vkMap       ## pure props / PropMap (symbol-keyed)
    vkSet       ## immutable hash-stable element set
    vkHashMap   ## immutable any-key hashed map
    vkNode      ## general node (head + props + body + meta)
    vkPipeline  ## reader/compiler-only sequenced `->`/`=>` pipeline syntax
    vkFunction  ## closure: params + body + captured scope
    vkCallableView ## checked invocation view, distinct from its original target
    vkNativeFn  ## built-in function implemented in Nim
    vkNamespace ## named binding container (`ns` or module root namespace)
    vkModule    ## first-class module value with a root namespace
    vkEnv       ## first-class eval environment (design Section 11.1 MVP)
    vkCallerEnv ## borrowed fexpr caller view; valid only during the syntax call
    vkCell      ## first-class mutable reference (design Section 12.2)
    vkAtomicCell ## first-class shared mutable reference (design Section 12.3)
    vkStream    ## first-class pull stream (design Section 6)
    vkTask      ## first-class structured task handle (design Section 13)
    vkChannel   ## first-class bounded FIFO channel (design Section 13.2)
    vkActorRef  ## first-class actor reference (design Section 13.4)
    vkActorContext ## opaque actor handler context
    vkActorStep ## actor handler continuation/stop result
    vkReplyTo   ## one-shot actor request/reply capability
    vkCPtr      ## opaque C pointer / owned foreign handle
    vkCSlice    ## opaque non-owning C pointer + element count
    vkBuffer    ## Gene-owned typed contiguous storage
    vkDeviceBuffer ## opaque accelerator/device buffer handle
    vkFfiLibrary ## loaded native library handle
    vkFfiCallable ## dynamically bound foreign callable
    vkLogger    ## immutable structured diagnostic logger handle
    vkEventBus  ## application event bus (docs/stdlib.md)
    vkEventSubscription ## opaque handle returned by `Bus/subscribe` (§7.1)
    vkEventMatcher ## `event/exact T` selector value (§6.3)
    vkRecordingSink ## `event/RecordingSink` — test sink recording every event
    vkNullSink  ## `event/NullSink` — accepts and discards
    vkCompositeSink ## `event/CompositeSink` — ordered fan-out to other sinks
    vkType      ## a declared nominal type (design Section 7)
    vkProtocol  ## a declared protocol (design Section 10)
    vkProtocolMessage ## callable protocol message dispatcher
    vkEnumVariant ## enum unit value or payload constructor descriptor

  ActorFailureStrategy* = enum
    afsStop
    afsRestart
    afsEscalate

  Value* = object
    bits*: uint64

  BigIntValue = object
    sign: int8                 # -1, 0, or 1
    digits: seq[uint32]        # little-endian base-1e9 limbs

proc hasSourceLoc*(loc: SourceLoc): bool {.inline.} =
  loc.line > 0 and loc.col > 0

const
  TAG_SHIFT = 48
  PAYLOAD_MASK = 0x0000_FFFF_FFFF_FFFF'u64

  # Immediate tags (no allocation, no refcount).
  VOID_TAG      = 0xFFF1'u64
  BOOL_TAG      = 0xFFF2'u64
  INT_TAG       = 0xFFF3'u64
  CHAR_TAG      = 0xFFF4'u64
  FLOATZERO_TAG = 0xFFF5'u64
  SYMBOL_TAG    = 0xFFF6'u64

  # Managed tags (heap pointer in payload, refcounted). All >= MANAGED_MIN so the
  # lifecycle hooks can test "needs refcount" with a single shift+compare.
  MANAGED_MIN   = 0xFFF7'u64
  CYCLE_OBJECT_TAG = 0xFFF7'u64
  STRING_TAG    = 0xFFF8'u64
  LIST_TAG      = 0xFFF9'u64
  MAP_TAG       = 0xFFFA'u64
  NODE_TAG      = 0xFFFB'u64
  INT64_TAG     = 0xFFFC'u64
  FUNCTION_TAG  = 0xFFFD'u64
  NATIVE_FN_TAG = 0xFFFE'u64
  # 0xFFFF is the generic object tag: an open-ended set of heap kinds (namespace,
  # type, and future stream/cell/task/...) that carry their concrete `ObjKind` in
  # the object header. The payload is a GC-managed (ORC) ref; the lifecycle hooks
  # GC_ref/GC_unref it. The dedicated tags above stay for the hot core kinds.
  OBJECT_TAG    = 0xFFFF'u64

  # A float whose raw bits land in tag space (0xFFF1.. negative NaNs) is folded to
  # this canonical quiet NaN, which lives below tag space and stores directly.
  CANONICAL_NAN = 0x7FF8_0000_0000_0000'u64

  SMALL_INT_MIN = -(1'i64 shl 47)
  SMALL_INT_MAX = (1'i64 shl 47) - 1
  INT_SIGN_BIT  = 0x0000_8000_0000_0000'u64

  BIG_BASE = 1_000_000_000'u64
  BIG_BASE_DIGITS = 9

# ---------------------------------------------------------------------------
# Value lifecycle hooks (must precede any Value-containing type so the managed
# heap objects below pick up these hooks, not an implicitly-generated one).
# ---------------------------------------------------------------------------

type ResourceReleaseHook* = proc(id: uint64) {.nimcall, raises: [].}

var resourceReleaseHook: ResourceReleaseHook

proc installResourceReleaseHook*(hook: ResourceReleaseHook) =
  ## Installed once by the VM. Keeping the hook in the value layer lets a
  ## native resource node release its runtime record on its final refcount
  ## transition without importing the VM or exposing the id to Gene.
  resourceReleaseHook = hook

type ContinuationEdgesHook* = proc(continuation: RootRef,
                                   scopes: var seq[pointer],
                                   values: var seq[uint64]): bool {.nimcall,
                                                                     raises: [].}
  ## Appends every owning Scope ref and boxed Value a VM continuation holds, as
  ## raw pointers and bits, and returns true. Returns false when it holds state
  ## the adapter does not model; the continuation's edges then stay uncounted.

var continuationEdgesHook: ContinuationEdgesHook

proc installContinuationEdgesHook*(hook: ContinuationEdgesHook) =
  ## Installed once by the VM, which alone knows a continuation's shape. Used
  ## by released-generation retirement (VM-2) for suspended generators.
  continuationEdgesHook = hook

proc rcRetain(bits: uint64) {.raises: [].}
proc rcRelease(bits: uint64) {.raises: [].}

# rcRetain and rcRelease run for every copy and drop of a heap Value. Each is
# a short proc that settles the common case itself and hands everything else
# to its `Full` body, which repeats the tests and so stays correct alone.
#
# The split exists for one reason. Nim loads the thread's error flag on entry
# to any proc that contains a checked operation or a call it must assume can
# raise a Defect, and on macOS a thread-local load is itself a function call —
# so the old bodies paid a second call per retain and per release before doing
# any work. The short procs therefore use unchecked count arithmetic, and
# reach the full bodies through an `importc` alias, which Nim treats as unable
# to raise. That is accurate: both bodies are `raises: []`, and callers check
# the flag after these hooks exactly as they did before.
proc rcRetainFull(bits: uint64) {.raises: [], exportc: "geneRcRetainFull".}
proc rcRetainOther(bits: uint64) {.importc: "geneRcRetainFull", raises: [].}
proc rcReleaseFull(bits: uint64) {.raises: [], exportc: "geneRcReleaseFull".}
proc rcReleaseOther(bits: uint64) {.importc: "geneRcReleaseFull", raises: [].}

proc `=destroy`(v: var Value) {.inline.} =
  let old = v.bits
  v.bits = 0
  if (old shr TAG_SHIFT) >= MANAGED_MIN:
    rcRelease(old)

proc `=copy`(dest: var Value, src: Value) {.inline.} =
  if dest.bits == src.bits: return
  if (src.bits shr TAG_SHIFT) >= MANAGED_MIN: rcRetain(src.bits)
  let old = dest.bits
  dest.bits = src.bits
  if (old shr TAG_SHIFT) >= MANAGED_MIN: rcRelease(old)

proc `=sink`(dest: var Value, src: Value) {.inline.} =
  let old = dest.bits
  dest.bits = src.bits
  if (old shr TAG_SHIFT) >= MANAGED_MIN: rcRelease(old)

proc `=dup`(src: Value): Value {.inline.} =
  if (src.bits shr TAG_SHIFT) >= MANAGED_MIN: rcRetain(src.bits)
  result.bits = src.bits

proc retainedCopy*(src: Value): Value {.inline.} =
  ## Force an owned copy when sink analysis must not transfer the caller's ref.
  if (src.bits shr TAG_SHIFT) >= MANAGED_MIN:
    rcRetain(src.bits)
  result.bits = src.bits

proc ownedValueFromBits*(bits: uint64): Value {.inline.} =
  ## Materialize an owned Value from raw bits held by a non-owning side store
  ## (e.g. the dispatch inline cache). The caller must guarantee the boxed
  ## object is still alive — a retain here without a prior matching one would
  ## otherwise double-count. `result.bits` starts nil (0), so the assignment
  ## touches no hook; the retain balances the eventual `=destroy`.
  if (bits shr TAG_SHIFT) >= MANAGED_MIN:
    rcRetain(bits)
  result.bits = bits

type
  ## Props and meta are symbol-keyed ordered maps. Keys are the bare symbol
  ## text (without the leading `^`/`@`), stored as interned symbol ids —
  ## `PropMap : (Map Sym Any)` (design §1.3), so the key id space is the
  ## symbol intern table and a symbol Value's payload is directly a key id.
  ## Insertion order is preserved for deterministic printing (design §18).
  ##
  ## Representation: an insertion-ordered entry vector, linear-scanned by
  ## int32 id while small; past `propSpillThreshold` a side index handles
  ## lookup. String-keyed procs mirror the std Table API so existing call
  ## sites keep working; they intern through the shared symbol table.
  ## Note: interned key ids are never reclaimed, so keying a long-lived map
  ## by unbounded distinct strings grows the intern table — use `HashMap`
  ## ({{...}}) for arbitrary-key data (revisit with the planned arena work).
  PropEntry* = object
    keyId: int32
    val: Value

  PropTable* = object
    data: seq[PropEntry]
    # Empty until data.len exceeds propSpillThreshold; when active it maps
    # every key id to its data position. A plain value (not ref) so copied
    # tables — detached snapshots — never share index state.
    index: Table[int32, int]

  PipelineSlotKind* = enum
    pskDefault
    pskHead
    pskBody
    pskProp

  PipelineSlot* = object
    kind*: PipelineSlotKind
    index*: int
    name*: string

  PipelineStageKind* = enum
    pstCall                   ## `->`: the whole incoming value enters the call
    pstIterate                ## `=>`: each item of the incoming value enters it

  PipelineStage* = object
    kind*: PipelineStageKind
    head*: Value
    props*: PropTable
    body*: seq[Value]
    meta*: PropTable
    sourceLoc*: SourceLoc
    slot*: PipelineSlot

  # Managed heap objects. Manually allocated (alloc0 / dealloc); each begins with
  # a refCount header used by retain/release.
  GeneString = object
    refCount: int
    shared: int
    when defined(geneAtomicGenerationRetirementProbe): rawPublished: int
    s: string
    keyId: int32  # interned key id of `s` plus one, once known; 0 = not probed

  GeneInt64 = object
    refCount: int
    shared: int
    when defined(geneAtomicGenerationRetirementProbe): rawPublished: int
    i: int64

  GeneList = object
    refCount: int
    shared: int
    when defined(geneAtomicGenerationRetirementProbe): rawPublished: int
    immutable: bool
    deepFrozen: bool
    frozenGraphProofs: uint8 # predicate-specific, certified at construction
    holdsEscapedFn: bool   # holds a promoted binding function; recheck on release
    cycleWatched: bool     # returned out of a closure cycle; recheck on release
    items: seq[Value]

  GeneMap = object
    refCount: int
    shared: int
    when defined(geneAtomicGenerationRetirementProbe): rawPublished: int
    immutable: bool
    deepFrozen: bool
    frozenGraphProofs: uint8
    holdsEscapedFn: bool   # holds a promoted binding function; recheck on release
    cycleWatched: bool     # returned out of a closure cycle; recheck on release
    entries: PropTable

  HashMapEntry* = object
    key*: Value
    val*: Value

  FailureClassification* = enum
    fcOrdinaryError
    fcGeneratedTypeFailure
    fcGeneratedContractViolation

  ErrorEvidence* = ref object
    ## Runtime-owned evidence, never supplied by Gene properties or serde.
    ## It belongs to the original node: adding evidence does not wrap, copy,
    ## change equality, or change the identity of an error payload.
    classification*: FailureClassification
    protocol*: Value
    formatter*: Value
    environment*: Scope
    weakEnvironment: pointer # scope-owned error back-edge; promoted on retain
    diagnostics*: PropTable

  GeneNode = object
    refCount: int
    shared: int
    when defined(geneAtomicGenerationRetirementProbe): rawPublished: int
    immutable: bool
    ## Deep immutability, distinct from `immutable` (events.md §6.5).
    ## `immutable` says "this container's own head/props/body cannot change";
    ## `deepFrozen` says "nothing reachable from here can change". Only deep
    ## `freeze` sets it — `freeze_shallow` must not, or the O(1)
    ## already-frozen check would accept a node still holding a mutable child.
    deepFrozen: bool
    constructing: bool
    holdsEscapedFn: bool   # holds a promoted binding function; recheck on release
    cycleWatched: bool     # returned out of a closure cycle; recheck on release
    resourceId: uint64
    errorEvidence: ErrorEvidence
    head: Value
    props: PropTable
    body: seq[Value]
    meta: PropTable

  ## One implemented message inside a ProtocolImpl. `message` is the protocol
  ## message value — the qualified identity (docs/spec/protocols.md): two messages
  ## with the same simple name in different protocols are distinct entries.
  ImplMessage* = object
    message*: Value
    fn*: Value

  ImplVisibility* = enum
    ivCanonical
    ivScoped
    ivOverlay

  ProtocolSelfBinding* = object
    protocol*: Value
    selfType*: Value # NIL means abstract Self is unavailable (universal)
    originProtocol*: Value
    originReceiver*: Value

  ImplBodySource* = object
    message*: Value
    protocol*: Value
    receiver*: Value

  ProtocolImpl* = object
    protocol*: Value
    receiver*: Value
    messages*: seq[ImplMessage]
    visibility*: ImplVisibility
    exported*: bool
    originPath*: string       # defining file module; empty for program/overlay
    imported*: bool           # explicit import_impl copy in another base scope
    inheritBodies*: bool
    localMessages*: seq[ImplMessage]
    selfBindings*: seq[ProtocolSelfBinding]
    bodySources*: seq[ImplBodySource]
    assemblyScope*: Scope # retained by imports and records outside their owning scope
    weakAssemblyScope*: pointer # owning-scope storage back-reference
    managedContract*: bool

  CoreValueMethod* = enum
    cvEqual, cvHash, cvCompare, cvSize, cvAt, cvPutAt

  CoreValueWitnesses* = array[CoreValueMethod, Value]

  TypeBinding* = object
    expr*: Value
    scope*: Scope           # strong only for future escaped bindings
    weakScope*: pointer     # ordinary scope-owned binding back-reference

  ## Opaque compiled function body used by runtime function values.
  FunctionCode* = ref object of RootObj

  ## Opaque runtime owner for scopes. The VM defines the concrete Application
  ## type; the value layer keeps only this base reference.
  RuntimeContext* = ref object of RootObj
    errorFunctionCreated*: proc(value: Value, scope: Scope) {.nimcall.}
    privateCompilerContext*: bool
    compilerOwnerLane*: int

  ## Shared instruction budget for policy-limited eval scopes. Budgets can be
  ## chained so nested evals with their own policy still consume the outer budget.
  EvalBudget* = ref object
    remaining*: int64
    parent*: EvalBudget
    hasDeadline*: bool
    deadline*: MonoTime
    hasMemoryLimit*: bool
    memoryBaseline*: int64
    memoryLimitBytes*: int64
    sampleCountdown*: int

  ModuleExecutionPolicy* = ref object
    maxSteps*: int64
    maxMemoryMb*: int64
    timeoutMs*: int64

  TypeBoundaryToken* = ref object
    ## Stable identity shared by a transient scope and detached conformance
    ## snapshots. The object has identity only; `marker` prevents an empty
    ## object representation from being optimized into a singleton.
    marker: bool

  ModuleRefState* = enum
    mrsUnresolved
    mrsResolving
    mrsResolved

  ModuleRefEntry* = ref object
    ## Stable one-time resolution slot owned by a module root scope. Keeping
    ## the resolved Value here roots identity-bearing targets for the module's
    ## lifetime; scalar Values use their ordinary copy/boxing semantics.
    name*: string
    state*: ModuleRefState
    value*: Value
    structuralPending*: bool

  ModuleRefTable* = ref object
    ## Lazily allocated only for a module root that actually uses `#Ref` or
    ## `$ref`. Ordinary lexical/call scopes keep a single nil pointer instead
    ## of carrying a full Table header on every allocation.
    entries*: Table[string, ModuleRefEntry]
    pendingStructural*: int

  WildcardFallback* = object
    ## Runtime value installed by a bare wildcard import. It deliberately
    ## lives outside `vars`, so reflection and export lookup never re-export it.
    value*: Value
    source*: string
    conflicts*: seq[string]
    parentCollision*: bool

  ## Lexical environment for the VM (a Nim ORC ref, so pure scope/namespace
  ## cycles are collectable). A first-class `Env` (design Section 11.1) is a
  ## later, richer concept.
  ##
  ## Scope-owned functions are stored with a weak captured-scope edge so a
  ## `Scope -> Value(fn) -> Scope` cycle does not keep both sides alive. Function
  ## values escaping as run/eval results are cloned back to a strong capture.
  Scope* = ref object
    retirementPublished: int # permanent raw/worker publication exclusion
    application*: RuntimeContext
    strictErrorLease*: RootRef
    compilerMacros*: RootRef # immutable compiler context; never a borrowed frame
    runtimeMacroSlots*: RootRef # immutable definition-to-private-slot registry
    parent*: Scope
    vars*: Table[string, Value]
    managedBindingPins*: Table[string, seq[Scope]]
    wildcardFallbacks*: Table[string, WildcardFallback]
    exportExcludedNames*: HashSet[string]
    slots*: seq[Value]
    slotTypes*: seq[TypeBinding]
    slotDefinedBits*: uint64
    slotDefinedOverflow*: seq[bool]
    slotNames*: seq[string]
    privateSlots*: seq[int] # inline lexical locals are unavailable to name lookup
    slotMirror*: bool
    varsDirty*: bool  # mirrored slot writes pending materialization into vars
    simpleCallScope*: bool
    captureMirror*: bool    # a closure's copy of values from an activation scope
    captureTop*: bool       # the copy's parent is the first static scope
    closureHeld*: bool      # a closure holds this call scope; never pool it
    nativeTouched*: bool    # a native that is handed the scope ran with it;
                            # a loop reusing the scope then resets all of it
    typeBoundaryToken*: TypeBoundaryToken
    typeBoundarySnapshot*: bool
    annotationSelfType*: Value # lexical type context of the current method body
    varTypes*: Table[string, TypeBinding]
    impls*: seq[ProtocolImpl]
    corePendingTypes*: seq[Value] # nominal Types awaiting unit activation
    implAssembly*: RootRef # VM-owned forward declaration state, lexical for eval
    implValidationEpoch*: uint64
    implValidationActive*: bool
    implOverlayRoot*: bool  # eval-local impls register here, never application-wide
    scopedImplImports*: bool # macro-result lexical boundary, not an eval unit
    implStageRoot*: bool    # module impls remain pending until atomic activation
    forceOverlayImpls*: bool # compiler-owned derive execution for overlay types
    moduleRoot*: bool       # program/file-module base scope
    sandboxGenerationReleased*: bool # generation released or discarded; retirement root
    moduleBase*: Scope      # cached ancestor module root; roots identify self via moduleRoot
    moduleStatic*: bool     # unconditional module/namespace declaration scope
    moduleRefs*: ModuleRefTable
    borrowedCallerEnv*: bool # scope or ancestor is inside a live syntax call
    requiredImplTypes*: seq[Value]
    evalBudget*: EvalBudget
    ## Immutable policy installed by the trusted sandbox host after a
    ## declaration-only module load. A fresh budget is created whenever an
    ## external call enters this module, so escaped functions and protocol
    ## methods cannot bypass the loader's supervision boundary.
    moduleExecutionPolicy*: ModuleExecutionPolicy
    sandboxGenerationId*: uint64
    ownsTasks*: bool
    ownedTasks*: seq[Value]
    ownedCleanupTasks*: seq[Value] # physical I/O retirement; not user-cancelled
    ownsActors*: bool
    actorFailureStrategy*: ActorFailureStrategy
    supervisorEvents*: Value
    supervisorDeadLetters*: Value
    actorMaxRestarts*: int      # supervisor ^max_restarts; <= 0 unlimited
    actorRestartWindowMs*: int  # supervisor ^within_ms; <= 0 lifetime
    ownedActors*: seq[Value]
    ## Stamps of this scope's by-name view, which the VM's lookup caches
    ## compare instead of repeating a lookup (see "By-name load cache" and
    ## "Namespace member cache" in vm.nim).
    ##
    ## `namesGen` covers which names the scope binds and what its non-slot
    ## bindings hold: `vars`, `wildcardFallbacks`, `exportExcludedNames`, the
    ## slot names and which of them are private. `slotsGen` covers the slot
    ## *values* of a mirrored scope — a module or namespace body, whose slots
    ## are its exported members and reach `vars` lazily. They are separate
    ## because a top-level loop writes module slots constantly, and that must
    ## not disturb what is remembered about names the module does not bind.
    ##
    ## **Every** change to one of these must be followed by `touchNames` or
    ## `touchSlots` on the scope. A missed call is a stale read of a rebound
    ## name, not a crash. Both are zero until first touched, and no two
    ## (scope, state) pairs ever share a nonzero stamp.
    namesGen*: uint64
    slotsGen*: uint64

  ## Runtime call metadata for envelope-aware native functions. Positional
  ## arguments stay as an openArray parameter on NativeProc to keep the hot
  ## builtin path allocation-free.
  NativeCall* = object
    calleeName*: string
    namedNames*: seq[string]
    namedValues*: seq[Value]
    dispatchScope*: Scope
    site*: Value             # the source call-site node, or NIL (design §3)
    loc*: SourceLoc          # bytecode call location when available

  NativeProc* = proc(args: openArray[Value]): Value {.nimcall.}
  NativeCallProc* = proc(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.}
  NativeContextCallProc* = proc(context: RootRef,
                                args: openArray[Value],
                                call: ptr NativeCall): Value {.nimcall.}

  ## typed_native AOT boundary (docs/workflows.md).
  ##
  ## The generated C never dereferences `GeneValue`, `GeneCall`, or
  ## `GeneContext` — it only passes them to helpers — so these are their real
  ## shapes. They live here because `aot_runtime.nim` implements the helpers
  ## while the loader lives in the VM's own compilation unit.
  AotCall* = object
    args*: ptr UncheckedArray[Value]
    len*: csize_t

  FfiBufferLease* = object
    ## Marshalling storage for one `Buffer` argument, owned by the call's
    ## `AotContext`.
    ##
    ## A Buffer is not borrowed like a `C/Slice`: every element is unpacked into
    ## `bytes`, the C callee writes through that storage, and the bytes are
    ## copied back into `buffer` afterwards. The storage therefore has to
    ## outlive the argument helper that built it — a view returned by value
    ## would dangle the moment the helper returned — and the copy-back has to be
    ## an explicit step after the callee runs.
    buffer*: Value
    elementLabel*: string
    bytes*: seq[uint8]
    length*: csize_t

  AotContext* = object
    ## Helpers report failure by filling `message`; the VM turns that into an
    ## ordinary Gene error at the boundary.
    message*: string
    failed*: bool
    scope* {.cursor.}: Scope # borrowed from the live NativeCall
    error*: ref GeneError
    panicked*: bool
    buffers*: seq[FfiBufferLease]
      ## Leases live and die with the call. A failed conversion means the callee
      ## never ran, so nothing is owed a copy-back and the seq simply frees.

  AotTraceFrameC* {.bycopy.} = object
    functionName*: cstring
    sourceName*: cstring
    line*: cint
    column*: cint

  AotEntryProc* = proc(ctx: ptr AotContext, call: ptr AotCall,
                       resultOut: ptr Value): cint {.cdecl.}

  AotModuleFunctionC* = object
    ## Mirrors `GeneAotModuleFunction` in the generated C; field order and
    ## types must stay in step with `emitExperimentalC`.
    geneName*: cstring
    cSymbol*: cstring
    entrySymbol*: cstring
    repr*: cstring
    arity*: cint
    frame*: pointer

  AotNativeTypeC* = object
    ## Mirrors `GeneAotNativeType`. One row per native Type the library's
    ## compiled code depends on, transitively.
    typeIdentity*: cstring
    abiIdentity*: cstring
    abiFingerprint*: cstring
    contractFingerprint*: cstring

  AotAbiLayoutC* = object
    ## Mirrors `GeneAotAbiLayout`. `measuredSize`/`measuredAlign` are filled in
    ## by the C compiler that built the library.
    abiIdentity*: cstring
    fingerprint*: cstring
    measuredSize*: csize_t
    measuredAlign*: csize_t

  AotAbiLayoutFieldC* = object
    ## Mirrors `GeneAotAbiLayoutField`.
    abiIdentity*: cstring
    fieldName*: cstring
    measuredOffset*: csize_t

  AotTypeRequirement* = object
    ## One `gene_aot_native_types` row: what a loaded library was compiled to
    ## assume about a native Type.
    typeIdentity*: string
    abiIdentity*: string
    abiFingerprint*: string
    contractFingerprint*: string

  AotMeasuredLayout* = object
    ## One `gene_aot_abi_layouts` row plus its field offsets, as the C compiler
    ## that built the library actually laid the struct out.
    abiIdentity*: string
    fingerprint*: string
    size*: int
    align*: int
    offsets*: Table[string, int]

  AotModuleRequirements* = ref object
    ## A loaded library's full requirement set, retained so it can be
    ## re-validated after the native type registry changes.
    ##
    ## Load-time validation is only a snapshot. A native Type re-registered
    ## afterwards can keep its identity and change its ABI or its policy, and
    ## nothing presented at the boundary would reveal it — the affected Type may
    ## never cross the boundary at all. The retained set plus the epoch it was
    ## last validated at is what turns the snapshot into a standing guarantee.
    requirements*: seq[AotTypeRequirement]
    validatedEpoch*: uint64
    invalid*: bool
    invalidReason*: string

  AotFfiFnInfoC* = object
    ## Mirrors `GeneFfiFnInfo` in the generated C.
    name*: cstring
    library*: cstring
    libraryDeclared*: bool
    symbol*: cstring
    abi*: cstring
    calling*: cstring
    wrapperName*: cstring
    release*: cstring
    arity*: csize_t
    resultType*: cstring

  CPtrReleaseProc* = proc(address: pointer) {.nimcall.}
  FfiLibraryCloseProc* = proc(handle: pointer) {.nimcall.}

  NativeFastKind* = enum
    nfkNone
    nfkAdd
    nfkSub
    nfkMul
    nfkLt
    nfkGt
    nfkLe
    nfkGe
    nfkDiv
    nfkRem
    nfkEq
    nfkNe

  NativeErrorMetadata* = object
    ## Host-authored identity of a compiler-known native effect model. Metadata
    ## is installed with the implementation and immutable after construction.
    ## The compiler model supplies invocation, callback, and deferred summaries;
    ## a matching display name alone never establishes that model.
    identity*: string
    version*: string

  GeneFunction = object
    refCount: int
    shared: int
    when defined(geneAtomicGenerationRetirementProbe): rawPublished: int
    name: string
    params: seq[string]
    code: FunctionCode
    scope: Scope             # strong capture for escaping closures
    weakScope: pointer       # non-owning Scope used for scope-owned bindings
    checksErrors: bool
    syntaxFn: bool           # named fexpr / syntax callable (design §3/§11.1)
    capturesCallerEnv: bool  # closure was created under a borrowed caller view
    errorTypes: seq[Value]
    errorLease: RootRef
    identity: int            # shared by weak/strong capture clones of one closure
    weakable: bool           # a scope binding; may drop its scope edge again
    cycleWatched: bool       # returned out of a closure cycle; recheck on release

  GeneNativeFn = object
    refCount: int
    shared: int
    when defined(geneAtomicGenerationRetirementProbe): rawPublished: int
    name: string
    impl: NativeProc
    callImpl: NativeCallProc
    contextImpl: NativeContextCallProc
    context: RootRef
    acceptsNamed: bool
    fastKind: NativeFastKind
    errorMetadata: NativeErrorMetadata

  # OBJECT_TAG heap kinds. `GeneObjectData` is the GC-managed (ORC) base; each
  # concrete kind subclasses it and `kind*` dispatches on `objKind`.
  ObjKind* = enum
    okNamespace
    okModule
    okBigInt
    okBytes
    okRegex
    okRange
    okDate
    okTime
    okDateTime
    okTimezone
    okDuration
    okSet
    okHashMap
    okPipeline
    okCallableView
    okEnv
    okCell
    okAtomicCell
    okStream
    okTask
    okChannel
    okActorRef
    okActorContext
    okActorStep
    okReplyTo
    okCPtr
    okCSlice
    okBuffer
    okDeviceBuffer
    okFfiLibrary
    okFfiCallable
    okLogger
    okEventBus
    okEventSubscription
    okEventMatcher
    okRecordingSink
    okNullSink
    okCompositeSink
    okType
    okEnum
    okProtocol
    okProtocolMessage
    okBoundMessage
    okEnumVariant

  GeneObjectData* = ref object of RootObj
    objKind*: ObjKind
    shared*: int
    when defined(geneAtomicGenerationRetirementProbe): rawPublished: int

  NamespaceData = ref object of GeneObjectData
    name: string
    scope: Scope          # the namespace's own bindings (its exports)
    moduleRoot: bool      # true only for loader-created module root namespaces
    modulePath: string    # non-empty only for file-backed module roots

  ModuleData = ref object of GeneObjectData
    valueRefs: int          # boxed Value owners; release-time self-cycle audit
    runtimeId: int
    instanceKey: string
    name: string
    path: string
    root: Value
    meta: PropTable
    dependencies: seq[string]

  BigIntData = ref object of GeneObjectData
    value: BigIntValue

  BytesData = ref object of GeneObjectData
    data: string

  RegexData = ref object of GeneObjectData
    pattern: string
    flags: string
    compiled: CompiledRegex
    groupCount: int
    groupNames: Table[string, int] # capture-name -> zero-based group index

  RangeData = ref object of GeneObjectData
    start: int64
    stop: int64
    step: int64
    inclusive: bool

  DateData = ref object of GeneObjectData
    year: int16
    month: int8
    day: int8

  TimeData = ref object of GeneObjectData
    hour: int8
    minute: int8
    second: int8
    microsecond: int32
    hasOffset: bool
    offsetMinutes: int16
    timezoneName: string

  DateTimeData = ref object of GeneObjectData
    year: int16
    month: int8
    day: int8
    hour: int8
    minute: int8
    second: int8
    microsecond: int32
    hasOffset: bool
    offsetMinutes: int16
    timezoneName: string

  TimezoneData = ref object of GeneObjectData
    hasOffset: bool
    offsetMinutes: int16
    name: string

  DurationData = ref object of GeneObjectData
    microseconds: int64

  SetData = ref object of GeneObjectData
    items: seq[Value]

  HashMapData = ref object of GeneObjectData
    entries: seq[HashMapEntry]

  PipelineData = ref object of GeneObjectData
    initial: Value
    stages: seq[PipelineStage]
    immutable: bool

  EnvData = ref object of GeneObjectData
    cycleRefs: int            # Value-held refs, for trial-deletion collection
    parent: Value         # parent Env value, or NIL
    bindings: Table[string, Value]
    imports: seq[Value]
    module: Value
    ## A closed capture: evaluating in it must NOT see the scope the `eval` is
    ## written in. `caller_env .snapshot [...]` sets it, because a snapshot
    ## promises exactly the names it lists and nothing else — a window onto the
    ## live scope would defeat the point of naming them.
    closedScope: bool
    policy: Value
    compilerMacros: RootRef
    compilerMacroFunctions: seq[Value]
    borrowed: bool
    borrowedActive: bool
    borrowedScope: Scope

  CellData = ref object of GeneObjectData
    cycleRefs: int            # Value-held refs, for trial-deletion collection
    value: Value
    valueType: Value
    valueScope: Scope
    holdsEscapedFn: bool      # holds a promoted binding function; recheck on release
    cycleWatched: bool        # returned out of a closure cycle; recheck on release

  AtomicCellData = ref object of CellData
    ## Inherits CellData's layout (cycleRefs/value) so the shared cycle-
    ## tracking code below keeps working unchanged; adds the lock that makes
    ## load/store/swap/compare_exchange linearizable (design Section 12.3).
    lock: Lock

  CallableViewData = ref object of GeneObjectData
    target: Value
    signature: Value
    typeScope: Scope
    ioReadCall: bool       # internal protocol-call admission, not a checked view
    ioReadDelegate: bool   # super read can continue the current admitted read

  StreamPullResult* = object
    has*: bool
    item*: Value

  StreamPullProc* = proc(stream: Value): StreamPullResult {.nimcall.}
  StreamCloseProc* = proc(stream: Value) {.nimcall.}
  StreamFailureCheckProc* = proc(stream: Value, error: ref CatchableError) {.nimcall.}

  StreamData = ref object of GeneObjectData
    items: seq[Value]
    index: int
    closed: bool
    source: Value
    callable: Value
    remaining: int64
    pull: StreamPullProc
    close: StreamCloseProc
    checkFailure: StreamFailureCheckProc
    buffered: bool
    pulling: bool
    buffer: Value
    itemType: Value
    errType: Value
    itemScope: Scope
    generatorCode: FunctionCode
    generatorScope: Scope
    generatorStack: seq[Value]
    generatorIp: int
    generatorContinuation: RootRef

  TaskState = ref object
    lock: Lock
    when compileOption("threads") and defined(gcAtomicArc):
      cond: Cond
    done: bool
    cancelRequested: bool
    cancelled: bool
    awaited: bool
    external: bool
    result: Value
    failed: bool
    errorMsg: string
    errorValue: Value
    hasErrorValue: bool
    panicked: bool
    panicMsg: string
    panicValue: Value
    hasPanicValue: bool
    retainedScopes: seq[Scope] # managed native result provenance until Task state dies

  TaskData = ref object of GeneObjectData
    state: TaskState
    resultType: Value
    errorType: Value
    boundaryScope: Scope

  TaskPayload* = object
    value*: Value
    cancelled*: bool
    hasError*: bool
    errorMessage*: string
    errorValue*: Value
    hasErrorValue*: bool
    hasPanic*: bool
    panicMessage*: string
    panicValue*: Value
    hasPanicValue*: bool

  ChannelState = ref object
    lock: Lock
    items: seq[Value]
    scopePins: seq[seq[Scope]] # per-item managed provenance, under `lock`
    capacity: int
    closed: bool

  ChannelData = ref object of GeneObjectData
    state: ChannelState
    itemType: Value
    itemScope: Scope

  ActorMessage* = object
    message*: Value
    reply*: Value
    workerAllowed*: bool
    pins*: seq[Scope]

  ActorLifecycle = ref object
    closed: bool

  ActorData = ref object of GeneObjectData
    lock: Lock
    lifecycle: ActorLifecycle
    capacity: int
    queue: seq[ActorMessage]
    reservedMessages: int
    processing: bool
    state: Value
    managed: bool
    statePins: seq[Scope]
    handlerPins: seq[Scope]
    contractPins: seq[Scope]
    restartInit: Value
    handler: Value
    messageType: Value
    messageTypeExplicit: bool
    failureStrategy: ActorFailureStrategy
    failureEvents: Value
    failureDeadLetters: Value
    parentFailureEvents: Value
    parentFailureDeadLetters: Value
    maxRestarts: int          # restart budget; <= 0 means unlimited (§18.5)
    restartWindowMs: int      # budget window; <= 0 means lifetime budget
    restartCount: int
    restartWindowStart: MonoTime

  ActorContextData = ref object of GeneObjectData
    actor: Value

  ActorStepData = ref object of GeneObjectData
    continueActor: bool
    state: Value

  ReplyToData = ref object of GeneObjectData
    lock: Lock
    sent: bool
    result: Value
    resultType: Value
    resultScope: Scope
    task: Value
    relaxedSend: bool   # native single-producer edge; skip Send boundary
                        # validation on the reply value (net/http pool)

  CPtrData = ref object of GeneObjectData
    address: pointer
    targetType: Value
    mutable: bool
    owned: bool
    closed: bool
    activeBorrows: int     # owner-lane native calls pin disposal/transfer
    release: CPtrReleaseProc
    foreignRelease: pointer
    library: Value       # pins and borrows the release shim's FFI image

  CSliceData = ref object of GeneObjectData
    address: pointer
    length: int
    targetType: Value
    mutable: bool

  BufferStorageKind* = enum
    bskValues, bskI8, bskU8, bskI16, bskU16, bskI32, bskU32,
    bskI64, bskU64, bskF32, bskF64

  BufferData = ref object of GeneObjectData
    elemType: Value
    elemScope: Scope
    storage: BufferStorageKind
    length: int
    items: seq[Value]
    packed: seq[byte]

  DeviceBufferData = ref object of GeneObjectData
    backend: string
    elemType: Value
    length: int

  FfiLibraryData = ref object of GeneObjectData
    handle: pointer
    path: string
    closed: bool
    close: FfiLibraryCloseProc
    nativeBorrows: int

  FfiCallableData = ref object of GeneObjectData
    name: string
    symbol: string
    address: pointer
    library: Value
    paramTypes: seq[Value]
    returnType: Value
    releaseName: string
    releaseAddress: pointer

  LoggerData = ref object of GeneObjectData
    name: string
    routeId: int
    payload: Value

  EventErrorPolicy* = enum
    ## docs/stdlib.md `eepRaiseAfter` is the default: every
    ## matching handler is attempted and one `EventPublishError` carries the
    ## ordered failures afterwards. `eepCollect` always returns a
    ## `PublishResult` from `publish` and leaves the failures to the publisher.
    eepRaiseAfter
    eepCollect

  EventSubscriptionSelector* = object
    ## One alternative a subscription matches on. A plain type or
    ## `event/exact T` yields one; a union selector `(| A B)` yields one per
    ## member (events.md §6.3).
    typeId*: int32           # compact event type id the alternative names
    exact*: bool             # `event/exact T` — descendants excluded

  EventSubscriptionEntry* = object
    ## One subscription in a bus, in subscription order (events.md §7.1/§7.5).
    ##
    ## Entries are appended and never removed while the bus is open: cancel
    ## clears `active` and drops the handler reference, so the sequence index
    ## doubles as the stable subscription identity the buckets and the resolved
    ## -match cache point at.
    ##
    ## A union subscription is **one** entry listed in several buckets, not
    ## several entries. §6.3 makes overlapping subscriptions fire separately and
    ## forbids deduplication, so registering `(| A B)` as two subscriptions
    ## would invoke the handler twice for a value matching both.
    handler*: Value
    selectors*: seq[EventSubscriptionSelector]
    once*: bool              # `^^once`
    active*: bool
    consumed*: bool          # one-shot already delivered (marked before the call)

  EventMatchCacheEntry* = object
    ## The merged, subscription-ordered match list for one concrete event type,
    ## stamped with the bus generation it was built at (events.md §6.4). The
    ## cache is copy-on-write: a stale entry is *replaced* by a freshly built
    ## one, never mutated, so a publication that already read the old entry
    ## keeps running against an unchanged list.
    generation*: int64
    subs*: seq[int32]        # indices into EventBusData.subs, ascending

  EventBusData* = ref object of GeneObjectData
    ## Fields are exported for `events.nim`, which is included into the VM and
    ## is the only writer. Everything outside it goes through the accessors
    ## below.
    cycleRefs: int
    closed*: bool
    errorPolicy*: EventErrorPolicy
    nestingLimit*: int
    nestingDepth*: int
    generation*: int64
    ownerLane*: int          # the lane that created it (events.md §9.1)
    subs*: seq[EventSubscriptionEntry]
    descendantBuckets*: Table[int32, seq[int32]]
    exactBuckets*: Table[int32, seq[int32]]
    matchCache*: Table[int32, EventMatchCacheEntry]

  EventSubscriptionData* = ref object of GeneObjectData
    ## A subscription handle. The bus edge is **non-owning**: a subscription
    ## keeps its handler reachable through the bus (§7.3), and an owning edge
    ## back would make every handle retain the whole bus.
    busBits*: uint64
    index*: int32            # index into EventBusData.subs

  EventMatcherData* = ref object of GeneObjectData
    ## `event/exact T`. Opaque, immutable, and deliberately not called
    ## `Path` — that name belongs to first-class traversal values (§6.3).
    target*: Value           # the Type it names
    typeId*: int32

  EventSinkData* = ref object of GeneObjectData
    ## Backs `RecordingSink`, `NullSink`, and `CompositeSink` — one Nim shape,
    ## three `ObjKind`s, so each keeps its own nominal type identity while the
    ## storage stays in one place.
    recorded*: seq[Value]    # RecordingSink
    sinks*: seq[Value]       # CompositeSink

  TypeRepr* = enum
    ## How instances of a nominal type are represented and created.
    ##
    ## `trOrdinary` is the default: an ordinary Gene node, freely constructible
    ## as data. `trNativeWrapper` marks a type whose props hold native state
    ## (an owned C pointer and its metadata); only a `ctor` or the native
    ## `newWrapper` factory may create one, and its declared fields are
    ## initializer-only. The marker is what lets the VM tell a deliberate
    ## native wrapper from an ordinary fieldless Gene type.
    trOrdinary
    trNativeWrapper

  TypeData = ref object of GeneObjectData
    valueRefs: int        # boxed references, excluding temporary Nim views
    scopeEscaped: bool   # later reads must promote a weakened declaration scope
    name: string
    contractPending: bool
    coreWitnessesSealed: bool
    coreWitnesses: CoreValueWitnesses
    annotationRefBits: uint64 # borrowed nominal/protocol identity in owned code
    annotationContractName: string # canonical builtin spelling for signature equality
    opaqueAbiAnnotation: bool
    parent: Value         # parent Type value, or NIL
    repr: TypeRepr        # representation marker (`^repr native_wrapper`);
                          # inherited through the nominal parent at newType
    nativeIdentity: string # module-qualified `^native` identity, or "".
    nativeAbiIdentity: string
      ## The layout this Type maps to. Not derivable from `nativeIdentity`: a
      ## Type can keep its identity and be repointed at a different `^abi`.
    nativeAbiFingerprint: string
    nativeContractFingerprint: string
      ## The authoritative value an AOT library's requirements are checked
      ## against. Covers policy (`^copy`, `^release`, `^wrapper`, `^mutable`,
      ## `^lifecycle`, handle schema) as well as layout — all of which compiled
      ## code bakes in.
                          # The typed_native AOT boundary matches an incoming
                          # wrapper against the identity the compiled code was
                          # built for; comparing names instead would let one
                          # module's look-alike satisfy another's guard. Not
                          # inherited: a nominal descendant is a different
                          # nominal type and does not share a native payload
                          # contract.
    fields: seq[TypeField]
    bodyFields: seq[TypeBodyField]
    scope: Scope          # retains the declaration environment after escape
    weakScope: pointer    # defining scope for scope-owned type metadata
    requiredProtocols: seq[Value]
    derivedProtocols: seq[Value]
    deriveRequests: seq[Value]
    messages: Table[string, Value] # type-direct messages (docs/spec/protocols.md)
    ctorFn: Value         # (ctor ...) function value, or NIL (design §7.1.1)
    aliasExpr: Value      # transparent alias (`alias` form): the aliased type
                          # expression, or NIL for an ordinary nominal type. An
                          # alias is not constructible; it expands in annotation
                          # position against the use-site scope.
    nativeCtor: Value     # native constructor for a built-in surface type
                          # (`($event/Bus ^error_policy …)`), or NIL. Distinct
                          # from `ctorFn`, which is a Gene `(ctor …)` reached
                          # through `new`: this one answers `(T …)` for a type
                          # whose instances are a native value kind rather than
                          # a schema of props.
    eventTypeId: int32    # compact event type id, or 0 for a non-event type
                          # (docs/stdlib.md). Assigned eagerly at
                          # `newType`, so ID allocation is a declaration-phase
                          # property and no publish site races for a counter.
    eventMatchIds: seq[int32]
                          # this type's id followed by every event ancestor's,
                          # most-derived first. Immutable once assigned: parent
                          # is single and fixed, so the list is stable.

  EnumData = ref object of GeneObjectData
    name: string
    typeParams: seq[string]
    backingType: Value
    variants: seq[Value]
    scope: Scope
    weakScope: pointer
    messages: Table[string, Value]

  EnumVariantData = ref object of GeneObjectData
    enumBits: uint64       # non-owning; the enum owns its variant descriptors
    name: string
    ordinal: int
    payloadTypes: seq[Value]
    backing: Value
    hasBacking: bool

  TypeField* = object
    name*: string
    nameId*: int32        # interned id of `name`; normalized by newType
    optional*: bool       # nil-admitting type — may be omitted at construction
    typeExpr*: Value      # annotation syntax, or NIL for `Any`
    scope*: Scope         # strong only for future escaped-field anchoring
    weakScope*: pointer   # defining scope for scope-owned field metadata

  TypeBodyField* = object
    rest*: bool            # trailing `T...` body schema
    typeExpr*: Value       # annotation syntax, or NIL for `Any`
    scope*: Scope
    weakScope*: pointer

  ProtocolData = ref object of GeneObjectData
    valueRefs: int        # boxed owners for mixed module-scope edge auditing
    name: string
    weakScope: pointer       # defining scope; module roots outlive loaded protocols
    messages: OrderedTable[string, Value] # own messages, keyed by local name
    deriveFn: Value
    universal: bool         # explicit ^universal conformance, never inferred
    errorRoot: bool         # the runtime's Error protocol, not a same-named declaration
    parents: seq[Value]      # direct ^inherit parents (docs/spec/protocols.md)
    closure: seq[Value]      # full transitive message closure, ancestors
                             # first, deduped by message identity; same-name
                             # messages from different protocols coexist
                             # (docs/spec/protocols.md)

  ProtocolMessageData = ref object of GeneObjectData
    name: string
    protocolBits: uint64  # non-owning backreference to the owning Protocol
    signatureFn: Value    # non-callable-by-contract function carrying the shape
    hasDefault: bool      # signatureFn is also the shared default closure

  BoundMessageData = ref object of GeneObjectData
    ## What `Proto:msg` / `Self:msg` yields in value position.
    ##
    ## Deliberately *not* extra fields on `ProtocolMessageData`. Widening that
    ## type cost 11-14% on `value.small_int.construct_access` — a benchmark that
    ## only runs `newInt`/`intVal` on immediates and cannot reach any of this.
    ## Growing the `case objKind` blocks for child-traversal and teardown slowed
    ## the not-managed fast path that every `Value` destructor takes. A separate
    ## object keeps the declaration-site type byte-identical.
    name: string
    protocolBits: uint64  # non-owning; set when the qualifier is a Protocol
    qualifier: Value      # the Protocol, or NIL for `Self:`
    boundScope: Scope     # where the value was written — impls resolve there
    weakScope: pointer    # scope-owned binding back-reference

# ---------------------------------------------------------------------------
# Interning (symbols are immediate indices; prop-key strings are deduplicated)
# ---------------------------------------------------------------------------

proc releaseFfiLibraryBorrow*(v: Value)

proc finalizeOwnedCPtr(data: CPtrData) {.nimcall.} =
  ## Owned foreign pointers must retire even if their Gene wrapper is dropped
  ## without an explicit C/close. Library pinning is qualified separately.
  if data == nil or not data.owned or data.closed or data.address == nil:
    return
  var retired = true
  try:
    if data.release != nil:
      data.release(data.address)
    elif data.foreignRelease != nil:
      type ForeignReleaseProc = proc(address: pointer) {.cdecl.}
      cast[ForeignReleaseProc](data.foreignRelease)(data.address)
  except CatchableError:
    retired = false
  if retired:
    data.address = nil
    data.closed = true
    if data.library.bits != 0:
      try: releaseFfiLibraryBorrow(data.library)
      except CatchableError: discard
      data.library = Value(bits: 0)

proc allocateOwnedCPtr(): CPtrData =
  new(result, finalizeOwnedCPtr)

proc finalizeFfiLibrary(data: FfiLibraryData) {.nimcall.} =
  if data == nil or data.closed or data.handle == nil or
      data.nativeBorrows > 0:
    return
  try:
    if data.close != nil: data.close(data.handle)
    data.handle = nil
    data.closed = true
  except CatchableError:
    discard

proc allocateFfiLibrary(): FfiLibraryData =
  new(result, finalizeFfiLibrary)

var
  symbolNames: seq[string]              # symbol id -> text
  symbolIds: Table[string, int]         # text -> symbol id
  internedNames: Table[string, string]  # deduped prop-key strings
  internLock: Lock
initLock(internLock)

proc internSymbolId(v: string): int32 =
  acquire(internLock)
  try:
    var id = symbolIds.getOrDefault(v, -1)
    if id < 0:
      id = symbolNames.len
      symbolNames.add v
      symbolIds[v] = id
    result = int32(id)
  finally:
    release(internLock)

proc lookupSymbolId(v: string): int32 =
  ## Lookup-only probe: -1 when the text was never interned, so misses
  ## (hasKey on an absent key) do not grow the intern table.
  acquire(internLock)
  try:
    result = int32(symbolIds.getOrDefault(v, -1))
  finally:
    release(internLock)

# ---------------------------------------------------------------------------
# PropTable operations (symbol-id keyed, insertion-ordered)
# ---------------------------------------------------------------------------

const propSpillThreshold = 16

proc propKeyId*(key: string): int32 {.inline.} =
  ## Intern `key` and return its symbol id (also the PropTable key id).
  internSymbolId(key)

proc propKeyText*(id: int32): lent string {.inline.} =
  ## Key id back to text. Ids are append-only, matching `symVal`'s
  ## unlocked-read posture.
  symbolNames[int(id)]

proc initPropTable*(initialSize = 0): PropTable {.inline.} =
  ## Zero state is a valid empty table; kept for std-Table-style call sites.
  discard initialSize

proc len*(t: PropTable): int {.inline.} = t.data.len

proc rebuildPropIndex(t: var PropTable) =
  t.index.clear()
  for i in 0 ..< t.data.len:
    t.index[t.data[i].keyId] = i

proc findId*(t: PropTable, id: int32): int {.inline.} =
  ## Entry position for a key id, or -1.
  if t.index.len > 0:
    result = t.index.getOrDefault(id, -1)
  else:
    for i in 0 ..< t.data.len:
      if t.data[i].keyId == id: return i
    result = -1

proc hasId*(t: PropTable, id: int32): bool {.inline.} =
  t.findId(id) >= 0

proc getById*(t: PropTable, id: int32): lent Value {.inline.} =
  let i = t.findId(id)
  if i < 0:
    raise newException(KeyError, "key not found: " & propKeyText(id))
  t.data[i].val

proc getOrDefaultById*(t: PropTable, id: int32): Value {.inline.} =
  let i = t.findId(id)
  if i >= 0: t.data[i].val else: Value()

proc getOrDefaultById*(t: PropTable, id: int32, default: Value): Value {.inline.} =
  let i = t.findId(id)
  if i >= 0: t.data[i].val else: default

proc tryGetById*(t: PropTable, id: int32, val: var Value): bool {.inline.} =
  ## Presence-exact lookup (a stored nil Value is distinguishable from miss).
  let i = t.findId(id)
  if i < 0: return false
  val = t.data[i].val
  true

proc lookupPropKeyId*(key: string): int32 {.inline.} =
  ## Lookup-only key-id probe: -1 when `key` was never interned (a miss for
  ## every PropTable), without growing the intern table.
  lookupSymbolId(key)

proc putById*(t: var PropTable, id: int32, v: sink Value) =
  let i = t.findId(id)
  if i >= 0:
    t.data[i].val = v          # update in place; insertion order unchanged
  else:
    t.data.add PropEntry(keyId: id, val: v)
    if t.index.len > 0:
      t.index[id] = t.data.high
    elif t.data.len > propSpillThreshold:
      t.rebuildPropIndex()

proc reserve*(t: var PropTable, capacity: int) =
  ## Room for `capacity` entries in a still-empty table, so a builder that
  ## knows the likely size does not regrow the entry list as it fills.
  if t.data.len == 0 and capacity > 0:
    t.data = newSeqOfCap[PropEntry](capacity)

proc delById*(t: var PropTable, id: int32) =
  let i = t.findId(id)
  if i < 0: return
  t.data.delete(i)             # preserves insertion order
  if t.index.len > 0:
    if t.data.len <= propSpillThreshold div 2:
      t.index.clear()
    else:
      t.rebuildPropIndex()

# String-keyed shims mirroring the std Table API.

proc hasKey*(t: PropTable, key: string): bool =
  if t.data.len == 0: return false
  let id = lookupSymbolId(key)
  id >= 0 and t.hasId(id)

proc contains*(t: PropTable, key: string): bool {.inline.} =
  t.hasKey(key)

proc `[]`*(t: PropTable, key: string): lent Value =
  let id = lookupSymbolId(key)
  let i = if id < 0: -1 else: t.findId(id)
  if i < 0:
    raise newException(KeyError, "key not found: " & key)
  t.data[i].val

proc `[]=`*(t: var PropTable, key: string, v: sink Value) {.inline.} =
  t.putById(propKeyId(key), v)

proc getOrDefault*(t: PropTable, key: string): Value =
  if t.data.len == 0: return Value()
  let id = lookupSymbolId(key)
  if id < 0: Value() else: t.getOrDefaultById(id)

proc getOrDefault*(t: PropTable, key: string, default: Value): Value =
  if t.data.len == 0: return default
  let id = lookupSymbolId(key)
  if id < 0: return default
  let i = t.findId(id)
  if i >= 0: t.data[i].val else: default

proc del*(t: var PropTable, key: string) =
  if t.data.len == 0: return
  let id = lookupSymbolId(key)
  if id >= 0: t.delById(id)

iterator pairs*(t: PropTable): (string, Value) =
  for i in 0 ..< t.data.len:
    yield (symbolNames[int(t.data[i].keyId)], t.data[i].val)

iterator idPairs*(t: PropTable): (int32, Value) =
  for i in 0 ..< t.data.len:
    yield (t.data[i].keyId, t.data[i].val)

iterator keys*(t: PropTable): lent string =
  for i in 0 ..< t.data.len:
    yield symbolNames[int(t.data[i].keyId)]

proc propKeyAtCopy*(t: PropTable, index: int): string =
  ## Stable insertion-order key read for a published frozen table. Copy while
  ## the symbol table lock protects its backing sequence from reallocation.
  if index < 0 or index >= t.data.len:
    raise newException(IndexDefect, "property index is out of bounds")
  let id = t.data[index].keyId
  acquire(internLock)
  try:
    let source = symbolNames[int(id)]
    result = newStringOfCap(source.len)
    result.add source
  finally:
    release(internLock)

iterator values*(t: PropTable): Value =
  for i in 0 ..< t.data.len:
    yield t.data[i].val

iterator borrowedValues*(t: PropTable): lent Value =
  ## `values` without the per-item copy, for walks that must not run release
  ## hooks. The table must not change during the loop.
  for i in 0 ..< t.data.len:
    yield t.data[i].val

iterator mvalues*(t: var PropTable): var Value =
  for i in 0 ..< t.data.len:
    yield t.data[i].val

# ---------------------------------------------------------------------------
# Low-level box helpers
# ---------------------------------------------------------------------------

template tagOf(v: Value): uint64 = v.bits shr TAG_SHIFT

proc isObjectTagged(v: Value): bool {.inline.} =
  let tag = v.bits shr TAG_SHIFT
  tag == OBJECT_TAG or tag == CYCLE_OBJECT_TAG

proc isManaged*(v: Value): bool {.inline.} =
  (v.bits shr TAG_SHIFT) >= MANAGED_MIN

proc isImmediateFloat(v: Value): bool {.inline.} =
  ## True when the bits decode as an IEEE float64 stored directly.
  v.bits != 0 and (v.bits shr TAG_SHIFT) < VOID_TAG

proc mkImm(tag: uint64, payload = 0'u64): Value {.inline.} =
  Value(bits: (tag shl TAG_SHIFT) or (payload and PAYLOAD_MASK))

proc boxPtr(tag: uint64, p: pointer): Value {.inline.} =
  Value(bits: (tag shl TAG_SHIFT) or (cast[uint64](p) and PAYLOAD_MASK))

template objData(v: Value): GeneObjectData =
  ## **A view, not a handle — and a `template` so that it stays one.**
  ##
  ## As a `proc` returning `GeneObjectData` this compiled to an owning `ref`:
  ## the cast was assigned to `result`, so ORC emitted a `=dup` on the way out
  ## and a matching `=destroy` — plus a `rememberCycle` root registration,
  ## since these types are potentially cyclic — at every call site. `kind` is
  ## the hottest read in the VM and goes through here, so every tag inspection
  ## in the interpreter was paying a refcount round trip to look at one enum
  ## field. A profile of a buffer-scan loop put ~20% of samples in that traffic.
  ##
  ## The retain was never buying anything. `v` is the owner: a boxed Value holds
  ## the reference for as long as it is live, which is the invariant the whole
  ## NaN-boxed layer already depends on. A template substitutes the cast at the
  ## use site, so `objData(v).objKind` is the field read it always should have
  ## been.
  ##
  ## The rule this creates for callers: **never outlive the `Value`.** Bind the
  ## result only when the owning Value is plainly live across the binding, and
  ## prefer `{.cursor.}` when you do — the hazard is the one already recorded
  ## for cursor save/restore, where a view survives a reassignment of the field
  ## that owned it.
  cast[GeneObjectData](cast[pointer](v.bits and PAYLOAD_MASK))

proc boxObject(data: GeneObjectData): Value =
  var tag = OBJECT_TAG
  case data.objKind
  of okType:
    TypeData(data).valueRefs = 1
  of okModule:
    ModuleData(data).valueRefs = 1
  of okProtocol:
    ProtocolData(data).valueRefs = 1
  of okEnv:
    EnvData(data).cycleRefs = 1
    tag = CYCLE_OBJECT_TAG
  of okCell, okAtomicCell:
    CellData(data).cycleRefs = 1
    tag = CYCLE_OBJECT_TAG
  of okEventBus:
    # A bus retains its handlers, and a handler routinely closes over the scope
    # that holds the bus. That is the same self-cycle Cell and Env have, so it
    # takes the same collector.
    EventBusData(data).cycleRefs = 1
    tag = CYCLE_OBJECT_TAG
  else:
    discard
  GC_ref(data)                                   # the box holds one reference
  Value(bits: (tag shl TAG_SHIFT) or
              (cast[uint64](cast[pointer](data)) and PAYLOAD_MASK))

type ManagedKind* = enum
  managedString, managedInt64, managedList, managedMap,
  managedNode, managedFunction, managedNativeFunction

when defined(geneRcStats):
  # Opt-in diagnostic: counts live managed (heap, refcounted) objects so tests can
  # assert that retain/release balance. Zero cost unless `-d:geneRcStats` is set.
  var liveManaged*: int
  var liveManagedByKind: array[ManagedKind, int]
  var nativeRootsOutstanding: int
  template managedKind(T: typedesc): ManagedKind =
    when T is GeneString: managedString
    elif T is GeneInt64: managedInt64
    elif T is GeneList: managedList
    elif T is GeneMap: managedMap
    elif T is GeneNode: managedNode
    elif T is GeneFunction: managedFunction
    elif T is GeneNativeFn: managedNativeFunction
    else: {.error: "untracked manually managed type".}
  template trackAlloc(T: typedesc) =
    when compileOption("threads"):
      discard atomicFetchAdd(addr liveManaged, 1, ATOMIC_RELAXED)
      discard atomicFetchAdd(addr liveManagedByKind[managedKind(T)], 1, ATOMIC_RELAXED)
    else:
      inc liveManaged
      inc liveManagedByKind[managedKind(T)]
  template trackFree(T: typedesc) =
    when compileOption("threads"):
      discard atomicFetchSub(addr liveManaged, 1, ATOMIC_RELAXED)
      discard atomicFetchSub(addr liveManagedByKind[managedKind(T)], 1, ATOMIC_RELAXED)
    else:
      dec liveManaged
      dec liveManagedByKind[managedKind(T)]
else:
  template trackAlloc(T: typedesc) = discard
  template trackFree(T: typedesc) = discard

proc managedLiveCount*(): int =
  when defined(geneRcStats):
    when compileOption("threads"): atomicLoadN(addr liveManaged, ATOMIC_ACQUIRE)
    else: liveManaged
  else:
    0

proc managedLiveByKind*(): array[ManagedKind, int] =
  when defined(geneRcStats):
    when compileOption("threads"):
      for kind in ManagedKind:
        result[kind] = atomicLoadN(addr liveManagedByKind[kind], ATOMIC_ACQUIRE)
    else: result = liveManagedByKind
  else:
    default(array[ManagedKind, int])

proc noteNativeRootCreated*() =
  when defined(geneRcStats):
    when compileOption("threads"):
      discard atomicFetchAdd(addr nativeRootsOutstanding, 1, ATOMIC_ACQ_REL)
    else:
      inc nativeRootsOutstanding

proc noteNativeRootReleased*() =
  when defined(geneRcStats):
    when compileOption("threads"):
      discard atomicFetchSub(addr nativeRootsOutstanding, 1, ATOMIC_ACQ_REL)
    else:
      dec nativeRootsOutstanding

proc nativeRootCount*(): int =
  when defined(geneRcStats):
    when compileOption("threads"):
      atomicLoadN(addr nativeRootsOutstanding, ATOMIC_ACQUIRE)
    else:
      nativeRootsOutstanding
  else:
    0

proc createObj(T: typedesc): ptr T {.inline.} =
  trackAlloc(T)
  cast[ptr T](alloc0(sizeof(T)))

proc encodeSmallInt(v: int64): uint64 {.inline.} =
  uint64(v) and PAYLOAD_MASK

proc decodeSmallInt(bits: uint64): int64 {.inline.} =
  let raw = bits and PAYLOAD_MASK
  if (raw and INT_SIGN_BIT) != 0:
    cast[int64](raw or not PAYLOAD_MASK)   # sign-extend bits 48..63
  else:
    cast[int64](raw)

proc normalizeBig(x: var BigIntValue) =
  while x.digits.len > 0 and x.digits[^1] == 0'u32:
    x.digits.setLen(x.digits.len - 1)
  if x.digits.len == 0:
    x.sign = 0
  elif x.sign == 0:
    x.sign = 1

proc bigZero(): BigIntValue =
  BigIntValue(sign: 0, digits: @[])

proc bigFromUInt64(mag: uint64, sign: int8): BigIntValue =
  if mag == 0:
    return bigZero()
  result.sign = sign
  var n = mag
  while n > 0:
    result.digits.add uint32(n mod BIG_BASE)
    n = n div BIG_BASE
  result.normalizeBig()

proc bigFromInt64(v: int64): BigIntValue =
  if v == 0:
    return bigZero()
  if v < 0:
    bigFromUInt64(uint64(-(v + 1)) + 1'u64, -1)
  else:
    bigFromUInt64(uint64(v), 1)

proc cmpAbs(a, b: BigIntValue): int =
  if a.digits.len < b.digits.len: return -1
  if a.digits.len > b.digits.len: return 1
  for i in countdown(a.digits.len - 1, 0):
    if a.digits[i] < b.digits[i]: return -1
    if a.digits[i] > b.digits[i]: return 1
  0

proc cmpBig(a, b: BigIntValue): int =
  if a.sign < b.sign: return -1
  if a.sign > b.sign: return 1
  if a.sign == 0: return 0
  let c = cmpAbs(a, b)
  if a.sign > 0: c else: -c

proc addAbs(a, b: BigIntValue): BigIntValue =
  result.sign = 1
  let n = max(a.digits.len, b.digits.len)
  result.digits = newSeq[uint32](n)
  var carry: uint64
  for i in 0 ..< n:
    let av = if i < a.digits.len: uint64(a.digits[i]) else: 0'u64
    let bv = if i < b.digits.len: uint64(b.digits[i]) else: 0'u64
    let s = av + bv + carry
    result.digits[i] = uint32(s mod BIG_BASE)
    carry = s div BIG_BASE
  if carry > 0:
    result.digits.add uint32(carry)
  result.normalizeBig()

proc subAbs(a, b: BigIntValue): BigIntValue =
  ## Absolute subtraction; requires |a| >= |b|.
  result.sign = 1
  result.digits = newSeq[uint32](a.digits.len)
  var borrow: int64
  for i in 0 ..< a.digits.len:
    let av = int64(a.digits[i]) - borrow
    let bv = if i < b.digits.len: int64(b.digits[i]) else: 0'i64
    var d = av - bv
    if d < 0:
      d += int64(BIG_BASE)
      borrow = 1
    else:
      borrow = 0
    result.digits[i] = uint32(d)
  result.normalizeBig()

proc negBig(a: BigIntValue): BigIntValue =
  result = a
  result.sign = -result.sign

proc addBig(a, b: BigIntValue): BigIntValue =
  if a.sign == 0: return b
  if b.sign == 0: return a
  if a.sign == b.sign:
    result = addAbs(a, b)
    result.sign = a.sign
    return
  let c = cmpAbs(a, b)
  if c == 0:
    return bigZero()
  if c > 0:
    result = subAbs(a, b)
    result.sign = a.sign
  else:
    result = subAbs(b, a)
    result.sign = b.sign

proc subBig(a, b: BigIntValue): BigIntValue =
  addBig(a, negBig(b))

proc mulAbsSmall(a: BigIntValue, small: uint32): BigIntValue =
  if a.sign == 0 or small == 0:
    return bigZero()
  result.sign = 1
  result.digits = newSeq[uint32](a.digits.len)
  var carry: uint64
  for i in 0 ..< a.digits.len:
    let p = uint64(a.digits[i]) * uint64(small) + carry
    result.digits[i] = uint32(p mod BIG_BASE)
    carry = p div BIG_BASE
  if carry > 0:
    result.digits.add uint32(carry)
  result.normalizeBig()

proc mulBig(a, b: BigIntValue): BigIntValue =
  if a.sign == 0 or b.sign == 0:
    return bigZero()
  result.sign = a.sign * b.sign
  result.digits = newSeq[uint32](a.digits.len + b.digits.len)
  for i in 0 ..< a.digits.len:
    var carry: uint64
    for j in 0 ..< b.digits.len:
      let idx = i + j
      let p = uint64(result.digits[idx]) +
        uint64(a.digits[i]) * uint64(b.digits[j]) + carry
      result.digits[idx] = uint32(p mod BIG_BASE)
      carry = p div BIG_BASE
    var idx = i + b.digits.len
    while carry > 0:
      if idx >= result.digits.len:
        result.digits.add 0
      let s = uint64(result.digits[idx]) + carry
      result.digits[idx] = uint32(s mod BIG_BASE)
      carry = s div BIG_BASE
      inc idx
  result.normalizeBig()

proc divModSmallAbs(a: BigIntValue, small: uint32): tuple[q: BigIntValue, r: uint32] =
  if small == 0:
    raise newException(FieldDefect, "division by zero")
  if a.sign == 0:
    return (bigZero(), 0'u32)
  result.q.sign = 1
  result.q.digits = newSeq[uint32](a.digits.len)
  var rem: uint64
  for i in countdown(a.digits.len - 1, 0):
    let cur = rem * BIG_BASE + uint64(a.digits[i])
    result.q.digits[i] = uint32(cur div uint64(small))
    rem = cur mod uint64(small)
  result.r = uint32(rem)
  result.q.normalizeBig()

proc shiftAddDigit(rem: BigIntValue, digit: uint32): BigIntValue =
  if rem.sign == 0 and digit == 0:
    return bigZero()
  result.sign = 1
  result.digits = newSeq[uint32](rem.digits.len + 1)
  result.digits[0] = digit
  for i in 0 ..< rem.digits.len:
    result.digits[i + 1] = rem.digits[i]
  result.normalizeBig()

proc divAbs(a, b: BigIntValue): BigIntValue =
  if b.sign == 0:
    raise newException(FieldDefect, "division by zero")
  let c = cmpAbs(a, b)
  if c < 0: return bigZero()
  if c == 0: return bigFromUInt64(1, 1)
  if b.digits.len == 1:
    return divModSmallAbs(a, b.digits[0]).q

  result.sign = 1
  result.digits = newSeq[uint32](a.digits.len)
  var rem = bigZero()
  for i in countdown(a.digits.len - 1, 0):
    rem = shiftAddDigit(rem, a.digits[i])
    var lo: uint64 = 0
    var hi: uint64 = BIG_BASE - 1
    var qdigit: uint32 = 0
    while lo <= hi:
      let mid = (lo + hi) div 2
      let prod = mulAbsSmall(b, uint32(mid))
      if cmpAbs(prod, rem) <= 0:
        qdigit = uint32(mid)
        lo = mid + 1
      else:
        if mid == 0: break
        hi = mid - 1
    result.digits[i] = qdigit
    if qdigit != 0:
      rem = subAbs(rem, mulAbsSmall(b, qdigit))
  result.normalizeBig()

proc divBig(a, b: BigIntValue): BigIntValue =
  if b.sign == 0:
    raise newException(FieldDefect, "division by zero")
  if a.sign == 0:
    return bigZero()
  result = divAbs(a, b)
  if result.sign != 0:
    result.sign = a.sign * b.sign

proc absFitsInt64(x: BigIntValue, negative: bool): bool =
  let limit =
    if negative: bigFromUInt64(1'u64 shl 63, 1)
    else: bigFromUInt64(uint64(high(int64)), 1)
  cmpAbs(x, limit) <= 0

proc bigToInt64(x: BigIntValue): tuple[ok: bool, value: int64] =
  if x.sign == 0:
    return (true, 0'i64)
  let negative = x.sign < 0
  if not absFitsInt64(x, negative):
    return (false, 0'i64)
  var mag: uint64
  for i in countdown(x.digits.len - 1, 0):
    mag = mag * BIG_BASE + uint64(x.digits[i])
  if negative:
    if mag == (1'u64 shl 63):
      (true, low(int64))
    else:
      (true, -int64(mag))
  else:
    (true, int64(mag))

proc parseBigDecimal(s: string): BigIntValue =
  var i = 0
  var sign: int8 = 1
  if s.len > 0 and s[0] == '-':
    sign = -1
    i = 1
  if i >= s.len:
    raise newException(FieldDefect, "invalid integer literal")
  result = bigZero()
  while i < s.len:
    let ch = s[i]
    if ch < '0' or ch > '9':
      raise newException(FieldDefect, "invalid integer literal")
    result = addBig(mulAbsSmall(result, 10),
                    bigFromUInt64(uint64(ord(ch) - ord('0')), 1))
    inc i
  if result.sign != 0:
    result.sign = sign

proc parseBigHex(s: string, start: int): BigIntValue =
  ## `s` is the full lexeme; `start` points just past the `0x` prefix. The
  ## reader only admits `0x` hex-digit runs (design §2.2), so `start` is a
  ## valid hex digit here.
  result = bigZero()
  var i = start
  while i < s.len:
    let ch = s[i]
    let v =
      case ch
      of '0'..'9': ord(ch) - ord('0')
      of 'a'..'f': ord(ch) - ord('a') + 10
      of 'A'..'F': ord(ch) - ord('A') + 10
      else: raise newException(FieldDefect, "invalid hexadecimal integer literal")
    result = addBig(mulAbsSmall(result, 16),
                    bigFromUInt64(uint64(v), 1))
    inc i

proc bigToString(x: BigIntValue): string =
  if x.sign == 0:
    return "0"
  if x.sign < 0:
    result.add '-'
  result.add $x.digits[^1]
  for i in countdown(x.digits.len - 2, 0):
    let part = $x.digits[i]
    result.add repeat("0", BIG_BASE_DIGITS - part.len)
    result.add part

# ---------------------------------------------------------------------------
# Conservative OBJECT_TAG cycle collection
# ---------------------------------------------------------------------------

var objectCycleCollecting = false

proc objectPayload(data: GeneObjectData): uint64 {.inline.} =
  cast[uint64](cast[pointer](data)) and PAYLOAD_MASK

proc tracksObjectCycles(data: GeneObjectData): bool {.inline.} =
  data.objKind in {okCell, okAtomicCell, okEnv, okEventBus}

proc objectCycleRefs(data: GeneObjectData): int {.inline.} =
  case data.objKind
  of okEnv:
    EnvData(data).cycleRefs
  of okCell, okAtomicCell:
    CellData(data).cycleRefs
  of okEventBus:
    EventBusData(data).cycleRefs
  else:
    0

template forObjectEdges(data: GeneObjectData, edgeBits: untyped,
                        action: untyped) =
  template emit(valueExpr: Value) =
    block:
      let edgeBits {.inject.} = valueExpr.bits
      action

  case data.objKind
  of okNamespace:
    discard
  of okModule:
    let d = ModuleData(data)
    emit(d.root)
    for val in d.meta.borrowedValues:
      emit(val)
  of okBigInt:
    discard
  of okBytes:
    discard
  of okRegex:
    discard
  of okRange:
    discard
  of okDate, okTime, okDateTime, okTimezone, okDuration:
    discard
  of okSet:
    for val in SetData(data).items:
      emit(val)
  of okHashMap:
    for entry in HashMapData(data).entries:
      emit(entry.key)
      emit(entry.val)
  of okPipeline:
    let d = PipelineData(data)
    emit(d.initial)
    for stage in d.stages:
      emit(stage.head)
      for val in stage.props.borrowedValues:
        emit(val)
      for val in stage.body:
        emit(val)
      for val in stage.meta.borrowedValues:
        emit(val)
  of okCallableView:
    let d = CallableViewData(data)
    emit(d.target)
    emit(d.signature)
  of okEnv:
    let d = EnvData(data)
    emit(d.parent)
    for val in d.compilerMacroFunctions: emit(val)
    for val in d.bindings.values:
      emit(val)
    for val in d.imports:
      emit(val)
    emit(d.module)
    emit(d.policy)
  of okCell, okAtomicCell:
    let d = CellData(data)
    emit(d.value)
    emit(d.valueType)
  of okStream:
    let d = StreamData(data)
    for val in d.items:
      emit(val)
    emit(d.source)
    emit(d.callable)
    emit(d.buffer)
    emit(d.itemType)
    emit(d.errType)
    for val in d.generatorStack:
      emit(val)
  of okTask:
    let d = TaskData(data)
    emit(d.resultType)
    emit(d.errorType)
  of okChannel:
    emit(ChannelData(data).itemType)
  of okActorRef:
    let d = ActorData(data)
    for item in d.queue:
      emit(item.message)
      emit(item.reply)
    emit(d.state)
    emit(d.restartInit)
    emit(d.handler)
    emit(d.messageType)
    emit(d.failureEvents)
    emit(d.failureDeadLetters)
    emit(d.parentFailureEvents)
    emit(d.parentFailureDeadLetters)
  of okActorContext:
    emit(ActorContextData(data).actor)
  of okActorStep:
    emit(ActorStepData(data).state)
  of okReplyTo:
    let d = ReplyToData(data)
    emit(d.result)
    emit(d.resultType)
    emit(d.task)
  of okCPtr:
    emit(CPtrData(data).targetType)
    emit(CPtrData(data).library)
  of okCSlice:
    emit(CSliceData(data).targetType)
  of okBuffer:
    let d = BufferData(data)
    emit(d.elemType)
    for val in d.items:
      emit(val)
  of okDeviceBuffer:
    emit(DeviceBufferData(data).elemType)
  of okFfiLibrary:
    discard
  of okFfiCallable:
    let d = FfiCallableData(data)
    emit(d.library)
    for val in d.paramTypes:
      emit(val)
    emit(d.returnType)
  of okLogger:
    emit(LoggerData(data).payload)
  of okEventBus:
    for sub in EventBusData(data).subs:
      emit(sub.handler)
  of okEventSubscription:
    # `busBits` is deliberately non-owning (see EventSubscriptionData), so the
    # handle contributes no edge and cannot keep a closed bus alive.
    discard
  of okEventMatcher:
    emit(EventMatcherData(data).target)
  of okRecordingSink, okNullSink, okCompositeSink:
    let d = EventSinkData(data)
    for val in d.recorded:
      emit(val)
    for val in d.sinks:
      emit(val)
  of okType:
    let d = TypeData(data)
    emit(d.parent)
    for m in CoreValueMethod:
      emit(d.coreWitnesses[m])
    for field in d.fields:
      emit(field.typeExpr)
    for field in d.bodyFields:
      emit(field.typeExpr)
    for val in d.requiredProtocols:
      emit(val)
    for val in d.derivedProtocols:
      emit(val)
    for val in d.deriveRequests:
      emit(val)
    for val in d.messages.values:
      emit(val)
    emit(d.ctorFn)
    emit(d.nativeCtor)
    emit(d.aliasExpr)
  of okEnum:
    let d = EnumData(data)
    emit(d.backingType)
    for val in d.variants:
      emit(val)
    for val in d.messages.values:
      emit(val)
  of okProtocol:
    let d = ProtocolData(data)
    for val in d.messages.values:
      emit(val)
    emit(d.deriveFn)
    for val in d.parents:
      emit(val)
    for val in d.closure:
      emit(val)
  of okProtocolMessage:
    let d = ProtocolMessageData(data)
    emit(d.signatureFn)
  of okBoundMessage:
    emit(BoundMessageData(data).qualifier)
  of okEnumVariant:
    let d = EnumVariantData(data)
    for val in d.payloadTypes:
      emit(val)
    emit(d.backing)

proc collectObjectGraph(data: GeneObjectData,
                        counts: var Table[uint64, int],
                        nodes: var seq[GeneObjectData]) =
  if data == nil:
    return
  let payload = objectPayload(data)
  if counts.hasKey(payload):
    return
  if not tracksObjectCycles(data):
    return
  counts[payload] = objectCycleRefs(data)
  nodes.add(data)
  forObjectEdges(data, edgeBits):
    if (edgeBits shr TAG_SHIFT) == CYCLE_OBJECT_TAG:
      let child = cast[GeneObjectData](cast[pointer](edgeBits and PAYLOAD_MASK))
      if tracksObjectCycles(child):
        collectObjectGraph(child, counts, nodes)

proc clearValueSlot(slot: var Value) {.inline.} =
  slot = Value(bits: 0)

proc clearObjectEdges(data: GeneObjectData) =
  case data.objKind
  of okNamespace:
    NamespaceData(data).scope = nil
  of okModule:
    let d = ModuleData(data)
    clearValueSlot(d.root)
    d.meta = initPropTable()
  of okBigInt:
    discard
  of okBytes:
    BytesData(data).data.setLen(0)
  of okRegex:
    let d = RegexData(data)
    d.pattern.setLen(0)
    d.flags.setLen(0)
    d.groupNames.clear()
  of okRange:
    discard
  of okDate, okTime, okDateTime, okTimezone, okDuration:
    discard
  of okSet:
    SetData(data).items.setLen(0)
  of okHashMap:
    HashMapData(data).entries.setLen(0)
  of okPipeline:
    let d = PipelineData(data)
    clearValueSlot(d.initial)
    d.stages.setLen(0)
  of okCallableView:
    let d = CallableViewData(data)
    clearValueSlot(d.target)
    clearValueSlot(d.signature)
    d.typeScope = nil
  of okEnv:
    let d = EnvData(data)
    clearValueSlot(d.parent)
    d.bindings = initTable[string, Value]()
    d.imports.setLen(0)
    clearValueSlot(d.module)
    clearValueSlot(d.policy)
    d.borrowedActive = false
    d.borrowedScope = nil
    d.compilerMacros = nil
    d.compilerMacroFunctions.setLen(0)
  of okCell, okAtomicCell:
    let d = CellData(data)
    clearValueSlot(d.value)
    clearValueSlot(d.valueType)
    d.valueScope = nil
  of okStream:
    let d = StreamData(data)
    d.items.setLen(0)
    clearValueSlot(d.source)
    clearValueSlot(d.callable)
    clearValueSlot(d.buffer)
    clearValueSlot(d.itemType)
    clearValueSlot(d.errType)
    d.itemScope = nil
    d.generatorScope = nil
    d.generatorStack.setLen(0)
  of okTask:
    let d = TaskData(data)
    d.state = nil
    clearValueSlot(d.resultType)
    clearValueSlot(d.errorType)
    d.boundaryScope = nil
  of okChannel:
    let d = ChannelData(data)
    d.state = nil
    clearValueSlot(d.itemType)
    d.itemScope = nil
  of okActorRef:
    let d = ActorData(data)
    d.lifecycle = nil
    d.queue.setLen(0)
    clearValueSlot(d.state)
    clearValueSlot(d.restartInit)
    clearValueSlot(d.handler)
    clearValueSlot(d.messageType)
    clearValueSlot(d.failureEvents)
    clearValueSlot(d.failureDeadLetters)
    clearValueSlot(d.parentFailureEvents)
    clearValueSlot(d.parentFailureDeadLetters)
    d.statePins.setLen(0)
    d.handlerPins.setLen(0)
    d.contractPins.setLen(0)
  of okActorContext:
    clearValueSlot(ActorContextData(data).actor)
  of okActorStep:
    clearValueSlot(ActorStepData(data).state)
  of okReplyTo:
    let d = ReplyToData(data)
    clearValueSlot(d.result)
    clearValueSlot(d.resultType)
    d.resultScope = nil
    clearValueSlot(d.task)
  of okCPtr:
    let d = CPtrData(data)
    clearValueSlot(d.targetType)
    clearValueSlot(d.library)
  of okCSlice:
    clearValueSlot(CSliceData(data).targetType)
  of okBuffer:
    let d = BufferData(data)
    clearValueSlot(d.elemType)
    d.elemScope = nil
    d.items.setLen(0)
    d.packed.setLen(0)
  of okDeviceBuffer:
    clearValueSlot(DeviceBufferData(data).elemType)
  of okFfiLibrary:
    discard
  of okFfiCallable:
    let d = FfiCallableData(data)
    clearValueSlot(d.library)
    d.paramTypes.setLen(0)
    clearValueSlot(d.returnType)
  of okLogger:
    clearValueSlot(LoggerData(data).payload)
  of okEventBus:
    let d = EventBusData(data)
    for i in 0 ..< d.subs.len:
      clearValueSlot(d.subs[i].handler)
    d.subs.setLen(0)
    d.descendantBuckets.clear()
    d.exactBuckets.clear()
    d.matchCache.clear()
  of okEventSubscription:
    EventSubscriptionData(data).busBits = 0
  of okEventMatcher:
    clearValueSlot(EventMatcherData(data).target)
  of okRecordingSink, okNullSink, okCompositeSink:
    let d = EventSinkData(data)
    for i in 0 ..< d.recorded.len:
      clearValueSlot(d.recorded[i])
    d.recorded.setLen(0)
    for i in 0 ..< d.sinks.len:
      clearValueSlot(d.sinks[i])
    d.sinks.setLen(0)
  of okType:
    let d = TypeData(data)
    clearValueSlot(d.parent)
    for witness in d.coreWitnesses.mitems:
      clearValueSlot(witness)
    d.fields.setLen(0)
    d.bodyFields.setLen(0)
    d.scope = nil
    d.weakScope = nil
    d.requiredProtocols.setLen(0)
    d.derivedProtocols.setLen(0)
    d.deriveRequests.setLen(0)
    d.messages = initTable[string, Value]()
    clearValueSlot(d.nativeCtor)
    clearValueSlot(d.aliasExpr)
  of okEnum:
    let d = EnumData(data)
    d.typeParams.setLen(0)
    clearValueSlot(d.backingType)
    d.variants.setLen(0)
    d.scope = nil
    d.weakScope = nil
    d.messages = initTable[string, Value]()
  of okProtocol:
    let d = ProtocolData(data)
    d.messages = initOrderedTable[string, Value]()
    d.weakScope = nil
    clearValueSlot(d.deriveFn)
    d.parents.setLen(0)
    d.closure.setLen(0)
  of okProtocolMessage:
    let d = ProtocolMessageData(data)
    d.protocolBits = 0
    clearValueSlot(d.signatureFn)
    d.hasDefault = false
  of okBoundMessage:
    let d = BoundMessageData(data)
    d.protocolBits = 0
    clearValueSlot(d.qualifier)
    d.boundScope = nil
  of okEnumVariant:
    let d = EnumVariantData(data)
    d.enumBits = 0
    d.payloadTypes.setLen(0)
    clearValueSlot(d.backing)
    d.hasBacking = false

proc tryCollectObjectCycle(seed: GeneObjectData) =
  if seed == nil or objectCycleCollecting or not tracksObjectCycles(seed):
    return

  objectCycleCollecting = true
  try:
    var counts = initTable[uint64, int]()
    var nodes: seq[GeneObjectData] = @[]
    collectObjectGraph(seed, counts, nodes)

    for data in nodes:
      forObjectEdges(data, edgeBits):
        if (edgeBits shr TAG_SHIFT) == CYCLE_OBJECT_TAG:
          let payload = edgeBits and PAYLOAD_MASK
          if counts.hasKey(payload):
            counts[payload] = counts.getOrDefault(payload) - 1

    for _, count in counts:
      if count != 0:
        return

    for data in nodes:
      clearObjectEdges(data)
  finally:
    objectCycleCollecting = false

# ---------------------------------------------------------------------------
# Reference counting bodies
# ---------------------------------------------------------------------------

template threadedRc: bool =
  compileOption("threads")

when compileOption("threads"):
  var errorEvidenceLocks: array[64, Lock]
  for lock in errorEvidenceLocks.mitems: initLock(lock)

template withErrorEvidenceLock(node: ptr GeneNode, body: untyped) =
  when compileOption("threads"):
    withLock errorEvidenceLocks[(cast[uint](node) shr 4) mod 64]:
      body
  else:
    body

template isSharedFlag(flag: var int): bool =
  when threadedRc:
    atomicLoadN(addr flag, ATOMIC_ACQUIRE) != 0
  else:
    flag != 0

template markSharedFlag(flag: var int) =
  when threadedRc:
    if atomicLoadN(addr flag, ATOMIC_ACQUIRE) == 0:
      atomicStoreN(addr flag, 1, ATOMIC_RELEASE)
  else:
    flag = 1

template retainManual(p: untyped) =
  when threadedRc:
    if isSharedFlag(p.shared):
      discard atomicFetchAdd(addr p.refCount, 1, ATOMIC_RELAXED)
    else:
      inc p.refCount
  else:
    inc p.refCount

template releaseManual(p: untyped, body: untyped) =
  when threadedRc:
    if isSharedFlag(p.shared):
      if atomicFetchSub(addr p.refCount, 1, ATOMIC_ACQ_REL) == 1:
        body
    else:
      dec p.refCount
      if p.refCount == 0:
        body
  else:
    dec p.refCount
    if p.refCount == 0:
      body

template markManualShared(p: untyped) =
  markSharedFlag(p.shared)

var scopeStampCounter: uint64

proc nextScopeStamp(): uint64 {.inline.} =
  ## A stamp no scope has carried before (see `Scope.namesGen`). Drawing from
  ## one process-wide counter, rather than counting per scope, is what keeps a
  ## new scope at a recycled address from matching a stamp remembered for the
  ## scope that used to live there.
  when threadedRc:
    atomicAddFetch(addr scopeStampCounter, 1'u64, ATOMIC_RELAXED)
  else:
    scopeStampCounter = scopeStampCounter + 1
    scopeStampCounter

proc touchNames*(scope: Scope) {.inline.} =
  scope.namesGen = nextScopeStamp()

proc touchSlots*(scope: Scope) {.inline.} =
  scope.slotsGen = nextScopeStamp()
  when defined(geneAtomicGenerationRetirementProbe):
    if managedPublicationDepth == 0: markSharedFlag(p.rawPublished)

var managedPublicationDepth {.threadvar.}: int
proc enterManagedValuePublication*() = inc managedPublicationDepth
proc leaveManagedValuePublication*() =
  doAssert managedPublicationDepth > 0
  dec managedPublicationDepth
proc managedValuePublicationActive*(): bool {.inline.} =
  managedPublicationDepth > 0

proc markObjectShared(data: GeneObjectData) {.inline.} =
  if data != nil:
    markSharedFlag(data.shared)
    when defined(geneAtomicGenerationRetirementProbe):
      if managedPublicationDepth == 0: markSharedFlag(data.rawPublished)

proc pinPublishedScope*(scope: Scope) =
  ## Record private compiler roots, plus qualification-only generation provenance,
  ## before handing a graph to another lane. Never inspect a published Scope
  ## during owner-lane retirement.
  ## This does not make concurrent Scope mutation or raw SDK refs safe.
  if scope != nil and scope.application != nil and scope.application.privateCompilerContext:
    let context {.cursor.} = scope.application
    var current {.cursor.} = scope
    while current != nil and current.application == context:
      markSharedFlag(current.retirementPublished)
      current = current.parent
  when defined(geneAtomicGenerationRetirementProbe):
    if managedPublicationDepth > 0: return
    var current {.cursor.} = scope
    while current != nil:
      markSharedFlag(current.retirementPublished)
      current = current.parent

proc scopePublishedForRetirement*(scope: Scope): bool =
  scope != nil and isSharedFlag(scope.retirementPublished)

proc pinLegacyManagedScopes*(scopes: openArray[Scope]) =
  ## A managed object handed to a legacy raw Value cannot report its later
  ## accesses. Keep its known defining generation (and lexical ancestors)
  ## in the retirement queue even after named handles drop.
  for scope in scopes:
    var current {.cursor.} = scope
    while current != nil:
      markSharedFlag(current.retirementPublished)
      current = current.parent

type
  StampedSet* = object
    ## A set of object addresses that is emptied by one increment, so a walk
    ## that runs for every stored value can reuse it without clearing or
    ## reallocating. A slot belongs to the current walk when its stamp matches.
    keys: seq[uint64]
    stamps: seq[uint32]
    stamp: uint32
    used: int
    shift: int

proc reset*(s: var StampedSet) =
  ## Empty the set for a new walk. The table itself is allocated on first use.
  if s.keys.len > 1 shl 18:
    # One very large graph should not pin its table for the thread's life.
    s.keys = @[]
    s.stamps = @[]
  s.used = 0
  if s.stamp == high(uint32):
    # Stamps written before the wrap must stop matching.
    for i in 0 ..< s.stamps.len:
      s.stamps[i] = 0
    s.stamp = 0
  inc s.stamp

proc grow(s: var StampedSet) =
  if s.keys.len == 0:
    s.keys = newSeq[uint64](64)
    s.stamps = newSeq[uint32](64)
    s.shift = 64 - 6
    if s.stamp == 0:
      s.stamp = 1
    return
  var keys = newSeq[uint64](s.keys.len * 2)
  var stamps = newSeq[uint32](s.keys.len * 2)
  let shift = s.shift - 1
  let mask = keys.len - 1
  for i in 0 ..< s.keys.len:
    if s.stamps[i] == s.stamp:
      var slot = int((s.keys[i] * 0x9E3779B97F4A7C15'u64) shr shift)
      while stamps[slot] == s.stamp:
        slot = (slot + 1) and mask
      stamps[slot] = s.stamp
      keys[slot] = s.keys[i]
  s.keys = move keys
  s.stamps = move stamps
  s.shift = shift

proc containsOrIncl*(s: var StampedSet, key: uint64): bool =
  if s.used * 2 >= s.keys.len:
    s.grow()
  let mask = s.keys.len - 1
  var slot = int((key * 0x9E3779B97F4A7C15'u64) shr s.shift)
  while s.stamps[slot] == s.stamp:
    if s.keys[slot] == key:
      return true
    slot = (slot + 1) and mask
  s.stamps[slot] = s.stamp
  s.keys[slot] = key
  inc s.used
  false

proc markSharedBits(bits: uint64, seen: var StampedSet)

proc markObjectSharedGraph(data: GeneObjectData, seen: var StampedSet) =
  if data == nil:
    return
  let key = objectPayload(data)
  if seen.containsOrIncl(key):
    return
  markObjectShared(data)
  block:
    # Private compiler scopes also need publication pins in ordinary builds:
    # a published object may retain a non-owning link into its defining scope.
    template pin(scope: Scope) = pinPublishedScope(scope)
    case data.objKind
    of okNamespace: pin(NamespaceData(data).scope)
    of okType:
      let d {.cursor.} = TypeData(data)
      when defined(geneAtomicGenerationRetirementProbe):
        markSharedBits(d.annotationRefBits, seen)
      pin(d.scope)
      pin(cast[Scope](d.weakScope))
      for field in d.fields:
        pin(field.scope)
        pin(cast[Scope](field.weakScope))
      for field in d.bodyFields:
        pin(field.scope)
        pin(cast[Scope](field.weakScope))
    of okEnum:
      pin(EnumData(data).scope)
      pin(cast[Scope](EnumData(data).weakScope))
    of okProtocol: pin(cast[Scope](ProtocolData(data).weakScope))
    of okProtocolMessage:
      when defined(geneAtomicGenerationRetirementProbe):
        markSharedBits(ProtocolMessageData(data).protocolBits, seen)
    of okBoundMessage:
      let message = BoundMessageData(data)
      when defined(geneAtomicGenerationRetirementProbe):
        if message.boundScope == nil and message.weakScope != nil:
          message.boundScope = cast[Scope](message.weakScope)
          message.weakScope = nil
      pin(message.boundScope)
      pin(cast[Scope](message.weakScope))
      when defined(geneAtomicGenerationRetirementProbe):
        markSharedBits(message.protocolBits, seen)
    of okEnumVariant:
      when defined(geneAtomicGenerationRetirementProbe):
        markSharedBits(EnumVariantData(data).enumBits, seen)
    of okCell, okAtomicCell: pin(CellData(data).valueScope)
    of okEnv: pin(EnvData(data).borrowedScope)
    of okCallableView: pin(CallableViewData(data).typeScope)
    of okStream:
      pin(StreamData(data).itemScope)
      pin(StreamData(data).generatorScope)
    of okTask: pin(TaskData(data).boundaryScope)
    of okChannel: pin(ChannelData(data).itemScope)
    of okReplyTo: pin(ReplyToData(data).resultScope)
    of okBuffer: pin(BufferData(data).elemScope)
    else: discard
  case data.objKind
  of okTask:
    let d = TaskData(data)
    markSharedBits(d.resultType.bits, seen)
    markSharedBits(d.errorType.bits, seen)
    var result, errorValue, panicValue: Value
    acquire(d.state.lock)
    try:
      result = d.state.result
      errorValue = d.state.errorValue
      panicValue = d.state.panicValue
    finally:
      release(d.state.lock)
    markSharedBits(result.bits, seen)
    markSharedBits(errorValue.bits, seen)
    markSharedBits(panicValue.bits, seen)
  of okChannel:
    let d = ChannelData(data)
    markSharedBits(d.itemType.bits, seen)
    var items: seq[Value]
    acquire(d.state.lock)
    try:
      items = d.state.items
    finally:
      release(d.state.lock)
    for item in items:
      markSharedBits(item.bits, seen)
  of okActorRef:
    let d = ActorData(data)
    var state, restartInit, handler, messageType, failureEvents,
      failureDeadLetters, parentFailureEvents, parentFailureDeadLetters: Value
    var queue: seq[ActorMessage]
    acquire(d.lock)
    try:
      state = d.state
      restartInit = d.restartInit
      handler = d.handler
      messageType = d.messageType
      failureEvents = d.failureEvents
      failureDeadLetters = d.failureDeadLetters
      parentFailureEvents = d.parentFailureEvents
      parentFailureDeadLetters = d.parentFailureDeadLetters
      queue = d.queue
    finally:
      release(d.lock)
    markSharedBits(state.bits, seen)
    markSharedBits(restartInit.bits, seen)
    markSharedBits(handler.bits, seen)
    markSharedBits(messageType.bits, seen)
    markSharedBits(failureEvents.bits, seen)
    markSharedBits(failureDeadLetters.bits, seen)
    markSharedBits(parentFailureEvents.bits, seen)
    markSharedBits(parentFailureDeadLetters.bits, seen)
    for item in queue:
      markSharedBits(item.message.bits, seen)
      markSharedBits(item.reply.bits, seen)
  of okAtomicCell:
    let cell {.cursor.} = AtomicCellData(data)
    var stored, itemType: Value
    acquire(cell.lock)
    try:
      stored = cell.value
      itemType = cell.valueType
    finally:
      release(cell.lock)
    markSharedBits(stored.bits, seen)
    markSharedBits(itemType.bits, seen)
  else:
    forObjectEdges(data, edgeBits):
      markSharedBits(edgeBits, seen)

proc markSharedBits(bits: uint64, seen: var StampedSet) =
  let tag = bits shr TAG_SHIFT
  if tag < MANAGED_MIN:
    return
  # A leaf has nothing below it and marking is idempotent, so it is marked
  # without an entry in the visited set; most of a data graph is leaves.
  case tag
  of STRING_TAG:
    markManualShared(cast[ptr GeneString](bits and PAYLOAD_MASK))
    return
  of INT64_TAG:
    markManualShared(cast[ptr GeneInt64](bits and PAYLOAD_MASK))
    return
  of NATIVE_FN_TAG:
    markManualShared(cast[ptr GeneNativeFn](bits and PAYLOAD_MASK))
    return
  else:
    discard
  if seen.containsOrIncl(bits):
    return
  case tag
  of LIST_TAG:
    # Children are read in place: iterating by value would copy and count
    # every item, and a Map's pairs would copy every key as well.
    let p = cast[ptr GeneList](bits and PAYLOAD_MASK)
    markManualShared(p)
    for i in 0 ..< p.items.len:
      markSharedBits(p.items[i].bits, seen)
  of MAP_TAG:
    let p = cast[ptr GeneMap](bits and PAYLOAD_MASK)
    markManualShared(p)
    for i in 0 ..< p.entries.data.len:
      markSharedBits(p.entries.data[i].val.bits, seen)
  of NODE_TAG:
    let p = cast[ptr GeneNode](bits and PAYLOAD_MASK)
    var evidence: ErrorEvidence
    withErrorEvidenceLock(p):
      if p.errorEvidence != nil and p.errorEvidence.weakEnvironment != nil:
        p.errorEvidence.environment = cast[Scope](p.errorEvidence.weakEnvironment)
        p.errorEvidence.weakEnvironment = nil
      markManualShared(p)
      evidence = p.errorEvidence
    markSharedBits(p.head.bits, seen)
    if evidence != nil:
      pinPublishedScope(evidence.environment)
      markSharedBits(evidence.protocol.bits, seen)
      markSharedBits(evidence.formatter.bits, seen)
      for _, item in evidence.diagnostics:
        markSharedBits(item.bits, seen)
    for i in 0 ..< p.props.data.len:
      markSharedBits(p.props.data[i].val.bits, seen)
    for i in 0 ..< p.body.len:
      markSharedBits(p.body[i].bits, seen)
    for i in 0 ..< p.meta.data.len:
      markSharedBits(p.meta.data[i].val.bits, seen)
  of FUNCTION_TAG:
    let p = cast[ptr GeneFunction](bits and PAYLOAD_MASK)
    pinPublishedScope(p.scope)
    pinPublishedScope(cast[Scope](p.weakScope))
    markManualShared(p)
    for item in p.errorTypes:
      markSharedBits(item.bits, seen)
  of CYCLE_OBJECT_TAG, OBJECT_TAG:
    markObjectSharedGraph(
      cast[GeneObjectData](cast[pointer](bits and PAYLOAD_MASK)), seen)
  else:
    discard

type SharedValuePublication* = object
  ## Scratch state for one synchronous publication of an unchanged graph.
  ## Keep separate from VM Scope/code visitation: marking does not walk those
  ## edges. Never reuse across publications or mutations, since a shared
  ## container may acquire children that have not yet been published.
  seen: StampedSet

proc reset*(publication: var SharedValuePublication) =
  ## Forget one publication so the next can reuse this scratch state.
  publication.seen.reset()

proc markSharedValue*(value: Value, publication: var SharedValuePublication) =
  markSharedBits(value.bits, publication.seen)

proc markSharedValue*(value: Value) =
  ## Mark a value graph as published across a Send boundary. Manual refcounted
  ## objects switch to atomic RC after this marker in threaded builds; generic
  ## ORC object refs still need the later atomicArc/worker-pool stage before true
  ## M:N execution.
  var publication: SharedValuePublication
  markSharedValue(value, publication)

proc publicationValueChildren*(value: Value): seq[Value] =
    ## Known object Value edges for the VM's code-publication walk. Call before
    ## handoff under admission; this is not a shared-container snapshot adapter.
    if value.tagOf == OBJECT_TAG or value.tagOf == CYCLE_OBJECT_TAG:
      let data {.cursor.} = objData(value)
      # Task/Channel/Actor snapshots already use their own locks in the VM walk.
      if data.objKind notin {okTask, okChannel, okActorRef, okAtomicCell}:
        forObjectEdges(data, bits):
          rcRetain(bits)
          result.add Value(bits: bits)
      var weakBits = 0'u64
      case data.objKind
      of okType: weakBits = TypeData(data).annotationRefBits
      of okProtocolMessage: weakBits = ProtocolMessageData(data).protocolBits
      of okBoundMessage: weakBits = BoundMessageData(data).protocolBits
      of okEnumVariant: weakBits = EnumVariantData(data).enumBits
      else: discard
      if weakBits != 0:
        rcRetain(weakBits)
        result.add Value(bits: weakBits)

template countsInPlace(p: untyped): bool =
  ## Whether this object's count is an ordinary integer: always in a build
  ## without threads, where the shared mark changes nothing about counting,
  ## and for an unpublished object otherwise. A published object's count is
  ## atomic; `retainPublished` and `releasePublished` handle it.
  when threadedRc: not isSharedFlag(p.shared)
  else: true

template retainPublished(p: untyped) =
  ## A published object's count, raised where it stands: the atomic add the
  ## full body makes for it, without the call. A program that spawns publishes
  ## most of its data, so this is the common case there, not the rare one.
  when threadedRc:
    if isSharedFlag(p.shared):
      discard atomicFetchAdd(addr p.refCount, 1, ATOMIC_RELAXED)
      return

template releasePublished(p: untyped, noBookkeeping: bool) =
  ## A published object's count, lowered where it stands while it stays above
  ## one. The exchange never takes the count to zero, so destruction stays in
  ## the full body, as does a release the object has bookkeeping for.
  when threadedRc:
    if isSharedFlag(p.shared) and noBookkeeping:
      var current = atomicLoadN(addr p.refCount, ATOMIC_RELAXED)
      while current > 1:
        if atomicCompareExchangeN(addr p.refCount, addr current, current - 1,
                                  true, ATOMIC_ACQ_REL, ATOMIC_RELAXED):
          return

proc rcRetain(bits: uint64) =
  ## A manual object whose count is an ordinary integer is bumped in place,
  ## and a published one with an atomic add. An unpublished Node carrying
  ## error evidence may have to restore its environment; it, and every object
  ## kind, go to the full body.
  let payload = bits and PAYLOAD_MASK
  case bits shr TAG_SHIFT
  of STRING_TAG:
    let p = cast[ptr GeneString](payload)
    if countsInPlace(p):
      p.refCount = p.refCount +% 1
      return
    retainPublished(p)
  of INT64_TAG:
    let p = cast[ptr GeneInt64](payload)
    if countsInPlace(p):
      p.refCount = p.refCount +% 1
      return
    retainPublished(p)
  of LIST_TAG:
    let p = cast[ptr GeneList](payload)
    if countsInPlace(p):
      p.refCount = p.refCount +% 1
      return
    retainPublished(p)
  of MAP_TAG:
    let p = cast[ptr GeneMap](payload)
    if countsInPlace(p):
      p.refCount = p.refCount +% 1
      return
    retainPublished(p)
  of NODE_TAG:
    let p = cast[ptr GeneNode](payload)
    if countsInPlace(p) and p.errorEvidence == nil:
      p.refCount = p.refCount +% 1
      return
    retainPublished(p)
  of FUNCTION_TAG:
    let p = cast[ptr GeneFunction](payload)
    if countsInPlace(p):
      p.refCount = p.refCount +% 1
      return
    retainPublished(p)
  of NATIVE_FN_TAG:
    let p = cast[ptr GeneNativeFn](payload)
    if countsInPlace(p):
      p.refCount = p.refCount +% 1
      return
    retainPublished(p)
  else:
    discard
  rcRetainOther(bits)

proc rcRetainFull(bits: uint64) =
  case bits shr TAG_SHIFT
  of STRING_TAG: retainManual(cast[ptr GeneString](bits and PAYLOAD_MASK))
  of INT64_TAG:  retainManual(cast[ptr GeneInt64](bits and PAYLOAD_MASK))
  of LIST_TAG:   retainManual(cast[ptr GeneList](bits and PAYLOAD_MASK))
  of MAP_TAG:    retainManual(cast[ptr GeneMap](bits and PAYLOAD_MASK))
  of NODE_TAG:
    let node = cast[ptr GeneNode](bits and PAYLOAD_MASK)
    retainManual(node)
    # Reading an error out of its owning scope makes its formatter environment
    # independently reachable again, just as escaping a scope-owned function
    # strengthens its captured scope. The nominal node itself never changes.
    if not isSharedFlag(node.shared) and node.errorEvidence != nil and
        node.errorEvidence.weakEnvironment != nil:
      node.errorEvidence.environment = cast[Scope](node.errorEvidence.weakEnvironment)
      node.errorEvidence.weakEnvironment = nil
  of FUNCTION_TAG:  retainManual(cast[ptr GeneFunction](bits and PAYLOAD_MASK))
  of NATIVE_FN_TAG: retainManual(cast[ptr GeneNativeFn](bits and PAYLOAD_MASK))
  of CYCLE_OBJECT_TAG:
    let data = cast[GeneObjectData](cast[pointer](bits and PAYLOAD_MASK))
    case data.objKind
    of okEnv:
      let d = EnvData(data)
      when threadedRc:
        if isSharedFlag(data.shared):
          discard atomicFetchAdd(addr d.cycleRefs, 1, ATOMIC_RELAXED)
        else:
          inc d.cycleRefs
      else:
        inc d.cycleRefs
    of okCell, okAtomicCell:
      let d = CellData(data)
      when threadedRc:
        if isSharedFlag(data.shared):
          discard atomicFetchAdd(addr d.cycleRefs, 1, ATOMIC_RELAXED)
        else:
          inc d.cycleRefs
      else:
        inc d.cycleRefs
    else:
      discard
    GC_ref(data)
  of OBJECT_TAG:
    let data = cast[GeneObjectData](cast[pointer](bits and PAYLOAD_MASK))
    if data.objKind == okModule:
      let module = ModuleData(data)
      when threadedRc:
        if isSharedFlag(data.shared):
          discard atomicFetchAdd(addr module.valueRefs, 1, ATOMIC_RELAXED)
        else:
          inc module.valueRefs
      else:
        inc module.valueRefs
    elif data.objKind == okProtocol:
      let protocol = ProtocolData(data)
      when threadedRc:
        if isSharedFlag(data.shared):
          discard atomicFetchAdd(addr protocol.valueRefs, 1, ATOMIC_RELAXED)
        else:
          inc protocol.valueRefs
      else:
        inc protocol.valueRefs
    elif data.objKind == okType:
      let typ = TypeData(data)
      when threadedRc:
        if isSharedFlag(data.shared):
          discard atomicFetchAdd(addr typ.valueRefs, 1, ATOMIC_RELAXED)
        else:
          inc typ.valueRefs
      else:
        inc typ.valueRefs
      if not isSharedFlag(data.shared) and typ.scopeEscaped and
          typ.scope == nil and typ.weakScope != nil:
        typ.scope = cast[Scope](typ.weakScope)
    GC_ref(data)
  else: discard

proc weakenOwnedErrorEnvironment(node: ptr GeneNode, bits: uint64) =
  # Only direct scope bindings count: a container holding the error might also
  # be reachable outside the scope. Shared nodes keep their strong pin because
  # inspecting another lane's bindings is not a permitted publication action.
  if isSharedFlag(node.shared) or node.errorEvidence == nil or
      node.errorEvidence.environment == nil:
    return
  let evidence = node.errorEvidence
  let owner = evidence.environment
  let references = node.refCount
  var owned = 0
  for i in 0 ..< owner.slots.len:
    if owner.slots[i].bits == bits: inc owned
  for binding in owner.vars.values:
    if binding.bits == bits: inc owned
  if owned == references and owned > 0:
    evidence.weakEnvironment = cast[pointer](owner)
    evidence.environment = nil
  # Releasing `owner` may free `node`; callers must not touch it afterwards.

proc isLoadedModuleRoot(owner: Scope): bool =
  # A loaded module already owns its root namespace through this_mod. Its
  # lifetime is managed by module activation/release; repeatedly walking that
  # entire declaration graph cannot reclaim anything it owns.
  if not owner.moduleRoot or not owner.vars.hasKey("this_mod"):
    return false
  let moduleBits = owner.vars.getOrDefault("this_mod").bits
  moduleBits shr TAG_SHIFT == OBJECT_TAG and
    cast[GeneObjectData](cast[pointer](moduleBits and PAYLOAD_MASK)).objKind == okModule

proc scopeOwnedReferences(owner: Scope, target: uint64): int =
  ## References to `target` that belong to `owner`: its bindings, plus those
  ## held by containers whose *entire* reference count the scope already
  ## accounts for. An externally retained or shared container keeps its
  ## references external, even if it is also stored here.
  var references = initTable[uint64, int]()
  template count(value: Value) =
    block:
      let key = value.bits
      if key shr TAG_SHIFT >= MANAGED_MIN:
        references[key] = references.getOrDefault(key) + 1
  for i in 0 ..< owner.slots.len:
    count(owner.slots[i])
  for value in owner.vars.values:
    count(value)
  for fallback in owner.wildcardFallbacks.values:
    count(fallback.value)
  for binding in owner.slotTypes:
    count(binding.expr)
  for binding in owner.varTypes.values:
    count(binding.expr)
  count(owner.annotationSelfType)
  for value in owner.requiredImplTypes:
    count(value)
  for value in owner.corePendingTypes:
    count(value)
  if owner.moduleRefs != nil:
    for entry in owner.moduleRefs.entries.values:
      if entry != nil:
        count(entry.value)
  count(owner.supervisorEvents)
  count(owner.supervisorDeadLetters)
  for value in owner.ownedTasks:
    count(value)
  for value in owner.ownedCleanupTasks:
    count(value)
  for value in owner.ownedActors:
    count(value)
  for impl in owner.impls:
    count(impl.protocol)
    count(impl.receiver)
    for message in impl.messages:
      count(message.message)
      count(message.fn)
    for message in impl.localMessages:
      count(message.message)
      count(message.fn)
    for binding in impl.selfBindings:
      count(binding.protocol)
      count(binding.selfType)
      count(binding.originProtocol)
      count(binding.originReceiver)
    for source in impl.bodySources:
      count(source.message)
      count(source.protocol)
      count(source.receiver)
  var visited = initHashSet[uint64]()
  while true:
    var ready: seq[uint64]
    for key, owned in references:
      if key == target or key in visited:
        continue
      var total = -1
      case key shr TAG_SHIFT
      of LIST_TAG:
        let value = cast[ptr GeneList](key and PAYLOAD_MASK)
        if not isSharedFlag(value.shared): total = value.refCount
      of MAP_TAG:
        let value = cast[ptr GeneMap](key and PAYLOAD_MASK)
        if not isSharedFlag(value.shared): total = value.refCount
      of NODE_TAG:
        let value = cast[ptr GeneNode](key and PAYLOAD_MASK)
        if not isSharedFlag(value.shared): total = value.refCount
      of CYCLE_OBJECT_TAG:
        let value = cast[GeneObjectData](cast[pointer](key and PAYLOAD_MASK))
        if value.objKind == okCell and not isSharedFlag(value.shared):
          total = CellData(value).cycleRefs
      of OBJECT_TAG:
        let value = cast[GeneObjectData](cast[pointer](key and PAYLOAD_MASK))
        if not isSharedFlag(value.shared):
          case value.objKind
          of okType: total = TypeData(value).valueRefs
          of okProtocol: total = ProtocolData(value).valueRefs
          of okModule: total = ModuleData(value).valueRefs
          else: discard
      else: discard
      if owned == total:
        ready.add key
    if ready.len == 0:
      break
    for key in ready:
      visited.incl key
      case key shr TAG_SHIFT
      of LIST_TAG:
        for value in cast[ptr GeneList](key and PAYLOAD_MASK).items:
          count(value)
      of MAP_TAG:
        for value in cast[ptr GeneMap](key and PAYLOAD_MASK).entries.values:
          count(value)
      of NODE_TAG:
        let node = cast[ptr GeneNode](key and PAYLOAD_MASK)
        count(node.head)
        for value in node.props.values: count(value)
        for value in node.body: count(value)
        for value in node.meta.values: count(value)
      of CYCLE_OBJECT_TAG:
        let value = cast[GeneObjectData](cast[pointer](key and PAYLOAD_MASK))
        if value.objKind == okCell:
          count(CellData(value).value)
      of OBJECT_TAG:
        let value = cast[GeneObjectData](cast[pointer](key and PAYLOAD_MASK))
        forObjectEdges(value, child):
          if child shr TAG_SHIFT >= MANAGED_MIN:
            references[child] = references.getOrDefault(child) + 1
      else: discard
  references.getOrDefault(target)

proc weakenOwnedTypeEnvironment(typ: TypeData, bits: uint64) =
  # The type keeps its nominal identity when it escapes. Once only its own
  # declaration's bindings retain it, release the scope back-edge; a later
  # read promotes it again in rcRetain. Do not inspect another lane's scope.
  if isSharedFlag(typ.shared) or typ.scope == nil:
    return
  let owner = typ.scope
  if owner.isLoadedModuleRoot:
    return
  let owned = scopeOwnedReferences(owner, bits)
  if owned > 0 and owned == typ.valueRefs:
    # Scope destruction can release this same type again. Detach first so a
    # nested release cannot revisit the scope field being destroyed.
    var retired = move typ.scope
    retired = nil

proc kind*(v: Value): ValueKind {.inline, raises: [].}

# ---------------------------------------------------------------------------
# Released sandbox generation retirement (VM-2)
# ---------------------------------------------------------------------------
#
# A released generation's module root closes cycles that cross manual Value
# counts and Nim refs, e.g. Scope.this_mod -> Module -> Namespace -> Scope and
# Scope binding -> Type -> Type.scope. ORC cannot see through a boxed Value
# (each box is a GC_ref), so such a graph survives after its last outside
# owner is gone. Retirement is trial deletion over the graph reachable from
# the pending generation roots: a node is internally owned when every counted
# reference to it comes from an expanded node, and a scope is torn down only
# when nothing externally owned reaches it through a strong or weak edge.
#
# Soundness depends on three rules. Every counted edge is a real owning
# reference, counted once per owner. Totals are complete: manual counts for
# boxed Values, and the ORC header count, which includes every box and every
# Nim ref, for scopes and ORC objects. Anything not enumerated — chunk
# constants, error evidence, `RootRef` state, other lanes — is left out, so its
# targets look externally owned and stay alive.

# AtomicArc builds run Gene worker lanes. Shared graphs remain excluded unless
# the threaded collector is qualified. A private compiler context can use the
# same probed count adapter on its owner lane without inspecting shared graphs.
# Single-threaded wasm uses the same
# layout-probed adapter for evaluation and activation scopes (not filesystem
# sandbox qualification). `int` follows the target's ORC header word size.
when defined(geneAtomicGenerationRetirementProbe) and
    (not defined(gcAtomicArc) or defined(gcOrc) or not defined(geneRcStats) or
     not compileOption("threads")):
  {.error: "geneAtomicGenerationRetirementProbe requires genuine AtomicArc and geneRcStats".}

when (defined(gcOrc) or defined(gcAtomicArc)) and
    not (defined(nimArcDebug) or defined(nimArcIds) or
         defined(nimOrcLeakDetector)):
  type NimRefHeader = object
    rc: int
    when defined(gcOrc):
      rootIdx: int
  const nimRefCountReadable = true
else:
  const nimRefCountReadable = false

proc nimStrongRefs(p: pointer): int {.inline.} =
  ## Complete Nim object owners: boxes (GC_ref) plus Nim refs. The selected
  ## Nim 2.2 memory-manager header is independently layout-probed below.
  when nimRefCountReadable:
    let header = cast[ptr NimRefHeader](cast[int](p) -% sizeof(NimRefHeader))
    when defined(gcAtomicArc):
      (atomicLoadN(addr header.rc, ATOMIC_ACQUIRE) shr 3) + 1
    else:
      (header.rc shr 4) + 1
  else:
    high(int)

when defined(gcAtomicArc):
  var retirementLayout {.threadvar.}: int
  var generationRetiring {.threadvar.}: bool
else:
  var retirementLayout = 0 # 0 unchecked, 1 verified, -1 unsupported
  var generationRetiring = false

when defined(geneAtomicGenerationRetirementProbe):
  var atomicGenerationRetirementBoundary {.threadvar.}: int
  proc enterAtomicGenerationRetirementBoundary*() =
    inc atomicGenerationRetirementBoundary
  proc leaveAtomicGenerationRetirementBoundary*() =
    doAssert atomicGenerationRetirementBoundary > 0
    dec atomicGenerationRetirementBoundary

proc retirementSupported(): bool =
  if retirementLayout == 0:
    retirementLayout = -1
    when nimRefCountReadable:
      let probe = Scope()
      let address = cast[pointer](probe)
      if nimStrongRefs(address) == 1:
        GC_ref(probe)
        let raised = nimStrongRefs(address)
        GC_unref(probe)
        if raised == 2 and nimStrongRefs(address) == 1:
          retirementLayout = 1
  retirementLayout == 1

when defined(geneScopeReuseTests):
  template withUnsupportedScopeRefcounts*(body: untyped) =
    ## Exercise a failed runtime layout probe without changing the toolchain.
    let savedLayout = retirementLayout
    retirementLayout = -1
    try:
      body
    finally:
      retirementLayout = savedLayout

proc generationRetirementAvailable*(): bool =
  ## Whether this build has its count adapter. AtomicArc remains unavailable
  ## without the qualification flag; a true probe result is not production support.
  when defined(gcAtomicArc) and not defined(geneAtomicGenerationRetirementProbe):
    false
  else:
    retirementSupported()

type
  RetireNodeKind = enum
    rnkValue, rnkScope, rnkRefTable, rnkRefEntry, rnkTaskState,
    rnkChannelState

  RetireNode = object
    kind: RetireNodeKind
    address: pointer    # a Scope or `#Ref` table/entry; `bits` for a Value
    bits: uint64
    total: int
    internal: int
    expanded: bool
    weakScanned: bool   # a live, unexpanded node's weak edges were followed
    pinned: bool        # an active native borrow keeps it alive
    live: bool
    edges: seq[int32]   # strong and weak successors, for liveness propagation

  RetireGraph = object
    complete: bool
    privateContext: RuntimeContext
    nodes: seq[RetireNode]
    refIndex: Table[uint64, int]  # Scopes and `#Ref` tables/entries
    valueIndex: Table[uint64, int]
    weakScopes: seq[tuple[source: int, target: uint64]]
    weakValues: seq[tuple[source: int, target: uint64]]
    ready: seq[int]

proc retireValueTotal(bits: uint64): int =
  # ORC runs without Gene worker lanes. The AtomicArc experiment requires a
  # paused-root boundary and pins published Values rather than trusting a snapshot.
  let payload = bits and PAYLOAD_MASK
  template manual(T: typedesc): int =
    block:
      let p = cast[ptr T](payload)
      when threadedRc:
        atomicLoadN(addr p.refCount, ATOMIC_ACQUIRE)
      else:
        p.refCount
  case bits shr TAG_SHIFT
  of STRING_TAG: manual(GeneString)
  of INT64_TAG: manual(GeneInt64)
  of LIST_TAG: manual(GeneList)
  of MAP_TAG: manual(GeneMap)
  of NODE_TAG: manual(GeneNode)
  of FUNCTION_TAG: manual(GeneFunction)
  of NATIVE_FN_TAG: manual(GeneNativeFn)
  of OBJECT_TAG, CYCLE_OBJECT_TAG:
    nimStrongRefs(cast[pointer](payload))
  else: high(int)

when defined(geneAtomicGenerationRetirementProbe):
  proc retirementValuePublished(bits: uint64): bool =
    let payload = bits and PAYLOAD_MASK
    case bits shr TAG_SHIFT
    of STRING_TAG: isSharedFlag(cast[ptr GeneString](payload).rawPublished)
    of INT64_TAG: isSharedFlag(cast[ptr GeneInt64](payload).rawPublished)
    of LIST_TAG: isSharedFlag(cast[ptr GeneList](payload).rawPublished)
    of MAP_TAG: isSharedFlag(cast[ptr GeneMap](payload).rawPublished)
    of NODE_TAG: isSharedFlag(cast[ptr GeneNode](payload).rawPublished)
    of FUNCTION_TAG: isSharedFlag(cast[ptr GeneFunction](payload).rawPublished)
    of NATIVE_FN_TAG: isSharedFlag(cast[ptr GeneNativeFn](payload).rawPublished)
    of OBJECT_TAG, CYCLE_OBJECT_TAG:
      let data {.cursor.} = cast[GeneObjectData](cast[pointer](payload))
      isSharedFlag(data.rawPublished)
    else: false

  proc valueRawPublishedForRetirement*(value: Value): bool =
    if value.bits shr TAG_SHIFT < MANAGED_MIN or
        (value.bits and PAYLOAD_MASK) == 0: return false
    retirementValuePublished(value.bits)

proc retirementValueShared(bits: uint64): bool =
  let payload = bits and PAYLOAD_MASK
  case bits shr TAG_SHIFT
  of STRING_TAG: isSharedFlag(cast[ptr GeneString](payload).shared)
  of INT64_TAG: isSharedFlag(cast[ptr GeneInt64](payload).shared)
  of LIST_TAG: isSharedFlag(cast[ptr GeneList](payload).shared)
  of MAP_TAG: isSharedFlag(cast[ptr GeneMap](payload).shared)
  of NODE_TAG: isSharedFlag(cast[ptr GeneNode](payload).shared)
  of FUNCTION_TAG: isSharedFlag(cast[ptr GeneFunction](payload).shared)
  of NATIVE_FN_TAG: isSharedFlag(cast[ptr GeneNativeFn](payload).shared)
  of OBJECT_TAG, CYCLE_OBJECT_TAG:
    let data {.cursor.} = cast[GeneObjectData](cast[pointer](payload))
    isSharedFlag(data.shared)
  else: false

proc valueNode(g: var RetireGraph, bits: uint64): int =
  if bits shr TAG_SHIFT < MANAGED_MIN or (bits and PAYLOAD_MASK) == 0:
    return -1
  result = g.valueIndex.getOrDefault(bits, -1)
  if result < 0:
    result = g.nodes.len
    g.nodes.add RetireNode(bits: bits, total: retireValueTotal(bits))
    when defined(geneAtomicGenerationRetirementProbe):
      g.nodes[result].pinned = retirementValuePublished(bits)
    if g.privateContext != nil and retirementValueShared(bits):
      g.nodes[result].pinned = true
    g.valueIndex[bits] = result

proc refNode(g: var RetireGraph, address: pointer,
             kind: RetireNodeKind): int =
  if address == nil:
    return -1
  let key = cast[uint64](address)
  result = g.refIndex.getOrDefault(key, -1)
  if result < 0:
    result = g.nodes.len
    g.nodes.add RetireNode(kind: kind, address: address,
                           total: nimStrongRefs(address))
    g.refIndex[key] = result

proc scopeNode(g: var RetireGraph, scope: Scope): int =
  result = g.refNode(cast[pointer](scope), rnkScope)
  if result >= 0 and scope.scopePublishedForRetirement:
    g.nodes[result].pinned = true
  if result >= 0 and g.privateContext != nil and scope.application != g.privateContext:
    g.nodes[result].pinned = true

proc strongEdge(g: var RetireGraph, source, target: int) =
  if target < 0:
    return
  inc g.nodes[target].internal
  g.nodes[source].edges.add int32(target)
  if not g.nodes[target].expanded and
      (g.nodes[target].internal == g.nodes[target].total or
       g.complete):
    g.ready.add target

proc expandRetireScope(g: var RetireGraph, idx: int, counting: static bool) =
  ## `counting` expands an internally owned node: strong edges are counted
  ## and discover their targets. Otherwise only weak edges are collected, for a
  ## live node whose uncounted strong edges already make their targets live.
  let s {.cursor.} = cast[Scope](g.nodes[idx].address)
  when counting:
    g.nodes[idx].expanded = true
  template value(v: Value) =
    when counting:
      g.strongEdge(idx, g.valueNode(v.bits))
  template scopeRef(x: Scope) =
    when counting:
      g.strongEdge(idx, g.scopeNode(x))
  template weakScope(p: pointer) =
    if p != nil:
      g.weakScopes.add (idx, cast[uint64](p))
  when counting:
    scopeRef(s.parent)
    scopeRef(s.moduleBase)
    for i in 0 ..< s.slots.len:
      value(s.slots[i])
    for v in s.vars.values:
      value(v)
    for pins in s.managedBindingPins.values:
      for source in pins:
        scopeRef(source)
    for fallback in s.wildcardFallbacks.values:
      value(fallback.value)
    value(s.annotationSelfType)
    for i in 0 ..< s.requiredImplTypes.len:
      value(s.requiredImplTypes[i])
    for i in 0 ..< s.corePendingTypes.len:
      value(s.corePendingTypes[i])
    # A module root shares its `#Ref` table with every scope that ran a chunk
    # declaring refs; the table and its entries are nodes of their own.
    if s.moduleRefs != nil:
      g.strongEdge(idx, g.refNode(cast[pointer](s.moduleRefs), rnkRefTable))
    value(s.supervisorEvents)
    value(s.supervisorDeadLetters)
    for i in 0 ..< s.ownedTasks.len:
      value(s.ownedTasks[i])
    for i in 0 ..< s.ownedCleanupTasks.len:
      value(s.ownedCleanupTasks[i])
    for i in 0 ..< s.ownedActors.len:
      value(s.ownedActors[i])
  for i in 0 ..< s.slotTypes.len:
    value(s.slotTypes[i].expr)
    scopeRef(s.slotTypes[i].scope)
    weakScope(s.slotTypes[i].weakScope)
  for binding in s.varTypes.values:
    value(binding.expr)
    scopeRef(binding.scope)
    weakScope(binding.weakScope)
  for impl in s.impls:
    when counting:
      value(impl.protocol)
      value(impl.receiver)
      for message in impl.messages:
        value(message.message)
        value(message.fn)
      for message in impl.localMessages:
        value(message.message)
        value(message.fn)
      for binding in impl.selfBindings:
        value(binding.protocol)
        value(binding.selfType)
        value(binding.originProtocol)
        value(binding.originReceiver)
      for source in impl.bodySources:
        value(source.message)
        value(source.protocol)
        value(source.receiver)
    scopeRef(impl.assemblyScope)
    weakScope(impl.weakAssemblyScope)

proc expandRetireModuleRef(g: var RetireGraph, idx: int) =
  ## `#Ref` tables and entries hold no weak edges, so only counting expands them.
  g.nodes[idx].expanded = true
  if g.nodes[idx].kind == rnkRefTable:
    let table {.cursor.} = cast[ModuleRefTable](g.nodes[idx].address)
    for entry in table.entries.values:
      g.strongEdge(idx, g.refNode(cast[pointer](entry), rnkRefEntry))
  else:
    let entry {.cursor.} = cast[ModuleRefEntry](g.nodes[idx].address)
    g.strongEdge(idx, g.valueNode(entry.value.bits))

proc expandRetireTaskState(g: var RetireGraph, idx: int) =
  ## The separately owned TaskState retains results and managed SDK Scope pins.
  ## Read its complete owning edges under the state lock at the collector gate.
  g.nodes[idx].expanded = true
  let state {.cursor.} = cast[TaskState](g.nodes[idx].address)
  acquire(state.lock)
  try:
    for scope in state.retainedScopes:
      g.strongEdge(idx, g.scopeNode(scope))
    g.strongEdge(idx, g.valueNode(state.result.bits))
    g.strongEdge(idx, g.valueNode(state.errorValue.bits))
    g.strongEdge(idx, g.valueNode(state.panicValue.bits))
  finally:
    release(state.lock)

proc expandRetireChannelState(g: var RetireGraph, idx: int) =
  g.nodes[idx].expanded = true
  let state {.cursor.} = cast[ChannelState](g.nodes[idx].address)
  acquire(state.lock)
  try:
    for item in state.items:
      g.strongEdge(idx, g.valueNode(item.bits))
    for pins in state.scopePins:
      for scope in pins:
        g.strongEdge(idx, g.scopeNode(scope))
  finally:
    release(state.lock)

proc expandRetireValue(g: var RetireGraph, idx: int, counting: static bool) =
  let bits = g.nodes[idx].bits
  let payload = bits and PAYLOAD_MASK
  when counting:
    g.nodes[idx].expanded = true
  template value(v: Value) =
    when counting:
      g.strongEdge(idx, g.valueNode(v.bits))
  template scopeRef(x: Scope) =
    when counting:
      g.strongEdge(idx, g.scopeNode(x))
  template weakScope(p: pointer) =
    if p != nil:
      g.weakScopes.add (idx, cast[uint64](p))
  template weakValue(target: uint64) =
    if target != 0:
      g.weakValues.add (idx, target)
  case bits shr TAG_SHIFT
  of LIST_TAG:
    when counting:
      let p = cast[ptr GeneList](payload)
      for i in 0 ..< p.items.len:
        value(p.items[i])
  of MAP_TAG:
    when counting:
      let p = cast[ptr GeneMap](payload)
      for i in 0 ..< p.entries.data.len:
        value(p.entries.data[i].val)
  of NODE_TAG:
    # Error evidence is a separately owned ref; its edges stay uncounted.
    when counting:
      let p = cast[ptr GeneNode](payload)
      value(p.head)
      for i in 0 ..< p.props.data.len:
        value(p.props.data[i].val)
      for i in 0 ..< p.body.len:
        value(p.body[i])
      for i in 0 ..< p.meta.data.len:
        value(p.meta.data[i].val)
  of FUNCTION_TAG:
    # Compiled code constants are not enumerated.
    let p = cast[ptr GeneFunction](payload)
    scopeRef(p.scope)
    weakScope(p.weakScope)
    when counting:
      for i in 0 ..< p.errorTypes.len:
        value(p.errorTypes[i])
  of OBJECT_TAG, CYCLE_OBJECT_TAG:
    let data {.cursor.} = cast[GeneObjectData](cast[pointer](payload))
    when counting:
      forObjectEdges(data, child):
        g.strongEdge(idx, g.valueNode(child))
    case data.objKind
    of okNamespace:
      scopeRef(cast[NamespaceData](data).scope)
    of okType:
      let d {.cursor.} = cast[TypeData](data)
      scopeRef(d.scope)
      weakScope(d.weakScope)
      for field in d.fields:
        scopeRef(field.scope)
        weakScope(field.weakScope)
      for field in d.bodyFields:
        scopeRef(field.scope)
        weakScope(field.weakScope)
    of okEnum:
      let d {.cursor.} = cast[EnumData](data)
      scopeRef(d.scope)
      weakScope(d.weakScope)
    of okProtocol:
      weakScope(cast[ProtocolData](data).weakScope)
    of okProtocolMessage:
      weakValue(cast[ProtocolMessageData](data).protocolBits)
    of okBoundMessage:
      let d {.cursor.} = cast[BoundMessageData](data)
      scopeRef(d.boundScope)
      weakScope(d.weakScope)
      weakValue(d.protocolBits)
    of okEnumVariant:
      weakValue(cast[EnumVariantData](data).enumBits)
    of okCell, okAtomicCell:
      scopeRef(cast[CellData](data).valueScope)
    of okEnv:
      scopeRef(cast[EnvData](data).borrowedScope)
    of okCallableView:
      scopeRef(cast[CallableViewData](data).typeScope)
    of okStream:
      let d {.cursor.} = cast[StreamData](data)
      scopeRef(d.itemScope)
      scopeRef(d.generatorScope)
      when counting:
        # A generator's continuation is VM state; count its edges only when the
        # stream is its sole owner and the VM can enumerate all of them.
        if d.generatorContinuation != nil and continuationEdgesHook != nil and
            nimStrongRefs(cast[pointer](d.generatorContinuation)) == 1:
          var scopes: seq[pointer]
          var values: seq[uint64]
          if continuationEdgesHook(d.generatorContinuation, scopes, values):
            for address in scopes:
              g.strongEdge(idx, g.scopeNode(cast[Scope](address)))
            for bits in values:
              g.strongEdge(idx, g.valueNode(bits))
    of okTask:
      let task {.cursor.} = cast[TaskData](data)
      scopeRef(task.boundaryScope)
      when counting:
        g.strongEdge(idx, g.refNode(cast[pointer](task.state), rnkTaskState))
    of okChannel:
      let channel {.cursor.} = cast[ChannelData](data)
      scopeRef(channel.itemScope)
      when counting:
        g.strongEdge(idx, g.refNode(cast[pointer](channel.state),
                                    rnkChannelState))
    of okActorRef:
      when counting:
        let actor {.cursor.} = cast[ActorData](data)
        for scope in actor.statePins:
          scopeRef(scope)
        for scope in actor.handlerPins:
          scopeRef(scope)
        for scope in actor.contractPins:
          scopeRef(scope)
        for item in actor.queue:
          for scope in item.pins:
            scopeRef(scope)
    of okReplyTo:
      scopeRef(cast[ReplyToData](data).resultScope)
    of okBuffer:
      scopeRef(cast[BufferData](data).elemScope)
    of okCPtr:
      if cast[CPtrData](data).activeBorrows > 0:
        g.nodes[idx].pinned = true
    of okFfiLibrary:
      if cast[FfiLibraryData](data).nativeBorrows > 0:
        g.nodes[idx].pinned = true
    else:
      discard
  else:
    discard

type RetiredScopeBindings = object
  vars: Table[string, Value]
  managedBindingPins: Table[string, seq[Scope]]
  wildcardFallbacks: Table[string, WildcardFallback]
  slots: seq[Value]
  slotTypes: seq[TypeBinding]
  varTypes: Table[string, TypeBinding]
  annotationSelfType: Value
  impls: seq[ProtocolImpl]
  requiredImplTypes: seq[Value]
  corePendingTypes: seq[Value]
  moduleRefs: ModuleRefTable
  supervisorEvents: Value
  supervisorDeadLetters: Value
  ownedTasks: seq[Value]
  ownedCleanupTasks: seq[Value]
  ownedActors: seq[Value]

proc takeRetiredBindings(s: Scope): RetiredScopeBindings =
  s.touchNames()
  result.vars = move s.vars
  result.managedBindingPins = move s.managedBindingPins
  result.wildcardFallbacks = move s.wildcardFallbacks
  result.slots = move s.slots
  result.slotTypes = move s.slotTypes
  result.varTypes = move s.varTypes
  result.annotationSelfType = move s.annotationSelfType
  result.impls = move s.impls
  result.requiredImplTypes = move s.requiredImplTypes
  result.corePendingTypes = move s.corePendingTypes
  result.moduleRefs = move s.moduleRefs
  result.supervisorEvents = move s.supervisorEvents
  result.supervisorDeadLetters = move s.supervisorDeadLetters
  result.ownedTasks = move s.ownedTasks
  result.ownedCleanupTasks = move s.ownedCleanupTasks
  result.ownedActors = move s.ownedActors
  s.slotNames.setLen(0)
  s.privateSlots.setLen(0)
  s.slotDefinedBits = 0
  s.slotDefinedOverflow.setLen(0)
  s.slotMirror = false
  s.varsDirty = false

proc moduleHeldOutside(root: Scope): bool =
  ## A root's Module is owned by its `this_mod` binding. Any further owner keeps
  ## the root alive through Module -> Namespace -> root, which is what the walk
  ## would conclude, so a retained generation skips it.
  var bits = 0'u64
  root.vars.withValue("this_mod", binding):
    bits = binding[].bits
  if bits shr TAG_SHIFT != OBJECT_TAG:
    return false
  let data {.cursor.} = cast[GeneObjectData](cast[pointer](bits and PAYLOAD_MASK))
  if data.objKind != okModule:
    return false
  let rootBits = cast[ModuleData](data).root.bits
  if rootBits shr TAG_SHIFT != OBJECT_TAG:
    return false
  let namespace {.cursor.} =
    cast[GeneObjectData](cast[pointer](rootBits and PAYLOAD_MASK))
  namespace.objKind == okNamespace and
    cast[NamespaceData](namespace).scope == root and
    nimStrongRefs(cast[pointer](data)) > 1

type RuntimeContextRoots* = object
  ## Exact owning fields of a private runtime context being relinquished.
  ## The lists add one temporary owner; owner tables count the original fields.
  scopes*: seq[Scope]
  values*: seq[Value]
  scopeOwners: Table[uint64, int]
  valueOwners: Table[uint64, int]

proc addOwnedScope*(roots: var RuntimeContextRoots, scope: Scope) =
  if scope == nil: return
  let key = cast[uint64](cast[pointer](scope))
  if not roots.scopeOwners.hasKey(key): roots.scopes.add scope
  roots.scopeOwners[key] = roots.scopeOwners.getOrDefault(key) + 1

proc addOwnedValue*(roots: var RuntimeContextRoots, value: Value) =
  if value.bits shr TAG_SHIFT < MANAGED_MIN or
      (value.bits and PAYLOAD_MASK) == 0: return
  if not roots.valueOwners.hasKey(value.bits): roots.values.add value
  roots.valueOwners[value.bits] = roots.valueOwners.getOrDefault(value.bits) + 1

proc currentEventLane*(): int {.inline.}

proc retirePendingScopes(pending: var seq[Scope], generations: bool,
                         extraOwners = 0, assumed = 0'u64,
                         assumedInternal: ptr int = nil,
                         complete = false,
                         context: RuntimeContext = nil,
                         contextRoots: ptr RuntimeContextRoots = nil): int =
  ## Trial deletion over `pending` roots; see retireReleasedGenerations.
  ## `extraOwners` counts known references to each root beyond the list.
  ## A nonzero `assumed` is a dry run: that value is expanded as though its
  ## outside references were gone, nothing is torn down, and the result is the
  ## number of roots that would retire, with the value's inside references
  ## stored in `assumedInternal`.
  when not nimRefCountReadable:
    return 0
  let privateRetirement = context != nil and context.privateCompilerContext and
    context.compilerOwnerLane == currentEventLane()
  when defined(gcAtomicArc):
    # Qualification-only: activation/returned-value collection has no worker
    # barrier. Generation callers must enter the VM's paused-root boundary.
    when defined(geneAtomicGenerationRetirementProbe):
      if not privateRetirement and (not generations or atomicGenerationRetirementBoundary == 0 or
          not retirementNativeAnalysisAdmitted()):
        return 0
    else:
      if not privateRetirement: return 0
  if pending.len == 0 or generationRetiring or not retirementSupported():
    return 0
  # Do not inspect a raw-exported root's mutable tables. The entire candidate
  # batch stays: weak relationships hidden there are not a stable snapshot.
  for root in pending:
    if root.scopePublishedForRetirement:
      return 0
  generationRetiring = true
  try:
    var g = RetireGraph(complete: complete,
      privateContext: if privateRetirement: context else: nil)
    var roots: seq[int]
    for root in pending:
      if root == nil:
        continue
      if generations and
          (not root.sandboxGenerationReleased or root.moduleHeldOutside()):
        continue
      let idx = g.scopeNode(root)
      if g.nodes[idx].expanded:
        continue
      if privateRetirement and g.nodes[idx].pinned: continue
      g.nodes[idx].total -= 1 + extraOwners # the pending list and known holders
      if contextRoots != nil:
        g.nodes[idx].total -= contextRoots[].scopeOwners.getOrDefault(cast[uint64](cast[pointer](root)))
      roots.add idx
      g.expandRetireScope(idx, counting = true)
    if contextRoots != nil:
      for value in contextRoots[].values:
        let idx = g.valueNode(value.bits)
        if idx >= 0:
          g.nodes[idx].total -= 1 + contextRoots[].valueOwners.getOrDefault(value.bits)
          if not g.nodes[idx].expanded: g.ready.add idx
    let assumedIdx = if assumed == 0: -1 else: g.valueNode(assumed)
    if assumedIdx >= 0 and not g.nodes[assumedIdx].expanded:
      g.expandRetireValue(assumedIdx, counting = true)
    while g.ready.len > 0:
      let idx = g.ready.pop()
      if g.nodes[idx].expanded:
        continue
      if privateRetirement and g.nodes[idx].pinned:
        # Private compiler cleanup has no cross-lane barrier. Shared Values
        # and foreign Scopes must remain opaque, including in normal builds.
        continue
      when defined(geneAtomicGenerationRetirementProbe):
        # A worker pause does not quiesce foreign native readers/mutators.
        # Published Values stay live; do not inspect/count their mutable edges.
        if g.nodes[idx].pinned:
          continue
      case g.nodes[idx].kind
      of rnkScope: g.expandRetireScope(idx, counting = true)
      of rnkValue: g.expandRetireValue(idx, counting = true)
      of rnkRefTable, rnkRefEntry: g.expandRetireModuleRef(idx)
      of rnkTaskState: g.expandRetireTaskState(idx)
      of rnkChannelState: g.expandRetireChannelState(idx)
    var queue: seq[int]
    for i in 0 ..< g.nodes.len:
      if g.nodes[i].internal > g.nodes[i].total:
        return 0 # an over-count means the edge inventory is wrong: retire nothing
      if not g.nodes[i].expanded or g.nodes[i].pinned or
          (g.nodes[i].internal < g.nodes[i].total and i != assumedIdx):
        g.nodes[i].live = true
        queue.add i
    template resolveWeakEdges(fromScope, fromValue: int) =
      for i in fromScope ..< g.weakScopes.len:
        let target = g.refIndex.getOrDefault(g.weakScopes[i].target, -1)
        if target >= 0 and g.nodes[target].kind == rnkScope:
          g.nodes[g.weakScopes[i].source].edges.add int32(target)
      for i in fromValue ..< g.weakValues.len:
        let target = g.valueIndex.getOrDefault(g.weakValues[i].target, -1)
        if target >= 0:
          g.nodes[g.weakValues[i].source].edges.add int32(target)
    resolveWeakEdges(0, 0)
    while queue.len > 0:
      let idx = queue.pop()
      if not g.nodes[idx].expanded and not g.nodes[idx].weakScanned:
        if g.nodes[idx].pinned and (privateRetirement or g.nodes[idx].kind == rnkScope):
          # Do not enumerate a raw-exported Scope on another lane.
          continue
        # An externally owned node can still hold a non-owning pointer into a
        # candidate (a Protocol's defining scope, a variant's Enum); that
        # target must outlive it.
        g.nodes[idx].weakScanned = true
        let fromScope = g.weakScopes.len
        let fromValue = g.weakValues.len
        case g.nodes[idx].kind
        of rnkScope: g.expandRetireScope(idx, counting = false)
        of rnkValue: g.expandRetireValue(idx, counting = false)
        of rnkRefTable, rnkRefEntry, rnkTaskState, rnkChannelState: discard
        resolveWeakEdges(fromScope, fromValue)
      for target in g.nodes[idx].edges:
        if not g.nodes[target].live:
          g.nodes[target].live = true
          queue.add int(target)
    if assumed != 0:
      if assumedIdx >= 0 and assumedInternal != nil:
        assumedInternal[] = g.nodes[assumedIdx].internal
      for idx in roots:
        if not g.nodes[idx].live:
          inc result
      return
    if context != nil:
      # Scope.application is not an edge in ordinary activation retirement.
      # For a whole private context, every such reference must be accounted
      # for, in addition to its one relinquishing owner. An unlisted scope,
      # native lease or SDK owner therefore prevents teardown conservatively.
      var owners = 1 + (if g.privateContext == context: 1 else: 0)
      for node in g.nodes:
        if node.kind == rnkScope and cast[Scope](node.address).application == context:
          inc owners
      if nimStrongRefs(cast[pointer](context)) != owners:
        return 0
      for idx in roots:
        if g.nodes[idx].live:
          return 0
    var doomed: seq[Scope]
    for i in 0 ..< g.nodes.len:
      if g.nodes[i].kind == rnkScope and g.nodes[i].expanded and
          not g.nodes[i].live:
        doomed.add cast[Scope](g.nodes[i].address)
    if doomed.len == 0:
      return 0
    var kept: seq[Scope]
    for root in pending:
      var retired = false
      for scope in doomed:
        if scope == root:
          retired = true
          break
      if not retired:
        kept.add root
    pending = kept
    var held: seq[RetiredScopeBindings]
    for scope in doomed:
      held.add scope.takeRetiredBindings()
    when defined(geneAtomicGenerationRetirementProbe):
      # Scope edges are detached and pinned Values remain in `held`. Reopen
      # native admission before invoking arbitrary last-owner cleanup.
      if not privateRetirement: finishRetirementNativeAnalysis()
    held.setLen(0)
    result = doomed.len
  finally:
    generationRetiring = false

proc retireReleasedGenerations*(pending: var seq[Scope]): int =
  ## Tears down released generation roots (and scopes they solely own) that
  ## nothing outside reaches any more. `pending` owns one reference to each
  ## root; retired roots are removed from it. Returns the number of scopes
  ## torn down. Callers must be on the owning lane with scheduler workers
  ## paused and no borrowed view into a pending generation, since counts are
  ## read as stable totals and teardown runs its releases immediately.
  retirePendingScopes(pending, generations = true)

proc retireReturningCallScope*(scope: Scope, owners = 1): int =
  ## Tears down a returning call scope that only its own closures still reach
  ## (see callScopeMayCycle), leaving the Scope object to its frame. `owners`
  ## counts its known holders: the frame's register, plus a finished fiber's
  ## own field. Same contract as retireReleasedGenerations otherwise.
  var pending = @[scope]
  retirePendingScopes(pending, generations = false, extraOwners = owners)

proc retireEvaluationScope*(scope: Scope): int =
  ## A host relinquishing an isolated evaluation root needs the complete
  ## reachable graph: a Type returned by nested eval can hold child scopes
  ## whose bindings supply its remaining owners. Waiting for all owners before
  ## expanding that Type would mistake this closed cycle for outside ownership.
  ## Live outside owners still seed liveness and keep everything they reach.
  ## The ordinary activation retirement path keeps its smaller, cheaper walk.
  var pending = @[scope]
  retirePendingScopes(pending, generations = false, extraOwners = 1,
                      complete = true)

proc retireRuntimeContextScopes*(context: RuntimeContext,
                                roots: var RuntimeContextRoots): bool =
  ## All-or-nothing trial deletion for a private, quiescent runtime context.
  ## On success the caller must release the owning fields recorded in roots.
  ## Outside references preserve the entire context. AtomicArc admits only an
  ## unpublished private compiler context on its owner lane; shared graphs retain
  ## the existing qualified-retirement requirement.
  if context != nil and context.privateCompilerContext and
      context.compilerOwnerLane != currentEventLane():
    return false
  retirePendingScopes(roots.scopes, generations = false, complete = true,
    context = context, contextRoots = addr roots) > 0

proc scopeHasOtherOwners*(scope: Scope): bool {.inline.} =
  ## Whether something besides the caller's one reference owns `scope`: the
  ## cheap first test before callScopeMayCycle, kept inline so a scope nothing
  ## else holds costs one header load. Always false where ORC counts cannot be
  ## read; callScopeMayCycle still checks the layout probe.
  when nimRefCountReadable and not defined(gcAtomicArc):
    nimStrongRefs(cast[pointer](scope)) > 1
  else:
    false

proc scopeIsUniquelyOwned*(scope: Scope): bool {.inline.} =
  ## Positive proof for reusing an ended activation. Unlike the retirement
  ## shortcut above, unavailable refcounts must never count as uniqueness.
  when nimRefCountReadable and not defined(gcAtomicArc):
    scope != nil and retirementSupported() and
      nimStrongRefs(cast[pointer](scope)) == 1
  else:
    false

proc capturesScopeChain(v: Value, owner: Scope, budget: var int,
                        seen: var HashSet[uint64], nested: bool): bool =
  ## Whether `v` reaches, directly or through lists, maps, nodes, and Cells, a
  ## closure that captured `owner` or one of its child scopes. At the top level
  ## (`nested` false) a promoted binding capturing `owner` itself does not
  ## count: it drops its edge again when its escaped copy is released. An
  ## exhausted budget answers true.
  dec budget
  if budget < 0:
    return true
  let bits = v.bits
  case bits shr TAG_SHIFT
  of FUNCTION_TAG:
    let p = cast[ptr GeneFunction](bits and PAYLOAD_MASK)
    if p.scope == owner:
      return nested or not p.weakable
    # A closure that copied its captures holds no activation scope, but a
    # copied value can still reach `owner`.
    var copy {.cursor.} = p.scope
    while copy != nil and copy.captureMirror:
      for i in 0 ..< copy.slots.len:
        if capturesScopeChain(copy.slots[i], owner, budget, seen, nested = true):
          return true
      copy = copy.parent
    var current = if p.scope != nil: p.scope.parent else: nil
    while current != nil:
      if current == owner:
        return true
      current = current.parent
    false
  of LIST_TAG:
    if seen.containsOrIncl(bits):
      return false
    let p = cast[ptr GeneList](bits and PAYLOAD_MASK)
    for i in 0 ..< p.items.len:
      if capturesScopeChain(p.items[i], owner, budget, seen, nested = true):
        return true
    false
  of MAP_TAG:
    if seen.containsOrIncl(bits):
      return false
    let p = cast[ptr GeneMap](bits and PAYLOAD_MASK)
    for i in 0 ..< p.entries.data.len:
      if capturesScopeChain(p.entries.data[i].val, owner, budget, seen,
                            nested = true):
        return true
    false
  of NODE_TAG:
    if seen.containsOrIncl(bits):
      return false
    let p = cast[ptr GeneNode](bits and PAYLOAD_MASK)
    for i in 0 ..< p.props.data.len:
      if capturesScopeChain(p.props.data[i].val, owner, budget, seen,
                            nested = true):
        return true
    for i in 0 ..< p.body.len:
      if capturesScopeChain(p.body[i], owner, budget, seen, nested = true):
        return true
    false
  of CYCLE_OBJECT_TAG:
    # A Cell's value is walked; trial deletion counts its edges. Envs,
    # streams, Tasks, and other objects are not: their closures are left to
    # the object-cycle path or stay retained.
    if seen.containsOrIncl(bits):
      return false
    let data {.cursor.} = cast[GeneObjectData](cast[pointer](bits and PAYLOAD_MASK))
    data.objKind == okCell and
      capturesScopeChain(CellData(data).value, owner, budget, seen,
                         nested = true)
  else:
    false

proc callScopeMayCycle*(scope: Scope): bool =
  ## Whether a scope whose activation ended may be kept alive only by a cycle
  ## through its own bindings: something besides the ending register still
  ## owns it, and a binding reaches a closure that captured it or one of its
  ## child scopes. A child's parent edge, or a container's edge to a closure
  ## over the scope itself, closes scope -> value -> closure -> scope; the weak
  ## captured-scope edge covers only a function bound directly in the scope
  ## that captured it. An oversized walk answers true; trial deletion decides.
  when not nimRefCountReadable or defined(gcAtomicArc):
    return false
  if scope == nil or not retirementSupported() or
      nimStrongRefs(cast[pointer](scope)) <= 1:
    return false
  var budget = 4096
  var seen: HashSet[uint64]
  for i in 0 ..< scope.slots.len:
    if capturesScopeChain(scope.slots[i], scope, budget, seen, nested = false):
      return true
  for v in scope.vars.values:
    if capturesScopeChain(v, scope, budget, seen, nested = false):
      return true
  false

proc returnedValueHoldsScope*(returned: Value, scope: Scope): bool =
  ## Whether a returned value holds a closure over `scope` or one of its child
  ## scopes. The return register then owns part of any cycle through `scope`,
  ## so retiring it now cannot succeed; watchReturnedCycle decides alone.
  var budget = 4096
  var seen: HashSet[uint64]
  capturesScopeChain(returned, scope, budget, seen, nested = true)

type
  CycleWatch = object
    root: Scope     # reached through the watched value, so this pins nothing new
    internal: int   # the value's references from inside the cycle
    queued: bool

  CycleWatches = object
    watches: Table[uint64, CycleWatch]
    recheckBits: seq[uint64]  # watched values released to their inside references
    recheckRoots: seq[Scope]  # roots whose watched value was freed

# Never freed: a watch still open at exit holds Scopes whose Application the
# VM module's globals have already destroyed.
var cycleWatchState: ptr CycleWatches
var cycleRecheckPending*: bool     # read by the VM on its return paths

proc cycleWatchesState(): ptr CycleWatches {.inline.} =
  if cycleWatchState == nil:
    cycleWatchState = create(CycleWatches)
  cycleWatchState

proc watchableShared(bits: uint64): bool =
  ## Whether `bits` is a watchable kind (list, map, node, function, Cell) that
  ## stays on the owning lane.
  let payload = bits and PAYLOAD_MASK
  if payload == 0:
    return false
  case bits shr TAG_SHIFT
  of LIST_TAG: not isSharedFlag(cast[ptr GeneList](payload).shared)
  of MAP_TAG: not isSharedFlag(cast[ptr GeneMap](payload).shared)
  of NODE_TAG: not isSharedFlag(cast[ptr GeneNode](payload).shared)
  of FUNCTION_TAG: not isSharedFlag(cast[ptr GeneFunction](payload).shared)
  of CYCLE_OBJECT_TAG:
    let data {.cursor.} = cast[GeneObjectData](cast[pointer](payload))
    data.objKind == okCell and not isSharedFlag(data.shared)
  else: false

proc setCycleWatched(bits: uint64) =
  let payload = bits and PAYLOAD_MASK
  case bits shr TAG_SHIFT
  of LIST_TAG: cast[ptr GeneList](payload).cycleWatched = true
  of MAP_TAG: cast[ptr GeneMap](payload).cycleWatched = true
  of NODE_TAG: cast[ptr GeneNode](payload).cycleWatched = true
  of FUNCTION_TAG: cast[ptr GeneFunction](payload).cycleWatched = true
  of CYCLE_OBJECT_TAG:
    CellData(cast[GeneObjectData](cast[pointer](payload))).cycleWatched = true
  else: discard

proc watchReturnedCycle*(root: Scope, returned: Value, owners = 1): bool =
  ## A returning call scope that failed retirement because the value it
  ## returns still reaches its cycle (the value, or a closure or container in
  ## it, is also bound there) retires once the caller lets that value go. A dry
  ## run decides whether the scope would retire without the value's outside
  ## references; if so, the value is watched and the scope is rechecked when
  ## the value is released down to its references from inside the cycle, or
  ## freed. `owners` counts `root`'s known holders, as for
  ## retireReturningCallScope.
  let bits = returned.bits
  if not watchableShared(bits) or cycleWatchesState().watches.hasKey(bits):
    return false
  var internal = 0
  var pending = @[root]
  if retirePendingScopes(pending, generations = false, extraOwners = owners,
                         assumed = bits, assumedInternal = addr internal) == 0:
    return false
  cycleWatchesState().watches[bits] = CycleWatch(root: root, internal: internal)
  setCycleWatched(bits)
  true

proc noteWatchedRelease(bits: uint64, remaining: int) {.noinline.} =
  ## A watched value was released; `remaining` is zero when it is being freed
  ## (for a Cell, when no Value holds it any more).
  ## The recheck waits for the VM's next return: a release can run anywhere,
  ## including under a borrowed view into the candidate scope.
  let state = cycleWatchesState()
  if remaining == 0:
    var watch: CycleWatch
    if state.watches.pop(bits, watch):
      state.recheckRoots.add move watch.root
      cycleRecheckPending = true
  else:
    state.watches.withValue(bits, watch):
      if not watch.queued and remaining <= watch.internal:
        watch.queued = true
        state.recheckBits.add bits
        cycleRecheckPending = true

proc drainCycleRechecks*(): int =
  ## Retire the scopes of watched values released since the last drain and
  ## return how many scopes were torn down. Callers are VM return paths with
  ## the same contract as retireReturningCallScope.
  if generationRetiring:
    return 0
  let state = cycleWatchesState()
  while state.recheckRoots.len > 0 or state.recheckBits.len > 0:
    # Each pending list holds exactly one reference of its own; a local copy
    # would be moved into it on last use, so none is kept.
    var pending: seq[Scope]
    var extraOwners = 0
    if state.recheckRoots.len > 0:
      pending.add state.recheckRoots.pop()
    else:
      let bits = state.recheckBits.pop()
      state.watches.withValue(bits, watch):
        watch.queued = false
        pending.add watch.root
        extraOwners = 1 # the watch entry
    if pending.len > 0:
      result += retirePendingScopes(pending, generations = false,
                                    extraOwners = extraOwners)
  cycleRecheckPending = false

proc cycleWatchCount*(): int =
  ## Values currently watched for a returned closure cycle (diagnostics).
  cycleWatchesState().watches.len

proc isPromotedBindingFunction(v: Value): bool {.inline.} =
  if v.bits shr TAG_SHIFT != FUNCTION_TAG:
    return false
  let p = cast[ptr GeneFunction](v.bits and PAYLOAD_MASK)
  p.weakable and p.scope != nil

type
  FunctionCandidates = object
    ## Promoted bindings collected from one released value. There are usually
    ## one or two, so they live inline and a release allocates nothing.
    inline: array[4, uint64]
    count: int
    overflow: seq[uint64]

proc add(candidates: var FunctionCandidates, bits: uint64) {.inline.} =
  if candidates.count < candidates.inline.len:
    candidates.inline[candidates.count] = bits
  else:
    candidates.overflow.add bits
  inc candidates.count

template collectPromotedBindingFunction(candidates: var FunctionCandidates, value: Value) =
  block:
    let itemBits = value.bits
    if itemBits shr TAG_SHIFT == FUNCTION_TAG:
      let fnp = cast[ptr GeneFunction](itemBits and PAYLOAD_MASK)
      if fnp.weakable and fnp.scope != nil:
        candidates.add itemBits

proc bindingReferences(owner: Scope, key: uint64): int =
  for i in 0 ..< owner.slots.len:
    if owner.slots[i].bits == key:
      inc result
  for value in owner.vars.values:
    if value.bits == key:
      inc result

proc shallowOwnedReferences(owner: Scope, target: uint64, exact: var bool): int =
  ## Allocation-free count of references to `target` held by the scope's
  ## bindings, directly or as items of containers those bindings wholly own.
  ## It never over-counts. `exact` turns false when such a container holds a
  ## further container this count does not follow.
  exact = true
  # These fields own Values as well, but the hot shallow path only indexes
  # bindings. A full walk is needed whenever any of them is populated.
  if owner.wildcardFallbacks.len > 0 or owner.slotTypes.len > 0 or
      owner.varTypes.len > 0 or owner.corePendingTypes.len > 0 or
      owner.requiredImplTypes.len > 0 or owner.moduleRefs != nil or
      owner.ownedTasks.len > 0 or owner.ownedCleanupTasks.len > 0 or
      owner.ownedActors.len > 0 or owner.annotationSelfType.bits != 0 or
      owner.supervisorEvents.bits != 0 or owner.supervisorDeadLetters.bits != 0 or
      owner.impls.len > 0:
    exact = false
  var total = 0
  template item(value: Value) =
    block:
      let itemBits = value.bits
      let tag = itemBits shr TAG_SHIFT
      if itemBits == target:
        inc total
      elif tag == LIST_TAG or tag == MAP_TAG or tag == NODE_TAG or
          tag == CYCLE_OBJECT_TAG:
        exact = false
  template root(key: uint64) =
    if key == target:
      inc total
    else:
      case key shr TAG_SHIFT
      of LIST_TAG:
        let c = cast[ptr GeneList](key and PAYLOAD_MASK)
        if not isSharedFlag(c.shared) and c.refCount == bindingReferences(owner, key):
          for i in 0 ..< c.items.len:
            item(c.items[i])
      of MAP_TAG:
        let c = cast[ptr GeneMap](key and PAYLOAD_MASK)
        if not isSharedFlag(c.shared) and c.refCount == bindingReferences(owner, key):
          for i in 0 ..< c.entries.data.len:
            item(c.entries.data[i].val)
      of NODE_TAG:
        let c = cast[ptr GeneNode](key and PAYLOAD_MASK)
        if not isSharedFlag(c.shared) and c.refCount == bindingReferences(owner, key):
          item(c.head)
          for i in 0 ..< c.props.data.len:
            item(c.props.data[i].val)
          for i in 0 ..< c.body.len:
            item(c.body[i])
          for i in 0 ..< c.meta.data.len:
            item(c.meta.data[i].val)
      of CYCLE_OBJECT_TAG:
        let data = cast[GeneObjectData](cast[pointer](key and PAYLOAD_MASK))
        if data.objKind == okCell and not isSharedFlag(data.shared) and
            CellData(data).cycleRefs == bindingReferences(owner, key):
          item(CellData(data).value)
      else: discard
  # A container bound more than once is counted at its first binding only.
  for i in 0 ..< owner.slots.len:
    let key = owner.slots[i].bits
    var seen = false
    for j in 0 ..< i:
      if owner.slots[j].bits == key:
        seen = true
        break
    if not seen:
      root(key)
  var varIndex = 0
  for value in owner.vars.values:
    let key = value.bits
    var seen = false
    for i in 0 ..< owner.slots.len:
      if owner.slots[i].bits == key:
        seen = true
        break
    if not seen:
      var earlier = 0
      for other in owner.vars.values:
        if earlier == varIndex:
          break
        if other.bits == key:
          seen = true
          break
        inc earlier
    if not seen:
      root(key)
    inc varIndex
  total

var weakeningOwnedFunctions {.threadvar.}: bool

proc weakenOwnedFunctions(candidates: FunctionCandidates) =
  ## A scope binding promoted when it escaped drops its strong back-edge again
  ## once every remaining reference belongs to its defining scope. Scopes retire
  ## only after every candidate is checked: retiring one can release the others
  ## and the container whose release triggered the check.
  # The ownership walk copies and releases values of its own; those releases
  # must not start a nested check of the same graph.
  if weakeningOwnedFunctions:
    return
  weakeningOwnedFunctions = true
  var retired: array[4, Scope]
  var retiredCount = 0
  var retiredMore: seq[Scope]
  for index in 0 ..< candidates.count:
    let bits =
      if index < candidates.inline.len: candidates.inline[index]
      else: candidates.overflow[index - candidates.inline.len]
    let p = cast[ptr GeneFunction](bits and PAYLOAD_MASK)
    if not p.weakable or p.scope == nil or isSharedFlag(p.shared) or
        cast[pointer](p.scope) != p.weakScope:
      continue
    let owner {.cursor.} = p.scope
    if owner.isLoadedModuleRoot:
      continue
    # The shallow count settles the usual shapes without allocating; the full
    # walk runs only when an owned container nests further containers.
    var exact = true
    if shallowOwnedReferences(owner, bits, exact) == p.refCount or
        (not exact and scopeOwnedReferences(owner, bits) == p.refCount):
      if retiredCount < retired.len:
        retired[retiredCount] = move p.scope
        inc retiredCount
      else:
        retiredMore.add move p.scope
  weakeningOwnedFunctions = false
  for i in 0 ..< retiredCount:
    retired[i] = nil
  retiredMore.setLen(0)

proc markEscapedFunctionHolder(container: Value) =
  ## Releasing a container that holds a promoted scope binding rechecks whether
  ## the binding's defining scope is again its only owner.
  case container.bits shr TAG_SHIFT
  of LIST_TAG:
    cast[ptr GeneList](container.bits and PAYLOAD_MASK).holdsEscapedFn = true
  of MAP_TAG:
    cast[ptr GeneMap](container.bits and PAYLOAD_MASK).holdsEscapedFn = true
  of NODE_TAG:
    cast[ptr GeneNode](container.bits and PAYLOAD_MASK).holdsEscapedFn = true
  of CYCLE_OBJECT_TAG:
    let data = cast[GeneObjectData](cast[pointer](container.bits and PAYLOAD_MASK))
    if data.objKind == okCell:
      CellData(data).holdsEscapedFn = true
  else: discard

proc noteFunctionStore*(container, stored: Value) =
  ## Record that `container` now holds `stored`, a possibly promoted binding.
  if stored.isPromotedBindingFunction:
    markEscapedFunctionHolder(container)

proc weakenEscapedListItems(p: ptr GeneList) =
  var candidates: FunctionCandidates
  for i in 0 ..< p.items.len:
    collectPromotedBindingFunction(candidates, p.items[i])
  if candidates.count == 0:
    p.holdsEscapedFn = false
  else:
    weakenOwnedFunctions(candidates)

proc weakenEscapedMapItems(p: ptr GeneMap) =
  var candidates: FunctionCandidates
  for i in 0 ..< p.entries.data.len:
    collectPromotedBindingFunction(candidates, p.entries.data[i].val)
  if candidates.count == 0:
    p.holdsEscapedFn = false
  else:
    weakenOwnedFunctions(candidates)

proc rcRelease(bits: uint64) =
  ## Most releases leave the object alive. For a manual object that counts in
  ## place and has no release-time bookkeeping that is a single decrement: no call is made,
  ## so no pending-exception check can cut it short. The count is known to
  ## exceed one, so the unchecked decrement cannot wrap.
  let payload = bits and PAYLOAD_MASK
  if payload != 0:
    case bits shr TAG_SHIFT
    of STRING_TAG:
      let p = cast[ptr GeneString](payload)
      if countsInPlace(p) and p.refCount > 1:
        p.refCount = p.refCount -% 1
        return
      releasePublished(p, true)
    of INT64_TAG:
      let p = cast[ptr GeneInt64](payload)
      if countsInPlace(p) and p.refCount > 1:
        p.refCount = p.refCount -% 1
        return
      releasePublished(p, true)
    of LIST_TAG:
      let p = cast[ptr GeneList](payload)
      if countsInPlace(p) and p.refCount > 1 and
          not p.cycleWatched and not p.holdsEscapedFn:
        p.refCount = p.refCount -% 1
        return
      releasePublished(p, not p.cycleWatched)
    of MAP_TAG:
      let p = cast[ptr GeneMap](payload)
      if countsInPlace(p) and p.refCount > 1 and
          not p.cycleWatched and not p.holdsEscapedFn:
        p.refCount = p.refCount -% 1
        return
      releasePublished(p, not p.cycleWatched)
    of NODE_TAG:
      let p = cast[ptr GeneNode](payload)
      if countsInPlace(p) and p.refCount > 1 and
          not p.cycleWatched and not p.holdsEscapedFn and
          p.errorEvidence == nil:
        p.refCount = p.refCount -% 1
        return
      releasePublished(p, not p.cycleWatched)
    of FUNCTION_TAG:
      let p = cast[ptr GeneFunction](payload)
      if countsInPlace(p) and p.refCount > 1 and
          not p.cycleWatched and not (p.weakable and p.scope != nil):
        p.refCount = p.refCount -% 1
        return
      releasePublished(p, not p.cycleWatched and not (p.weakable and p.scope != nil))
    of NATIVE_FN_TAG:
      let p = cast[ptr GeneNativeFn](payload)
      if countsInPlace(p) and p.refCount > 1:
        p.refCount = p.refCount -% 1
        return
      releasePublished(p, true)
    else:
      discard
  rcReleaseOther(bits)

proc rcReleaseFull(bits: uint64) =
  when compileOption("exceptions", "goto"):
    # Nim can destroy a Value before clearing the pending-exception flag (see
    # pending_exception.nim). The error checks after this body's own calls
    # would then return mid-release, skipping the free or GC_unref and leaking
    # whatever the value owned. Run the release as if nothing were pending,
    # then restore the flag. Recursion rather than withoutPendingException
    # keeps the common path to one flag load.
    let pending = pendingExceptionFlag()
    if unlikely(pending[]):
      pending[] = false
      rcReleaseFull(bits)
      pending[] = true
      return
  let payload = bits and PAYLOAD_MASK
  if payload == 0: return
  case bits shr TAG_SHIFT
  of STRING_TAG:
    let p = cast[ptr GeneString](payload)
    releaseManual(p):
      reset(p[]); dealloc(p); trackFree(GeneString)
  of INT64_TAG:
    let p = cast[ptr GeneInt64](payload)
    releaseManual(p):
      reset(p[]); dealloc(p); trackFree(GeneInt64)
  of LIST_TAG:
    let p = cast[ptr GeneList](payload)
    releaseManual(p):
      if unlikely(p.cycleWatched): noteWatchedRelease(bits, 0)
      reset(p[]); dealloc(p); trackFree(GeneList)
      return
    if unlikely(p.cycleWatched): noteWatchedRelease(bits, p.refCount)
    if p.holdsEscapedFn and not isSharedFlag(p.shared):
      weakenEscapedListItems(p)
  of MAP_TAG:
    let p = cast[ptr GeneMap](payload)
    releaseManual(p):
      if unlikely(p.cycleWatched): noteWatchedRelease(bits, 0)
      reset(p[]); dealloc(p); trackFree(GeneMap)
      return
    if unlikely(p.cycleWatched): noteWatchedRelease(bits, p.refCount)
    if p.holdsEscapedFn and not isSharedFlag(p.shared):
      weakenEscapedMapItems(p)
  of NODE_TAG:
    let p = cast[ptr GeneNode](payload)
    releaseManual(p):
      if unlikely(p.cycleWatched): noteWatchedRelease(bits, 0)
      if p.resourceId != 0 and resourceReleaseHook != nil:
        resourceReleaseHook(p.resourceId)
      reset(p[]); dealloc(p); trackFree(GeneNode)
      return
    if unlikely(p.cycleWatched): noteWatchedRelease(bits, p.refCount)
    if p.holdsEscapedFn and not isSharedFlag(p.shared):
      var candidates: FunctionCandidates
      collectPromotedBindingFunction(candidates, p.head)
      for i in 0 ..< p.props.data.len:
        collectPromotedBindingFunction(candidates, p.props.data[i].val)
      for i in 0 ..< p.body.len:
        collectPromotedBindingFunction(candidates, p.body[i])
      for i in 0 ..< p.meta.data.len:
        collectPromotedBindingFunction(candidates, p.meta.data[i].val)
      if candidates.count > 0:
        # Weakening can release this node; leave its error environment for a
        # later release.
        weakenOwnedFunctions(candidates)
        return
      p.holdsEscapedFn = false
    weakenOwnedErrorEnvironment(p, bits)
  of FUNCTION_TAG:
    let p = cast[ptr GeneFunction](payload)
    releaseManual(p):
      if unlikely(p.cycleWatched): noteWatchedRelease(bits, 0)
      reset(p[]); dealloc(p); trackFree(GeneFunction)
      return
    if unlikely(p.cycleWatched): noteWatchedRelease(bits, p.refCount)
    if p.weakable and p.scope != nil:
      var candidates: FunctionCandidates
      candidates.add bits
      weakenOwnedFunctions(candidates)
  of NATIVE_FN_TAG:
    let p = cast[ptr GeneNativeFn](payload)
    releaseManual(p):
      reset(p[]); dealloc(p); trackFree(GeneNativeFn)
  of CYCLE_OBJECT_TAG:
    let data = cast[GeneObjectData](cast[pointer](payload))
    var shouldTryCycle = false
    case data.objKind
    of okEnv:
      let d = EnvData(data)
      let newRefs =
        when threadedRc:
          if isSharedFlag(data.shared):
            atomicFetchSub(addr d.cycleRefs, 1, ATOMIC_ACQ_REL) - 1
          else:
            if d.cycleRefs > 0:
              dec d.cycleRefs
            d.cycleRefs
        else:
          if d.cycleRefs > 0:
            dec d.cycleRefs
          d.cycleRefs
      shouldTryCycle = newRefs > 0
    of okCell, okAtomicCell:
      let d = CellData(data)
      let newRefs =
        when threadedRc:
          if isSharedFlag(data.shared):
            atomicFetchSub(addr d.cycleRefs, 1, ATOMIC_ACQ_REL) - 1
          else:
            if d.cycleRefs > 0:
              dec d.cycleRefs
            d.cycleRefs
        else:
          if d.cycleRefs > 0:
            dec d.cycleRefs
          d.cycleRefs
      shouldTryCycle = newRefs > 0
      if unlikely(d.cycleWatched): noteWatchedRelease(bits, newRefs)
      if newRefs > 0 and d.holdsEscapedFn and not isSharedFlag(data.shared):
        # The pending GC_unref below still pins this cell while scopes retire.
        var candidates: FunctionCandidates
        collectPromotedBindingFunction(candidates, d.value)
        if candidates.count == 0:
          d.holdsEscapedFn = false
        else:
          weakenOwnedFunctions(candidates)
    else:
      discard
    GC_unref(data)
    if shouldTryCycle:
      tryCollectObjectCycle(data)
  of OBJECT_TAG:
    let data = cast[GeneObjectData](cast[pointer](payload))
    if data.objKind == okModule:
      let module = ModuleData(data)
      when threadedRc:
        if isSharedFlag(data.shared):
          discard atomicFetchSub(addr module.valueRefs, 1, ATOMIC_ACQ_REL)
        else:
          dec module.valueRefs
      else:
        dec module.valueRefs
    elif data.objKind == okProtocol:
      let protocol = ProtocolData(data)
      when threadedRc:
        if isSharedFlag(data.shared):
          discard atomicFetchSub(addr protocol.valueRefs, 1, ATOMIC_ACQ_REL)
        else:
          dec protocol.valueRefs
      else:
        dec protocol.valueRefs
    elif data.objKind == okType:
      let typ = TypeData(data)
      when threadedRc:
        if isSharedFlag(data.shared):
          discard atomicFetchSub(addr typ.valueRefs, 1, ATOMIC_ACQ_REL)
        else:
          dec typ.valueRefs
      else:
        dec typ.valueRefs
      weakenOwnedTypeEnvironment(typ, bits)
    GC_unref(data)
  else: discard

# ---------------------------------------------------------------------------
# Singletons
# ---------------------------------------------------------------------------

let
  NIL* = Value(bits: 0)
  VOID* = mkImm(VOID_TAG)
  TRUE* = mkImm(BOOL_TAG, 1)
  FALSE* = mkImm(BOOL_TAG, 0)

# ---------------------------------------------------------------------------
# Introspection accessors
# These are read-only projections. Future VM/runtime mutation should use
# dedicated update APIs rather than mutating seq/table values returned here.
# ---------------------------------------------------------------------------

proc isHeapBacked*(v: Value): bool {.inline.} =
  v.isManaged

const objKindValueKinds: array[ObjKind, ValueKind] = [
  ## `ObjKind` -> `ValueKind`, as a table rather than a `case`.
  ##
  ## `kind` is `{.inline.}` and is the hottest read in the VM, so its *body
  ## size* is part of the interface: a switch here grew with every heap kind
  ## added, and once it grew past what the C compiler would inline, every
  ## `kind` call in the interpreter became a real call. Adding the six event
  ## value kinds crossed that line and cost ~7% across the VM benchmarks —
  ## uniformly, which is the signature of a lost inline rather than of new
  ## work. A table is O(1) in code size, so the next kind is free.
  ##
  ## Two entries are not identities and must stay in sync with their arms:
  ## `okEnum` is a `vkType` (an enum *is* a type value), and `okBoundMessage`
  ## is a `vkProtocolMessage`. `okEnv` is the one kind the table cannot answer
  ## — a borrowed Env is a `vkCallerEnv` — so `kind` special-cases it below.
  okNamespace: vkNamespace,
  okModule: vkModule,
  okBigInt: vkInt,
  okBytes: vkBytes,
  okRegex: vkRegex,
  okRange: vkRange,
  okDate: vkDate,
  okTime: vkTime,
  okDateTime: vkDateTime,
  okTimezone: vkTimezone,
  okDuration: vkDuration,
  okSet: vkSet,
  okHashMap: vkHashMap,
  okPipeline: vkPipeline,
  okCallableView: vkCallableView,
  okEnv: vkEnv,
  okCell: vkCell,
  okAtomicCell: vkAtomicCell,
  okStream: vkStream,
  okTask: vkTask,
  okChannel: vkChannel,
  okActorRef: vkActorRef,
  okActorContext: vkActorContext,
  okActorStep: vkActorStep,
  okReplyTo: vkReplyTo,
  okCPtr: vkCPtr,
  okCSlice: vkCSlice,
  okBuffer: vkBuffer,
  okDeviceBuffer: vkDeviceBuffer,
  okFfiLibrary: vkFfiLibrary,
  okFfiCallable: vkFfiCallable,
  okLogger: vkLogger,
  okEventBus: vkEventBus,
  okEventSubscription: vkEventSubscription,
  okEventMatcher: vkEventMatcher,
  okRecordingSink: vkRecordingSink,
  okNullSink: vkNullSink,
  okCompositeSink: vkCompositeSink,
  okType: vkType,
  okEnum: vkType,
  okProtocol: vkProtocol,
  okProtocolMessage: vkProtocolMessage,
  okBoundMessage: vkProtocolMessage,
  okEnumVariant: vkEnumVariant,
]

proc kind*(v: Value): ValueKind {.inline, raises: [].} =
  if v.bits == 0: return vkNil
  let tag = v.bits shr TAG_SHIFT
  if tag < VOID_TAG: return vkFloat   # direct float (incl. +/-Inf, canonical NaN)
  case tag
  of VOID_TAG: vkVoid
  of BOOL_TAG: vkBool
  of INT_TAG: vkInt
  of CHAR_TAG: vkChar
  of FLOATZERO_TAG: vkFloat
  of SYMBOL_TAG: vkSymbol
  of STRING_TAG: vkString
  of INT64_TAG: vkInt
  of LIST_TAG: vkList
  of MAP_TAG: vkMap
  of NODE_TAG: vkNode
  of FUNCTION_TAG: vkFunction
  of NATIVE_FN_TAG: vkNativeFn
  of CYCLE_OBJECT_TAG, OBJECT_TAG:
    let objKind = objData(v).objKind
    if objKind == okEnv:
      # `cast`, not `EnvData(...)`. The checked downcast emits an
      # `isObjDisplayCheck` that can `raiseObjectConversionError`, and one
      # possible raise anywhere in this proc compiles *every* `kind` call — the
      # hottest read in the VM — with the goto-exception preamble: a
      # thread-local `nimErrorFlag()` load on entry plus a branch after each
      # inner call. The test above has already established the dynamic type, so
      # the check can only ever succeed.
      if cast[EnvData](objData(v)).borrowed: vkCallerEnv else: vkEnv
    else:
      objKindValueKinds[objKind]
  else: vkNil

proc isNil*(v: Value): bool {.inline.} =
  v.bits == 0

proc boolVal*(v: Value): bool {.inline.} =
  if v.tagOf != BOOL_TAG:
    raise newException(FieldDefect, "value is not a Bool")
  (v.bits and PAYLOAD_MASK) != 0

proc intVal*(v: Value): int64 {.inline.} =
  case v.bits shr TAG_SHIFT
  of INT_TAG: decodeSmallInt(v.bits)
  of INT64_TAG: cast[ptr GeneInt64](v.bits and PAYLOAD_MASK).i
  of OBJECT_TAG:
    if objData(v).objKind == okBigInt:
      let converted = bigToInt64(BigIntData(objData(v)).value)
      if converted.ok:
        return converted.value
      raise newException(FieldDefect, "Int does not fit in int64")
    raise newException(FieldDefect, "value is not an Int")
  else:
    raise newException(FieldDefect, "value is not an Int")

proc intFitsInt64*(v: Value): bool =
  if v.kind != vkInt:
    return false
  try:
    discard v.intVal
    true
  except FieldDefect:
    false

proc floatVal*(v: Value): float64 {.inline.} =
  if v.isImmediateFloat:
    return cast[float64](v.bits)
  if v.tagOf == FLOATZERO_TAG:
    return 0.0
  raise newException(FieldDefect, "value is not a Float")

proc strVal*(v: Value): lent string =
  if v.tagOf != STRING_TAG:
    raise newException(FieldDefect, "value is not a String")
  cast[ptr GeneString](v.bits and PAYLOAD_MASK).s

# A Str used as a map or property key is resolved to its interned key id, which
# costs a lock and a hash of the text. A Str's text never changes, so the id is
# remembered on the object: the same key object — a constant in code, or a
# value reused across calls — resolves once. Only a positive answer is stored;
# "never interned" can stop being true. Racing writers store the same id.

template loadCachedKeyId(p: ptr GeneString): int32 =
  when threadedRc: atomicLoadN(addr p.keyId, ATOMIC_RELAXED)
  else: p.keyId

template storeCachedKeyId(p: ptr GeneString, id: int32) =
  when threadedRc: atomicStoreN(addr p.keyId, id, ATOMIC_RELAXED)
  else: p.keyId = id

proc strKeyId*(v: Value): int32 =
  ## Key id of a Str's text, interning it.
  if v.tagOf != STRING_TAG:
    raise newException(FieldDefect, "value is not a String")
  let p = cast[ptr GeneString](v.bits and PAYLOAD_MASK)
  let cached = loadCachedKeyId(p)
  if cached != 0:
    return cached - 1
  result = internSymbolId(p.s)
  storeCachedKeyId(p, result + 1)

proc strLookupKeyId*(v: Value): int32 =
  ## Key id of a Str's text, or -1 when that text was never interned (so it is
  ## a miss for every PropTable). Never grows the intern table.
  if v.tagOf != STRING_TAG:
    raise newException(FieldDefect, "value is not a String")
  let p = cast[ptr GeneString](v.bits and PAYLOAD_MASK)
  let cached = loadCachedKeyId(p)
  if cached != 0:
    return cached - 1
  result = lookupSymbolId(p.s)
  if result >= 0:
    storeCachedKeyId(p, result + 1)

proc bytesVal*(v: Value): lent string =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okBytes:
    raise newException(FieldDefect, "value is not Bytes")
  BytesData(objData(v)).data

proc regexPattern*(v: Value): lent string =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okRegex:
    raise newException(FieldDefect, "value is not a Regex")
  RegexData(objData(v)).pattern

proc regexFlags*(v: Value): lent string =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okRegex:
    raise newException(FieldDefect, "value is not a Regex")
  RegexData(objData(v)).flags

proc regexCompiled*(v: Value): CompiledRegex =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okRegex:
    raise newException(FieldDefect, "value is not a Regex")
  RegexData(objData(v)).compiled

proc regexGroupCount*(v: Value): int =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okRegex:
    raise newException(FieldDefect, "value is not a Regex")
  RegexData(objData(v)).groupCount

proc regexGroupNames*(v: Value): Table[string, int] =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okRegex:
    raise newException(FieldDefect, "value is not a Regex")
  RegexData(objData(v)).groupNames

proc rangeData(v: Value): RangeData =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okRange:
    raise newException(FieldDefect, "value is not a Range")
  RangeData(objData(v))

proc rangeStart*(v: Value): int64 =
  v.rangeData.start

proc rangeStop*(v: Value): int64 =
  v.rangeData.stop

proc rangeStep*(v: Value): int64 =
  v.rangeData.step

proc rangeInclusive*(v: Value): bool =
  v.rangeData.inclusive

proc dateData(v: Value): DateData =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okDate:
    raise newException(FieldDefect, "value is not a Date")
  DateData(objData(v))

proc dateYear*(v: Value): int =
  int(v.dateData.year)

proc dateMonth*(v: Value): int =
  int(v.dateData.month)

proc dateDay*(v: Value): int =
  int(v.dateData.day)

proc timeData(v: Value): TimeData =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okTime:
    raise newException(FieldDefect, "value is not a Time")
  TimeData(objData(v))

proc timeHour*(v: Value): int =
  int(v.timeData.hour)

proc timeMinute*(v: Value): int =
  int(v.timeData.minute)

proc timeSecond*(v: Value): int =
  int(v.timeData.second)

proc timeMicrosecond*(v: Value): int =
  int(v.timeData.microsecond)

proc timeHasOffset*(v: Value): bool =
  v.timeData.hasOffset

proc timeOffsetMinutes*(v: Value): int =
  int(v.timeData.offsetMinutes)

proc timeTimezoneName*(v: Value): lent string =
  v.timeData.timezoneName

proc dateTimeData(v: Value): DateTimeData =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okDateTime:
    raise newException(FieldDefect, "value is not a DateTime")
  DateTimeData(objData(v))

proc dateTimeYear*(v: Value): int =
  int(v.dateTimeData.year)

proc dateTimeMonth*(v: Value): int =
  int(v.dateTimeData.month)

proc dateTimeDay*(v: Value): int =
  int(v.dateTimeData.day)

proc dateTimeHour*(v: Value): int =
  int(v.dateTimeData.hour)

proc dateTimeMinute*(v: Value): int =
  int(v.dateTimeData.minute)

proc dateTimeSecond*(v: Value): int =
  int(v.dateTimeData.second)

proc dateTimeMicrosecond*(v: Value): int =
  int(v.dateTimeData.microsecond)

proc dateTimeHasOffset*(v: Value): bool =
  v.dateTimeData.hasOffset

proc dateTimeOffsetMinutes*(v: Value): int =
  int(v.dateTimeData.offsetMinutes)

proc dateTimeTimezoneName*(v: Value): lent string =
  v.dateTimeData.timezoneName

proc timezoneData(v: Value): TimezoneData =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okTimezone:
    raise newException(FieldDefect, "value is not a Timezone")
  TimezoneData(objData(v))

proc timezoneHasOffset*(v: Value): bool =
  v.timezoneData.hasOffset

proc timezoneOffsetMinutes*(v: Value): int =
  int(v.timezoneData.offsetMinutes)

proc timezoneName*(v: Value): lent string =
  v.timezoneData.name

proc durationData(v: Value): DurationData =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okDuration:
    raise newException(FieldDefect, "value is not a Duration")
  DurationData(objData(v))

proc durationMicroseconds*(v: Value): int64 =
  v.durationData.microseconds

proc charVal*(v: Value): Rune {.inline.} =
  if v.tagOf != CHAR_TAG:
    raise newException(FieldDefect, "value is not a Char")
  Rune(int32(v.bits and 0xffffffff'u64))

proc symVal*(v: Value): lent string =
  if v.tagOf != SYMBOL_TAG:
    raise newException(FieldDefect, "value is not a Symbol")
  symbolNames[int(v.bits and PAYLOAD_MASK)]

proc symbolId*(v: Value): int32 {.inline.} =
  ## A symbol's interned id — directly a PropTable key id (design §1.3:
  ## PropMap keys are symbols). No lock, no string.
  if v.tagOf != SYMBOL_TAG:
    raise newException(FieldDefect, "value is not a Symbol")
  int32(v.bits and PAYLOAD_MASK)

proc listItems*(v: Value): lent seq[Value] =
  if v.tagOf != LIST_TAG:
    raise newException(FieldDefect, "value is not a List")
  cast[ptr GeneList](v.bits and PAYLOAD_MASK).items

proc listImmutable*(v: Value): bool =
  if v.tagOf != LIST_TAG:
    raise newException(FieldDefect, "value is not a List")
  cast[ptr GeneList](v.bits and PAYLOAD_MASK).immutable

proc mapEntries*(v: Value): lent PropTable =
  if v.tagOf != MAP_TAG:
    raise newException(FieldDefect, "value is not a Map")
  cast[ptr GeneMap](v.bits and PAYLOAD_MASK).entries

proc mapImmutable*(v: Value): bool =
  if v.tagOf != MAP_TAG:
    raise newException(FieldDefect, "value is not a Map")
  cast[ptr GeneMap](v.bits and PAYLOAD_MASK).immutable

proc setItems*(v: Value): lent seq[Value] =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okSet:
    raise newException(FieldDefect, "value is not a Set")
  SetData(objData(v)).items

proc hashMapEntries*(v: Value): lent seq[HashMapEntry] =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okHashMap:
    raise newException(FieldDefect, "value is not a HashMap")
  HashMapData(objData(v)).entries

proc pipelineData(v: Value): PipelineData =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okPipeline:
    raise newException(FieldDefect, "value is not pipeline syntax")
  PipelineData(objData(v))

proc pipelineInitial*(v: Value): Value =
  v.pipelineData.initial

proc pipelineStages*(v: Value): lent seq[PipelineStage] =
  v.pipelineData.stages

proc pipelineImmutable*(v: Value): bool =
  v.pipelineData.immutable

proc head*(v: Value): Value =
  if v.tagOf != NODE_TAG:
    raise newException(FieldDefect, "value is not a Node")
  cast[ptr GeneNode](v.bits and PAYLOAD_MASK).head

proc borrowedNodeHead*(v: Value): lent Value =
  ## Read-only graph walkers keep the node alive and must not create temporary
  ## owners (or run release hooks) merely to inspect its head.
  if v.tagOf != NODE_TAG:
    raise newException(FieldDefect, "value is not a Node")
  cast[ptr GeneNode](v.bits and PAYLOAD_MASK).head

proc props*(v: Value): lent PropTable =
  if v.tagOf != NODE_TAG:
    raise newException(FieldDefect, "value is not a Node")
  cast[ptr GeneNode](v.bits and PAYLOAD_MASK).props

proc body*(v: Value): lent seq[Value] =
  if v.tagOf != NODE_TAG:
    raise newException(FieldDefect, "value is not a Node")
  cast[ptr GeneNode](v.bits and PAYLOAD_MASK).body

proc meta*(v: Value): lent PropTable =
  if v.tagOf != NODE_TAG:
    raise newException(FieldDefect, "value is not a Node")
  cast[ptr GeneNode](v.bits and PAYLOAD_MASK).meta

proc nodeImmutable*(v: Value): bool =
  if v.tagOf != NODE_TAG:
    raise newException(FieldDefect, "value is not a Node")
  cast[ptr GeneNode](v.bits and PAYLOAD_MASK).immutable

proc nodeConstructing*(v: Value): bool {.inline.} =
  v.tagOf == NODE_TAG and cast[ptr GeneNode](v.bits and PAYLOAD_MASK).constructing

proc errorEvidence*(v: Value): ErrorEvidence {.inline.} =
  if v.tagOf == NODE_TAG:
    let node = cast[ptr GeneNode](v.bits and PAYLOAD_MASK)
    withErrorEvidenceLock(node):
      result = node.errorEvidence

proc cloneErrorEvidence(source: ErrorEvidence): ErrorEvidence =
  result = ErrorEvidence(diagnostics: initPropTable())
  if source != nil:
    result.classification = source.classification
    result.protocol = source.protocol
    result.formatter = source.formatter
    result.environment = if source.environment != nil: source.environment
                         else: cast[Scope](source.weakEnvironment)
    for key, value in source.diagnostics: result.diagnostics[key] = value

proc updateErrorEvidence*(v: Value, update: proc (evidence: ErrorEvidence) {.closure.}) =
  ## Readers retain an immutable snapshot. Build each update outside the lock,
  ## then publish it only if its source snapshot is still current. The callback
  ## edits only its private copy and may be retried after a concurrent update.
  if v.tagOf != NODE_TAG:
    raise newException(FieldDefect, "error evidence requires a node")
  let node = cast[ptr GeneNode](v.bits and PAYLOAD_MASK)
  while true:
    let previous = v.errorEvidence
    let candidate = cloneErrorEvidence(previous)
    update(candidate)
    # Published evidence can be read by another lane immediately. Prepare its
    # value graph before publication, without holding a node lock recursively.
    markSharedValue(candidate.protocol)
    markSharedValue(candidate.formatter)
    for _, item in candidate.diagnostics: markSharedValue(item)
    var published = false
    var retired: ErrorEvidence
    withErrorEvidenceLock(node):
      if node.errorEvidence == previous:
        retired = move node.errorEvidence
        node.errorEvidence = candidate
        published = true
    reset(retired) # releasing an old environment must happen outside the lock
    if published: return

proc installErrorWitness*(v, protocol, formatter: Value, environment: Scope) =
  v.updateErrorEvidence(proc (evidence: ErrorEvidence) =
    # Concurrent first admissions agree on whichever complete witness wins.
    if evidence.protocol.kind == vkProtocol: return
    evidence.protocol = protocol
    evidence.formatter = formatter
    evidence.environment = environment)

proc setFailureClassification*(v: Value, classification: FailureClassification) =
  v.updateErrorEvidence(proc (evidence: ErrorEvidence) =
    evidence.classification = classification)

proc copyErrorEvidence*(copy, original: Value): Value =
  ## Container copies keep the failure's origin and selected implementation,
  ## but get their own diagnostic table. Mutating/rethrowing a copy must not
  ## update the original's trace. Fresh constructors and serde do not call this.
  let source = original.errorEvidence
  if copy.tagOf == NODE_TAG and source != nil:
    let node = cast[ptr GeneNode](copy.bits and PAYLOAD_MASK)
    let candidate = cloneErrorEvidence(source)
    var retired: ErrorEvidence
    withErrorEvidenceLock(node):
      retired = move node.errorEvidence
      node.errorEvidence = candidate
    reset(retired)
  copy

proc inheritErrorEvidence*(copy, original: Value): Value =
  ## A transported node needs its own scope pin: weakening the original's
  ## scope-owned back-edge must not weaken a separately reachable copy.
  copy.copyErrorEvidence(original)

proc generatedFailure*(v: Value): bool {.inline.} =
  let evidence = v.errorEvidence
  evidence != nil and evidence.classification != fcOrdinaryError

proc hasErrorWitness*(v: Value): bool {.inline.} =
  let evidence = v.errorEvidence
  evidence != nil and evidence.protocol.kind == vkProtocol

proc errorProperties*(v: Value): PropTable =
  ## A diagnostic view for reporters. Ordinary node props/equality remain the
  ## original payload; diagnostic selectors may fall back to this side data.
  result = v.props
  let evidence = v.errorEvidence
  if evidence != nil:
    for key, value in evidence.diagnostics:
      if not result.hasKey(key): result[key] = value

proc finishNodeConstruction*(v: Value) =
  if v.tagOf != NODE_TAG:
    raise newException(FieldDefect, "value is not a Node")
  cast[ptr GeneNode](v.bits and PAYLOAD_MASK).constructing = false

proc setListItem*(v: Value, index: int, value: Value) =
  if v.tagOf != LIST_TAG:
    raise newException(FieldDefect, "value is not a List")
  let p = cast[ptr GeneList](v.bits and PAYLOAD_MASK)
  if p.immutable:
    raise newException(GeneError, "cannot mutate immutable List")
  p.items[index] = (if value.kind == vkVoid: NIL else: value)

proc pushListItem*(v: Value, value: Value) =
  if v.tagOf != LIST_TAG:
    raise newException(FieldDefect, "value is not a List")
  let p = cast[ptr GeneList](v.bits and PAYLOAD_MASK)
  if p.immutable:
    raise newException(GeneError, "cannot mutate immutable List")
  p.items.add(if value.kind == vkVoid: NIL else: value)

proc putMapEntry*(v: Value, key: string, value: Value) =
  if v.tagOf != MAP_TAG:
    raise newException(FieldDefect, "value is not a Map")
  let p = cast[ptr GeneMap](v.bits and PAYLOAD_MASK)
  if p.immutable:
    raise newException(GeneError, "cannot mutate immutable Map")
  if value.kind == vkVoid:
    p.entries.del(key)
  else:
    p.entries[key] = value

proc isPropMap*(v: Value): bool {.inline.} =
  ## A `{...}` PropMap (not a general HashMap), by tag alone.
  v.tagOf == MAP_TAG

proc plainPathKeyId*(selector: Value): int32 {.inline.} =
  ## For the selector of a plain one-key read (`row/amount`) — a Node with no
  ## props whose single segment is a Sym, or a Str other than a `.msg` /
  ## `?.msg` send — that key's PropTable id, or -1 when its text was never
  ## interned and so is absent from every table. -2 for any other value.
  if selector.tagOf != NODE_TAG:
    return -2
  let node = cast[ptr GeneNode](selector.bits and PAYLOAD_MASK)
  if node.body.len != 1 or node.props.data.len != 0:
    return -2
  let segment = node.body[0].bits
  case segment shr TAG_SHIFT
  of SYMBOL_TAG:
    result = int32(segment and PAYLOAD_MASK)
  of STRING_TAG:
    let str = cast[ptr GeneString](segment and PAYLOAD_MASK)
    if str.s.len > 0 and (str.s[0] == '.' or
        (str.s.len > 1 and str.s[0] == '?' and str.s[1] == '.')):
      return -2
    let cached = loadCachedKeyId(str)
    if cached != 0:
      return cached - 1
    result = lookupSymbolId(str.s)
    if result >= 0:
      storeCachedKeyId(str, result + 1)
  else:
    result = -2

proc putMapEntryById*(v: Value, keyId: int32, value: Value) =
  ## `putMapEntry` for a caller that already holds the key id. `value` must not
  ## be void: removal goes through `putMapEntry`, which probes without
  ## interning.
  if v.tagOf != MAP_TAG:
    raise newException(FieldDefect, "value is not a Map")
  let p = cast[ptr GeneMap](v.bits and PAYLOAD_MASK)
  if p.immutable:
    raise newException(GeneError, "cannot mutate immutable Map")
  p.entries.putById(keyId, value)

proc setNodeProp*(v: Value, key: string, value: Value) =
  if v.tagOf != NODE_TAG:
    raise newException(FieldDefect, "value is not a Node")
  let p = cast[ptr GeneNode](v.bits and PAYLOAD_MASK)
  if p.immutable:
    raise newException(GeneError, "cannot mutate immutable Node")
  if value.kind == vkVoid:
    p.props.del(key)
  else:
    p.props[key] = value

proc setNodeBody*(v: Value, items: sink seq[Value]) =
  if v.tagOf != NODE_TAG:
    raise newException(FieldDefect, "value is not a Node")
  let p = cast[ptr GeneNode](v.bits and PAYLOAD_MASK)
  if p.immutable:
    raise newException(GeneError, "cannot mutate immutable Node")
  p.body = items

proc pushNodeBody*(v: Value, item: Value) =
  if v.tagOf != NODE_TAG:
    raise newException(FieldDefect, "value is not a Node")
  let p = cast[ptr GeneNode](v.bits and PAYLOAD_MASK)
  if p.immutable:
    raise newException(GeneError, "cannot mutate immutable Node")
  p.body.add item

proc setNodeBodyItem*(v: Value, index: int, item: Value) =
  if v.tagOf != NODE_TAG:
    raise newException(FieldDefect, "value is not a Node")
  let p = cast[ptr GeneNode](v.bits and PAYLOAD_MASK)
  if p.immutable:
    raise newException(GeneError, "cannot mutate immutable Node")
  if index < 0 or index >= p.body.len:
    raise newException(GeneError, "node body index out of range: " & $index)
  p.body[index] = item

proc setNodePartsAfterModuleRefPatch*(v: Value, props: sink PropTable,
                                      body: sink seq[Value]) =
  ## Internal construction-time update used after all module-reference fixups
  ## have landed. Public mutability is intentionally not consulted here.
  if v.tagOf != NODE_TAG:
    raise newException(FieldDefect, "value is not a Node")
  let p = cast[ptr GeneNode](v.bits and PAYLOAD_MASK)
  p.props = props
  p.body = body

proc fnName*(v: Value): lent string =
  if v.tagOf != FUNCTION_TAG:
    raise newException(FieldDefect, "value is not a Function")
  cast[ptr GeneFunction](v.bits and PAYLOAD_MASK).name

proc isSyntaxFn*(v: Value): bool {.inline.} =
  ## True for named fexpr syntax callables (design §3/§11.1); false for every other
  ## value, including ordinary functions.
  v.tagOf == FUNCTION_TAG and
    cast[ptr GeneFunction](v.bits and PAYLOAD_MASK).syntaxFn

proc fnParams*(v: Value): lent seq[string] =
  if v.tagOf != FUNCTION_TAG:
    raise newException(FieldDefect, "value is not a Function")
  cast[ptr GeneFunction](v.bits and PAYLOAD_MASK).params

proc fnCode*(v: Value): FunctionCode =
  if v.tagOf != FUNCTION_TAG:
    raise newException(FieldDefect, "value is not a Function")
  cast[ptr GeneFunction](v.bits and PAYLOAD_MASK).code

proc fnScope*(v: Value): Scope =
  if v.tagOf != FUNCTION_TAG:
    raise newException(FieldDefect, "value is not a Function")
  let fn = cast[ptr GeneFunction](v.bits and PAYLOAD_MASK)
  if fn.scope != nil:
    fn.scope
  else:
    cast[Scope](fn.weakScope)

proc fnScopeAddr*(v: Value): pointer {.inline.} =
  ## `fnScope` of a value known to be a function, borrowed: read it through a
  ## `{.cursor.}` local. A counted Scope copy costs an ORC cycle-candidate
  ## registration when released, on every call that asks.
  let fn = cast[ptr GeneFunction](v.bits and PAYLOAD_MASK)
  if fn.scope != nil: cast[pointer](fn.scope) else: fn.weakScope

proc fnCodeAddr*(v: Value): pointer {.inline.} =
  ## `fnCode` of a value known to be a function, borrowed like fnScopeAddr.
  cast[pointer](cast[ptr GeneFunction](v.bits and PAYLOAD_MASK).code)

proc fnHasErrorLease*(v: Value): bool {.inline.} =
  v.kind == vkFunction and
    cast[ptr GeneFunction](v.bits and PAYLOAD_MASK).errorLease != nil

proc fnIdentity*(v: Value): int =
  ## Weak and strong capture clones of one closure are the same function.
  if v.tagOf != FUNCTION_TAG:
    raise newException(FieldDefect, "value is not a Function")
  cast[ptr GeneFunction](v.bits and PAYLOAD_MASK).identity

proc fnHasWeakScope*(v: Value): bool =
  if v.tagOf != FUNCTION_TAG:
    raise newException(FieldDefect, "value is not a Function")
  let fn = cast[ptr GeneFunction](v.bits and PAYLOAD_MASK)
  fn.scope == nil and fn.weakScope != nil

proc fnCapturesCallerEnv*(v: Value): bool =
  if v.tagOf != FUNCTION_TAG:
    raise newException(FieldDefect, "value is not a Function")
  cast[ptr GeneFunction](v.bits and PAYLOAD_MASK).capturesCallerEnv

proc fnChecksErrors*(v: Value): bool =
  if v.tagOf != FUNCTION_TAG:
    raise newException(FieldDefect, "value is not a Function")
  cast[ptr GeneFunction](v.bits and PAYLOAD_MASK).checksErrors

proc fnErrorTypes*(v: Value): lent seq[Value] =
  if v.tagOf != FUNCTION_TAG:
    raise newException(FieldDefect, "value is not a Function")
  cast[ptr GeneFunction](v.bits and PAYLOAD_MASK).errorTypes

proc fnErrorLease*(v: Value): RootRef =
  if v.kind == vkFunction: cast[ptr GeneFunction](v.bits and PAYLOAD_MASK).errorLease
  else: nil

proc setFnErrorLease*(v: Value, lease: RootRef) =
  if v.kind != vkFunction:
    raise newException(FieldDefect, "error proof lease requires a function")
  cast[ptr GeneFunction](v.bits and PAYLOAD_MASK).errorLease = lease


proc nativeFnName*(v: Value): lent string {.inline.} =
  if v.tagOf != NATIVE_FN_TAG:
    raise newException(FieldDefect, "value is not a NativeFn")
  cast[ptr GeneNativeFn](v.bits and PAYLOAD_MASK).name

proc nativeImpl*(v: Value): NativeProc {.inline.} =
  if v.tagOf != NATIVE_FN_TAG:
    raise newException(FieldDefect, "value is not a NativeFn")
  cast[ptr GeneNativeFn](v.bits and PAYLOAD_MASK).impl

proc nativeCallImpl*(v: Value): NativeCallProc {.inline.} =
  if v.tagOf != NATIVE_FN_TAG:
    raise newException(FieldDefect, "value is not a NativeFn")
  cast[ptr GeneNativeFn](v.bits and PAYLOAD_MASK).callImpl

proc nativeContextCallImpl*(v: Value): NativeContextCallProc {.inline.} =
  if v.tagOf != NATIVE_FN_TAG:
    raise newException(FieldDefect, "value is not a NativeFn")
  cast[ptr GeneNativeFn](v.bits and PAYLOAD_MASK).contextImpl

proc nativeContext*(v: Value): RootRef {.inline.} =
  if v.tagOf != NATIVE_FN_TAG:
    raise newException(FieldDefect, "value is not a NativeFn")
  cast[ptr GeneNativeFn](v.bits and PAYLOAD_MASK).context

proc nativeAcceptsNamed*(v: Value): bool {.inline.} =
  if v.tagOf != NATIVE_FN_TAG:
    raise newException(FieldDefect, "value is not a NativeFn")
  cast[ptr GeneNativeFn](v.bits and PAYLOAD_MASK).acceptsNamed

proc nativeFastKind*(v: Value): NativeFastKind {.inline.} =
  if v.tagOf != NATIVE_FN_TAG:
    raise newException(FieldDefect, "value is not a NativeFn")
  cast[ptr GeneNativeFn](v.bits and PAYLOAD_MASK).fastKind

proc nativeErrorMetadata*(v: Value): lent NativeErrorMetadata {.inline.} =
  if v.tagOf != NATIVE_FN_TAG:
    raise newException(FieldDefect, "value is not a NativeFn")
  cast[ptr GeneNativeFn](v.bits and PAYLOAD_MASK).errorMetadata

proc ffiCallableData(v: Value): FfiCallableData =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okFfiCallable:
    raise newException(FieldDefect, "value is not an FfiCallable")
  FfiCallableData(objData(v))

proc ffiCallableName*(v: Value): lent string =
  ffiCallableData(v).name

proc ffiCallableSymbol*(v: Value): lent string =
  ffiCallableData(v).symbol

proc ffiCallableAddress*(v: Value): pointer =
  ffiCallableData(v).address

proc ffiCallableLibrary*(v: Value): Value =
  ffiCallableData(v).library

proc ffiCallableParamTypes*(v: Value): lent seq[Value] =
  ffiCallableData(v).paramTypes

proc ffiCallableReturnType*(v: Value): Value =
  ffiCallableData(v).returnType

proc ffiCallableReleaseName*(v: Value): lent string =
  ffiCallableData(v).releaseName

proc ffiCallableReleaseAddress*(v: Value): pointer =
  ffiCallableData(v).releaseAddress

proc newEnv*(bindings: sink Table[string, Value],
             parent: Value = NIL,
             imports: sink seq[Value] = @[],
             module: Value = NIL,
             policy: Value = NIL,
             bindingScope: Scope = nil): Value

proc newCallerEnv*(scope: Scope): Value
proc callerEnvScope*(v: Value): Scope
proc deactivateCallerEnv*(v: Value)

type
  WeakScopeLiveProc* = proc(ctx: pointer, target: pointer): bool {.nimcall.}
  WeakScopeGuard* = object
    ## Scopes known to outlive an escaping value. `scope` and its lexical
    ## ancestors are protected; `live`, when set, answers for further scopes
    ## such as every frame still on the VM stack.
    scope*: Scope
    live*: WeakScopeLiveProc
    ctx*: pointer

proc escapeWeakFunctions*(v: Value, protectedScope: Scope = nil): Value
proc escapeWeakFunctions*(v: Value, guard: WeakScopeGuard): Value

proc nsName*(v: Value): lent string =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okNamespace:
    raise newException(FieldDefect, "value is not a Namespace")
  NamespaceData(objData(v)).name

proc setNsName*(v: Value, name: sink string) =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okNamespace:
    raise newException(FieldDefect, "value is not a Namespace")
  NamespaceData(objData(v)).name = name

proc borrowedNsScope*(v: Value): lent Scope =
  ## The namespace must remain alive and unchanged for the borrow's lifetime.
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okNamespace:
    raise newException(FieldDefect, "value is not a Namespace")
  NamespaceData(objData(v)).scope

proc nsScope*(v: Value): Scope =
  ## Retain the scope independently of the namespace that owns it.
  v.borrowedNsScope

proc nsModulePath*(v: Value): lent string =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okNamespace:
    raise newException(FieldDefect, "value is not a Namespace")
  NamespaceData(objData(v)).modulePath

proc nsIsModuleRoot*(v: Value): bool =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okNamespace:
    raise newException(FieldDefect, "value is not a Namespace")
  NamespaceData(objData(v)).moduleRoot

proc moduleName*(v: Value): lent string =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okModule:
    raise newException(FieldDefect, "value is not a Module")
  ModuleData(objData(v)).name

proc setModuleName*(v: Value, name: sink string) =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okModule:
    raise newException(FieldDefect, "value is not a Module")
  let data = ModuleData(objData(v))
  data.name = name
  if data.root.kind == vkNamespace:
    data.root.setNsName(data.name)

proc modulePath*(v: Value): lent string =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okModule:
    raise newException(FieldDefect, "value is not a Module")
  ModuleData(objData(v)).path

proc moduleRuntimeId*(v: Value): int =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okModule:
    raise newException(FieldDefect, "value is not a Module")
  ModuleData(objData(v)).runtimeId

proc moduleInstanceKey*(v: Value): string =
  if v.kind != vkModule:
    raise newException(FieldDefect, "value is not a Module")
  ModuleData(objData(v)).instanceKey

proc setModuleInstanceKey*(v: Value, key: string) =
  if v.kind != vkModule:
    raise newException(FieldDefect, "value is not a Module")
  ModuleData(objData(v)).instanceKey = key

proc moduleRootNamespace*(v: Value): Value =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okModule:
    raise newException(FieldDefect, "value is not a Module")
  ModuleData(objData(v)).root

proc recordModuleDependency*(v: Value, dependencyPath: string) =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okModule:
    raise newException(FieldDefect, "value is not a Module")
  let data = ModuleData(objData(v))
  if dependencyPath notin data.dependencies:
    data.dependencies.add dependencyPath

proc moduleDependencies*(v: Value): lent seq[string] =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okModule:
    raise newException(FieldDefect, "value is not a Module")
  ModuleData(objData(v)).dependencies

proc moduleMeta*(v: Value): lent PropTable =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okModule:
    raise newException(FieldDefect, "value is not a Module")
  ModuleData(objData(v)).meta

proc setModuleMeta*(v: Value, meta: sink PropTable) =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okModule:
    raise newException(FieldDefect, "value is not a Module")
  ModuleData(objData(v)).meta = meta

proc envParent*(v: Value): Value =
  if not v.isObjectTagged or objData(v).objKind != okEnv:
    raise newException(FieldDefect, "value is not an Env")
  EnvData(objData(v)).parent

proc envBindings*(v: Value): lent Table[string, Value] =
  if not v.isObjectTagged or objData(v).objKind != okEnv:
    raise newException(FieldDefect, "value is not an Env")
  EnvData(objData(v)).bindings

proc envImports*(v: Value): lent seq[Value] =
  if not v.isObjectTagged or objData(v).objKind != okEnv:
    raise newException(FieldDefect, "value is not an Env")
  EnvData(objData(v)).imports

proc envModule*(v: Value): Value =
  if not v.isObjectTagged or objData(v).objKind != okEnv:
    raise newException(FieldDefect, "value is not an Env")
  EnvData(objData(v)).module

proc envClosedScope*(v: Value): bool =
  if not v.isObjectTagged or objData(v).objKind != okEnv:
    raise newException(FieldDefect, "value is not an Env")
  EnvData(objData(v)).closedScope

proc envCompilerMacros*(v: Value): RootRef =
  if v.kind notin {vkEnv, vkCallerEnv}:
    raise newException(FieldDefect, "compiler context requires Env or CallerEnv")
  EnvData(objData(v)).compilerMacros

proc setEnvCompilerMacros*(v: Value, context: RootRef) =
  if v.kind notin {vkEnv, vkCallerEnv}:
    raise newException(FieldDefect, "compiler context requires Env or CallerEnv")
  EnvData(objData(v)).compilerMacros = context

proc envMacroFunctions*(v: Value): seq[Value] =
  if v.kind notin {vkEnv, vkCallerEnv}:
    raise newException(FieldDefect, "macro closures require Env or CallerEnv")
  EnvData(objData(v)).compilerMacroFunctions

proc setEnvMacroFunctions*(v: Value, functions: sink seq[Value]) =
  if v.kind notin {vkEnv, vkCallerEnv}:
    raise newException(FieldDefect, "macro closures require Env or CallerEnv")
  EnvData(objData(v)).compilerMacroFunctions = functions

proc setEnvClosedScope*(v: Value, closed: bool) =
  if not v.isObjectTagged or objData(v).objKind != okEnv:
    raise newException(FieldDefect, "value is not an Env")
  EnvData(objData(v)).closedScope = closed

proc envPolicy*(v: Value): Value =
  if not v.isObjectTagged or objData(v).objKind != okEnv:
    raise newException(FieldDefect, "value is not an Env")
  EnvData(objData(v)).policy

proc cellValue*(v: Value): Value =
  if not v.isObjectTagged or objData(v).objKind != okCell:
    raise newException(FieldDefect, "value is not a Cell")
  CellData(objData(v)).value

proc setCellValue*(v, newValue: Value) =
  if not v.isObjectTagged or objData(v).objKind != okCell:
    raise newException(FieldDefect, "value is not a Cell")
  CellData(objData(v)).value = newValue

proc cellValueType*(v: Value): Value =
  if not v.isObjectTagged or objData(v).objKind != okCell:
    raise newException(FieldDefect, "value is not a Cell")
  CellData(objData(v)).valueType

proc cellValueScope*(v: Value): Scope =
  if not v.isObjectTagged or objData(v).objKind != okCell:
    raise newException(FieldDefect, "value is not a Cell")
  CellData(objData(v)).valueScope

proc setCellValueType*(v, valueType: Value, valueScope: Scope) =
  if not v.isObjectTagged or objData(v).objKind != okCell:
    raise newException(FieldDefect, "value is not a Cell")
  let data = CellData(objData(v))
  data.valueType = valueType
  data.valueScope = valueScope

proc asAtomicCellData(v: Value): AtomicCellData =
  if not v.isObjectTagged or objData(v).objKind != okAtomicCell:
    raise newException(FieldDefect, "value is not an AtomicCell")
  AtomicCellData(objData(v))

template withAtomicCellLock(d: AtomicCellData, body: untyped): untyped =
  acquire(d.lock)
  try:
    body
  finally:
    release(d.lock)

proc atomicCellValue*(v: Value): Value =
  let d = v.asAtomicCellData
  withAtomicCellLock(d):
    result = d.value

proc setAtomicCellValue*(v, newValue: Value) =
  let d = v.asAtomicCellData
  if isSharedFlag(d.shared): markSharedValue(newValue)
  var retired: Value
  withAtomicCellLock(d):
    retired = retainedCopy(d.value)
    d.value = newValue
  reset(retired) # physical cleanup outside the cell lock

proc atomicCellSwap*(v, newValue: Value): Value =
  ## Reads the current value and replaces it as a single locked critical
  ## section (not a separate load + store), so a concurrent swap/CAS cannot
  ## interleave between the read and the write.
  let d = v.asAtomicCellData
  if isSharedFlag(d.shared): markSharedValue(newValue)
  withAtomicCellLock(d):
    result = retainedCopy(d.value)
    d.value = newValue

proc atomicCellCompareExchange*(v, expected, newValue: Value,
                                eq: proc (a, b: Value): bool): bool =
  ## Compares the current value against `expected` using the caller-supplied
  ## equality (`same?`, from equality.nim — types.nim can't import it without
  ## a cycle) and swaps in the same locked critical section as the compare,
  ## avoiding the check-then-set race of separate load/compare/store calls.
  let d = v.asAtomicCellData
  if isSharedFlag(d.shared): markSharedValue(newValue)
  var retired: Value
  withAtomicCellLock(d):
    if eq(d.value, expected):
      retired = retainedCopy(d.value)
      d.value = newValue
      result = true
    else:
      result = false
  reset(retired) # last-owner callbacks cannot re-enter under the cell lock

proc callableViewData(v: Value): CallableViewData =
  if v.kind != vkCallableView:
    raise newException(FieldDefect, "value is not a checked callable")
  CallableViewData(objData(v))

proc callableViewTarget*(v: Value): Value = v.callableViewData.target
proc callableViewSignature*(v: Value): Value = v.callableViewData.signature
proc callableViewScope*(v: Value): Scope = v.callableViewData.typeScope
proc isIoReadCall*(v: Value): bool =
  v.kind == vkCallableView and v.callableViewData.ioReadCall
proc isIoReadDelegate*(v: Value): bool =
  v.isIoReadCall and v.callableViewData.ioReadDelegate

proc newCallableView*(target, signature: Value, typeScope: Scope,
                      ioReadCall = false, ioReadDelegate = false): Value =
  boxObject(CallableViewData(objKind: okCallableView, target: target,
    signature: signature, typeScope: typeScope, ioReadCall: ioReadCall,
    ioReadDelegate: ioReadDelegate))

proc newIoReadCall*(target: Value, delegated = false): Value =
  newCallableView(target, Value(bits: 0), nil, ioReadCall = true,
                  ioReadDelegate = delegated)

proc streamData(v: Value): StreamData =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okStream:
    raise newException(FieldDefect, "value is not a Stream")
  StreamData(objData(v))

template withTaskStateLock(s: TaskState, body: untyped): untyped =
  acquire(s.lock)
  try:
    body
  finally:
    release(s.lock)

template withChannelStateLock(s: ChannelState, body: untyped): untyped =
  acquire(s.lock)
  try:
    body
  finally:
    release(s.lock)

template withActorLock(d: ActorData, body: untyped): untyped =
  acquire(d.lock)
  try:
    body
  finally:
    release(d.lock)

template withReplyToLock(d: ReplyToData, body: untyped): untyped =
  acquire(d.lock)
  try:
    body
  finally:
    release(d.lock)

proc newTaskState(done = false, cancelRequested = false, cancelled = false,
                  awaited = false, external = false, taskResult = NIL, errorMsg = "",
                  errorValue = NIL, hasErrorValue = false,
                  panicMsg = "", panicValue = NIL,
                  hasPanicValue = false, failed = false, panicked = false): TaskState =
  new(result)
  initLock(result.lock)
  when compileOption("threads") and defined(gcAtomicArc):
    initCond(result.cond)
  result.done = done
  result.cancelRequested = cancelRequested
  result.cancelled = cancelled
  result.awaited = awaited
  result.external = external
  result.result = taskResult
  result.failed = failed or errorMsg.len > 0 or hasErrorValue
  result.errorMsg = errorMsg
  result.errorValue = errorValue
  result.hasErrorValue = hasErrorValue
  result.panicked = panicked or panicMsg.len > 0 or hasPanicValue
  result.panicMsg = panicMsg
  result.panicValue = panicValue
  result.hasPanicValue = hasPanicValue

proc newChannelState(capacity: int, items: seq[Value] = @[],
                     closed = false,
                     scopePins: seq[seq[Scope]] = @[]): ChannelState =
  new(result)
  initLock(result.lock)
  result.items = items
  if scopePins.len == 0:
    result.scopePins = newSeq[seq[Scope]](items.len)
  else:
    doAssert scopePins.len == items.len
    result.scopePins = scopePins
  result.capacity = capacity
  result.closed = closed

proc newActorData(capacity: int, state, restartInit, handler,
                  messageType: Value,
                  messageTypeExplicit: bool,
                  failureStrategy: ActorFailureStrategy,
                  failureEvents, failureDeadLetters: Value,
                  parentFailureEvents: Value = NIL,
                  parentFailureDeadLetters: Value = NIL,
                  maxRestarts = 0, restartWindowMs = 0,
                  lifecycle = ActorLifecycle()): ActorData =
  result = ActorData(objKind: okActorRef,
                     lifecycle: lifecycle,
                     capacity: capacity,
                     state: state,
                     restartInit: restartInit,
                     handler: handler,
                     messageType: messageType,
                     messageTypeExplicit: messageTypeExplicit,
                     failureStrategy: failureStrategy,
                     failureEvents: failureEvents,
                     failureDeadLetters: failureDeadLetters,
                     parentFailureEvents: parentFailureEvents,
                     parentFailureDeadLetters: parentFailureDeadLetters,
                     maxRestarts: maxRestarts,
                     restartWindowMs: restartWindowMs)
  initLock(result.lock)

proc skipStreamVoids(data: StreamData) =
  while not data.closed and data.index < data.items.len and
      data.items[data.index].kind == vkVoid:
    inc data.index

proc closeStream*(v: Value)

proc fillStreamBuffer(stream: Value, data: StreamData): bool =
  if data.closed:
    return false
  if data.buffered:
    return true
  if data.pulling:
    raise newException(GeneError, "a Stream cannot be pulled reentrantly")
  data.pulling = true
  defer: data.pulling = false
  while not data.closed:
    var pulled: StreamPullResult
    try:
      pulled = data.pull(stream)
    except CatchableError:
      # A producer failure is terminal. Close the adaptor and its owned source,
      # but preserve the producer's first error if cleanup also fails.
      try:
        stream.closeStream()
      except CatchableError:
        discard
      raise
    if data.closed:
      return false
    if not pulled.has:
      stream.closeStream()
      return false
    if pulled.item.kind != vkVoid:
      data.buffer = pulled.item
      data.buffered = true
      return true
  false

proc streamHasNext*(v: Value): bool =
  let data = streamData(v)
  if data.pull != nil:
    return fillStreamBuffer(v, data)
  if data.source.kind == vkStream:
    if data.closed:
      return false
    try:
      result = data.source.streamHasNext()
    except CatchableError as producerError:
      try:
        if data.checkFailure != nil:
          data.checkFailure(v, producerError)
      finally:
        try: v.closeStream()
        except CatchableError: discard
      raise
    if not result:
      v.closeStream()
    return
  data.skipStreamVoids()
  not data.closed and data.index < data.items.len

proc streamPeek*(v: Value): Value =
  if not v.streamHasNext:
    raise newException(FieldDefect, "stream is exhausted")
  let data = streamData(v)
  if data.pull != nil:
    return data.buffer
  if data.source.kind == vkStream:
    try:
      return data.source.streamPeek
    except CatchableError as producerError:
      try:
        if data.checkFailure != nil:
          data.checkFailure(v, producerError)
      finally:
        try: v.closeStream()
        except CatchableError: discard
      raise
  data.items[data.index]

proc streamNext*(v: Value): Value =
  result = v.streamPeek
  let data = streamData(v)
  if data.pull != nil:
    data.buffered = false
    data.buffer = NIL
    return
  if data.source.kind == vkStream:
    discard data.source.streamNext
  else:
    inc data.index

proc closeStream*(v: Value) =
  let data = streamData(v)
  if data.closed:
    return
  defer:
    # Closed cursors cannot produce another typed item or failure. Retiring
    # their annotation environment also breaks owner/parameter-view cycles.
    var retired = move data.itemScope
    retired = nil
  data.closed = true
  data.buffered = false
  data.buffer = NIL
  var firstError: ref CatchableError
  if data.close != nil:
    let close = data.close
    data.close = nil
    try:
      close(v)
    except CatchableError as cleanupError:
      firstError = cleanupError
  if data.source.kind == vkStream:
    try:
      data.source.closeStream()
    except CatchableError as cleanupError:
      if firstError == nil:
        firstError = cleanupError
  data.source = NIL
  data.callable = NIL
  data.generatorCode = nil
  data.generatorScope = nil
  data.generatorStack.setLen(0)
  data.generatorIp = 0
  data.generatorContinuation = nil
  data.items.setLen(0)
  data.index = 0
  if firstError != nil:
    if data.checkFailure != nil:
      data.checkFailure(v, firstError)
    raise firstError

proc detachStreamSource*(v: Value) =
  ## Relinquish adaptor ownership without closing the upstream cursor.
  streamData(v).source = NIL

proc streamSource*(v: Value): Value =
  streamData(v).source

proc streamCallable*(v: Value): Value =
  streamData(v).callable

proc streamRemaining*(v: Value): int64 =
  streamData(v).remaining

proc setStreamRemaining*(v: Value, remaining: int64) =
  streamData(v).remaining = remaining

proc streamItemType*(v: Value): Value =
  streamData(v).itemType

proc streamErrType*(v: Value): Value =
  streamData(v).errType

proc streamItemScope*(v: Value): Scope =
  streamData(v).itemScope

proc streamGeneratorCode*(v: Value): FunctionCode =
  streamData(v).generatorCode

proc streamGeneratorScope*(v: Value): Scope =
  streamData(v).generatorScope

proc streamGeneratorStack*(v: Value): var seq[Value] =
  streamData(v).generatorStack

proc streamGeneratorIp*(v: Value): int =
  streamData(v).generatorIp

proc setStreamGeneratorIp*(v: Value, ip: int) =
  streamData(v).generatorIp = ip

proc streamGeneratorContinuation*(v: Value): RootRef =
  streamData(v).generatorContinuation

proc setStreamGeneratorContinuation*(v: Value, continuation: RootRef) =
  streamData(v).generatorContinuation = continuation

proc clearStreamGeneratorContinuation*(v: Value) =
  streamData(v).generatorContinuation = nil

# Templates + cast, NOT procs returning refs: a proc materializes an owning
# TaskData/TaskState temporary whose inc/dec goes through plain (non-atomic)
# ORC refcounting. Task and Channel state is read and settled from foreign
# threads (os/exec-*-async workers) while the scheduler polls the same
# objects, so those temporaries silently corrupt the refcount via lost
# updates and the object is freed while still referenced. The caller's Value
# argument pins the object, so hook-free borrows are safe — bind results
# with {.cursor.}.
template taskData(v: Value): TaskData =
  block:
    if v.tagOf != OBJECT_TAG or objData(v).objKind != okTask:
      raise newException(FieldDefect, "value is not a Task")
    cast[TaskData](cast[pointer](v.bits and PAYLOAD_MASK))

template taskState(v: Value): TaskState =
  taskData(v).state

proc taskDone*(v: Value): bool =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    result = data.done

proc taskCancelled*(v: Value): bool =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    result = data.cancelled

proc taskCancelRequested*(v: Value): bool =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    result = data.cancelRequested

proc taskAwaited*(v: Value): bool =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    result = data.awaited

proc taskExternalPending*(v: Value): bool =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    result = data.external and not data.done

proc waitExternalTaskChange*(v: Value): bool =
  ## Wait for a native/external operation to settle this task. Returns true when
  ## the task is now done; false means it was not an external-pending task.
  when compileOption("threads") and defined(gcAtomicArc):
    let data {.cursor.} = taskState(v)
    withTaskStateLock(data):
      if not data.external or data.done:
        return data.done
      wait(data.cond, data.lock)
      result = data.done
  else:
    false

proc cancelTask*(v: Value) =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    if not data.done:
      data.cancelRequested = true

proc tryCancelTask*(v: Value): bool =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    if data.done:
      return
    data.done = true
    data.cancelRequested = false
    data.cancelled = true
    data.external = false
    result = true
    when compileOption("threads") and defined(gcAtomicArc):
      broadcast(data.cond)

proc finishTaskCancel*(v: Value) =
  discard tryCancelTask(v)

proc taskResult*(v: Value): Value =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    result = data.result

proc taskHasError*(v: Value): bool =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    result = data.failed

proc taskErrorMsg*(v: Value): string =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    result = data.errorMsg

proc taskErrorValue*(v: Value): Value =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    result = data.errorValue

proc taskHasErrorValue*(v: Value): bool =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    result = data.hasErrorValue

proc taskHasPanic*(v: Value): bool =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    result = data.panicked

proc taskPanicMsg*(v: Value): string =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    result = data.panicMsg

proc taskPanicValue*(v: Value): Value =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    result = data.panicValue

proc taskHasPanicValue*(v: Value): bool =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    result = data.hasPanicValue

proc taskResultType*(v: Value): Value =
  taskData(v).resultType

proc taskErrorType*(v: Value): Value =
  taskData(v).errorType

proc taskBoundaryScope*(v: Value): Scope =
  taskData(v).boundaryScope

proc taskSharesState*(a, b: Value): bool =
  a.kind == vkTask and b.kind == vkTask and taskData(a).state == taskData(b).state

proc readTaskPayload(v: Value, consume: static bool): TaskPayload =
  ## Checking consumption and taking the outcome are one operation. Separate
  ## reads let concurrent awaiters observe a payload after another cleared it.
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    if data.awaited:
      when consume:
        raise newException(GeneError, "task result has already been awaited")
      else:
        raise newException(GeneError, "task result has already been consumed by await")
    if not data.done:
      raise newException(GeneError, "task result is not ready")
    result.cancelled = data.cancelled
    result.hasError = data.failed
    result.hasErrorValue = data.hasErrorValue
    result.hasPanic = data.panicked
    result.hasPanicValue = data.hasPanicValue
    when consume:
      data.awaited = true
      data.cancelRequested = false
      result.value = move data.result
      result.errorMessage = move data.errorMsg
      result.errorValue = move data.errorValue
      result.panicMessage = move data.panicMsg
      result.panicValue = move data.panicValue
      data.failed = false
      data.hasErrorValue = false
      data.panicked = false
      data.hasPanicValue = false
    else:
      result.value = data.result
      result.errorMessage = data.errorMsg
      result.errorValue = data.errorValue
      result.panicMessage = data.panicMsg
      result.panicValue = data.panicValue

proc consumeTaskPayload*(v: Value): TaskPayload =
  readTaskPayload(v, true)

proc peekTaskPayload*(v: Value): TaskPayload =
  readTaskPayload(v, false)

proc clearTaskPayload*(v: Value) =
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    data.awaited = true
    data.cancelRequested = false
    data.result = NIL
    data.failed = false
    data.errorMsg = ""
    data.errorValue = NIL
    data.hasErrorValue = false
    data.panicked = false
    data.panicMsg = ""
    data.panicValue = NIL
    data.hasPanicValue = false

# Same discipline as taskData: hook-free borrow, no owning ref temporary
# (channels are pushed/closed from exec worker threads).
template channelData(v: Value): ChannelData =
  block:
    if v.tagOf != OBJECT_TAG or objData(v).objKind != okChannel:
      raise newException(FieldDefect, "value is not a Channel")
    cast[ChannelData](cast[pointer](v.bits and PAYLOAD_MASK))

proc channelCapacity*(v: Value): int =
  let state {.cursor.} = channelData(v).state
  withChannelStateLock(state):
    result = state.capacity

proc channelLen*(v: Value): int =
  let state {.cursor.} = channelData(v).state
  withChannelStateLock(state):
    result = state.items.len

proc channelItemsSnapshot*(v: Value): seq[Value] =
  let state {.cursor.} = channelData(v).state
  withChannelStateLock(state):
    result = state.items

proc channelClosed*(v: Value): bool =
  let state {.cursor.} = channelData(v).state
  withChannelStateLock(state):
    result = state.closed

proc channelFull*(v: Value): bool =
  let state {.cursor.} = channelData(v).state
  withChannelStateLock(state):
    result = state.items.len >= state.capacity

proc channelSendState*(v: Value): tuple[closed: bool, full: bool] =
  let state {.cursor.} = channelData(v).state
  withChannelStateLock(state):
    result.closed = state.closed
    result.full = state.items.len >= state.capacity

proc channelRecvState*(v: Value): tuple[closed: bool, empty: bool] =
  let state {.cursor.} = channelData(v).state
  withChannelStateLock(state):
    result.closed = state.closed
    result.empty = state.items.len == 0

proc channelItemType*(v: Value): Value =
  channelData(v).itemType

proc channelItemScope*(v: Value): Scope =
  channelData(v).itemScope

proc closeChannel*(v: Value) =
  let state {.cursor.} = channelData(v).state
  withChannelStateLock(state):
    state.closed = true

proc pushChannel*(v, item: Value) =
  let stored = escapeWeakFunctions(item)
  let state {.cursor.} = channelData(v).state
  withChannelStateLock(state):
    state.items.add stored
    state.scopePins.add @[]

proc tryPushChannel*(v, item: Value): tuple[pushed: bool, closed: bool,
                                            full: bool] =
  let stored = escapeWeakFunctions(item)
  let state {.cursor.} = channelData(v).state
  withChannelStateLock(state):
    if state.closed:
      result.closed = true
    elif state.items.len >= state.capacity:
      result.full = true
    else:
      state.items.add stored
      state.scopePins.add @[]
      result.pushed = true

proc tryPushManagedChannel*(v, item: Value, pins: seq[Scope]):
    tuple[pushed: bool, closed: bool, full: bool] =
  let stored = escapeWeakFunctions(item)
  let state {.cursor.} = channelData(v).state
  withChannelStateLock(state):
    if state.closed:
      result.closed = true
    elif state.items.len >= state.capacity:
      result.full = true
    else:
      state.items.add stored
      state.scopePins.add pins
      result.pushed = true

proc ownedChannelPins(pins: seq[Scope]): seq[Scope] {.inline.} = pins

proc tryPopManagedChannel*(v: Value):
    tuple[popped: bool, item: Value, pins: seq[Scope]] =
  let state {.cursor.} = channelData(v).state
  withChannelStateLock(state):
    if state.items.len == 0:
      return
    result.item = state.items[0]
    result.pins = ownedChannelPins(state.scopePins[0])
    state.items.delete(0)
    state.scopePins.delete(0)
    result.popped = true

proc popChannel*(v: Value): Value =
  let state {.cursor.} = channelData(v).state
  var pins: seq[Scope]
  withChannelStateLock(state):
    if state.items.len == 0:
      raise newException(FieldDefect, "channel is empty")
    result = state.items[0]
    pins = ownedChannelPins(state.scopePins[0])
    state.items.delete(0)
    state.scopePins.delete(0)
  if pins.len > 0:
    pinLegacyManagedScopes(pins)
    markSharedValue(result) # handed to the legacy VM surface

proc tryPopChannel*(v: Value): tuple[popped: bool, item: Value] =
  let state {.cursor.} = channelData(v).state
  var pins: seq[Scope]
  withChannelStateLock(state):
    if state.items.len == 0:
      return (false, NIL)
    result.item = state.items[0]
    pins = ownedChannelPins(state.scopePins[0])
    state.items.delete(0)
    state.scopePins.delete(0)
    result.popped = true
  if pins.len > 0:
    pinLegacyManagedScopes(pins)
    markSharedValue(result.item) # legacy raw return

proc actorData(v: Value): ActorData =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okActorRef:
    raise newException(FieldDefect, "value is not an ActorRef")
  ActorData(objData(v))

proc actorState*(v: Value): Value =
  let data = actorData(v)
  withActorLock(data):
    result = data.state

proc setActorState*(v, state: Value) =
  let stored = escapeWeakFunctions(state)
  let data = actorData(v)
  withActorLock(data):
    if data.managed:
      raise newException(GeneError, "managed Actor state needs an ownership ticket")
    data.state = stored

proc actorHandler*(v: Value): Value =
  let data = actorData(v)
  withActorLock(data):
    result = data.handler

proc setActorHandler*(v, handler: Value) =
  let stored = escapeWeakFunctions(handler)
  let data = actorData(v)
  withActorLock(data):
    if data.managed:
      raise newException(GeneError, "managed Actor handler needs an ownership ticket")
    data.handler = stored

proc actorSnapshotFields*(v: Value): tuple[state: Value, mailbox: int,
                                           closed: bool, processing: bool,
                                           idle: bool] =
  let data = actorData(v)
  withActorLock(data):
    result.state = data.state
    result.mailbox = data.queue.len
    result.closed = data.lifecycle.closed
    result.processing = data.processing
    result.idle = not data.processing and data.queue.len == 0 and
      data.reservedMessages == 0

proc finishActorContinue*(v, state: Value) =
  let stored = escapeWeakFunctions(state)
  let data = actorData(v)
  withActorLock(data):
    data.state = stored
    data.processing = false

proc configureManagedActor*(v: Value, statePins, handlerPins,
                            contractPins: seq[Scope]) =
  let data = actorData(v)
  withActorLock(data):
    data.managed = true
    data.statePins = statePins
    data.handlerPins = handlerPins
    data.contractPins = contractPins

proc actorManaged*(v: Value): bool =
  let data = actorData(v)
  withActorLock(data):
    result = data.managed

proc actorManagedStateSnapshot*(v: Value): tuple[state: Value,
                                                 pins: seq[Scope]] =
  let data = actorData(v)
  withActorLock(data):
    if not data.managed:
      raise newException(GeneError, "managed state requires a managed Actor")
    result.state = data.state
    result.pins = data.statePins

proc finishActorContinueManaged*(v, state: Value, pins: seq[Scope]) =
  let stored = escapeWeakFunctions(state)
  let data = actorData(v)
  var oldState: Value
  var oldPins: seq[Scope]
  withActorLock(data):
    doAssert data.managed
    oldState = move(data.state)
    oldPins = move(data.statePins)
    data.state = stored
    data.statePins = pins
    data.processing = false
  reset(oldState)
  reset(oldPins)

proc tryUpgradeIdleActor*(v, state, handler: Value): bool =
  let storedState = escapeWeakFunctions(state)
  let storedHandler = escapeWeakFunctions(handler)
  let data = actorData(v)
  withActorLock(data):
    if data.processing or data.queue.len > 0 or data.reservedMessages > 0:
      return false
    data.state = storedState
    data.handler = storedHandler
    result = true

proc tryUpgradeIdleManagedActor*(v, state, handler: Value,
    statePins, handlerPins: seq[Scope]): bool =
  let storedState = escapeWeakFunctions(state)
  let storedHandler = escapeWeakFunctions(handler)
  let data = actorData(v)
  var oldState, oldHandler: Value
  var oldStatePins, oldHandlerPins: seq[Scope]
  withActorLock(data):
    if not data.managed:
      raise newException(GeneError, "managed upgrade requires a managed Actor")
    if data.processing or data.queue.len > 0 or data.reservedMessages > 0:
      return false
    oldState = move(data.state)
    oldHandler = move(data.handler)
    oldStatePins = move(data.statePins)
    oldHandlerPins = move(data.handlerPins)
    data.state = storedState
    data.handler = storedHandler
    data.statePins = statePins
    data.handlerPins = handlerPins
    result = true
  reset(oldState)
  reset(oldHandler)
  reset(oldStatePins)
  reset(oldHandlerPins)

proc actorRestartInit*(v: Value): Value =
  let data = actorData(v)
  withActorLock(data):
    result = data.restartInit

proc actorConsumeRestartBudget*(v: Value): bool =
  ## Take one restart permission under the actor's ^max_restarts/^within_ms
  ## policy (async-http-server proposal §18.5). False means the budget is
  ## exhausted and the actor must stop instead of restarting. Failure-path
  ## only; never called on message hot paths.
  let data = actorData(v)
  withActorLock(data):
    if data.maxRestarts <= 0:
      return true
    let now = getMonoTime()
    if data.restartWindowMs > 0 and
        (data.restartCount == 0 or
         (now - data.restartWindowStart).inMilliseconds >=
           data.restartWindowMs):
      data.restartWindowStart = now
      data.restartCount = 0
    if data.restartCount >= data.maxRestarts:
      return false
    inc data.restartCount
    result = true

proc actorMessageType*(v: Value): Value =
  let data = actorData(v)
  withActorLock(data):
    result = data.messageType

proc actorMessageTypeExplicit*(v: Value): bool =
  let data = actorData(v)
  withActorLock(data):
    result = data.messageTypeExplicit

proc actorFailureStrategy*(v: Value): ActorFailureStrategy =
  let data = actorData(v)
  withActorLock(data):
    result = data.failureStrategy

proc actorFailureEvents*(v: Value): Value =
  let data = actorData(v)
  withActorLock(data):
    result = data.failureEvents

proc actorFailureDeadLetters*(v: Value): Value =
  let data = actorData(v)
  withActorLock(data):
    result = data.failureDeadLetters

proc actorParentFailureEvents*(v: Value): Value =
  let data = actorData(v)
  withActorLock(data):
    result = data.parentFailureEvents

proc actorParentFailureDeadLetters*(v: Value): Value =
  let data = actorData(v)
  withActorLock(data):
    result = data.parentFailureDeadLetters

proc setActorMessageType*(v, messageType: Value) =
  let data = actorData(v)
  withActorLock(data):
    if data.managed:
      raise newException(GeneError, "managed Actor contract needs an ownership ticket")
    data.messageType = messageType

proc setManagedActorMessageType*(v, messageType: Value,
                                 pins: seq[Scope]) =
  let data = actorData(v)
  var oldType: Value
  var oldPins: seq[Scope]
  withActorLock(data):
    if not data.managed:
      raise newException(GeneError, "managed contract requires a managed Actor")
    oldType = move(data.messageType)
    oldPins = move(data.contractPins)
    data.messageType = messageType
    data.contractPins = pins
  reset(oldType)
  reset(oldPins)

proc actorClosed*(v: Value): bool =
  let data = actorData(v)
  withActorLock(data):
    result = data.lifecycle.closed

proc actorProcessing*(v: Value): bool =
  let data = actorData(v)
  withActorLock(data):
    result = data.processing

proc setActorProcessing*(v: Value, processing: bool) =
  let data = actorData(v)
  withActorLock(data):
    data.processing = processing

proc actorQueueLen*(v: Value): int =
  let data = actorData(v)
  withActorLock(data):
    result = data.queue.len

proc actorFull*(v: Value): bool =
  let data = actorData(v)
  withActorLock(data):
    result = data.queue.len + data.reservedMessages >= data.capacity

proc actorSendState*(v: Value): tuple[closed: bool, full: bool] =
  let data = actorData(v)
  withActorLock(data):
    result.closed = data.lifecycle.closed
    result.full = data.queue.len + data.reservedMessages >= data.capacity

proc closeActor*(v: Value) =
  let data = actorData(v)
  withActorLock(data):
    data.lifecycle.closed = true

proc drainActorMessages*(v: Value): seq[ActorMessage] =
  let data = actorData(v)
  withActorLock(data):
    result = data.queue
    data.queue.setLen(0)

proc closeActorAndDrainMessages*(v: Value): seq[ActorMessage] =
  let data = actorData(v)
  withActorLock(data):
    data.lifecycle.closed = true
    result = data.queue
    data.queue.setLen(0)
    data.reservedMessages = 0
    data.processing = false

proc actorMessagesSnapshot*(v: Value): seq[ActorMessage] =
  let data = actorData(v)
  withActorLock(data):
    result = data.queue

proc pushActorMessage*(v, message: Value) =
  let stored = escapeWeakFunctions(message)
  let data = actorData(v)
  withActorLock(data):
    data.queue.add ActorMessage(message: stored, reply: NIL,
                                workerAllowed: false)

proc pushActorMessage*(v, message, reply: Value) =
  let stored = escapeWeakFunctions(message)
  let data = actorData(v)
  withActorLock(data):
    data.queue.add ActorMessage(message: stored, reply: reply,
                                workerAllowed: true)

proc tryPushActorMessage*(v, message: Value,
                          workerAllowed = false): tuple[pushed: bool,
                                                        closed: bool,
                                                        full: bool] =
  let stored = escapeWeakFunctions(message)
  let data = actorData(v)
  withActorLock(data):
    if data.lifecycle.closed:
      result.closed = true
    elif data.queue.len + data.reservedMessages >= data.capacity:
      result.full = true
    else:
      data.queue.add ActorMessage(message: stored, reply: NIL,
                                  workerAllowed: workerAllowed)
      result.pushed = true

proc tryPushManagedActorMessage*(v, message: Value,
                                 pins: seq[Scope]): tuple[pushed: bool,
                                                          closed: bool,
                                                          full: bool] =
  let stored = escapeWeakFunctions(message)
  let data = actorData(v)
  withActorLock(data):
    if not data.managed:
      raise newException(GeneError, "managed send requires a managed Actor")
    if data.lifecycle.closed:
      result.closed = true
    elif data.queue.len + data.reservedMessages >= data.capacity:
      result.full = true
    else:
      data.queue.add ActorMessage(message: stored, reply: NIL,
                                  workerAllowed: true, pins: pins)
      result.pushed = true

proc tryPushActorMessage*(v, message, reply: Value): tuple[pushed: bool,
                                                           closed: bool,
                                                           full: bool] =
  let stored = escapeWeakFunctions(message)
  let data = actorData(v)
  withActorLock(data):
    if data.lifecycle.closed:
      result.closed = true
    elif data.queue.len + data.reservedMessages >= data.capacity:
      result.full = true
    else:
      data.queue.add ActorMessage(message: stored, reply: reply,
                                  workerAllowed: true)
      result.pushed = true

proc tryReserveActorMessage*(v: Value): tuple[reserved: bool, closed: bool,
                                              full: bool] =
  let data = actorData(v)
  withActorLock(data):
    if data.lifecycle.closed:
      result.closed = true
    elif data.queue.len + data.reservedMessages >= data.capacity:
      result.full = true
    else:
      inc data.reservedMessages
      result.reserved = true

proc releaseReservedActorMessage*(v: Value) =
  let data = actorData(v)
  withActorLock(data):
    if data.reservedMessages > 0:
      dec data.reservedMessages

proc commitReservedActorMessage*(v, message, reply: Value): tuple[pushed: bool,
                                                                  closed: bool] =
  let stored = escapeWeakFunctions(message)
  let data = actorData(v)
  withActorLock(data):
    if data.reservedMessages > 0:
      dec data.reservedMessages
    if data.lifecycle.closed:
      result.closed = true
    else:
      data.queue.add ActorMessage(message: stored, reply: reply,
                                  workerAllowed: true)
      result.pushed = true

proc popActorMessage*(v: Value): ActorMessage =
  let data = actorData(v)
  withActorLock(data):
    if data.queue.len == 0:
      raise newException(FieldDefect, "actor mailbox is empty")
    result = data.queue[0]
    data.queue.delete(0)

proc tryStartActorMessage*(v: Value): tuple[started: bool, item: ActorMessage] =
  let data = actorData(v)
  withActorLock(data):
    if data.processing or data.lifecycle.closed or data.queue.len == 0:
      return (false, ActorMessage())
    result.item = data.queue[0]
    data.queue.delete(0)
    data.processing = true
    result.started = true

proc actorContextActor*(v: Value): Value =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okActorContext:
    raise newException(FieldDefect, "value is not an ActorContext")
  ActorContextData(objData(v)).actor

proc actorStepContinue*(v: Value): bool =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okActorStep:
    raise newException(FieldDefect, "value is not an ActorStep")
  ActorStepData(objData(v)).continueActor

proc actorStepState*(v: Value): Value =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okActorStep:
    raise newException(FieldDefect, "value is not an ActorStep")
  ActorStepData(objData(v)).state

proc replyToData(v: Value): ReplyToData =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okReplyTo:
    raise newException(FieldDefect, "value is not a ReplyTo")
  ReplyToData(objData(v))

proc replyToSent*(v: Value): bool =
  let data = replyToData(v)
  withReplyToLock(data):
    result = data.sent

proc replyToResult*(v: Value): Value =
  let data = replyToData(v)
  withReplyToLock(data):
    result = data.result

proc replyToResultType*(v: Value): Value =
  let data = replyToData(v)
  withReplyToLock(data):
    result = data.resultType

proc replyToResultScope*(v: Value): Scope =
  let data = replyToData(v)
  withReplyToLock(data):
    result = data.resultScope

proc replyToRelaxedSend*(v: Value): bool =
  let data = replyToData(v)
  withReplyToLock(data):
    result = data.relaxedSend

proc replyToTask*(v: Value): Value =
  let data = replyToData(v)
  withReplyToLock(data):
    result = data.task

proc setReplyToResultType*(v, resultType: Value, scope: Scope) =
  let data = replyToData(v)
  withReplyToLock(data):
    data.resultType = resultType
    data.resultScope = scope

proc cancelReplyTo*(v: Value) =
  let data = replyToData(v)
  withReplyToLock(data):
    data.sent = true
    data.result = NIL
    data.task = NIL

proc completeTask*(v, value: Value)

proc claimReplyToCancel*(v: Value): tuple[claimed: bool, task: Value] =
  let data = replyToData(v)
  withReplyToLock(data):
    if data.sent:
      return
    data.sent = true
    data.result = NIL
    result.task = data.task
    data.task = NIL
    result.claimed = true

proc trySendReplyTo*(v, value: Value): tuple[sent: bool, task: Value,
                                             discarded: bool] =
  let stored = escapeWeakFunctions(value)
  let data = replyToData(v)
  withReplyToLock(data):
    if data.sent:
      return
    if data.task.kind == vkTask and data.task.taskDone:
      data.sent = true
      data.result = NIL
      data.task = NIL
      result.sent = true
      result.discarded = true
      return
    data.result = stored
    data.sent = true
    result.task = data.task
    data.task = NIL
    result.sent = true
  if result.task.kind == vkTask:
    completeTask(result.task, stored)

proc sendReplyTo*(v, value: Value) =
  if not trySendReplyTo(v, value).sent:
    raise newException(FieldDefect, "reply has already been sent")

proc cPtrData(v: Value): CPtrData =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okCPtr:
    raise newException(FieldDefect, "value is not a C pointer")
  CPtrData(objData(v))

proc cPtrAddress*(v: Value): pointer =
  cPtrData(v).address

proc cPtrTargetType*(v: Value): Value =
  cPtrData(v).targetType

proc cPtrMutable*(v: Value): bool =
  cPtrData(v).mutable

proc cPtrOwned*(v: Value): bool =
  cPtrData(v).owned

proc cPtrClosed*(v: Value): bool =
  cPtrData(v).closed

proc cPtrIsNull*(v: Value): bool =
  let data = cPtrData(v)
  data.address == nil

proc borrowCPtr*(v: Value) =
  ## The caller keeps a strong Value until releaseCPtrBorrow. This pin only
  ## prevents explicit disposal/transfer while a native operation is active.
  let data = cPtrData(v)
  if data.closed or data.address == nil:
    raise newException(GeneError, "cannot borrow a closed C pointer")
  inc data.activeBorrows

proc releaseCPtrBorrow*(v: Value) =
  let data = cPtrData(v)
  if data.activeBorrows <= 0:
    raise newException(GeneError, "C pointer has no active borrow")
  dec data.activeBorrows

proc closeCPtr*(v: Value) =
  let data = cPtrData(v)
  if not data.owned:
    raise newException(GeneError, "cannot close a borrowed C pointer")
  if data.closed:
    return
  if data.activeBorrows > 0:
    raise newException(GeneError, "cannot close a C pointer while a native call borrows it")
  if data.release != nil and data.address != nil:
    data.release(data.address)
  elif data.foreignRelease != nil and data.address != nil:
    type ForeignReleaseProc = proc(address: pointer) {.cdecl.}
    cast[ForeignReleaseProc](data.foreignRelease)(data.address)
  data.address = nil
  data.closed = true
  if data.library.kind == vkFfiLibrary:
    releaseFfiLibraryBorrow(data.library)
    data.library = NIL

proc relinquishCPtr*(v: Value) =
  ## Mark an owned pointer closed *without* running its release callback.
  ##
  ## This is ownership transfer, not disposal: someone else now owns the
  ## address and will free it. `closeCPtr` would free it here, leaving the new
  ## owner with a dangling pointer — and the wrapper must still become unusable
  ## so the same address cannot be handed out twice.
  let data = cPtrData(v)
  if data.closed:
    return
  if data.activeBorrows > 0:
    raise newException(GeneError, "cannot transfer a C pointer while a native call borrows it")
  data.address = nil
  data.closed = true

proc restoreCPtr*(v: Value, address: pointer) =
  ## Undo `relinquishCPtr`. Ownership transfer is only complete once the callee
  ## actually runs; if acquisition fails afterwards the transfer must be taken
  ## back, or the pointer has no owner at all — the wrapper is closed and
  ## nothing will ever release it.
  let data = cPtrData(v)
  if data.activeBorrows > 0:
    raise newException(GeneError, "cannot replace a C pointer while a native call borrows it")
  data.address = address
  data.closed = false

proc cSliceData(v: Value): CSliceData =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okCSlice:
    raise newException(FieldDefect, "value is not a C slice")
  CSliceData(objData(v))

proc cSliceAddress*(v: Value): pointer =
  cSliceData(v).address

proc cSliceLen*(v: Value): int =
  cSliceData(v).length

proc cSliceTargetType*(v: Value): Value =
  cSliceData(v).targetType

proc cSliceMutable*(v: Value): bool =
  cSliceData(v).mutable

proc cSliceIsNull*(v: Value): bool =
  cSliceData(v).address == nil

# Buffer access is split into a *check* and a *view*, deliberately, and the
# split is what makes it free.
#
# As one `bufferData(v)` proc this cost a `=dup`/`=destroy` pair per access —
# ORC traffic on the innermost loop in the language, since every element read
# and write goes through it. Folding the guard and the cast into a `template`
# does not fix it either: a template whose body is a `block` yields a block
# *expression*, which Nim assigns to a temporary, and the assignment is the
# copy. Only a bare expression substitutes cleanly.
#
# So: `checkBuffer` is a statement, `bufferView` is an expression, and
# `bufferView(v).items` compiles to the field read it reads as.

template checkBuffer(v: Value) =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okBuffer:
    raise newException(FieldDefect, "value is not a Buffer")

template bufferView(v: Value): BufferData =
  ## Only valid after `checkBuffer`. `cast` rather than `BufferData(...)`
  ## because that conversion re-proves the tag with an `isObjDisplayCheck` and
  ## carries a `raiseObjectConversionError` path the guard has already ruled
  ## out. Non-owning, on the same terms as `objData`: `v` is the owner.
  cast[BufferData](objData(v))

proc bufferElemType*(v: Value): Value =
  checkBuffer(v)
  bufferView(v).elemType

proc bufferElemScope*(v: Value): Scope =
  checkBuffer(v)
  bufferView(v).elemScope

func bufferElementBytes*(storage: BufferStorageKind): int =
  case storage
  of bskValues: sizeof(Value)
  of bskI8, bskU8: 1
  of bskI16, bskU16: 2
  of bskI32, bskU32, bskF32: 4
  of bskI64, bskU64, bskF64: 8

proc bufferStorageKind*(v: Value): BufferStorageKind =
  checkBuffer(v)
  bufferView(v).storage

proc bufferLen*(v: Value): int {.inline.} =
  checkBuffer(v)
  let data {.cursor.} = bufferView(v)
  if data.storage == bskValues: data.items.len
  else: data.length

proc bufferStorageBytes*(v: Value): int =
  ## Backing payload only, excluding the fixed-size buffer descriptor.
  checkBuffer(v)
  let data {.cursor.} = bufferView(v)
  if data.storage == bskValues: data.items.len * sizeof(Value)
  else: data.packed.len

proc bufferItem*(v: Value, index: int): Value {.inline.}
proc setBufferItem*(v: Value, index: int, item: Value) {.inline.}
proc fillBufferItems*(v: Value, first, last: int, item: Value)
proc copyBufferItems*(dst: Value, dstStart: int,
                      src: Value, srcStart, srcEnd: int)

iterator bufferItems*(v: Value): Value =
  ## Walk without materializing a boxed copy of packed storage.
  for i in 0 ..< v.bufferLen:
    yield v.bufferItem(i)

proc bufferToItems*(v: Value): seq[Value] =
  ## An explicit detached conversion, used by Buffer/to_list.
  result = newSeq[Value](v.bufferLen)
  for i in 0 ..< result.len:
    result[i] = v.bufferItem(i)

proc deviceBufferData(v: Value): DeviceBufferData =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okDeviceBuffer:
    raise newException(FieldDefect, "value is not a Device/Buffer")
  DeviceBufferData(objData(v))

proc deviceBufferBackend*(v: Value): string =
  deviceBufferData(v).backend

proc deviceBufferElemType*(v: Value): Value =
  deviceBufferData(v).elemType

proc deviceBufferLen*(v: Value): int =
  deviceBufferData(v).length

proc ffiLibraryData(v: Value): FfiLibraryData =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okFfiLibrary:
    raise newException(FieldDefect, "value is not an FFI library")
  FfiLibraryData(objData(v))

proc ffiLibraryHandle*(v: Value): pointer =
  ffiLibraryData(v).handle

proc ffiLibraryPath*(v: Value): string =
  ffiLibraryData(v).path

proc ffiLibraryClosed*(v: Value): bool =
  ffiLibraryData(v).closed

proc closeFfiLibrary*(v: Value) =
  let data = ffiLibraryData(v)
  if data.closed:
    return
  if data.nativeBorrows > 0:
    raise newException(GeneError,
      "ffi/Library has active native borrows")
  if data.close != nil and data.handle != nil:
    data.close(data.handle)
  data.handle = nil
  data.closed = true

proc borrowFfiLibrary*(v: Value) =
  let data = ffiLibraryData(v)
  if data.closed or data.handle == nil:
    raise newException(GeneError, "ffi/Library is closed")
  inc data.nativeBorrows

proc releaseFfiLibraryBorrow*(v: Value) =
  let data = ffiLibraryData(v)
  if data.nativeBorrows <= 0:
    raise newException(GeneError,
      "ffi/Library has no native borrow")
  dec data.nativeBorrows

proc typeName*(v: Value): string =
  if v.tagOf != OBJECT_TAG or objData(v).objKind notin {okType, okEnum}:
    raise newException(FieldDefect, "value is not a Type")
  case objData(v).objKind
  of okEnum: EnumData(objData(v)).name
  else: TypeData(objData(v)).name

proc typeParent*(v: Value): Value =
  if v.tagOf != OBJECT_TAG or objData(v).objKind notin {okType, okEnum}:
    raise newException(FieldDefect, "value is not a Type")
  if objData(v).objKind == okEnum:
    return NIL
  TypeData(objData(v)).parent

proc typeRepr*(v: Value): TypeRepr =
  ## The type's representation marker. Enums and non-types are ordinary.
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okType:
    return trOrdinary
  TypeData(objData(v)).repr

proc typeNativeIdentity*(v: Value): string =
  ## The `^native` identity this type was compiled with, or "" when it has no
  ## native representation. See `TypeData.nativeIdentity`.
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okType:
    return ""
  TypeData(objData(v)).nativeIdentity

proc typeNativeAbiIdentity*(v: Value): string =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okType:
    return ""
  TypeData(objData(v)).nativeAbiIdentity

proc typeNativeAbiFingerprint*(v: Value): string =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okType:
    return ""
  TypeData(objData(v)).nativeAbiFingerprint

proc typeNativeContractFingerprint*(v: Value): string =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okType:
    return ""
  TypeData(objData(v)).nativeContractFingerprint

proc typeInheritsFrom*(actual, ancestor: Value): bool =
  ## Nominal ancestry by Type *identity*: true when `actual` is `ancestor` or
  ## one of its nominal descendants. Every step compares `bits`, never the name —
  ## two modules may each declare a `Conn`, and a name check would let one
  ## module's value satisfy the other's receiver guard.
  if actual.kind != vkType or ancestor.kind != vkType:
    return false
  var current = actual
  while current.kind == vkType:
    if current.bits == ancestor.bits:
      return true
    current = current.typeParent
  false

proc isNativeWrapperType*(v: Value): bool {.inline.} =
  ## True for a `^repr native_wrapper` type and, because newType copies the
  ## marker down, for every nominal descendant of one. Checking the flag rather
  ## than walking the ancestry keeps the construction and write gates O(1).
  v.tagOf == OBJECT_TAG and objData(v).objKind == okType and
    TypeData(objData(v)).repr == trNativeWrapper

proc typeFields*(v: Value): seq[TypeField] =
  ## Full field schema, parent fields first (inheritance is merged at newType).
  if v.tagOf != OBJECT_TAG or objData(v).objKind notin {okType, okEnum}:
    raise newException(FieldDefect, "value is not a Type")
  if objData(v).objKind == okEnum:
    return @[]
  TypeData(objData(v)).fields

proc typeBodyFields*(v: Value): seq[TypeBodyField] =
  ## Full body schema, parent fields first (inheritance is merged at newType).
  if v.tagOf != OBJECT_TAG or objData(v).objKind notin {okType, okEnum}:
    raise newException(FieldDefect, "value is not a Type")
  if objData(v).objKind == okEnum:
    return @[]
  TypeData(objData(v)).bodyFields

proc typeCtor*(v: Value): Value =
  ## The type's own (ctor ...) function value, or NIL.
  if v.tagOf != OBJECT_TAG or objData(v).objKind notin {okType, okEnum}:
    raise newException(FieldDefect, "value is not a Type")
  if objData(v).objKind == okEnum:
    return NIL
  TypeData(objData(v)).ctorFn

proc typeNativeCtor*(v: Value): Value =
  ## The native `(T …)` constructor for a built-in surface type, or NIL.
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okType:
    return NIL
  TypeData(objData(v)).nativeCtor

proc setTypeNativeCtor*(v: Value, ctor: Value) =
  ## Install-once, at built-in registration. A built-in surface type is
  ## immutable after construction (the process shares one identity across
  ## Applications), so this must run before the type is published.
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okType:
    raise newException(FieldDefect, "value is not a Type")
  TypeData(objData(v)).nativeCtor = ctor

proc typeConstructor*(v: Value): Value =
  ## The nearest constructor in the type's ancestry, including the type
  ## itself. A child constructor overrides an inherited one; constructors do
  ## not chain automatically.
  var current = v
  while current.kind == vkType:
    let ctor = current.typeCtor
    if ctor.kind != vkNil:
      return ctor
    current = current.typeParent
  NIL

proc typeScope*(v: Value): Scope =
  if v.tagOf != OBJECT_TAG or objData(v).objKind notin {okType, okEnum}:
    raise newException(FieldDefect, "value is not a Type")
  if objData(v).objKind == okEnum:
    let data = EnumData(objData(v))
    if data.scope != nil:
      return data.scope
    return cast[Scope](data.weakScope)
  let data = TypeData(objData(v))
  if data.scope != nil:
    data.scope
  else:
    cast[Scope](data.weakScope)

proc typeFieldScope*(field: TypeField, fallback: Scope): Scope =
  if field.scope != nil:
    field.scope
  elif field.weakScope != nil:
    cast[Scope](field.weakScope)
  else:
    fallback

proc typeBodyFieldScope*(field: TypeBodyField, fallback: Scope): Scope =
  if field.scope != nil:
    field.scope
  elif field.weakScope != nil:
    cast[Scope](field.weakScope)
  else:
    fallback

proc typeRequiredProtocols*(v: Value): lent seq[Value] =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okType:
    raise newException(FieldDefect, "value is not a Type")
  TypeData(objData(v)).requiredProtocols

proc typeDerivedProtocols*(v: Value): lent seq[Value] =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okType:
    raise newException(FieldDefect, "value is not a Type")
  TypeData(objData(v)).derivedProtocols

proc typeDeriveRequests*(v: Value): lent seq[Value] =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okType:
    raise newException(FieldDefect, "value is not a Type")
  TypeData(objData(v)).deriveRequests

proc isEnumType*(v: Value): bool {.inline.} =
  v.tagOf == OBJECT_TAG and objData(v).objKind == okEnum

proc enumTypeParams*(v: Value): seq[string] =
  if not v.isEnumType:
    raise newException(FieldDefect, "value is not an Enum")
  EnumData(objData(v)).typeParams

proc enumBackingType*(v: Value): Value =
  if not v.isEnumType:
    raise newException(FieldDefect, "value is not an Enum")
  EnumData(objData(v)).backingType

proc enumVariants*(v: Value): seq[Value] =
  if not v.isEnumType:
    raise newException(FieldDefect, "value is not an Enum")
  EnumData(objData(v)).variants

proc enumVariantDescriptor*(enumType: Value, name: string): Value =
  if not enumType.isEnumType:
    return VOID
  for variant in EnumData(objData(enumType)).variants:
    if EnumVariantData(objData(variant)).name == name:
      return variant
  VOID

proc isEnumVariant*(v: Value): bool {.inline.} =
  v.tagOf == OBJECT_TAG and objData(v).objKind == okEnumVariant

proc enumVariantEnum*(v: Value): Value =
  if not v.isEnumVariant:
    raise newException(FieldDefect, "value is not an enum variant")
  result.bits = EnumVariantData(objData(v)).enumBits
  if (result.bits shr TAG_SHIFT) >= MANAGED_MIN:
    rcRetain(result.bits)

proc enumVariantName*(v: Value): string =
  if not v.isEnumVariant:
    raise newException(FieldDefect, "value is not an enum variant")
  EnumVariantData(objData(v)).name

proc enumVariantOrdinal*(v: Value): int =
  if not v.isEnumVariant:
    raise newException(FieldDefect, "value is not an enum variant")
  EnumVariantData(objData(v)).ordinal

proc enumVariantPayloadTypes*(v: Value): seq[Value] =
  if not v.isEnumVariant:
    raise newException(FieldDefect, "value is not an enum variant")
  EnumVariantData(objData(v)).payloadTypes

proc enumVariantHasBacking*(v: Value): bool =
  if not v.isEnumVariant:
    raise newException(FieldDefect, "value is not an enum variant")
  EnumVariantData(objData(v)).hasBacking

proc enumVariantBacking*(v: Value): Value =
  if not v.isEnumVariant:
    raise newException(FieldDefect, "value is not an enum variant")
  let data = EnumVariantData(objData(v))
  if data.hasBacking: data.backing else: VOID

proc enumValueVariant*(v: Value): Value =
  if v.isEnumVariant:
    return v
  if v.kind == vkNode and v.head.isEnumVariant:
    return v.head
  NIL

proc enumValueEnum*(v: Value): Value =
  let variant = v.enumValueVariant
  if variant.kind == vkEnumVariant:
    variant.enumVariantEnum
  else:
    NIL

proc protocolName*(v: Value): lent string =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okProtocol:
    raise newException(FieldDefect, "value is not a Protocol")
  ProtocolData(objData(v)).name

proc isErrorProtocol*(v: Value): bool {.inline.} =
  v.tagOf == OBJECT_TAG and objData(v).objKind == okProtocol and
    ProtocolData(objData(v)).errorRoot

proc protocolScope*(v: Value): Scope =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okProtocol:
    raise newException(FieldDefect, "value is not a Protocol")
  cast[Scope](ProtocolData(objData(v)).weakScope)

proc protocolMessages*(v: Value): lent OrderedTable[string, Value] =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okProtocol:
    raise newException(FieldDefect, "value is not a Protocol")
  ProtocolData(objData(v)).messages

proc protocolDeriveFn*(v: Value): Value =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okProtocol:
    raise newException(FieldDefect, "value is not a Protocol")
  ProtocolData(objData(v)).deriveFn

proc protocolUniversal*(v: Value): bool =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okProtocol:
    raise newException(FieldDefect, "value is not a Protocol")
  ProtocolData(objData(v)).universal

proc protocolMessageName*(v: Value): lent string =
  # `lent` cannot borrow out of a case *expression*, so branch with returns.
  if v.tagOf == OBJECT_TAG:
    let d {.cursor.} = objData(v)   # a view; `v` owns it for this scope
    if d.objKind == okProtocolMessage:
      return ProtocolMessageData(d).name
    if d.objKind == okBoundMessage:
      return BoundMessageData(d).name
  raise newException(FieldDefect, "value is not a ProtocolMessage")

proc protocolMessageProtocol*(v: Value): Value =
  if v.tagOf != OBJECT_TAG:
    raise newException(FieldDefect, "value is not a ProtocolMessage")
  let bits =
    case objData(v).objKind
    of okProtocolMessage: ProtocolMessageData(objData(v)).protocolBits
    of okBoundMessage: BoundMessageData(objData(v)).protocolBits
    else: raise newException(FieldDefect, "value is not a ProtocolMessage")
  if (bits shr TAG_SHIFT) >= MANAGED_MIN:
    rcRetain(bits)
  Value(bits: bits)

proc protocolMessageSignatureFn*(v: Value): Value =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okProtocolMessage:
    raise newException(FieldDefect, "value is not a ProtocolMessage")
  ProtocolMessageData(objData(v)).signatureFn

proc protocolMessageDefaultFn*(v: Value): Value =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okProtocolMessage:
    raise newException(FieldDefect, "value is not a ProtocolMessage")
  let d = ProtocolMessageData(objData(v))
  if d.hasDefault: d.signatureFn else: NIL

# ---------------------------------------------------------------------------
# Constructors
# ---------------------------------------------------------------------------

proc newInt*(v: int64): Value {.inline.} =
  if v >= SMALL_INT_MIN and v <= SMALL_INT_MAX:
    mkImm(INT_TAG, encodeSmallInt(v))
  else:
    let p = createObj(GeneInt64)
    p.refCount = 1
    p.i = v
    boxPtr(INT64_TAG, p)

proc intBigValue(v: Value): BigIntValue =
  case v.bits shr TAG_SHIFT
  of INT_TAG:
    bigFromInt64(decodeSmallInt(v.bits))
  of INT64_TAG:
    bigFromInt64(cast[ptr GeneInt64](v.bits and PAYLOAD_MASK).i)
  of OBJECT_TAG:
    if objData(v).objKind == okBigInt:
      BigIntData(objData(v)).value
    else:
      raise newException(FieldDefect, "value is not an Int")
  else:
    raise newException(FieldDefect, "value is not an Int")

proc bigToValue(x: BigIntValue): Value =
  let converted = bigToInt64(x)
  if converted.ok:
    return newInt(converted.value)
  boxObject(BigIntData(objKind: okBigInt, value: x))

proc newIntFromDecimal*(s: string): Value =
  bigToValue(parseBigDecimal(s))

proc newIntFromHex*(s: string): Value =
  ## s is the full hex literal lexeme, optionally signed: `0x1f` or `-0x1f`
  ## (design §2.2 hex_integer). The reader classifies the whole atom, so the
  ## sign arrives here rather than being lexed separately.
  if s.len > 0 and s[0] == '-':
    var v = parseBigHex(s, 3)
    if v.sign != 0: v.sign = -v.sign
    bigToValue(v)
  else:
    bigToValue(parseBigHex(s, 2))

proc intToString*(v: Value): string =
  case v.bits shr TAG_SHIFT
  of INT_TAG, INT64_TAG:
    $v.intVal
  of OBJECT_TAG:
    if objData(v).objKind == okBigInt:
      bigToString(BigIntData(objData(v)).value)
    else:
      raise newException(FieldDefect, "value is not an Int")
  else:
    raise newException(FieldDefect, "value is not an Int")

proc intToFloat*(v: Value): float64 =
  parseFloat(v.intToString)

proc intIsZero*(v: Value): bool {.inline.} =
  case v.bits shr TAG_SHIFT
  of INT_TAG, INT64_TAG:
    v.intVal == 0
  of OBJECT_TAG:
    if objData(v).objKind == okBigInt:
      BigIntData(objData(v)).value.sign == 0
    else:
      raise newException(FieldDefect, "value is not an Int")
  else:
    raise newException(FieldDefect, "value is not an Int")

proc isInt64Backed(v: Value): bool {.inline.} =
  let tag = v.bits shr TAG_SHIFT
  tag == INT_TAG or tag == INT64_TAG

proc isSmallInt*(v: Value): bool {.inline.} =
  (v.bits shr TAG_SHIFT) == INT_TAG

proc smallIntVal*(v: Value): int64 {.inline.} =
  decodeSmallInt(v.bits)

# Two small Ints are 48-bit values, so their sum and difference always fit an
# int64. The unchecked operators say so: a checked `+` would give these
# two-instruction helpers a raise path, and with it an error-flag test in
# every arithmetic opcode that calls them.
proc smallIntAddKnown*(a, b: Value, outValue: var Value): bool {.inline.} =
  let s = a.smallIntVal +% b.smallIntVal
  if s < SMALL_INT_MIN or s > SMALL_INT_MAX:
    return false
  outValue = mkImm(INT_TAG, encodeSmallInt(s))
  true

proc smallIntSubKnown*(a, b: Value, outValue: var Value): bool {.inline.} =
  let s = a.smallIntVal -% b.smallIntVal
  if s < SMALL_INT_MIN or s > SMALL_INT_MAX:
    return false
  outValue = mkImm(INT_TAG, encodeSmallInt(s))
  true

proc smallIntAdd*(a, b: Value, outValue: var Value): bool {.inline.} =
  if not (a.isSmallInt and b.isSmallInt):
    return false
  smallIntAddKnown(a, b, outValue)

proc smallIntSub*(a, b: Value, outValue: var Value): bool {.inline.} =
  if not (a.isSmallInt and b.isSmallInt):
    return false
  smallIntSubKnown(a, b, outValue)

proc intCompare*(a, b: Value): int {.inline.} =
  if a.isSmallInt and b.isSmallInt:
    # The usual case, answered before the general kind and width tests.
    let av = a.smallIntVal
    let bv = b.smallIntVal
    return (if av < bv: -1 elif av > bv: 1 else: 0)
  if a.kind != vkInt or b.kind != vkInt:
    raise newException(FieldDefect, "value is not an Int")
  if a.isInt64Backed and b.isInt64Backed:
    let av = a.intVal
    let bv = b.intVal
    if av < bv: -1 elif av > bv: 1 else: 0
  else:
    cmpBig(a.intBigValue, b.intBigValue)

proc intCompareToInt64*(a: Value, b: int64): int {.inline.} =
  intCompare(a, newInt(b))

proc checkedAdd64(a, b: int64, outValue: var int64): bool {.inline.} =
  if (b > 0 and a > high(int64) - b) or
     (b < 0 and a < low(int64) - b):
    return false
  outValue = a + b
  true

proc checkedSub64(a, b: int64, outValue: var int64): bool {.inline.} =
  if (b > 0 and a < low(int64) + b) or
     (b < 0 and a > high(int64) + b):
    return false
  outValue = a - b
  true

proc mulOverflows64(a, b: int64, product: var int64): bool {.
  importc: "__builtin_smulll_overflow", nodecl.}
  ## The C compiler's checked multiply: true when the exact product does not
  ## fit an int64.

proc checkedMul64(a, b: int64, outValue: var int64): bool {.inline.} =
  # One multiply and a flag test. Deciding the same thing from magnitudes
  # costs an integer division on every Int multiplication.
  not mulOverflows64(a, b, outValue)

proc intAdd*(a, b: Value): Value {.inline.} =
  if a.isInt64Backed and b.isInt64Backed:
    var s: int64
    if checkedAdd64(a.intVal, b.intVal, s):
      return newInt(s)
  bigToValue(addBig(a.intBigValue, b.intBigValue))

proc intNeg*(a: Value): Value {.inline.} =
  if a.isInt64Backed:
    let av = a.intVal
    if av != low(int64):
      return newInt(-av)
  bigToValue(negBig(a.intBigValue))

proc intSub*(a, b: Value): Value {.inline.} =
  if a.isInt64Backed and b.isInt64Backed:
    var s: int64
    if checkedSub64(a.intVal, b.intVal, s):
      return newInt(s)
  bigToValue(subBig(a.intBigValue, b.intBigValue))

proc intMul*(a, b: Value): Value {.inline.} =
  if a.isSmallInt and b.isSmallInt:
    var p: int64
    if checkedMul64(a.smallIntVal, b.smallIntVal, p):
      return newInt(p)
  elif a.isInt64Backed and b.isInt64Backed:
    var p: int64
    if checkedMul64(a.intVal, b.intVal, p):
      return newInt(p)
  bigToValue(mulBig(a.intBigValue, b.intBigValue))

proc intDiv*(a, b: Value): Value {.inline.} =
  if b.intIsZero:
    raise newException(FieldDefect, "division by zero")
  if a.isInt64Backed and b.isInt64Backed:
    let av = a.intVal
    let bv = b.intVal
    if not (av == low(int64) and bv == -1):
      return newInt(av div bv)
  bigToValue(divBig(a.intBigValue, b.intBigValue))

proc newFloat*(v: float64): Value {.inline.} =
  let raw = cast[uint64](v)
  if raw == 0:
    return mkImm(FLOATZERO_TAG)            # +0.0 (raw 0 is reserved for nil)
  if (raw shr TAG_SHIFT) >= VOID_TAG:
    return Value(bits: CANONICAL_NAN)      # negative NaN colliding with tag space
  Value(bits: raw)

proc newStr*(v: sink string): Value =
  let p = createObj(GeneString)
  p.refCount = 1
  p.s = v
  boxPtr(STRING_TAG, p)

proc newBytes*(v: sink string): Value =
  boxObject(BytesData(objKind: okBytes, data: v))

proc canonicalRegexFlags*(flags: string): string =
  var seen: set[char]
  for ch in flags:
    if ch notin {'i', 'm', 's', 'x'}:
      raise newException(GeneError, "invalid Regex flag: " & $ch)
    if ch in seen:
      raise newException(GeneError, "duplicate Regex flag: " & $ch)
    seen.incl ch
  for ch in ['i', 'm', 's', 'x']:
    if ch in seen:
      result.add ch

when not defined(geneWasm):
  proc regexFlagSet(flags: string): set[nre.RegexFlag] =
    result = {nre.reStudy}
    for ch in canonicalRegexFlags(flags):
      case ch
      of 'i': result.incl nre.reIgnoreCase
      of 'm': result.incl nre.reMultiLine
      of 's': result.incl nre.reDotAll
      of 'x': result.incl nre.reExtended
      else: discard

proc regexCaptureInfo(pattern: string): tuple[count: int, names: Table[string, int]] =
  result.names = initTable[string, int]()
  var i = 0
  var groupIndex = 0
  var inClass = false
  while i < pattern.len:
    let ch = pattern[i]
    if ch == '\\':
      i += 2
      continue
    if ch == '[':
      inClass = true
      inc i
      continue
    if ch == ']' and inClass:
      inClass = false
      inc i
      continue
    if ch != '(' or inClass:
      inc i
      continue

    if i + 1 < pattern.len and pattern[i + 1] == '?':
      if i + 3 < pattern.len and pattern[i + 2] == '<' and
          pattern[i + 3] notin {'=', '!'}:
        var j = i + 3
        while j < pattern.len and pattern[j] != '>':
          inc j
        if j < pattern.len:
          let name = pattern[i + 3 ..< j]
          if name.len > 0:
            result.names[name] = groupIndex
          inc groupIndex
          i = j + 1
          continue
      elif i + 3 < pattern.len and pattern[i + 2] == '\'':
        var j = i + 3
        while j < pattern.len and pattern[j] != '\'':
          inc j
        if j < pattern.len:
          let name = pattern[i + 3 ..< j]
          if name.len > 0:
            result.names[name] = groupIndex
          inc groupIndex
          i = j + 1
          continue
      elif i + 4 < pattern.len and pattern[i + 2] == 'P' and
          pattern[i + 3] == '<':
        var j = i + 4
        while j < pattern.len and pattern[j] != '>':
          inc j
        if j < pattern.len:
          let name = pattern[i + 4 ..< j]
          if name.len > 0:
            result.names[name] = groupIndex
          inc groupIndex
          i = j + 1
          continue
      else:
        i += 2
        continue

    inc groupIndex
    inc i
  result.count = groupIndex

proc newRegex*(pattern: string, flags = ""): Value =
  let canonical = canonicalRegexFlags(flags)
  let captureInfo = regexCaptureInfo(pattern)
  when defined(geneWasm):
    boxObject(RegexData(objKind: okRegex,
                        pattern: pattern,
                        flags: canonical,
                        compiled: nil,
                        groupCount: captureInfo.count,
                        groupNames: captureInfo.names))
  else:
    try:
      boxObject(RegexData(objKind: okRegex,
                          pattern: pattern,
                          flags: canonical,
                          compiled: nre.re(pattern, regexFlagSet(canonical)),
                          groupCount: captureInfo.count,
                          groupNames: captureInfo.names))
    except nre.RegexError as e:
      raise newException(GeneError, "invalid Regex: " & e.msg)

proc newChar*(r: Rune): Value {.inline.} =
  mkImm(CHAR_TAG, uint64(int32(r)) and 0xffffffff'u64)

proc newSym*(v: string): Value =
  mkImm(SYMBOL_TAG, uint64(internSymbolId(v)))

proc newSymFromKeyId*(id: int32): Value {.inline.} =
  ## The symbol for an existing PropTable key id (see `symbolId`): the same
  ## value `newSym(propKeyText(id))` returns, without re-interning the text.
  mkImm(SYMBOL_TAG, uint64(id))

proc newBool*(v: bool): Value {.inline.} =
  if v: TRUE else: FALSE

const
  FrozenNoCallerEnv* = 1'u8
  FrozenNoScopeCapture* = 2'u8
  FrozenNoWeakScope* = 4'u8
  FrozenPlainDataProofs = FrozenNoCallerEnv or FrozenNoScopeCapture or FrozenNoWeakScope

proc frozenGraphProofs*(v: Value): uint8

proc newList*(items: sink seq[Value] = @[], immutable = false,
              deepFrozen = false): Value =
  let p = createObj(GeneList)
  p.refCount = 1
  p.immutable = immutable
  p.deepFrozen = deepFrozen
  p.items = items
  if immutable and deepFrozen:
    p.frozenGraphProofs = FrozenPlainDataProofs
    for i in 0 ..< p.items.len:
      p.frozenGraphProofs = p.frozenGraphProofs and frozenGraphProofs(p.items[i])
      if p.frozenGraphProofs == 0: break
  boxPtr(LIST_TAG, p)

proc withoutVoidEntries(entries: sink PropTable): PropTable =
  # Every Map is built through here. Walk the stored entries directly: the
  # `pairs` iterator hands out each key as a copied string, which the common
  # no-void answer never looks at.
  var hasVoid = false
  for i in 0 ..< entries.data.len:
    if entries.data[i].val.kind == vkVoid:
      hasVoid = true
      break
  if not hasVoid:
    return entries
  result = initPropTable()
  for i in 0 ..< entries.data.len:
    if entries.data[i].val.kind != vkVoid:
      result.putById(entries.data[i].keyId, entries.data[i].val)

proc newMap*(entries: sink PropTable = initPropTable(),
             immutable = false, deepFrozen = false): Value =
  let p = createObj(GeneMap)
  p.refCount = 1
  p.immutable = immutable
  p.deepFrozen = deepFrozen
  p.entries = withoutVoidEntries(entries)
  if immutable and deepFrozen:
    p.frozenGraphProofs = FrozenPlainDataProofs
    for i in 0 ..< p.entries.data.len:
      p.frozenGraphProofs = p.frozenGraphProofs and frozenGraphProofs(p.entries.data[i].val)
      if p.frozenGraphProofs == 0: break
  boxPtr(MAP_TAG, p)

proc newSet*(items: sink seq[Value] = @[]): Value =
  boxObject(SetData(objKind: okSet, items: items))

proc newHashMap*(entries: sink seq[HashMapEntry] = @[]): Value =
  boxObject(HashMapData(objKind: okHashMap, entries: entries))

proc newPipeline*(initial: sink Value, stages: sink seq[PipelineStage],
                  immutable = false): Value =
  boxObject(PipelineData(objKind: okPipeline, initial: initial,
                          stages: stages, immutable: immutable))

proc newRange*(start, stop: int64, step: int64 = 1,
               inclusive = false): Value =
  if step == 0:
    raise newException(GeneError, "range step must not be zero")
  boxObject(RangeData(objKind: okRange, start: start, stop: stop,
                      step: step, inclusive: inclusive))

proc isLeapYear(year: int): bool {.inline.} =
  (year mod 4 == 0 and year mod 100 != 0) or (year mod 400 == 0)

proc daysInMonth(year, month: int): int =
  case month
  of 1, 3, 5, 7, 8, 10, 12: 31
  of 4, 6, 9, 11: 30
  of 2: (if isLeapYear(year): 29 else: 28)
  else: 0

proc requireDateParts(year, month, day: int) =
  if year < 1 or year > 9999:
    raise newException(GeneError, "date year must be in 1..9999")
  if month < 1 or month > 12:
    raise newException(GeneError, "date month must be in 1..12")
  let maxDay = daysInMonth(year, month)
  if day < 1 or day > maxDay:
    raise newException(GeneError, "date day is out of range for month")

proc requireTimeParts(hour, minute, second, microsecond: int) =
  if hour < 0 or hour > 23:
    raise newException(GeneError, "time hour must be in 0..23")
  if minute < 0 or minute > 59:
    raise newException(GeneError, "time minute must be in 0..59")
  if second < 0 or second > 59:
    raise newException(GeneError, "time second must be in 0..59")
  if microsecond < 0 or microsecond > 999_999:
    raise newException(GeneError, "time microsecond must be in 0..999999")

proc requireOffsetMinutes(offsetMinutes: int) =
  if offsetMinutes < -23 * 60 - 59 or offsetMinutes > 23 * 60 + 59:
    raise newException(GeneError, "timezone offset must be within +/-23:59")

proc newDate*(year, month, day: int): Value =
  requireDateParts(year, month, day)
  boxObject(DateData(objKind: okDate, year: int16(year), month: int8(month),
                     day: int8(day)))

proc newTime*(hour, minute: int, second = 0, microsecond = 0,
              hasOffset = false, offsetMinutes = 0,
              timezoneName = ""): Value =
  requireTimeParts(hour, minute, second, microsecond)
  if hasOffset:
    requireOffsetMinutes(offsetMinutes)
  boxObject(TimeData(objKind: okTime, hour: int8(hour),
                     minute: int8(minute), second: int8(second),
                     microsecond: int32(microsecond),
                     hasOffset: hasOffset,
                     offsetMinutes: int16(offsetMinutes),
                     timezoneName: timezoneName))

proc newDateTime*(year, month, day, hour, minute: int, second = 0,
                  microsecond = 0, hasOffset = false, offsetMinutes = 0,
                  timezoneName = ""): Value =
  requireDateParts(year, month, day)
  requireTimeParts(hour, minute, second, microsecond)
  if hasOffset:
    requireOffsetMinutes(offsetMinutes)
  boxObject(DateTimeData(objKind: okDateTime, year: int16(year),
                         month: int8(month), day: int8(day),
                         hour: int8(hour), minute: int8(minute),
                         second: int8(second),
                         microsecond: int32(microsecond),
                         hasOffset: hasOffset,
                         offsetMinutes: int16(offsetMinutes),
                         timezoneName: timezoneName))

proc newTimezone*(hasOffset: bool, offsetMinutes = 0, name = ""): Value =
  if hasOffset:
    requireOffsetMinutes(offsetMinutes)
  boxObject(TimezoneData(objKind: okTimezone, hasOffset: hasOffset,
                         offsetMinutes: int16(offsetMinutes), name: name))

proc newDuration*(microseconds: int64): Value =
  boxObject(DurationData(objKind: okDuration, microseconds: microseconds))

proc newNode*(head: Value,
              props: sink PropTable = initPropTable(),
              body: sink seq[Value] = @[],
              meta: sink PropTable = initPropTable(),
              immutable = false,
              constructing = false,
              deepFrozen = false): Value =
  let p = createObj(GeneNode)
  p.refCount = 1
  p.immutable = immutable
  p.deepFrozen = deepFrozen
  p.constructing = constructing
  p.head = head
  p.props = withoutVoidEntries(props)
  p.body = body
  p.meta = withoutVoidEntries(meta)
  boxPtr(NODE_TAG, p)

proc nodeResourceId*(v: Value): uint64 =
  if v.kind != vkNode:
    raise newException(FieldDefect,
      "resource id metadata requires a node")
  cast[ptr GeneNode](v.bits and PAYLOAD_MASK).resourceId

proc setNodeResourceId*(v: Value, id: uint64) =
  if v.kind != vkNode:
    raise newException(FieldDefect,
      "resource id metadata requires a node")
  cast[ptr GeneNode](v.bits and PAYLOAD_MASK).resourceId = id

proc takeNodeResourceId*(v: Value): uint64 =
  if v.kind != vkNode:
    return 0
  let node = cast[ptr GeneNode](v.bits and PAYLOAD_MASK)
  result = node.resourceId
  node.resourceId = 0

const pendingModuleRefHead = "\x00gene_module_ref_pending"

proc newPendingModuleRef*(name: string): Value =
  ## Internal-only structural fixup. Its head contains NUL, which source text
  ## cannot produce, so ordinary Gene data cannot alias this representation.
  newNode(newSym(pendingModuleRefHead), body = @[newSym(name)], immutable = true)

proc isPendingModuleRef*(v: Value): bool {.inline.} =
  v.kind == vkNode and v.head.kind == vkSymbol and
    v.head.symVal == pendingModuleRefHead and v.body.len == 1 and
    v.body[0].kind == vkSymbol

proc pendingModuleRefName*(v: Value): string =
  if not v.isPendingModuleRef:
    raise newException(FieldDefect, "value is not a pending module reference")
  $v.body[0].symVal

proc containsPendingModuleRef*(v: Value, name: string,
                               seen: var HashSet[uint64]): bool =
  if v.isPendingModuleRef:
    return v.body[0].symVal == name
  if not v.isManaged or seen.containsOrIncl(v.bits):
    return false
  case v.kind
  of vkPipeline:
    if containsPendingModuleRef(v.pipelineInitial, name, seen): return true
    for stage in v.pipelineStages:
      if containsPendingModuleRef(stage.head, name, seen): return true
      for _, item in stage.props:
        if containsPendingModuleRef(item, name, seen): return true
      for item in stage.body:
        if containsPendingModuleRef(item, name, seen): return true
      for _, item in stage.meta:
        if containsPendingModuleRef(item, name, seen): return true
  of vkList:
    for item in v.listItems:
      if containsPendingModuleRef(item, name, seen): return true
  of vkMap:
    for _, item in v.mapEntries:
      if containsPendingModuleRef(item, name, seen): return true
  of vkSet:
    for item in v.setItems:
      if containsPendingModuleRef(item, name, seen): return true
  of vkHashMap:
    for entry in v.hashMapEntries:
      if containsPendingModuleRef(entry.key, name, seen) or
          containsPendingModuleRef(entry.val, name, seen): return true
  of vkNode:
    if containsPendingModuleRef(v.head, name, seen): return true
    for _, item in v.props:
      if containsPendingModuleRef(item, name, seen): return true
    for item in v.body:
      if containsPendingModuleRef(item, name, seen): return true
    for _, item in v.meta:
      if containsPendingModuleRef(item, name, seen): return true
  # A mutable cell is an allocate/patch-capable cycle boundary. Do not report
  # a self-reference through it as an unsupported immutable cycle; the patch
  # pass below safely installs the target into the already-allocated cell.
  of vkCell, vkAtomicCell:
    discard
  else:
    discard
  false

proc patchPendingModuleRef*(v: Value, name: string, target: Value,
                            seen: var HashSet[uint64]): Value =
  ## Construction-time allocate/patch/seal support. This deliberately bypasses
  ## public immutability checks: no source unit is published until every fixup
  ## has been replaced.
  if v.isPendingModuleRef:
    if v.body[0].symVal == name: return target
    return v
  if not v.isManaged or seen.containsOrIncl(v.bits):
    return v
  case v.kind
  of vkPipeline:
    var stages: seq[PipelineStage]
    for stage in v.pipelineStages:
      var props = initPropTable()
      for key, item in stage.props:
        props[key] = patchPendingModuleRef(item, name, target, seen)
      var body: seq[Value]
      for item in stage.body:
        body.add patchPendingModuleRef(item, name, target, seen)
      var meta = initPropTable()
      for key, item in stage.meta:
        meta[key] = patchPendingModuleRef(item, name, target, seen)
      stages.add PipelineStage(
        kind: stage.kind,
        head: patchPendingModuleRef(stage.head, name, target, seen),
        props: props, body: body, meta: meta,
        sourceLoc: stage.sourceLoc, slot: stage.slot)
    return newPipeline(
      patchPendingModuleRef(v.pipelineInitial, name, target, seen),
      stages, v.pipelineImmutable)
  of vkList:
    let p = cast[ptr GeneList](v.bits and PAYLOAD_MASK)
    for i in 0 ..< p.items.len:
      p.items[i] = patchPendingModuleRef(p.items[i], name, target, seen)
  of vkMap:
    let p = cast[ptr GeneMap](v.bits and PAYLOAD_MASK)
    for i in 0 ..< p.entries.data.len:
      p.entries.data[i].val =
        patchPendingModuleRef(p.entries.data[i].val, name, target, seen)
  of vkHashMap:
    let data = HashMapData(objData(v))
    for i in 0 ..< data.entries.len:
      data.entries[i].key =
        patchPendingModuleRef(data.entries[i].key, name, target, seen)
      data.entries[i].val =
        patchPendingModuleRef(data.entries[i].val, name, target, seen)
  of vkSet:
    let data = SetData(objData(v))
    for i in 0 ..< data.items.len:
      data.items[i] = patchPendingModuleRef(data.items[i], name, target, seen)
  of vkNode:
    let p = cast[ptr GeneNode](v.bits and PAYLOAD_MASK)
    p.head = patchPendingModuleRef(p.head, name, target, seen)
    for i in 0 ..< p.props.data.len:
      p.props.data[i].val =
        patchPendingModuleRef(p.props.data[i].val, name, target, seen)
    for i in 0 ..< p.body.len:
      p.body[i] = patchPendingModuleRef(p.body[i], name, target, seen)
    for i in 0 ..< p.meta.data.len:
      p.meta.data[i].val =
        patchPendingModuleRef(p.meta.data[i].val, name, target, seen)
  of vkCell:
    v.setCellValue(patchPendingModuleRef(v.cellValue, name, target, seen))
  of vkAtomicCell:
    v.setAtomicCellValue(
      patchPendingModuleRef(v.atomicCellValue, name, target, seen))
  else:
    discard
  v

var functionIdentitySeq: int

proc nextFunctionIdentity(): int {.inline.} =
  when compileOption("threads"):
    atomicFetchAdd(addr functionIdentitySeq, 1, ATOMIC_RELAXED) + 1
  else:
    inc functionIdentitySeq
    functionIdentitySeq

proc newFunction*(name: string, params: sink seq[string],
                  code: FunctionCode, scope: Scope,
                  checksErrors = false,
                  errorTypes: sink seq[Value] = @[],
                  syntaxFn = false): Value =
  let p = createObj(GeneFunction)
  p.refCount = 1
  p.identity = nextFunctionIdentity()
  p.name = name
  p.params = params
  p.code = code
  p.scope = scope
  p.checksErrors = checksErrors
  p.syntaxFn = syntaxFn
  p.capturesCallerEnv = scope != nil and scope.borrowedCallerEnv
  p.errorTypes = errorTypes
  result = boxPtr(FUNCTION_TAG, p)
  if scope != nil and scope.application != nil and scope.application.errorFunctionCreated != nil:
    scope.application.errorFunctionCreated(result, scope)

proc cloneFunctionCapture(v: Value, scope: Scope, weak: bool,
                          weakable = false): Value =
  let src = cast[ptr GeneFunction](v.bits and PAYLOAD_MASK)
  let p = createObj(GeneFunction)
  p.refCount = 1
  p.identity = src.identity
  p.weakable = weakable
  p.name = src.name
  p.params = src.params
  p.code = src.code
  if weak:
    p.weakScope = cast[pointer](scope)
  else:
    p.scope = scope
    if weakable:
      # Remember the owner, so the binding can drop back to weak.
      p.weakScope = cast[pointer](scope)
  p.checksErrors = src.checksErrors
  p.syntaxFn = src.syntaxFn
  p.capturesCallerEnv = src.capturesCallerEnv
  p.errorTypes = src.errorTypes
  p.errorLease = src.errorLease
  boxPtr(FUNCTION_TAG, p)

proc protocolMessageScope*(v: Value): Scope
proc protocolMessageIsBound*(v: Value): bool {.inline.}
proc cloneBoundMessageScope(v: Value, scope: Scope, weak: bool): Value
proc weakenScopeFunctions(v: Value, owner: Scope): Value

proc functionForScopeStorage*(v: Value, owner: Scope, binding = false): Value =
  ## Store scope-owned functions with a weak back-edge so the owner can be
  ## reclaimed after its ordinary references are dropped. A `binding` stored in
  ## a scope's slots or vars escapes in place and re-weakens on release.
  case v.bits shr TAG_SHIFT
  of FUNCTION_TAG, NODE_TAG, OBJECT_TAG, CYCLE_OBJECT_TAG:
    discard
  else:
    # Every binding store passes through here; only the kinds tested below
    # can carry a scope edge, and each of them has one of these four tags.
    return v
  if v.kind == vkFunction:
    let capture = v.fnScope
    if not v.fnHasWeakScope and capture == owner:
      return cloneFunctionCapture(v, owner, weak = true, weakable = binding)
    if v.fnHasWeakScope and capture != owner:
      # A weak binding is borrowed from its exact owner. Passing/storing that
      # function in a different scope must keep the original capture alive.
      return cloneFunctionCapture(v, capture, weak = false,
        weakable = cast[ptr GeneFunction](v.bits and PAYLOAD_MASK).weakable)
  if v.kind == vkProtocolMessage and v.protocolMessageIsBound:
    let data = BoundMessageData(objData(v))
    let capture = v.protocolMessageScope
    if data.boundScope == owner:
      return cloneBoundMessageScope(v, owner, weak = true)
    if data.boundScope == nil and capture != owner:
      return cloneBoundMessageScope(v, capture, weak = false)
  if v.kind == vkNode and v.head.kind == vkSymbol and
      v.head.symVal == "Path":
    return weakenScopeFunctions(v, owner)
  if v.kind == vkCallableView:
    let target = functionForScopeStorage(v.callableViewTarget, owner, binding)
    if target.bits != v.callableViewTarget.bits:
      return newCallableView(target, v.callableViewSignature,
        v.callableViewScope, ioReadCall = v.isIoReadCall,
        ioReadDelegate = v.isIoReadDelegate)
  if v.kind == vkStream:
    # Same cycle, one hop removed: a lazy stream stored into the scope its
    # callables capture (scope -> stream -> callable -> scope). Weaken the
    # callable edges along the source chain here — the sound point, where the
    # owner is known — never at stream construction, where nothing guarantees
    # another strong reference to the callable survives.
    var cur = v
    while cur.kind == vkStream:
      let data = streamData(cur)
      let cb = data.callable
      if cb.kind == vkFunction and not cb.fnHasWeakScope and cb.fnScope == owner:
        data.callable = cloneFunctionCapture(cb, owner, weak = true)
      cur = data.source
  v

proc weakenScopeFunctions(v: Value, owner: Scope): Value =
  if owner == nil or not v.isManaged:
    return v
  case v.kind
  of vkFunction, vkProtocolMessage, vkCallableView:
    functionForScopeStorage(v, owner)
  of vkList:
    for i, item in v.listItems:
      let weakened = weakenScopeFunctions(item, owner)
      if weakened.bits != item.bits:
        var items = newSeq[Value](v.listItems.len)
        for j in 0 ..< i:
          items[j] = v.listItems[j]
        items[i] = weakened
        for j in i + 1 ..< v.listItems.len:
          items[j] = weakenScopeFunctions(v.listItems[j], owner)
        return newList(items, v.listImmutable)
    v
  of vkMap:
    var changed = false
    for _, val in v.mapEntries:
      let weakened = weakenScopeFunctions(val, owner)
      if weakened.bits != val.bits:
        changed = true
        break
    if not changed:
      return v
    var entries = initPropTable()
    for key, val in v.mapEntries:
      entries[key] = weakenScopeFunctions(val, owner)
    newMap(entries, v.mapImmutable)
  of vkSet:
    for i, item in v.setItems:
      let weakened = weakenScopeFunctions(item, owner)
      if weakened.bits != item.bits:
        var items = newSeq[Value](v.setItems.len)
        for j in 0 ..< i:
          items[j] = v.setItems[j]
        items[i] = weakened
        for j in i + 1 ..< v.setItems.len:
          items[j] = weakenScopeFunctions(v.setItems[j], owner)
        return newSet(items)
    v
  of vkHashMap:
    var changed = false
    for entry in v.hashMapEntries:
      let weakenedKey = weakenScopeFunctions(entry.key, owner)
      let weakenedVal = weakenScopeFunctions(entry.val, owner)
      if weakenedKey.bits != entry.key.bits or weakenedVal.bits != entry.val.bits:
        changed = true
        break
    if not changed:
      return v
    var entries: seq[HashMapEntry]
    for entry in v.hashMapEntries:
      entries.add HashMapEntry(key: weakenScopeFunctions(entry.key, owner),
                               val: weakenScopeFunctions(entry.val, owner))
    newHashMap(entries)
  of vkPipeline:
    let weakenedInitial = weakenScopeFunctions(v.pipelineInitial, owner)
    var changed = weakenedInitial.bits != v.pipelineInitial.bits
    if not changed:
      for stage in v.pipelineStages:
        if weakenScopeFunctions(stage.head, owner).bits != stage.head.bits:
          changed = true
          break
        for _, val in stage.props:
          if weakenScopeFunctions(val, owner).bits != val.bits:
            changed = true
            break
        if changed: break
        for item in stage.body:
          if weakenScopeFunctions(item, owner).bits != item.bits:
            changed = true
            break
        if changed: break
        for _, val in stage.meta:
          if weakenScopeFunctions(val, owner).bits != val.bits:
            changed = true
            break
        if changed: break
    if not changed:
      return v
    var stages: seq[PipelineStage]
    for stage in v.pipelineStages:
      var props = initPropTable()
      for key, val in stage.props:
        props[key] = weakenScopeFunctions(val, owner)
      var body: seq[Value]
      for item in stage.body:
        body.add weakenScopeFunctions(item, owner)
      var meta = initPropTable()
      for key, val in stage.meta:
        meta[key] = weakenScopeFunctions(val, owner)
      stages.add PipelineStage(
        kind: stage.kind,
        head: weakenScopeFunctions(stage.head, owner),
        props: props, body: body, meta: meta,
        sourceLoc: stage.sourceLoc, slot: stage.slot)
    newPipeline(weakenedInitial, stages, v.pipelineImmutable)
  of vkNode:
    let weakenedHead = weakenScopeFunctions(v.head, owner)
    var changed = weakenedHead.bits != v.head.bits
    if not changed:
      for _, val in v.props:
        let weakened = weakenScopeFunctions(val, owner)
        if weakened.bits != val.bits:
          changed = true
          break
    if not changed:
      for item in v.body:
        let weakened = weakenScopeFunctions(item, owner)
        if weakened.bits != item.bits:
          changed = true
          break
    if not changed:
      for _, val in v.meta:
        let weakened = weakenScopeFunctions(val, owner)
        if weakened.bits != val.bits:
          changed = true
          break
    if not changed:
      return v
    var props = initPropTable()
    for key, val in v.props:
      props[key] = weakenScopeFunctions(val, owner)
    var body: seq[Value]
    for item in v.body:
      body.add weakenScopeFunctions(item, owner)
    var meta = initPropTable()
    for key, val in v.meta:
      meta[key] = weakenScopeFunctions(val, owner)
    newNode(weakenedHead, props = props, body = body, meta = meta,
            immutable = v.nodeImmutable, constructing = v.nodeConstructing).
      inheritErrorEvidence(v)
  of vkBuffer:
    checkBuffer(v)
    let data {.cursor.} = bufferView(v)
    var changed = false
    var items = newSeq[Value](data.items.len)
    for i, item in data.items:
      let weakened = weakenScopeFunctions(item, owner)
      items[i] = weakened
      if weakened.bits != item.bits:
        changed = true
    if not changed:
      return v
    boxObject(BufferData(objKind: okBuffer, elemType: data.elemType,
                         elemScope: data.elemScope, items: items))
  else:
    v

proc weakScopeProtected(guard: WeakScopeGuard, target: pointer): bool =
  var current = guard.scope
  while current != nil:
    if cast[pointer](current) == target:
      return true
    current = current.parent
  guard.live != nil and guard.live(guard.ctx, target)

proc escapeStreamReturn*(value: Value, guard: WeakScopeGuard): Value =
  ## Returning to a caller that still owns every weak callback scope does not
  ## require an escaping copy. Preserve the actual cursor (and its lookahead)
  ## rather than forking it merely to retain already-live lexical scopes.
  if value.kind == vkStream and (guard.scope != nil or guard.live != nil):
    var current = value
    var safe = true
    var seen = initHashSet[uint64]()
    while current.kind == vkStream and not seen.containsOrIncl(current.bits):
      let data = streamData(current)
      if data.callable.kind == vkFunction and data.callable.fnHasWeakScope:
        if not weakScopeProtected(guard, cast[pointer](data.callable.fnScope)):
          safe = false
          break
      if escapeWeakFunctions(data.buffer, guard).bits != data.buffer.bits:
        safe = false
        break
      current = data.source
    if safe:
      return value
  escapeWeakFunctions(value, guard)

proc escapeStreamReturn*(value: Value, caller: Scope): Value =
  escapeStreamReturn(value, WeakScopeGuard(scope: caller))

proc escapeWeakFunctions*(v: Value, protectedScope: Scope): Value =
  escapeWeakFunctions(v, WeakScopeGuard(scope: protectedScope))

type
  EscapeVisited = object
    ## Containers one escape has already reached. A stored or returned value
    ## usually holds only a few, so they live inline and allocate nothing.
    inline: array[16, uint64]
    count: int
    overflow: HashSet[uint64]
    overflowUsed: bool
    scan: ptr StampedSet   # the thread's reusable set, while this walk owns it

  EscapeWalk = object
    visited: EscapeVisited
    rebuilt: seq[tuple[source, escaped: Value]]

var escapeScanSet {.threadvar.}: StampedSet
var escapeScanBusy {.threadvar.}: bool

when defined(geneGraphProofTests):
  type FrozenEscapeStats* = object
    visits*, skips*, walkVisits*, walkSkips*: int64
  var frozenEscapeStats {.threadvar.}: FrozenEscapeStats
  var collectingFrozenEscapeStats {.threadvar.}: bool
  proc beginFrozenEscapeStats*() =
    frozenEscapeStats = FrozenEscapeStats()
    collectingFrozenEscapeStats = true
  proc finishFrozenEscapeStats*(): FrozenEscapeStats =
    collectingFrozenEscapeStats = false
    frozenEscapeStats

proc firstVisit(visited: var EscapeVisited, bits: uint64): bool =
  ## True the first time `bits` is reached.
  if not visited.overflowUsed:
    for i in 0 ..< visited.count:
      if visited.inline[i] == bits:
        return false
    if visited.count < visited.inline.len:
      visited.inline[visited.count] = bits
      inc visited.count
      return true
    # The inline entries move into the set with the first one that does not
    # fit, so a large graph is not compared against all of them at every step.
    visited.overflowUsed = true
    if visited.scan != nil:
      visited.scan[].reset()
      for i in 0 ..< visited.count:
        discard visited.scan[].containsOrIncl(visited.inline[i])
    else:
      visited.overflow = initHashSet[uint64]()
      for i in 0 ..< visited.count:
        visited.overflow.incl visited.inline[i]
  if visited.scan != nil:
    return not visited.scan[].containsOrIncl(bits)
  not visited.overflow.containsOrIncl(bits)

proc clearVisited(visited: var EscapeVisited) =
  visited.count = 0
  if visited.scan != nil:
    visited.scan = nil
    visited.overflowUsed = false
  elif visited.overflowUsed:
    visited.overflow.clear()
    visited.overflowUsed = false

proc mayNeedEscape(v: Value, guard: WeakScopeGuard, visited: var EscapeVisited,
                   markHolder: bool): bool =
  ## Whether escaping `v` can change anything: a weak function or type scope the
  ## guard does not protect, a promoted binding whose holder is not marked yet,
  ## or a kind this scan does not look inside. `markHolder` says `v` sits
  ## directly in a list, map or node the walk would still have to mark. The scan
  ## reads values in place without copying them, and reaches each container
  ## once, so cycles and shared structure end it.
  when defined(geneGraphProofTests):
    if collectingFrozenEscapeStats: inc frozenEscapeStats.visits
  when not defined(geneDisableFrozenGraphProofs):
    if (v.frozenGraphProofs and FrozenNoWeakScope) != 0:
      when defined(geneGraphProofTests):
        if collectingFrozenEscapeStats: inc frozenEscapeStats.skips
      return false
  case v.bits shr TAG_SHIFT
  of LIST_TAG:
    if not visited.firstVisit(v.bits):
      return false
    let p = cast[ptr GeneList](v.bits and PAYLOAD_MASK)
    let mark = not p.holdsEscapedFn
    for i in 0 ..< p.items.len:
      if mayNeedEscape(p.items[i], guard, visited, mark):
        return true
    false
  of MAP_TAG:
    if not visited.firstVisit(v.bits):
      return false
    let p = cast[ptr GeneMap](v.bits and PAYLOAD_MASK)
    let mark = not p.holdsEscapedFn
    for i in 0 ..< p.entries.data.len:
      if mayNeedEscape(p.entries.data[i].val, guard, visited, mark):
        return true
    false
  of NODE_TAG:
    if not visited.firstVisit(v.bits):
      return false
    let p = cast[ptr GeneNode](v.bits and PAYLOAD_MASK)
    let mark = not p.holdsEscapedFn
    if mayNeedEscape(p.head, guard, visited, mark):
      return true
    for i in 0 ..< p.props.data.len:
      if mayNeedEscape(p.props.data[i].val, guard, visited, mark):
        return true
    for i in 0 ..< p.body.len:
      if mayNeedEscape(p.body[i], guard, visited, mark):
        return true
    for i in 0 ..< p.meta.data.len:
      if mayNeedEscape(p.meta.data[i].val, guard, visited, mark):
        return true
    false
  of FUNCTION_TAG:
    let p = cast[ptr GeneFunction](v.bits and PAYLOAD_MASK)
    if p.scope != nil:
      markHolder and p.weakable
    else:
      p.weakScope != nil and not weakScopeProtected(guard, p.weakScope)
  of CYCLE_OBJECT_TAG, OBJECT_TAG:
    case v.kind
    of vkProtocolMessage:
      if objData(v).objKind != okBoundMessage:
        return false
      let data = BoundMessageData(objData(v))
      data.boundScope == nil and data.weakScope != nil and
        not weakScopeProtected(guard, data.weakScope)
    of vkType:
      if objData(v).objKind != okType:
        return false
      let data = TypeData(objData(v))
      data.scope == nil and data.weakScope != nil and
        not weakScopeProtected(guard, data.weakScope)
    of vkCallableView:
      mayNeedEscape(v.callableViewTarget, guard, visited, false)
    of vkSet:
      if not visited.firstVisit(v.bits):
        return false
      for item in v.setItems:
        if mayNeedEscape(item, guard, visited, false):
          return true
      false
    of vkHashMap:
      if not visited.firstVisit(v.bits):
        return false
      for entry in v.hashMapEntries:
        if mayNeedEscape(entry.key, guard, visited, false) or
            mayNeedEscape(entry.val, guard, visited, false):
          return true
      false
    of vkPipeline, vkStream, vkTask, vkChannel, vkActorRef, vkActorContext,
       vkActorStep, vkReplyTo, vkEnv, vkBuffer, vkFfiCallable:
      true
    else:
      false
  else:
    false

proc escapeWalk(v: Value, guard: WeakScopeGuard, walk: var EscapeWalk): Value

proc escapeKind(v: Value, guard: WeakScopeGuard, walk: var EscapeWalk): Value =
  template escapeNested(value: Value): Value =
    escapeWalk(value, guard, walk)
  case v.kind
  of vkProtocolMessage:
    if objData(v).objKind == okBoundMessage:
      let data = BoundMessageData(objData(v))
      if data.boundScope == nil and data.weakScope != nil and
          not weakScopeProtected(guard, data.weakScope):
        return cloneBoundMessageScope(v, cast[Scope](data.weakScope), weak = false)
    v
  of vkType:
    if objData(v).objKind == okType:
      let data = TypeData(objData(v))
      if data.scope == nil and data.weakScope != nil:
        if weakScopeProtected(guard, data.weakScope):
          return v
        data.scope = cast[Scope](data.weakScope)
        data.scopeEscaped = true
    v
  of vkCallableView:
    let target = escapeNested(v.callableViewTarget)
    if target.bits == v.callableViewTarget.bits:
      return v
    newCallableView(target, v.callableViewSignature,
      v.callableViewScope, ioReadCall = v.isIoReadCall,
      ioReadDelegate = v.isIoReadDelegate)
  of vkFunction:
    if v.fnHasWeakScope:
      let fnp = cast[ptr GeneFunction](v.bits and PAYLOAD_MASK)
      if weakScopeProtected(guard, fnp.weakScope):
        return v
      if fnp.weakable and not isSharedFlag(fnp.shared):
        # A scope binding escapes in place, keeping its identity; releases
        # re-weaken it once only its defining scope holds it again.
        fnp.scope = cast[Scope](fnp.weakScope)
        return v
      return cloneFunctionCapture(v, v.fnScope, weak = false)
    v
  of vkList:
    var holdsPromoted = false
    for i, item in v.listItems:
      let escaped = escapeNested(item)
      if escaped.isPromotedBindingFunction:
        holdsPromoted = true
      if escaped.bits != item.bits:
        var items = newSeq[Value](v.listItems.len)
        for j in 0 ..< i:
          items[j] = v.listItems[j]
        items[i] = escaped
        for j in i + 1 ..< v.listItems.len:
          items[j] = escapeNested(v.listItems[j])
          if items[j].isPromotedBindingFunction:
            holdsPromoted = true
        if not v.listImmutable:
          cast[ptr GeneList](v.bits and PAYLOAD_MASK).items = move items
          if holdsPromoted:
            markEscapedFunctionHolder(v)
          return v
        let rebuilt = newList(items, v.listImmutable)
        if holdsPromoted:
          markEscapedFunctionHolder(rebuilt)
        return rebuilt
    if holdsPromoted:
      markEscapedFunctionHolder(v)
    v
  of vkMap:
    var changed = false
    var holdsPromoted = false
    # Index the entries: `pairs` copies every key's name.
    let mp = cast[ptr GeneMap](v.bits and PAYLOAD_MASK)
    for i in 0 ..< mp.entries.data.len:
      let escaped = escapeNested(mp.entries.data[i].val)
      if escaped.isPromotedBindingFunction:
        holdsPromoted = true
      if escaped.bits != mp.entries.data[i].val.bits:
        changed = true
        break
    if not changed:
      if holdsPromoted:
        markEscapedFunctionHolder(v)
      return v
    var entries = initPropTable()
    for key, val in v.mapEntries:
      let escaped = escapeNested(val)
      if escaped.isPromotedBindingFunction:
        holdsPromoted = true
      entries[key] = escaped
    if not v.mapImmutable:
      cast[ptr GeneMap](v.bits and PAYLOAD_MASK).entries = move entries
      if holdsPromoted:
        markEscapedFunctionHolder(v)
      return v
    let rebuilt = newMap(entries, v.mapImmutable)
    if holdsPromoted:
      markEscapedFunctionHolder(rebuilt)
    rebuilt
  of vkSet:
    for i, item in v.setItems:
      let escaped = escapeNested(item)
      if escaped.bits != item.bits:
        var items = newSeq[Value](v.setItems.len)
        for j in 0 ..< i:
          items[j] = v.setItems[j]
        items[i] = escaped
        for j in i + 1 ..< v.setItems.len:
          items[j] = escapeNested(v.setItems[j])
        return newSet(items)
    v
  of vkHashMap:
    var changed = false
    for entry in v.hashMapEntries:
      let escapedKey = escapeNested(entry.key)
      let escapedVal = escapeNested(entry.val)
      if escapedKey.bits != entry.key.bits or escapedVal.bits != entry.val.bits:
        changed = true
        break
    if not changed:
      return v
    var entries: seq[HashMapEntry]
    for entry in v.hashMapEntries:
      entries.add HashMapEntry(key: escapeNested(entry.key),
                               val: escapeNested(entry.val))
    newHashMap(entries)
  of vkPipeline:
    let escapedInitial = escapeNested(v.pipelineInitial)
    var changed = escapedInitial.bits != v.pipelineInitial.bits
    if not changed:
      for stage in v.pipelineStages:
        if escapeNested(stage.head).bits != stage.head.bits:
          changed = true
          break
        for _, val in stage.props:
          if escapeNested(val).bits != val.bits:
            changed = true
            break
        if changed: break
        for item in stage.body:
          if escapeNested(item).bits != item.bits:
            changed = true
            break
        if changed: break
        for _, val in stage.meta:
          if escapeNested(val).bits != val.bits:
            changed = true
            break
        if changed: break
    if not changed:
      return v
    var stages: seq[PipelineStage]
    for stage in v.pipelineStages:
      var props = initPropTable()
      for key, val in stage.props:
        props[key] = escapeNested(val)
      var body: seq[Value]
      for item in stage.body:
        body.add escapeNested(item)
      var meta = initPropTable()
      for key, val in stage.meta:
        meta[key] = escapeNested(val)
      stages.add PipelineStage(
        kind: stage.kind,
        head: escapeNested(stage.head),
        props: props, body: body, meta: meta,
        sourceLoc: stage.sourceLoc, slot: stage.slot)
    newPipeline(escapedInitial, stages, v.pipelineImmutable)
  of vkNode:
    var holdsPromoted = false
    let escapedHead = escapeNested(v.head)
    if escapedHead.isPromotedBindingFunction:
      holdsPromoted = true
    var changed = escapedHead.bits != v.head.bits
    # Index props and meta: `pairs` copies every key's name.
    let np = cast[ptr GeneNode](v.bits and PAYLOAD_MASK)
    if not changed:
      for i in 0 ..< np.props.data.len:
        let escaped = escapeNested(np.props.data[i].val)
        if escaped.isPromotedBindingFunction:
          holdsPromoted = true
        if escaped.bits != np.props.data[i].val.bits:
          changed = true
          break
    if not changed:
      for item in v.body:
        let escaped = escapeNested(item)
        if escaped.isPromotedBindingFunction:
          holdsPromoted = true
        if escaped.bits != item.bits:
          changed = true
          break
    if not changed:
      for i in 0 ..< np.meta.data.len:
        let escaped = escapeNested(np.meta.data[i].val)
        if escaped.isPromotedBindingFunction:
          holdsPromoted = true
        if escaped.bits != np.meta.data[i].val.bits:
          changed = true
          break
    if not changed:
      if holdsPromoted:
        markEscapedFunctionHolder(v)
      return v
    var props = initPropTable()
    for key, val in v.props:
      let escaped = escapeNested(val)
      if escaped.isPromotedBindingFunction:
        holdsPromoted = true
      props[key] = escaped
    var body: seq[Value]
    for item in v.body:
      let escaped = escapeNested(item)
      if escaped.isPromotedBindingFunction:
        holdsPromoted = true
      body.add escaped
    var meta = initPropTable()
    for key, val in v.meta:
      let escaped = escapeNested(val)
      if escaped.isPromotedBindingFunction:
        holdsPromoted = true
      meta[key] = escaped
    # A scope-owned Path may contain a weak held-message back-edge. Escaping
    # it must leave the scope's stored copy weak; replacing that copy in place
    # would recreate scope -> Path -> message -> scope.
    if not v.nodeImmutable and not
        (v.head.kind == vkSymbol and v.head.symVal == "Path"):
      let node = cast[ptr GeneNode](v.bits and PAYLOAD_MASK)
      node.head = escapedHead
      node.props = move props
      node.body = move body
      node.meta = move meta
      if holdsPromoted:
        markEscapedFunctionHolder(v)
      return v
    let rebuilt = newNode(escapedHead, props = props, body = body, meta = meta,
            immutable = v.nodeImmutable, constructing = v.nodeConstructing).
      inheritErrorEvidence(v)
    if holdsPromoted:
      markEscapedFunctionHolder(rebuilt)
    rebuilt
  of vkStream:
    let data = streamData(v)
    let escapedSource = escapeNested(data.source)
    let escapedCallable = escapeNested(data.callable)
    let escapedBuffer = escapeNested(data.buffer)
    if escapedSource.bits == data.source.bits and
        escapedCallable.bits == data.callable.bits and
        escapedBuffer.bits == data.buffer.bits:
      return v
    boxObject(StreamData(objKind: okStream, source: escapedSource,
                         items: data.items, index: data.index,
                         callable: escapedCallable, remaining: data.remaining,
                         pull: data.pull, closed: data.closed,
                         close: data.close,
                         checkFailure: data.checkFailure,
                         buffered: data.buffered, buffer: escapedBuffer,
                         itemType: data.itemType, errType: data.errType,
                         itemScope: data.itemScope,
                         generatorCode: data.generatorCode,
                         generatorScope: data.generatorScope,
                         generatorStack: data.generatorStack,
                         generatorIp: data.generatorIp,
                         generatorContinuation: data.generatorContinuation))
  of vkTask:
    let data {.cursor.} = taskData(v)
    let state = data.state
    var done: bool
    var cancelRequested: bool
    var cancelled: bool
    var awaited: bool
    var sourceResult: Value
    var failed: bool
    var errorMsg: string
    var sourceError: Value
    var hasErrorValue: bool
    var panicked: bool
    var panicMsg: string
    var sourcePanic: Value
    var hasPanicValue: bool
    withTaskStateLock(state):
      done = state.done
      cancelRequested = state.cancelRequested
      cancelled = state.cancelled
      awaited = state.awaited
      sourceResult = state.result
      failed = state.failed
      errorMsg = state.errorMsg
      sourceError = state.errorValue
      hasErrorValue = state.hasErrorValue
      panicked = state.panicked
      panicMsg = state.panicMsg
      sourcePanic = state.panicValue
      hasPanicValue = state.hasPanicValue
    let escapedResult = escapeNested(sourceResult)
    let escapedError = escapeNested(sourceError)
    let escapedPanic = escapeNested(sourcePanic)
    if escapedResult.bits == sourceResult.bits and
        escapedError.bits == sourceError.bits and
        escapedPanic.bits == sourcePanic.bits:
      return v
    boxObject(TaskData(objKind: okTask,
                       state: newTaskState(done = done,
                         cancelRequested = cancelRequested,
                         cancelled = cancelled,
                         awaited = awaited,
                         taskResult = escapedResult,
                         failed = failed,
                         errorMsg = errorMsg,
                         errorValue = escapedError,
                         hasErrorValue = hasErrorValue,
                         panicked = panicked,
                         panicMsg = panicMsg,
                         panicValue = escapedPanic,
                         hasPanicValue = hasPanicValue),
                       resultType: data.resultType,
                       errorType: data.errorType,
                       boundaryScope: data.boundaryScope))
  of vkChannel:
    let data {.cursor.} = channelData(v)
    var sourceItems: seq[Value]
    var sourcePins: seq[seq[Scope]]
    var capacity: int
    var closed: bool
    withChannelStateLock(data.state):
      sourceItems = data.state.items
      sourcePins = data.state.scopePins
      capacity = data.state.capacity
      closed = data.state.closed
    var changed = false
    var escapedItems = newSeq[Value](sourceItems.len)
    for i, item in sourceItems:
      escapedItems[i] = escapeNested(item)
      if escapedItems[i].bits != item.bits:
        changed = true
    if not changed:
      return v
    let escapedState = newChannelState(capacity, escapedItems, closed, sourcePins)
    boxObject(ChannelData(objKind: okChannel, state: escapedState,
                          itemType: data.itemType,
                          itemScope: data.itemScope))
  of vkActorRef:
    let data = actorData(v)
    var lifecycle: ActorLifecycle
    var capacity: int
    var processing: bool
    var reservedMessages: int
    var sourceState: Value
    var sourceRestartInit: Value
    var sourceHandler: Value
    var sourceMessageType: Value
    var messageTypeExplicit: bool
    var failureStrategy: ActorFailureStrategy
    var sourceFailureEvents: Value
    var sourceFailureDeadLetters: Value
    var sourceParentFailureEvents: Value
    var sourceParentFailureDeadLetters: Value
    var sourceQueue: seq[ActorMessage]
    withActorLock(data):
      lifecycle = data.lifecycle
      capacity = data.capacity
      processing = data.processing
      reservedMessages = data.reservedMessages
      sourceState = data.state
      sourceRestartInit = data.restartInit
      sourceHandler = data.handler
      sourceMessageType = data.messageType
      messageTypeExplicit = data.messageTypeExplicit
      failureStrategy = data.failureStrategy
      sourceFailureEvents = data.failureEvents
      sourceFailureDeadLetters = data.failureDeadLetters
      sourceParentFailureEvents = data.parentFailureEvents
      sourceParentFailureDeadLetters = data.parentFailureDeadLetters
      sourceQueue = data.queue
    let escapedState = escapeNested(sourceState)
    let escapedRestartInit = escapeNested(sourceRestartInit)
    let escapedHandler = escapeNested(sourceHandler)
    let escapedFailureEvents = escapeNested(sourceFailureEvents)
    let escapedFailureDeadLetters = escapeNested(sourceFailureDeadLetters)
    let escapedParentFailureEvents =
      escapeNested(sourceParentFailureEvents)
    let escapedParentFailureDeadLetters =
      escapeNested(sourceParentFailureDeadLetters)
    var escapedQueue = newSeq[ActorMessage](sourceQueue.len)
    var changed = escapedState.bits != sourceState.bits or
      escapedRestartInit.bits != sourceRestartInit.bits or
      escapedHandler.bits != sourceHandler.bits or
      escapedFailureEvents.bits != sourceFailureEvents.bits or
      escapedFailureDeadLetters.bits != sourceFailureDeadLetters.bits or
      escapedParentFailureEvents.bits != sourceParentFailureEvents.bits or
      escapedParentFailureDeadLetters.bits != sourceParentFailureDeadLetters.bits
    for i, item in sourceQueue:
      let escapedMessage = escapeNested(item.message)
      let escapedReply = escapeNested(item.reply)
      escapedQueue[i] = ActorMessage(message: escapedMessage,
                                     reply: escapedReply,
                                     workerAllowed: item.workerAllowed)
      if escapedMessage.bits != item.message.bits or
          escapedReply.bits != item.reply.bits:
        changed = true
    if not changed:
      return v
    let escapedData = newActorData(capacity,
      state = escapedState,
      restartInit = escapedRestartInit,
      handler = escapedHandler,
      messageType = sourceMessageType,
      messageTypeExplicit = messageTypeExplicit,
      failureStrategy = failureStrategy,
      failureEvents = escapedFailureEvents,
      failureDeadLetters = escapedFailureDeadLetters,
      parentFailureEvents = escapedParentFailureEvents,
      parentFailureDeadLetters = escapedParentFailureDeadLetters,
      lifecycle = lifecycle)
    escapedData.queue = escapedQueue
    escapedData.processing = processing
    escapedData.reservedMessages = reservedMessages
    boxObject(escapedData)
  of vkActorContext:
    let actor = v.actorContextActor
    let escapedActor = escapeNested(actor)
    if escapedActor.bits == actor.bits:
      return v
    boxObject(ActorContextData(objKind: okActorContext, actor: escapedActor))
  of vkActorStep:
    let state = v.actorStepState
    let escapedState = escapeNested(state)
    if escapedState.bits == state.bits:
      return v
    boxObject(ActorStepData(objKind: okActorStep,
                            continueActor: v.actorStepContinue,
                            state: escapedState))
  of vkReplyTo:
    let data = replyToData(v)
    var sourceResult: Value
    var sourceTask: Value
    withReplyToLock(data):
      sourceResult = data.result
      sourceTask = data.task
    let escapedResult = escapeNested(sourceResult)
    let escapedTask = escapeNested(sourceTask)
    if escapedResult.bits != sourceResult.bits or
        escapedTask.bits != sourceTask.bits:
      withReplyToLock(data):
        if data.result.bits == sourceResult.bits:
          data.result = escapedResult
        if data.task.bits == sourceTask.bits:
          data.task = escapedTask
    v
  of vkEnv:
    let data = EnvData(objData(v))
    let escapedParent = escapeNested(data.parent)
    var changed = escapedParent.bits != data.parent.bits
    var macroFunctions: seq[Value]
    for function in data.compilerMacroFunctions:
      let escaped = escapeNested(function)
      macroFunctions.add escaped
      if escaped.bits != function.bits: changed = true
    var bindings = initTable[string, Value]()
    for key, val in data.bindings:
      let escaped = escapeNested(val)
      bindings[key] = escaped
      if escaped.bits != val.bits:
        changed = true
    var imports = newSeq[Value](data.imports.len)
    for i, item in data.imports:
      let escaped = escapeNested(item)
      imports[i] = escaped
      if escaped.bits != item.bits:
        changed = true
    let escapedModule = escapeNested(data.module)
    let escapedPolicy = escapeNested(data.policy)
    if escapedModule.bits != data.module.bits or
        escapedPolicy.bits != data.policy.bits:
      changed = true
    if not changed:
      return v
    let escaped = newEnv(bindings, escapedParent, imports, escapedModule, escapedPolicy)
    escaped.setEnvCompilerMacros(data.compilerMacros)
    escaped.setEnvMacroFunctions(macroFunctions)
    escaped.setEnvClosedScope(data.closedScope)
    escaped
  of vkCallerEnv:
    v
  of vkCPtr:
    v
  of vkCSlice:
    v
  of vkBuffer:
    checkBuffer(v)
    let data {.cursor.} = bufferView(v)
    var changed = false
    var items = newSeq[Value](data.items.len)
    for i, item in data.items:
      let escaped = escapeNested(item)
      items[i] = escaped
      if escaped.bits != item.bits:
        changed = true
    if not changed:
      return v
    boxObject(BufferData(objKind: okBuffer, elemType: data.elemType,
                         elemScope: data.elemScope, items: items))
  of vkFfiCallable:
    let data = ffiCallableData(v)
    let escapedLibrary = escapeNested(data.library)
    if escapedLibrary.bits == data.library.bits:
      return v
    boxObject(FfiCallableData(objKind: okFfiCallable,
                              name: data.name,
                              symbol: data.symbol,
                              address: data.address,
                              library: escapedLibrary,
                              paramTypes: data.paramTypes,
                              returnType: data.returnType,
                              releaseName: data.releaseName,
                              releaseAddress: data.releaseAddress))
  of vkDeviceBuffer, vkFfiLibrary:
    v
  else:
    v

proc escapeWalk(v: Value, guard: WeakScopeGuard, walk: var EscapeWalk): Value =
  when defined(geneGraphProofTests):
    if collectingFrozenEscapeStats: inc frozenEscapeStats.walkVisits
  when not defined(geneDisableFrozenGraphProofs):
    if (v.frozenGraphProofs and FrozenNoWeakScope) != 0:
      when defined(geneGraphProofTests):
        if collectingFrozenEscapeStats: inc frozenEscapeStats.walkSkips
      return v
  ## Escapes each container once. A container met again gets what its first
  ## escape produced, or itself while that escape is still running: it is then
  ## part of a cycle, and a mutable container changes in place, so the reference
  ## stays right. An immutable container rebuilt inside a cycle is the one case
  ## left: the back-reference keeps pointing at the original.
  if not v.isManaged:
    return v
  case v.bits shr TAG_SHIFT
  of LIST_TAG, MAP_TAG, NODE_TAG, CYCLE_OBJECT_TAG, OBJECT_TAG:
    discard
  else:
    return escapeKind(v, guard, walk)
  if not walk.visited.firstVisit(v.bits):
    for entry in walk.rebuilt:
      if entry.source.bits == v.bits:
        return entry.escaped
    return v
  result = escapeKind(v, guard, walk)
  if result.bits != v.bits:
    # Holding the source also keeps its address from being reused, and matched
    # as visited, by an allocation later in this walk.
    walk.rebuilt.add (source: v, escaped: result)

proc escapeWeakFunctions*(v: Value, guard: WeakScopeGuard): Value =
  ## Values that leave their defining run/eval boundary must keep weakly-stored
  ## lexical scopes alive. A function whose owning scope the guard reports live
  ## stays as it is. Mutable containers are updated in place so their identity
  ## and aliases survive; only immutable containers holding a weak function are
  ## rebuilt. Most stored and returned values hold nothing to escape, so a scan
  ## that copies nothing decides first whether the walk runs at all.
  if not v.isManaged:
    return v
  if v.bits shr TAG_SHIFT == FUNCTION_TAG:
    # mayNeedEscape for a function outside any holder, without setting up a
    # walk: every return of a closure asks.
    let p = cast[ptr GeneFunction](v.bits and PAYLOAD_MASK)
    if p.scope != nil or p.weakScope == nil or
        weakScopeProtected(guard, p.weakScope):
      return v
  var walk: EscapeWalk
  # The scan below only reads: it runs no destructor and calls nothing that
  # could start another escape, so it may use the thread's reusable set. The
  # walk after it mutates and can release values, and keeps its own.
  let ownsScanSet = not escapeScanBusy
  if ownsScanSet:
    escapeScanBusy = true
    walk.visited.scan = addr escapeScanSet
  let needed = mayNeedEscape(v, guard, walk.visited, markHolder = false)
  if ownsScanSet:
    escapeScanBusy = false
  if not needed:
    return v
  walk.visited.clearVisited()
  escapeWalk(v, guard, walk)

proc newCompletedTask*(value: Value): Value =
  boxObject(TaskData(objKind: okTask,
                     state: newTaskState(done = true,
                       taskResult = escapeWeakFunctions(value))))

proc newPendingTask*(): Value =
  ## A task whose computation has not finished yet. The scheduler fills in the
  ## outcome with completeTask/failTask/panicTask once its fiber settles.
  boxObject(TaskData(objKind: okTask, state: newTaskState(done = false)))

proc newExternalTask*(): Value =
  ## A task whose result is owned by a native/external operation. Awaiting it is
  ## treated as external progress rather than scheduler deadlock.
  boxObject(TaskData(objKind: okTask,
                     state: newTaskState(done = false, external = true)))

proc retainTaskSourceScopes*(v: Value, scopes: openArray[Scope]) =
  ## SDK payload handles may carry weak Type/protocol/code environments. The
  ## Task's physical result owner must keep those Scopes after the input handle
  ## drops, including across user cancellation until physical settlement.
  if scopes.len == 0: return
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    if not data.done:
      for scope in scopes: data.retainedScopes.add scope

proc tryCompleteTask*(v, value: Value): bool =
  let stored = escapeWeakFunctions(value)
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    if data.done:
      return
    data.done = true
    data.cancelRequested = false
    data.external = false
    data.result = stored
    result = true
    when compileOption("threads") and defined(gcAtomicArc):
      broadcast(data.cond)

proc completeTask*(v, value: Value) =
  discard tryCompleteTask(v, value)

proc tryFailTask*(v: Value, message: string, value: Value = NIL,
                  hasValue = false): bool =
  let stored = escapeWeakFunctions(value)
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    if data.done:
      return
    data.done = true
    data.cancelRequested = false
    data.external = false
    data.errorMsg = message
    data.failed = true
    data.errorValue = stored
    data.hasErrorValue = hasValue
    result = true
    when compileOption("threads") and defined(gcAtomicArc):
      broadcast(data.cond)

proc failTask*(v: Value, message: string, value: Value = NIL, hasValue = false) =
  discard tryFailTask(v, message, value, hasValue)

proc tryPanicTask*(v: Value, message: string, value: Value = NIL,
                   hasValue = false): bool =
  let stored = escapeWeakFunctions(value)
  let data {.cursor.} = taskState(v)
  withTaskStateLock(data):
    if data.done:
      return
    data.done = true
    data.cancelRequested = false
    data.external = false
    data.panicMsg = message
    data.panicked = true
    data.panicValue = stored
    data.hasPanicValue = hasValue
    result = true
    when compileOption("threads") and defined(gcAtomicArc):
      broadcast(data.cond)

proc panicTask*(v: Value, message: string, value: Value = NIL, hasValue = false) =
  discard tryPanicTask(v, message, value, hasValue)

proc newFailedTask*(message: string, value: Value = NIL,
                    hasValue = false): Value =
  boxObject(TaskData(objKind: okTask,
                     state: newTaskState(done = true,
                       failed = true,
                       errorMsg = message,
                       errorValue = escapeWeakFunctions(value),
                       hasErrorValue = hasValue)))

proc newPanickedTask*(message: string, value: Value = NIL,
                      hasValue = false): Value =
  boxObject(TaskData(objKind: okTask,
                     state: newTaskState(done = true,
                       panicked = true,
                       panicMsg = message,
                       panicValue = escapeWeakFunctions(value),
                       hasPanicValue = hasValue)))

proc newCheckedTask*(source, resultType, errorType: Value,
                     boundaryScope: Scope): Value =
  let data {.cursor.} = taskData(source)
  boxObject(TaskData(objKind: okTask, state: data.state,
                     resultType: resultType, errorType: errorType,
                     boundaryScope: boundaryScope))

proc newChannel*(capacity = 16): Value =
  boxObject(ChannelData(objKind: okChannel,
                        state: newChannelState(capacity)))

proc newCheckedChannel*(source, itemType: Value, itemScope: Scope): Value =
  let data {.cursor.} = channelData(source)
  boxObject(ChannelData(objKind: okChannel, state: data.state,
                        itemType: itemType, itemScope: itemScope))

proc newActorRef*(capacity: int, state, handler, messageType: Value,
                  restartInit: Value = NIL,
                  failureStrategy: ActorFailureStrategy = afsStop,
                  failureEvents: Value = NIL,
                  failureDeadLetters: Value = NIL,
                  parentFailureEvents: Value = NIL,
                  parentFailureDeadLetters: Value = NIL,
                  maxRestarts = 0, restartWindowMs = 0,
                  messageTypeExplicit = false): Value =
  let storedRestartInit =
    if restartInit.kind == vkFunction:
      functionForScopeStorage(restartInit, restartInit.fnScope)
    else:
      restartInit
  let storedHandler =
    if handler.kind == vkFunction:
      functionForScopeStorage(handler, handler.fnScope)
    else:
      handler
  boxObject(newActorData(capacity,
                         state = escapeWeakFunctions(state),
                         restartInit = storedRestartInit,
                         handler = storedHandler,
                         messageType = messageType,
                         messageTypeExplicit = messageTypeExplicit,
                         failureStrategy = failureStrategy,
                         failureEvents = failureEvents,
                         failureDeadLetters = failureDeadLetters,
                         parentFailureEvents = parentFailureEvents,
                         parentFailureDeadLetters = parentFailureDeadLetters,
                         maxRestarts = maxRestarts,
                         restartWindowMs = restartWindowMs))

proc newActorContext*(actor: Value): Value =
  boxObject(ActorContextData(objKind: okActorContext, actor: actor))

proc newActorContinue*(state: Value): Value =
  boxObject(ActorStepData(objKind: okActorStep,
                          continueActor: true,
                          state: escapeWeakFunctions(state)))

proc newActorStop*(): Value =
  boxObject(ActorStepData(objKind: okActorStep,
                          continueActor: false))

proc newReplyTo*(resultType = NIL, resultScope: Scope = nil,
                 task = NIL, relaxedSend = false): Value =
  let data = ReplyToData(objKind: okReplyTo,
                         result: NIL,
                         resultType: resultType,
                         resultScope: resultScope,
                         task: task,
                         relaxedSend: relaxedSend)
  initLock(data.lock)
  boxObject(data)

proc newCPtr*(address: pointer, targetType: Value = NIL,
              mutable = true): Value =
  boxObject(CPtrData(objKind: okCPtr, address: address,
                     targetType: targetType, mutable: mutable))

proc newCConstPtr*(address: pointer, targetType: Value = NIL): Value =
  newCPtr(address, targetType, mutable = false)

proc newCOwnedPtr*(address: pointer, release: CPtrReleaseProc,
                   targetType: Value = NIL, mutable = true): Value =
  var data = allocateOwnedCPtr()
  data.objKind = okCPtr
  data.address = address
  data.targetType = targetType
  data.mutable = mutable
  data.owned = true
  data.release = release
  boxObject(data)

proc newCForeignOwnedPtr*(address: pointer, releaseAddress: pointer,
                          targetType: Value = NIL,
                          mutable = true, library: Value = NIL): Value =
  var data = allocateOwnedCPtr()
  data.objKind = okCPtr
  data.address = address
  data.targetType = targetType
  data.mutable = mutable
  data.owned = true
  data.foreignRelease = releaseAddress
  if library.kind == vkFfiLibrary:
    borrowFfiLibrary(library)
    data.library = library
  boxObject(data)

proc newCSlice*(address: pointer, length: int, targetType: Value = NIL,
                mutable = true): Value =
  if length < 0:
    raise newException(GeneError, "C slice length must be non-negative")
  boxObject(CSliceData(objKind: okCSlice, address: address, length: length,
                       targetType: targetType, mutable: mutable))

proc packedUInt64(item: Value): uint64 =
  if item.intFitsInt64:
    let n = item.intVal
    if n < 0:
      raise newException(FieldDefect, "negative value in unsigned buffer")
    return uint64(n)
  let n = item.intBigValue
  if n.sign < 0:
    raise newException(FieldDefect, "negative value in unsigned buffer")
  for i in countdown(n.digits.high, 0):
    let digit = uint64(n.digits[i])
    if result > (high(uint64) - digit) div BIG_BASE:
      raise newException(FieldDefect, "value does not fit in unsigned buffer")
    result = result * BIG_BASE + digit

proc bufferItem*(v: Value, index: int): Value {.inline.} =
  checkBuffer(v)
  let data {.cursor.} = bufferView(v)
  if index < 0 or index >= v.bufferLen:
    raise newException(FieldDefect, "buffer index out of range")
  template readPacked(T: typedesc): untyped =
    block:
      var value: T
      copyMem(addr value, unsafeAddr data.packed[index * sizeof(T)], sizeof(T))
      value
  case data.storage
  of bskValues: data.items[index]
  of bskI8: newInt(int64(readPacked(int8)))
  of bskU8: newInt(int64(readPacked(uint8)))
  of bskI16: newInt(int64(readPacked(int16)))
  of bskU16: newInt(int64(readPacked(uint16)))
  of bskI32: newInt(int64(readPacked(int32)))
  of bskU32: newInt(int64(readPacked(uint32)))
  of bskI64: newInt(readPacked(int64))
  of bskU64:
    let value = readPacked(uint64)
    if value <= uint64(high(int64)): newInt(int64(value))
    else: bigToValue(bigFromUInt64(value, 1))
  of bskF32: newFloat(float64(readPacked(float32)))
  of bskF64: newFloat(readPacked(float64))

proc setBufferItem*(v: Value, index: int, item: Value) {.inline.} =
  ## The VM/native boundary validates the element before entering this storage
  ## operation. The element representation is fixed when the buffer is made.
  checkBuffer(v)
  let data {.cursor.} = bufferView(v)
  if index < 0 or index >= v.bufferLen:
    raise newException(FieldDefect, "buffer index out of range")
  template writePacked(T: typedesc, expression: untyped) =
    var value = T(expression)
    copyMem(addr data.packed[index * sizeof(T)], addr value, sizeof(T))
  case data.storage
  of bskValues: data.items[index] = escapeWeakFunctions(item)
  of bskI8: writePacked(int8, item.intVal)
  of bskU8: writePacked(uint8, item.intVal)
  of bskI16: writePacked(int16, item.intVal)
  of bskU16: writePacked(uint16, item.intVal)
  of bskI32: writePacked(int32, item.intVal)
  of bskU32: writePacked(uint32, item.intVal)
  of bskI64: writePacked(int64, item.intVal)
  of bskU64: writePacked(uint64, packedUInt64(item))
  of bskF32: writePacked(float32, item.floatVal)
  of bskF64: writePacked(float64, item.floatVal)

proc fillBufferItems*(v: Value, first, last: int, item: Value) =
  checkBuffer(v)
  if first < 0 or last < first or last > v.bufferLen:
    raise newException(FieldDefect, "buffer fill range out of bounds")
  if first == last:
    return
  let data {.cursor.} = bufferView(v)
  if data.storage == bskValues:
    let stored = escapeWeakFunctions(item)
    for i in first ..< last:
      data.items[i] = stored
  else:
    v.setBufferItem(first, item)
    let width = bufferElementBytes(data.storage)
    # Copy the already-converted element, doubling the initialized run.
    var filled = 1
    let count = last - first
    while filled < count:
      let copying = min(filled, count - filled)
      copyMem(addr data.packed[(first + filled) * width],
              addr data.packed[first * width], copying * width)
      filled += copying

proc copyBufferItems*(dst: Value, dstStart: int,
                      src: Value, srcStart, srcEnd: int) =
  checkBuffer(dst)
  checkBuffer(src)
  let n = srcEnd - srcStart
  if srcStart < 0 or n < 0 or srcEnd > src.bufferLen or dstStart < 0 or
      dstStart > dst.bufferLen or n > dst.bufferLen - dstStart:
    raise newException(FieldDefect, "buffer copy range out of bounds")
  if n == 0:
    return
  let d {.cursor.} = bufferView(dst)
  let s {.cursor.} = bufferView(src)
  if d.storage == s.storage and d.storage != bskValues:
    let width = bufferElementBytes(d.storage)
    moveMem(addr d.packed[dstStart * width],
            unsafeAddr s.packed[srcStart * width], n * width)
  elif cast[pointer](d) == cast[pointer](s) and dstStart > srcStart:
    for k in countdown(n - 1, 0):
      dst.setBufferItem(dstStart + k, src.bufferItem(srcStart + k))
  else:
    for k in 0 ..< n:
      dst.setBufferItem(dstStart + k, src.bufferItem(srcStart + k))

proc newPackedBuffer*(elemType: Value, storage: BufferStorageKind, length: int,
                      elemScope: Scope = nil): Value =
  if storage == bskValues or length < 0 or
      length > high(int) div bufferElementBytes(storage):
    raise newException(GeneError, "invalid packed buffer storage or length")
  boxObject(BufferData(objKind: okBuffer, elemType: elemType,
                       elemScope: elemScope, storage: storage, length: length,
                       packed: newSeq[byte](length * bufferElementBytes(storage))))

proc newByteBuffer*(raw: string, elemType: Value): Value =
  result = newPackedBuffer(elemType, bskU8, raw.len)
  if raw.len > 0:
    let data {.cursor.} = bufferView(result)
    copyMem(addr data.packed[0], unsafeAddr raw[0], raw.len)

proc bufferByteString*(v: Value): string =
  ## The caller has checked the U8 element contract. Generic host-created
  ## buffers still need element validation at the boundary.
  checkBuffer(v)
  let data {.cursor.} = bufferView(v)
  if data.storage != bskU8:
    raise newException(FieldDefect, "buffer does not have packed byte storage")
  result = newString(data.packed.len)
  if result.len > 0:
    copyMem(addr result[0], unsafeAddr data.packed[0], result.len)

proc newBuffer*(elemType: Value = NIL, items: sink seq[Value] = @[],
                elemScope: Scope = nil): Value =
  for i in 0 ..< items.len:
    if items[i].kind == vkVoid:
      items[i] = NIL
    else:
      items[i] = escapeWeakFunctions(items[i])
  boxObject(BufferData(objKind: okBuffer, elemType: elemType,
                       elemScope: elemScope, items: items))

proc newDeviceBuffer*(backend: string, elemType: Value, length: int): Value =
  if backend.len == 0:
    raise newException(GeneError, "Device/Buffer backend must not be empty")
  if length < 0:
    raise newException(GeneError, "Device/Buffer length must be non-negative")
  boxObject(DeviceBufferData(objKind: okDeviceBuffer,
                             backend: backend,
                             elemType: elemType,
                             length: length))

proc newFfiLibrary*(handle: pointer, path: string,
                    close: FfiLibraryCloseProc): Value =
  if handle == nil:
    raise newException(GeneError, "FFI library handle must not be nil")
  var data = allocateFfiLibrary()
  data.objKind = okFfiLibrary
  data.handle = handle
  data.path = path
  data.close = close
  boxObject(data)

proc newLogger*(name: string, routeId: int, payload: Value): Value =
  if name.len == 0:
    raise newException(GeneError, "Logger name must not be empty")
  boxObject(LoggerData(objKind: okLogger, name: name, routeId: routeId,
                       payload: payload))

proc loggerName*(v: Value): string =
  if v.kind != vkLogger:
    raise newException(FieldDefect, "value is not a Logger")
  LoggerData(objData(v)).name

proc loggerRouteId*(v: Value): int =
  if v.kind != vkLogger:
    raise newException(FieldDefect, "value is not a Logger")
  LoggerData(objData(v)).routeId

proc loggerPayload*(v: Value): Value =
  if v.kind != vkLogger:
    raise newException(FieldDefect, "value is not a Logger")
  LoggerData(objData(v)).payload

# ---------------------------------------------------------------------------
# Application event bus storage (docs/stdlib.md)
# ---------------------------------------------------------------------------
#
# Only the storage lives here. Matching, dispatch, freezing, and error policy
# are in `events.nim`, which is included into the VM where `applyCall` and the
# error types it raises are available.

when compileOption("threads"):
  var cachedEventLane {.threadvar.}: int

proc currentEventLane*(): int {.inline.} =
  ## Lane identity for bus ownership (events.md §9.1).
  ##
  ## Threads are the lane boundary in this runtime: every root-lane fiber runs
  ## on one thread, and the atomicArc worker lane is another, so a thread id
  ## separates exactly the cases §9.1 separates. Cached in a threadvar because
  ## `publish` reads it — `getThreadId` is a libc call on some platforms and
  ## this must not show up next to dispatch.
  ##
  ## Under `--threads:off` (the wasm profile) there is one lane by
  ## construction, so the check is a constant.
  when compileOption("threads"):
    if cachedEventLane == 0:
      cachedEventLane = getThreadId()
    cachedEventLane
  else:
    0

const defaultEventNestingLimit* = 16
  ## §7.6's "conservative default" nesting limit. Deep-first nested publication
  ## is legal; unbounded recursion through it is not.

proc newEventBus*(errorPolicy: EventErrorPolicy = eepRaiseAfter,
                  nestingLimit = defaultEventNestingLimit): Value =
  boxObject(EventBusData(objKind: okEventBus, errorPolicy: errorPolicy,
                         nestingLimit: nestingLimit,
                         ownerLane: currentEventLane(),
                         descendantBuckets: initTable[int32, seq[int32]](),
                         exactBuckets: initTable[int32, seq[int32]](),
                         matchCache: initTable[int32, EventMatchCacheEntry]()))

template busData*(v: Value): EventBusData =
  ## The bus payload. Never outlive `v` — see the `objData` contract.
  EventBusData(objData(v))

proc requireEventBus*(v: Value) {.inline.} =
  if v.kind != vkEventBus:
    raise newException(FieldDefect, "value is not an event/Bus")

proc eventBusClosed*(v: Value): bool =
  requireEventBus(v)
  busData(v).closed

proc eventBusErrorPolicy*(v: Value): EventErrorPolicy =
  requireEventBus(v)
  busData(v).errorPolicy

proc eventBusNestingLimit*(v: Value): int =
  requireEventBus(v)
  busData(v).nestingLimit

proc eventBusOwnerLane*(v: Value): int =
  requireEventBus(v)
  busData(v).ownerLane

proc newEventSubscription*(bus: Value, index: int32): Value =
  requireEventBus(bus)
  boxObject(EventSubscriptionData(objKind: okEventSubscription,
                                  busBits: bus.bits, index: index))

template subscriptionData*(v: Value): EventSubscriptionData =
  EventSubscriptionData(objData(v))

proc subscriptionBus*(v: Value): Value =
  ## The bus this handle points at, retained for the caller. The stored edge is
  ## non-owning, so a handle never keeps a bus alive; reconstituting it here is
  ## the one place that turns those bits back into a counted reference.
  if v.kind != vkEventSubscription:
    raise newException(FieldDefect, "value is not an event/Subscription")
  result.bits = subscriptionData(v).busBits
  if (result.bits shr TAG_SHIFT) >= MANAGED_MIN:
    rcRetain(result.bits)

proc newEventMatcher*(target: Value, typeId: int32): Value =
  boxObject(EventMatcherData(objKind: okEventMatcher, target: target,
                             typeId: typeId))

proc eventMatcherTarget*(v: Value): Value =
  if v.kind != vkEventMatcher:
    raise newException(FieldDefect, "value is not an event/Matcher")
  EventMatcherData(objData(v)).target

proc eventMatcherTypeId*(v: Value): int32 =
  if v.kind != vkEventMatcher:
    raise newException(FieldDefect, "value is not an event/Matcher")
  EventMatcherData(objData(v)).typeId

proc newRecordingSink*(): Value =
  boxObject(EventSinkData(objKind: okRecordingSink))

proc newNullSink*(): Value =
  boxObject(EventSinkData(objKind: okNullSink))

proc newCompositeSink*(sinks: sink seq[Value]): Value =
  boxObject(EventSinkData(objKind: okCompositeSink, sinks: sinks))

template sinkData*(v: Value): EventSinkData =
  EventSinkData(objData(v))

proc recordedEvents*(v: Value): lent seq[Value] =
  if v.kind != vkRecordingSink:
    raise newException(FieldDefect, "value is not an event/RecordingSink")
  EventSinkData(objData(v)).recorded

proc recordEvent*(v: Value, event: Value) =
  if v.kind != vkRecordingSink:
    raise newException(FieldDefect, "value is not an event/RecordingSink")
  EventSinkData(objData(v)).recorded.add event

proc clearRecordedEvents*(v: Value) =
  if v.kind != vkRecordingSink:
    raise newException(FieldDefect, "value is not an event/RecordingSink")
  EventSinkData(objData(v)).recorded.setLen(0)

proc compositeSinks*(v: Value): lent seq[Value] =
  if v.kind != vkCompositeSink:
    raise newException(FieldDefect, "value is not an event/CompositeSink")
  EventSinkData(objData(v)).sinks

const EventSinkKinds* = {vkEventBus, vkRecordingSink, vkNullSink,
                         vkCompositeSink}
  ## The value kinds the built-in `EventSink` impls cover. A Gene type may
  ## implement the protocol too; this set is only the native shortcut.

const EventValueKinds* = {vkEventBus, vkEventSubscription, vkEventMatcher,
                          vkRecordingSink, vkNullSink, vkCompositeSink}

proc newFfiCallable*(name, symbol: string, address: pointer, library: Value,
                     paramTypes: seq[Value], returnType: Value,
                     releaseName = "", releaseAddress: pointer = nil): Value =
  if address == nil:
    raise newException(GeneError, "FFI callable address must not be nil")
  boxObject(FfiCallableData(objKind: okFfiCallable,
                            name: name,
                            symbol: symbol,
                            address: address,
                            library: library,
                            paramTypes: paramTypes,
                            returnType: returnType,
                            releaseName: releaseName,
                            releaseAddress: releaseAddress))

proc classifyNativeFastKind*(name: string): NativeFastKind =
  case name
  of "+": nfkAdd
  of "-": nfkSub
  of "*": nfkMul
  of "<": nfkLt
  of ">": nfkGt
  of "<=": nfkLe
  of ">=": nfkGe
  of "/": nfkDiv
  of "//": nfkRem
  of "==": nfkEq
  of "!=": nfkNe
  else: nfkNone

proc newNativeFn*(name: string, impl: NativeProc,
                  acceptsNamed = false,
                  errorMetadata = NativeErrorMetadata(),
                  fastKind = nfkNone): Value =
  let p = createObj(GeneNativeFn)
  p.refCount = 1
  p.name = name
  p.impl = impl
  p.acceptsNamed = acceptsNamed
  p.fastKind = fastKind
  p.errorMetadata = errorMetadata
  boxPtr(NATIVE_FN_TAG, p)

proc newNativeCallFn*(name: string, impl: NativeCallProc,
                      acceptsNamed = true,
                      errorMetadata = NativeErrorMetadata()): Value =
  let p = createObj(GeneNativeFn)
  p.refCount = 1
  p.name = name
  p.callImpl = impl
  p.acceptsNamed = acceptsNamed
  p.fastKind = nfkNone
  p.errorMetadata = errorMetadata
  boxPtr(NATIVE_FN_TAG, p)

proc newNativeContextFn*(name: string, context: RootRef,
                         impl: NativeContextCallProc,
                         acceptsNamed = true): Value =
  let p = createObj(GeneNativeFn)
  p.refCount = 1
  p.name = name
  p.context = context
  p.contextImpl = impl
  p.acceptsNamed = acceptsNamed
  p.fastKind = nfkNone
  boxPtr(NATIVE_FN_TAG, p)

proc newNamespace*(name: string, scope: Scope, modulePath = "",
                   moduleRoot = false): Value =
  boxObject(NamespaceData(objKind: okNamespace, name: name, scope: scope,
                          moduleRoot: moduleRoot, modulePath: modulePath))

var moduleIdentitySeq: int

proc nextModuleIdentity(): int =
  when compileOption("threads"):
    atomicFetchAdd(addr moduleIdentitySeq, 1, ATOMIC_RELAXED) + 1
  else:
    inc moduleIdentitySeq
    moduleIdentitySeq

proc newModule*(name: string, root: Value, path = "",
                meta: sink PropTable = initPropTable()): Value =
  if root.kind != vkNamespace:
    raise newException(FieldDefect, "module root is not a Namespace")
  boxObject(ModuleData(objKind: okModule, name: name, path: path, root: root,
                       meta: meta, runtimeId: nextModuleIdentity()))

proc newEnv*(bindings: sink Table[string, Value],
             parent: Value = NIL,
             imports: sink seq[Value] = @[],
             module: Value = NIL,
             policy: Value = NIL,
             bindingScope: Scope = nil): Value =
  var storedBindings = initTable[string, Value]()
  for key, value in bindings:
    storedBindings[key] = weakenScopeFunctions(value, bindingScope)
  boxObject(EnvData(objKind: okEnv, parent: parent, bindings: storedBindings,
                    imports: imports, module: module, policy: policy))

var callerEnvsCreated: int

proc anyCallerEnvCreated*(): bool {.inline.} =
  ## Whether this process has ever made a borrowed CallerEnv. `newCallerEnv`
  ## is the only place one comes from, so until it has run no value anywhere
  ## can carry one. Never reset: an expired CallerEnv is still a CallerEnv.
  when threadedRc: atomicLoadN(addr callerEnvsCreated, ATOMIC_RELAXED) != 0
  else: callerEnvsCreated != 0

proc newCallerEnv*(scope: Scope): Value =
  if scope == nil:
    raise newException(FieldDefect, "CallerEnv requires a caller scope")
  when threadedRc: discard atomicFetchAdd(addr callerEnvsCreated, 1, ATOMIC_RELAXED)
  else: inc callerEnvsCreated
  boxObject(EnvData(objKind: okEnv, borrowed: true, borrowedActive: true,
                    borrowedScope: scope))

proc callerEnvScope*(v: Value): Scope =
  if not v.isObjectTagged or objData(v).objKind != okEnv:
    raise newException(FieldDefect, "value is not a CallerEnv")
  let data = EnvData(objData(v))
  if not data.borrowed:
    raise newException(FieldDefect, "value is not a CallerEnv")
  if not data.borrowedActive or data.borrowedScope == nil:
    raise newException(GeneError,
      "CallerEnv is no longer valid outside its syntax call")
  data.borrowedScope

proc deactivateCallerEnv*(v: Value) =
  if not v.isObjectTagged or objData(v).objKind != okEnv:
    raise newException(FieldDefect, "value is not a CallerEnv")
  let data = EnvData(objData(v))
  if not data.borrowed:
    raise newException(FieldDefect, "value is not a CallerEnv")
  data.borrowedActive = false
  data.borrowedScope = nil

proc newCell*(value: Value): Value =
  boxObject(CellData(objKind: okCell, value: value))

proc newAtomicCell*(value: Value): Value =
  let d = AtomicCellData(objKind: okAtomicCell, value: value)
  initLock(d.lock)
  boxObject(d)

proc newStream*(items: sink seq[Value]): Value =
  boxObject(StreamData(objKind: okStream, items: items, index: 0, closed: false))

proc newTypedStream*(items: sink seq[Value], itemType, errType: Value,
                     itemScope: Scope): Value =
  boxObject(StreamData(objKind: okStream, items: items, index: 0,
                       itemType: itemType, errType: errType,
                       itemScope: itemScope, closed: false))

proc newCheckedStream*(source, itemType, errType: Value, itemScope: Scope,
                       checkFailure: StreamFailureCheckProc = nil): Value =
  boxObject(StreamData(objKind: okStream, source: source, itemType: itemType,
                       errType: errType, itemScope: itemScope, closed: false,
                       checkFailure: checkFailure))

proc newLazyStream*(source: Value, pull: StreamPullProc,
                    callable: Value = NIL, remaining: int64 = -1,
                    itemType: Value = NIL, errType: Value = NIL,
                    itemScope: Scope = nil,
                    close: StreamCloseProc = nil): Value =
  # The stream owns its callable strongly, like every other heap container
  # (channels, cells, actor state). Weakening the captured-scope edge here
  # dangles when the operand stack held the only strong reference to an
  # inline lambda; the scope->stream->callable->scope self-cycle this trades
  # back is a leak, not a crash, matching the container-wide tradeoff.
  let storedCallable = escapeWeakFunctions(callable)
  boxObject(StreamData(objKind: okStream, source: source, callable: storedCallable,
                       remaining: remaining, pull: pull, close: close, itemType: itemType,
                       errType: errType, itemScope: itemScope, closed: false))

proc newGeneratorStream*(code: FunctionCode, scope: Scope,
                         pull: StreamPullProc,
                         close: StreamCloseProc = nil): Value =
  boxObject(StreamData(objKind: okStream, pull: pull, close: close, closed: false,
                       generatorCode: code, generatorScope: scope,
                       generatorStack: @[], generatorIp: 0))

# ---------------------------------------------------------------------------
# Compact event type identity (docs/stdlib.md)
# ---------------------------------------------------------------------------

var
  eventTypeIdCounter: int32
  eventTypeIdLock: Lock
initLock(eventTypeIdLock)

proc nextEventTypeId(): int32 =
  ## Ids identify *type declarations*, not names: two modules declaring the
  ## same printed path get different ids.
  ##
  ## **The counter is process-wide, where §6.4 says "the application owns the
  ## counter". That is a real deviation, not a reading of the spec.** What §6.4
  ## is protecting still holds: nothing is registered here and nothing can be
  ## looked up from it — it hands out an opaque monotonic number and keeps no
  ## table — so there is still no global topic namespace, nothing to collide
  ## in, and nothing a module can observe. What is lost is only that two
  ## Applications in one process draw from one sequence instead of two, which
  ## no interface exposes.
  ##
  ## Note this is *not* justified by shared type identity: `event/Event` is
  ## built per Application in `registerEventNamespace`, so each Application
  ## already has its own root with its own id. Making the counter per
  ## Application is therefore possible; it needs `newType` to reach an
  ## Application, and `newType` takes a `Scope` that is nil on the builtins
  ## path.
  acquire(eventTypeIdLock)
  try:
    inc eventTypeIdCounter
    result = eventTypeIdCounter
  finally:
    release(eventTypeIdLock)

proc eventTypeId*(v: Value): int32 =
  ## 0 when `v` is not a nominal Type or not an `event/Event` descendant. An
  ## alias never carries one: only `newType` assigns, and it builds no aliases.
  ## `vkType` also covers enums, whose payload is an `EnumData`, so the test is
  ## on the object kind rather than the value kind.
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okType:
    return 0
  TypeData(objData(v)).eventTypeId

proc eventMatchIds*(v: Value): lent seq[int32] =
  ## This type's id first, then each event ancestor's, up to `event/Event`.
  ## Only meaningful when `eventTypeId(v)` is nonzero.
  TypeData(objData(v)).eventMatchIds

proc newType*(name: string, parent: Value, ownFields: seq[TypeField],
              requiredProtocols: sink seq[Value], scope: Scope,
              derivedProtocols: sink seq[Value] = @[],
              deriveRequests: sink seq[Value] = @[],
              ownBodyFields: seq[TypeBodyField] = @[],
              messages: sink Table[string, Value] = initTable[string, Value](),
              ctorFn: Value = NIL,
              repr: TypeRepr = trOrdinary,
              nativeIdentity = "",
              nativeAbiIdentity = "",
              nativeAbiFingerprint = "",
              nativeContractFingerprint = "",
              eventRoot = false): Value =
  ## A nominal type. Single inheritance is merged eagerly: the parent's fields
  ## come first, then this type's own fields (design Section 7.3).
  var fields: seq[TypeField]
  var bodyFields: seq[TypeBodyField]
  var repr = repr
  if parent.kind == vkType:
    fields = typeFields(parent)
    bodyFields = typeBodyFields(parent)
    # The wrapper rule is inherited: a Gene-side subtype may add messages and
    # impls, but it must not reopen construction on a native payload (design
    # §16.6). Merging it here — like the field schema — keeps every later check
    # a single flag read instead of an ancestry walk.
    if parent.isNativeWrapperType:
      repr = trNativeWrapper
  for f in ownFields:
    for inherited in fields:
      if inherited.name == f.name:
        raise newException(GeneError,
          "type " & name & " redeclares inherited field: " & f.name)
    var owned = f
    # Normalize the cached key id here so every construction site (compiler,
    # stdlib type registrations, runtime types) flows through one funnel and
    # runtime construction/validation can trust `nameId` unconditionally.
    owned.nameId = propKeyId(owned.name)
    if owned.scope == nil and owned.weakScope == nil:
      owned.weakScope = cast[pointer](scope)
    fields.add owned
  if ownBodyFields.len > 0 and bodyFields.len > 0 and bodyFields[^1].rest:
    raise newException(GeneError,
      "type " & name & " cannot add body fields after inherited rest body field")
  for f in ownBodyFields:
    var owned = f
    if owned.scope == nil and owned.weakScope == nil:
      owned.weakScope = cast[pointer](scope)
    bodyFields.add owned
  # Event identity is assigned here — eagerly, at declaration — so no lane bumps
  # a shared counter at first publish (events.md §6.4). A type is an event type
  # exactly when it is the `event/Event` root or a nominal descendant of one,
  # which is a single field read on the parent.
  var eventId: int32 = 0
  var matchIds: seq[int32]
  if eventRoot:
    eventId = nextEventTypeId()
    matchIds = @[eventId]
  elif parent.eventTypeId != 0:
    eventId = nextEventTypeId()
    let inherited = parent.eventMatchIds
    matchIds = newSeqOfCap[int32](inherited.len + 1)
    matchIds.add eventId
    for id in inherited:
      matchIds.add id
  boxObject(TypeData(objKind: okType, name: name, parent: parent,
                     coreWitnessesSealed: true,
                     repr: repr, nativeIdentity: nativeIdentity,
                     nativeAbiIdentity: nativeAbiIdentity,
                     nativeAbiFingerprint: nativeAbiFingerprint,
                     nativeContractFingerprint: nativeContractFingerprint,
                     fields: fields,
                     bodyFields: bodyFields,
                     weakScope: cast[pointer](scope),
                     requiredProtocols: requiredProtocols,
                     derivedProtocols: derivedProtocols,
                     deriveRequests: deriveRequests,
                     messages: messages,
                     ctorFn: ctorFn,
                     eventTypeId: eventId,
                     eventMatchIds: matchIds))

proc newTypeAlias*(name: string, expr: Value): Value =
  ## A transparent type alias (design §7.4.1): a Type value carrying only the
  ## aliased expression. It resolves in scope like a nominal name but expands to
  ## `expr` wherever a type is checked; it is never constructible.
  boxObject(TypeData(objKind: okType, name: name, parent: NIL,
                     aliasExpr: expr))

proc closedAbiAnnotation*(name: string): Value =
  ## An opaque C pointee label is not a lexical Gene type reference.
  boxObject(TypeData(objKind: okType, name: name, parent: NIL,
    aliasExpr: newSym(name), opaqueAbiAnnotation: true))

proc isOpaqueAbiAnnotation*(v: Value): bool {.inline.} =
  v.tagOf == OBJECT_TAG and objData(v).objKind == okType and
    TypeData(objData(v)).opaqueAbiAnnotation

proc borrowedTypeAnnotation*(typ: Value, canonicalName = ""): Value =
  ## Declaration-owned code must not create Type -> method -> Type RC cycles.
  ## These internal aliases borrow the identity rooted by the declaration's
  ## owner/scope. closeTypeExpr expands them to owning Values whenever a type
  ## boundary escapes into a cell, callable view, or other runtime object.
  if typ.kind notin {vkType, vkProtocol}:
    raise newException(GeneError, "type annotation identity must be a type or protocol")
  boxObject(TypeData(objKind: okType,
    name: (if typ.kind == vkType: typ.typeName else: typ.protocolName),
    annotationRefBits: typ.bits, annotationContractName: canonicalName))

proc isBorrowedTypeAnnotation*(v: Value): bool {.inline.} =
  v.tagOf == OBJECT_TAG and objData(v).objKind == okType and
    TypeData(objData(v)).annotationRefBits != 0

proc borrowedAnnotationContractName*(v: Value): string =
  if v.isBorrowedTypeAnnotation: TypeData(objData(v)).annotationContractName else: ""

proc isTypeAlias*(v: Value): bool {.inline.} =
  v.tagOf == OBJECT_TAG and objData(v).objKind == okType and
    (TypeData(objData(v)).aliasExpr.kind != vkNil or
     TypeData(objData(v)).annotationRefBits != 0)

proc typeAliasExpr*(v: Value): Value {.inline.} =
  let data = TypeData(objData(v))
  if data.annotationRefBits != 0:
    ownedValueFromBits(data.annotationRefBits)
  else:
    data.aliasExpr

proc ownTypeAnnotation*(expr: Value): Value =
  ## Retain borrowed declaration identities when reflection exports annotation
  ## data, without changing the source spelling of ordinary builtin sugar.
  if expr.isBorrowedTypeAnnotation:
    return expr.typeAliasExpr
  case expr.kind
  of vkNode:
    let head = ownTypeAnnotation(expr.head)
    var changed = head.bits != expr.head.bits
    var body: seq[Value]
    for item in expr.body:
      let owned = ownTypeAnnotation(item)
      body.add owned
      changed = changed or owned.bits != item.bits
    var props = initPropTable()
    for key, item in expr.props:
      let owned = ownTypeAnnotation(item)
      props[key] = owned
      changed = changed or owned.bits != item.bits
    if changed: newNode(head, body = body, props = props, meta = expr.meta,
                         immutable = expr.nodeImmutable)
    else: expr
  of vkList:
    var changed = false
    var items: seq[Value]
    for item in expr.listItems:
      let owned = ownTypeAnnotation(item)
      items.add owned
      changed = changed or owned.bits != item.bits
    if changed: newList(items, expr.listImmutable) else: expr
  of vkMap:
    var changed = false
    var props = initPropTable()
    for key, item in expr.mapEntries:
      let owned = ownTypeAnnotation(item)
      props[key] = owned
      changed = changed or owned.bits != item.bits
    if changed: newMap(props, expr.mapImmutable) else: expr
  else: expr

proc implAssemblyScope*(impl: ProtocolImpl): Scope =
  if impl.assemblyScope != nil: impl.assemblyScope else: cast[Scope](impl.weakAssemblyScope)

proc implForScopeStorage*(impl: ProtocolImpl, owner: Scope): ProtocolImpl =
  result = impl
  let source = impl.implAssemblyScope
  if source == owner:
    result.assemblyScope = nil
    result.weakAssemblyScope = cast[pointer](source)
  else:
    result.assemblyScope = source
    result.weakAssemblyScope = nil

proc replaceScopeImpls*(scope: Scope, impls: sink seq[ProtocolImpl]) =
  ## Install `impls` as the scope's impls, then release the previous ones.
  ## Releasing an impl's values can walk this scope's references
  ## (weakenOwnedTypeEnvironment -> scopeOwnedReferences). Assigning over the
  ## field destroyed the old list in place, and that walk read it half freed.
  var previous = move scope.impls
  scope.impls = impls
  previous.setLen(0)

proc typeContractPending*(typ: Value): bool =
  typ.tagOf == OBJECT_TAG and objData(typ).objKind == okType and
    TypeData(objData(typ)).contractPending

proc setTypeContractPending*(typ: Value, pending: bool) =
  if typ.tagOf != OBJECT_TAG or objData(typ).objKind != okType:
    raise newException(FieldDefect, "pending contract requires a nominal type")
  TypeData(objData(typ)).contractPending = pending

proc typeCoreWitnessesSealed*(typ: Value): bool =
  if typ.kind != vkType:
    raise newException(FieldDefect, "core witnesses require a nominal type")
  TypeData(objData(typ)).coreWitnessesSealed

proc typeCoreWitnesses*(typ: Value): CoreValueWitnesses =
  if not typ.typeCoreWitnessesSealed:
    raise newException(GeneError, "ValueProtocolPending: " & typ.typeName)
  TypeData(objData(typ)).coreWitnesses

proc typeCoreWitness*(typ: Value, operation: CoreValueMethod): Value =
  typ.typeCoreWitnesses[operation]

proc markTypeCoreWitnessesPending*(typ: Value) =
  if typ.kind != vkType or typ.isTypeAlias:
    raise newException(FieldDefect, "core witnesses require a nominal type")
  TypeData(objData(typ)).coreWitnessesSealed = false

proc sealTypeCoreWitnesses*(typ: Value, witnesses: CoreValueWitnesses) =
  if typ.kind != vkType or typ.isTypeAlias or typ.typeCoreWitnessesSealed:
    raise newException(GeneError, "core witnesses are already sealed")
  let data = TypeData(objData(typ))
  data.coreWitnesses = witnesses
  data.coreWitnessesSealed = true

proc setTypeOwnMessages*(typ: Value, messages: sink Table[string, Value], ctor: Value) =
  ## Complete a fresh nominal declaration before publishing its binding.
  if objData(typ).objKind == okEnum:
    EnumData(objData(typ)).messages = messages
    return
  let data = TypeData(objData(typ))
  data.messages = messages
  data.ctorFn = ctor

proc setTypeSchemaAnnotations*(typ: Value, fields: sink seq[TypeField],
                               bodyFields: sink seq[TypeBodyField]) =
  let data = TypeData(objData(typ))
  data.fields = fields
  data.bodyFields = bodyFields

proc unionTypeExpr*(members: sink seq[Value]): Value =
  ## `(| A B ...)` as a value: an *anonymous* transparent alias over the same
  ## `|` node the annotation form already uses (design §7.4.1).
  ##
  ## Reusing the alias representation is the point. `(alias U (| A B))` already
  ## produces exactly this with a name attached, `matchesTypeExpr` already
  ## expands it, and `constructTypedInstance` already refuses to construct it —
  ## so a union value is not a new kind of thing, it is the thing `alias` makes
  ## with the name left off. A dedicated `vkUnion` would add a value kind for
  ## something the type checker already handles structurally, and `kind` is
  ## `{.inline.}` and size-sensitive.
  newTypeAlias("", newNode(newSym("|"), body = members))

proc isUnionType*(v: Value): bool =
  ## True for a type value whose expansion is a `|` node — whether it was
  ## written `(| A B)` or named with `alias`.
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okType:
    return false
  let expr = TypeData(objData(v)).aliasExpr
  expr.kind == vkNode and expr.head.kind == vkSymbol and
    expr.head.symVal == "|"

proc unionTypeMembers*(v: Value): lent seq[Value] =
  ## The alternatives of a union type value. Only meaningful when
  ## `isUnionType(v)`.
  TypeData(objData(v)).aliasExpr.body

proc newEnum*(name: string, typeParams: sink seq[string],
              variants: openArray[tuple[name: string, payloadTypes: seq[Value],
                                         hasBacking: bool, backing: Value]],
              backingType: Value, scope: Scope,
              messages: sink Table[string, Value] = initTable[string, Value]()): Value =
  let data = EnumData(objKind: okEnum, name: name, typeParams: typeParams,
                      backingType: backingType, weakScope: cast[pointer](scope),
                      messages: messages)
  result = boxObject(data)
  for i, spec in variants:
    let variant = boxObject(EnumVariantData(objKind: okEnumVariant,
                                            enumBits: result.bits,
                                            name: spec.name,
                                            ordinal: i,
                                            payloadTypes: spec.payloadTypes,
                                            backing: spec.backing,
                                            hasBacking: spec.hasBacking))
    data.variants.add variant

proc typeDirectMessage*(v: Value, name: string): Value =
  ## Type-direct message lookup, walking the parent chain — most-derived type
  ## wins (docs/spec/protocols.md). Returns NIL when no type in the chain defines
  ## `name`; stored messages are always functions, never NIL.
  var t = v
  while t.kind == vkType:
    case objData(t).objKind
    of okType:
      let data = TypeData(objData(t))
      if data.messages.hasKey(name):
        return data.messages[name]
      t = data.parent
    of okEnum:
      let data = EnumData(objData(t))
      if data.messages.hasKey(name):
        return data.messages[name]
      t = NIL
    else:
      t = NIL
  NIL

proc newProtocolMessage*(protocol: Value, name: string,
                         signatureFn: Value = NIL,
                         hasDefault = false): Value =
  boxObject(ProtocolMessageData(objKind: okProtocolMessage,
                                name: name,
                                protocolBits: protocol.bits,
                                signatureFn: signatureFn,
                                hasDefault: hasDefault))

proc newBoundMessage*(qualifier: Value, name: string, protocolBits: uint64,
                      scope: Scope): Value =
  ## A message value carrying where it was written. This is a *message*, not a
  ## function: it prints as one, satisfies `Callable`, and is accepted as a held
  ## send callee `(x .%m)` — which a closure cannot be.
  boxObject(BoundMessageData(objKind: okBoundMessage,
                             name: name,
                             protocolBits: protocolBits,
                             qualifier: qualifier,
                             boundScope: scope))

proc cloneBoundMessageScope(v: Value, scope: Scope, weak: bool): Value =
  let original = BoundMessageData(objData(v))
  boxObject(BoundMessageData(objKind: okBoundMessage,
                             name: original.name,
                             protocolBits: original.protocolBits,
                             qualifier: original.qualifier,
                             boundScope: (if weak: nil else: scope),
                             weakScope: (if weak: cast[pointer](scope) else: nil)))

proc protocolMessageQualifier*(v: Value): Value =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okBoundMessage:
    raise newException(FieldDefect, "value is not a bound message")
  BoundMessageData(objData(v)).qualifier

proc protocolMessageScope*(v: Value): Scope =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okBoundMessage:
    raise newException(FieldDefect, "value is not a bound message")
  let data = BoundMessageData(objData(v))
  if data.boundScope != nil: data.boundScope
  else: cast[Scope](data.weakScope)

proc protocolMessageIsBound*(v: Value): bool {.inline.} =
  v.tagOf == OBJECT_TAG and objData(v).objKind == okBoundMessage

proc newProtocol*(name: string, messageNames: openArray[string],
                  deriveFn: Value = NIL, parents: sink seq[Value] = @[],
                  signatures: openArray[Value] = [],
                  hasDefaults: openArray[bool] = [],
                  universal = false, scope: Scope = nil,
                  errorRoot = false): Value =
  ## `parents` are already-constructed ^inherit ancestors (docs/spec/protocols.md).
  ## The message closure is flattened eagerly, ancestors first, deduped by
  ## message identity. A protocol message is identified by its defining
  ## protocol plus local name (docs/spec/protocols.md): same-name messages from
  ## unrelated parents coexist in the closure, and an own message may reuse
  ## an inherited simple name — it is a new distinct message, not an override
  ## (docs/spec/protocols.md). Diamond re-inheritance contributes one entry
  ## because it is the same message value through two paths.
  var closure: seq[Value]
  for parent in parents:
    if parent.kind != vkProtocol:
      raise newException(GeneError, "protocol ^inherit entries must be protocols")
    for pmsg in ProtocolData(objData(parent)).closure:
      var present = false
      for existing in closure:
        if existing.bits == pmsg.bits:
          present = true
          break
      if not present:
        closure.add pmsg
  let data = ProtocolData(objKind: okProtocol, name: name,
                          weakScope: cast[pointer](scope),
                          messages: initOrderedTable[string, Value](),
                          deriveFn: deriveFn, universal: universal, errorRoot: errorRoot,
                          parents: parents,
                          closure: closure)
  let protocol = boxObject(data)
  for i, messageName in messageNames:
    let signatureFn = if i < signatures.len: signatures[i] else: NIL
    let hasDefault = i < hasDefaults.len and hasDefaults[i]
    let message = newProtocolMessage(protocol, messageName, signatureFn, hasDefault)
    data.messages[messageName] = message
    data.closure.add message
  if universal:
    for message in data.closure:
      if protocolMessageDefaultFn(message).kind == vkNil:
        raise newException(GeneError,
          "universal protocol " & name &
          " requires defaults for every message: " &
          protocolMessageName(message))
  protocol

proc protocolParents*(v: Value): lent seq[Value] =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okProtocol:
    raise newException(FieldDefect, "value is not a Protocol")
  ProtocolData(objData(v)).parents

proc protocolClosure*(v: Value): lent seq[Value] =
  ## The full transitive message closure (own + inherited), ancestors first.
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okProtocol:
    raise newException(FieldDefect, "value is not a Protocol")
  ProtocolData(objData(v)).closure

proc protocolClosureByName*(v: Value, name: string): seq[Value] =
  ## All closure messages whose local name is `name`. More than one result
  ## means the simple name is ambiguous and needs qualification
  ## (docs/spec/protocols.md).
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okProtocol:
    raise newException(FieldDefect, "value is not a Protocol")
  for message in ProtocolData(objData(v)).closure:
    if ProtocolMessageData(objData(message)).name == name:
      result.add message

proc protocolClosureContains*(v, message: Value): bool =
  if v.tagOf != OBJECT_TAG or objData(v).objKind != okProtocol:
    return false
  for existing in ProtocolData(objData(v)).closure:
    if existing.bits == message.bits:
      return true
  false

proc protocolIsOrInherits*(candidate, target: Value): bool =
  ## True if `candidate` is `target`, or `target` is a transitive ^inherit
  ## ancestor of `candidate` (design docs/spec/protocols.md).
  if candidate.kind != vkProtocol or target.kind != vkProtocol:
    return false
  if candidate.bits == target.bits:
    return true
  for parent in ProtocolData(objData(candidate)).parents:
    if protocolIsOrInherits(parent, target):
      return true
  false

proc typeDeclaresMessageFreeProtocol*(typ, protocol: Value): bool =
  ## A type's `^impl [P]` is itself the conformance when P's inherited message
  ## closure is empty: an impl would carry no bodies (docs/spec/protocols.md).
  ## Nominal subtypes inherit the declaration, as they inherit a parent's impl.
  var current = typ
  while current.tagOf == OBJECT_TAG and objData(current).objKind == okType:
    for required in TypeData(objData(current)).requiredProtocols:
      if required.kind == vkProtocol and
          ProtocolData(objData(required)).closure.len == 0 and
          protocolIsOrInherits(required, protocol):
        return true
    current = TypeData(objData(current)).parent
  false

proc internName*(v: string): string =
  ## Deduplicate a prop-key string so identical keys share storage.
  acquire(internLock)
  try:
    result = internedNames.getOrDefault(v)
    if result.len == 0 and v.len != 0:
      internedNames[v] = v
      result = v
  finally:
    release(internLock)

# ---------------------------------------------------------------------------
# Truthiness (design Section 1.6): false, nil, void are falsy.
# ---------------------------------------------------------------------------

proc isTruthy*(v: Value): bool {.inline.} =
  case v.kind
  of vkNil, vkVoid: false
  of vkBool: v.boolVal
  else: true

proc isAbsent*(v: Value): bool {.inline.} =
  ## Absence in Gene's two-absence model (design §1.6): explicit empty `nil`
  ## or missing/skipped `void`. Distinct from falsiness — `false`, `0`, and
  ## `""` are present. This is the test behind `absent?`/`present?` and `??`.
  v.kind == vkNil or v.kind == vkVoid

proc isImmutable*(v: Value): bool =
  case v.kind
  of vkBytes, vkRegex, vkRange, vkDate, vkTime, vkDateTime, vkTimezone,
     vkDuration, vkSet, vkHashMap:
    true
  of vkList: v.listImmutable
  of vkMap: v.mapImmutable
  of vkNode: v.nodeImmutable
  else: false

proc frozenGraphProofs*(v: Value): uint8 =
  ## A stronger, predicate-specific certificate than deepFrozen. Plain lists
  ## and property maps compose it once, during construction. There is no lazy
  ## write to a published object, global memo table, or caller-dependent cache.
  ## Nodes are deliberately not admitted: even structurally frozen nodes may
  ## acquire runtime error evidence. Types and all scope/resource-bearing
  ## values also keep their full checks. An ancestor containing any such value
  ## receives no certificate; eligible children can still be skipped locally.
  case v.kind
  of vkNil, vkVoid, vkBool, vkInt, vkFloat, vkString, vkBytes, vkChar, vkSymbol:
    FrozenPlainDataProofs
  of vkList:
    cast[ptr GeneList](v.bits and PAYLOAD_MASK).frozenGraphProofs
  of vkMap:
    cast[ptr GeneMap](v.bits and PAYLOAD_MASK).frozenGraphProofs
  else:
    0'u8

proc isDeepFrozen*(v: Value): bool =
  ## "Nothing reachable from here can change" — the answer `event/Bus publish`
  ## needs to skip a redundant freeze traversal (docs/stdlib.md).
  ##
  ## Distinct from `isImmutable`, which `freeze_shallow` can set on a container
  ## whose children are untouched. Only the deep `freeze` builder and a
  ## construction path that assembles from already-deep-frozen parts may set the
  ## bit, so a true answer composes by construction rather than by re-derivation.
  ##
  ## **It is O(1) on the node/list/map spine, and not on `Set`/`HashMap`.**
  ## §17.3 asks for O(1); those two kinds carry no deep bit of their own —
  ## `freeze` rebuilds them through `buildSet`/`buildHashMap`, which take no
  ## flag — so they are walked. The walk terminates fast in practice because
  ## set elements and hash-map keys must be hash-stable, which already excludes
  ## most deep structure, but an event whose payload is a large set pays a scan
  ## per publish rather than a bit read. Closing the gap means threading the
  ## flag through both builders.
  case v.kind
  of vkNil, vkVoid, vkBool, vkInt, vkFloat, vkString, vkBytes, vkRegex,
     vkRange, vkDate, vkTime, vkDateTime, vkTimezone, vkDuration, vkChar,
     vkSymbol, vkLogger, vkType, vkProtocol, vkProtocolMessage, vkEnumVariant,
     vkEventMatcher:
    # Scalars and the immutable object kinds `freeze` returns unchanged.
    true
  of vkList:
    cast[ptr GeneList](v.bits and PAYLOAD_MASK).deepFrozen
  of vkMap:
    cast[ptr GeneMap](v.bits and PAYLOAD_MASK).deepFrozen
  of vkNode:
    cast[ptr GeneNode](v.bits and PAYLOAD_MASK).deepFrozen
  of vkSet:
    for item in v.setItems:
      if not item.isDeepFrozen:
        return false
    true
  of vkHashMap:
    for entry in v.hashMapEntries:
      if not entry.key.isDeepFrozen or not entry.val.isDeepFrozen:
        return false
    true
  else:
    false
