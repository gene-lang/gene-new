## Gene Intermediate Representation for the MVP bytecode VM.
##
## GIR is intentionally small here: stack bytecode plus nested compiled function
## prototypes. It is the handoff boundary between syntax compilation and runtime
## execution.

import std/[math, os, sets, strutils, tables]
import ./[printer, types]

const
  MaxInferredReturnDepth* = 8
  PipelineTargetName* = "\x00gene_prepared_target"
  PipelineMessageName* = "\x00gene_prepared_message"
  PipelineArgumentsName* = "\x00gene_prepared_arguments"
  PipelineItemName* = "\x00gene_prepared_item"
  BlockBindingPrefix* = "\x00gene_block:"
  MaxCaptureLevels* = 8 # activation levels a closure copies from (CapturePlan)

type
  OpCode* = enum
    opNoop
    opPushConst
    opLoadName
    opLoadNativeFast
    opLoadLocal
    opLoadLocalFast
    opLoadArg      # scopeless calls: push stack[curStackBase + intArg]
    opLoadOuterLocal
    opDefineName
    opDefineLocal
    # Loop-body variants of the two defines. A `var` inside a loop body is one
    # declaration executed many times, not many declarations — so it overwrites
    # its binding instead of tripping the duplicate check. The compiler picks
    # these purely from `loopDepth`, so behaviour outside a loop is unchanged
    # and legal branch shadowing — `(if c (var x 1) (var x 2))` — still works.
    opRedefineName
    opRedefineLocal
    opSetName
    opSetLocal
    opSetOuterLocal
    opRefBegin          # mark a predeclared module reference resolving
    opRefFinish         # pop target, resolve and patch structural fixups
    opRefAbort          # reset a still-resolving entry from an ensure body
    opRefGet            # runtime $deref: resolved target or typed error
    opRefGetStructural  # reader #Deref: resolved target or internal fixup
    opPop
    opMakeList
    opMakeListSplice
    opMakeMap
    opMakeHashMap
    opMakeNode
    opMakePipeline
    opMakeSelector
    opApplySelector
    opApplySelectorTop
    opMakeFn
    opMakeNamespace
    opSetModuleName
    opMakeEnv
    opEval
    opMakeType
    opMakeAlias        # pop a type expr, push a transparent alias named `name`
    opMakeEnum
    opWebModule        # compile the embedded web block, push its asset value
    opMakeProtocol
    opMakeImpl
    opImport
    opImportImpl
    opCall0
    opCall1
    opCallName0
    opCallName1
    opCallNameN
    opCallLocal0
    opCallParentLocal0
    opCallOuterLocal0
    opCallLocal1
    opCallParentLocal1
    opCallOuterLocal1
    opCallLocalN
    opRecur1
    opRecur1LocalIntSubConst
    opRecur1LocalIntSubImm
    opRecur1LocalIntSubConstSameScope
    opRecur1LocalIntSubImmSameScope
    opReturnLocalIfIntLtConst
    opReturnLocalIfIntLtImm
    opCall2
    opCall
    opCallSplice
    opNew            # constructor keyword: type + named args + body args
    opResolveMessage  # pop receiver, resolve message name receiver-first, push callee below named args + receiver (docs/spec/protocols.md)
    opSuperSend       # pop enclosing type + self; resolve msg from the type's parent, push callee + self (super delegation, design §10)
    opSuperQualifiedSend # like opSuperSend, but pops a qualifier too: (super .Q:m) selects against the parent, not the receiver
    opSetPath         # [base, seg..., value] -> checked in-place write through setMutableChild; pushes the stored value (set, design §12.1)
    opPlaceSendReceiver # move receiver below newly evaluated named args
    opIntAdd2
    opReturnIntAdd2
    opIntSub2
    opIntMul2
    opIntLt2
    opIntGt2
    opIntLe2
    opIntGe2
    opIntAddConst
    opIntSubConst
    opIntMulConst
    opIntLtConst
    opIntGtConst
    opIntLeConst
    opIntGeConst
    opIntFast2
    opIntFastConst
    opNativeFast2
    opNativeFastConst
    opMatch           # pop target, run the first matching branch in a child scope
    opMatchBind       # pop target, destructure against a pattern (or MatchError)
    opMatchBindReplace # pop target, destructure and replace existing loop binds
    opForEach         # pop a collection, run a for-loop body per item
    opMakeIterator    # pop an iterable value, push a stream iterator
    opIteratorHasNext # pop a stream iterator, push Bool
    opIteratorNext    # pop a stream iterator, push next item
    opIteratorClose   # pop a stream iterator and close it
    opLoopBreak       # exit the nearest active loop
    opLoopContinue    # skip to the next iteration of the nearest active loop
    opTry             # run a body with catch clauses and an ensure block
    opTaskScope       # run a structured task scope body
    opSupervisor      # run a supervised actor-owner body
    opSpawn           # run a child task body and push a Task handle
    opAwait           # pop a Task and push/rethrow its completed result
    opFail            # pop an Error value and raise it through GeneError
    opPanic           # pop a value and raise it through GenePanic
    opYield           # suspend a generator and expose the stack top as item
    opExplicitReturn  # leave the nearest function, unwinding structured cleanup
    opJumpIfFalse
    opJumpIfFalseOrPop # falsy top: jump keeping the value; truthy: pop it (&&)
    opJumpIfTrueOrPop  # truthy top: jump keeping the value; falsy: pop it (||)
    opJumpIfPresentOrPop # present top (not nil/void): jump keeping it; absent: pop (??)
    opJumpIfAbsent     # absent top (nil/void): jump keeping it; present: fall through
                       # keeping it too — the receiver is still needed (?~)
                       # flag=true tests only void (path traversal)
    opNot              # replace the top with the Bool inverse of its truthiness
    opJump
    opReturn
    opReturnBareInt
    opCheckType
    opDeclareType
    opSyntaxCall  # pop raw call node + fexpr callee, apply the syntax call (design §3/§11.1)
    opDefineRuntimeMacro # store a definition-side closure in an activation's private slot
    opInvokeRuntimeMacro # match raw syntax arguments and call that ordinary closure
    opExecuteRuntimeMacro # compile/enter returned syntax; flag: normalize pipeline operand only
    opRuntimePipelineStage # execute direct macro operands before classifying slots
    opRejectSyntaxSend # reject an fexpr at a .send before evaluating send arguments
    opResolveQualifiedMessage # pop receiver + message value; resolve the impl, push callee + receiver
    opQualifiedSend # pop receiver + protocol (`P` of `P:msg`); dispatch `name` on the receiver
    opBindMessage # pop qualifier; push a message value bound to the current scope
    opPreparePipelineCall # snapshot fixed components and expanded call layout
    opCallPrepared        # invoke a prepared layout with the current item
    opMakePipelineStream  # normal conversion followed by a lazy mapping adapter
    opCheckCallableArguments # checked view payload -> target, prepared args, slot
    opCheckCallableResult    # result + checked view payload -> checked result
    opBlockScope             # lexical block; caller control-flow targets survive
    opLoopEnter              # record inline loop exit/continue targets and operand base
    opLoopLeave              # retire the inline loop target
    opLoadStdlibPath          # constant Path from gene; depth indexes extra cache slots

  Instruction* = object
    op*: OpCode
    intArg*: int
    depth*: int
    name*: string
    names*: seq[string]
    flag*: bool
    tail*: bool

  ParamDefault* = object
    optional*: bool
    defaultChunk*: Chunk

  NativeCompileOp* = enum
    ncoNone
    ncoIntIdentity
    ncoIntAdd
    ncoIntSub
    ncoIntMul
    ncoI64Identity
    ncoI64Add
    ncoI64Sub
    ncoI64Mul
    ncoF64Identity
    ncoF64Add
    ncoF64Sub
    ncoF64Mul

  AotFrameKind* = enum
    afkNone
    afkTypedNative

  AotReprKind* = enum
    arkNone
    arkI64
    arkI32
      ## A *boundary* representation, not an arithmetic one. Gene's `I32` is a
      ## range-checked Int: interpreted code rejects a return that leaves the
      ## 32-bit range, while C `int32_t` arithmetic would wrap silently. Values
      ## of this repr therefore only cross edges — parameter, result, native
      ## field, FFI argument — and widen to `arkI64` to be computed with, so
      ## compiled and interpreted code cannot disagree.
    arkCStr
      ## `const char *`, borrowed for the call's extent. Like `arkI32` this is
      ## a boundary representation: it crosses edges and is passed on, but it
      ## is never computed with, and a Gene `Str` argument owns the storage it
      ## points at (proposal §6.3.2).
    arkF64
    arkNativePtr

  AotRepr* = object
    ## Resolved machine representation for one typed-native function edge.
    ## Native pointers retain their nominal Type and concrete ABI layout so C
    ## emission never needs to recover either from a runtime binding.
    kind*: AotReprKind
    typeName*: string
    nullable*: bool
    nativeType*: NativeTypeProto

  AotLocal* = object
    ## One statically represented local in a typed-native function. The source
    ## initializer remains in `aotExpr`; this table is the compiler's proof of
    ## the local's machine representation for validation and C emission.
    name*: string
    repr*: AotRepr
    mutable*: bool
    outOfScope*: bool
      ## Set when analysis leaves the block that declared this local. The entry
      ## stays for C emission, which needs every local's representation, but
      ## name resolution stops seeing it — matching the C block the emitter
      ## produces. Names are unique per function, so emission can still look up
      ## by name unambiguously.

  NativeOwnership* = enum
    noNone
    noBorrow
    noTransfer
    noCopy

  NativeEntryProto* = object
    ## Explicit dynamic entry for one typed-native function. Pointer edges have
    ## an ownership policy; scalar edges use the ordinary generated FFI value
    ## adapters and therefore stay `noNone` here.
    enabled*: bool
    paramOwnership*: seq[NativeOwnership]
    resultOwnership*: NativeOwnership
    resultBorrowParam*: int

  TaskFrameKind* = enum
    tfkNone
    tfkVm
    tfkGenerator

  NamedParam* = object
    arg*: string
    local*: string
    typeExpr*: Value
    defaultValue*: ParamDefault

  ErrorCheckMode* = enum
    ecmDynamic
    ecmWarn
    ecmStrict

  ErrorTypeSummary* = object
    ## Source declaration identity, not a printed nominal name. Runtime proof
    ## admission additionally resolves expr in the owning declaration scope.
    identity*: string
    name*: string
    expr*: Value
    ancestors*: seq[string]

  ErrorEffectSummary* = object
    open*: bool
    named*: seq[ErrorTypeSummary]

  ErrorOrigin* = object
    declaration*: string
    callee*: string
    loc*: SourceLoc

  ErrorProofDependency* = object
    target*: Value
    nativeMetadata*: NativeErrorMetadata
    returnDepth*: int # zero: invocation; positive: result after this many calls
    returnKind*: string # callable, task, or stream when consuming an inferred result
    returnKindOnly*: bool # classification is needed, but deferred errors are not consumed
    returnTaskFresh*: bool
    returnTaskIsolated*: bool
    returnNativeMetadata*: NativeErrorMetadata
    returnTypeIdentity*: string
    returnTypeContract*: string
    returnMessageIdentity*: string
    typeIdentityOnly*: bool
    constructorCall*: bool
    messageName*: string
    typeDepth*: int # nominal parent steps from target to the declaring type
    producer*: string
    permitted*: ErrorEffectSummary
    loc*: SourceLoc

  ErrorReturnContract* = object
    kind*: string
    errorsKnown*: bool
    errors*: ErrorEffectSummary
    valueType*: Value
    nativeMetadata*: NativeErrorMetadata
    typeIdentity*: string
    typeContract*: string
    messageIdentity*: string
    taskFresh*: bool
    taskIsolated*: bool

  CallableErrorSummary* = ref object
    name*: string
    identity*: string
    version*: string
    declared*: bool
    declaredRow*: ErrorEffectSummary
    inferredRow*: ErrorEffectSummary
    producerRow*: ErrorEffectSummary
    resultType*: Value
    inferredResultType*: Value
    receiverType*: ErrorTypeSummary # declaring Self binding for concrete methods/ctors
    resultKind*: string
    resultErrorsKnown*: bool
    resultErrors*: ErrorEffectSummary
    returnContracts*: seq[ErrorReturnContract] # bounded, acyclic chain of returned callables/values
    origins*: seq[ErrorOrigin]
    dependencies*: seq[ErrorProofDependency]

  CapturePlan* = ref object
    ## How a closure created inside function, loop, match, or catch
    ## activations copies the values it reads instead of holding those
    ## activation scopes (docs/proposals/vm-reliability.md, VM-2). Level 1 is
    ## the scope the closure is created in; levels 1..activationLevels are
    ## activations and the next one is static (module, program, namespace).
    activationLevels*: int
    mirrorLevels*: int          # levels 1..mirrorLevels get a copy
    keepDepth*: bool            # a static level is addressed by depth
    slots*: seq[seq[int]]       # captured slots per mirrored level
    names*: seq[seq[string]]    # their names
    slotNames*: seq[seq[string]] # per level, indexed by slot; empty unless a
                                 # capture is read by name

  FunctionProto* {.acyclic.} = ref object of FunctionCode
    name*: string
    capturePlan*: CapturePlan # nil: the closure holds its defining scope
    sourceLoc*: SourceLoc
    receiverSelfAnnotation*: bool # retain legacy [self : Self] provenance
    signatureErrorExprs*: seq[Value]
    annotationSelfBits*: uint64 # runtime-only borrowed declaring type identity
    contractResolved*: bool
    signatureHadSelf*: bool # provenance survives closing and recomposition
    typeParams*: seq[string]
    localNames*: seq[string]
    positionalSlots*: seq[int]
    positionalSlotMaySet*: seq[bool]
    positionalParamsMaySet*: bool
    namedSlots*: seq[int]
    restSlot*: int
    params*: seq[string]
    requiredPositional*: int
    simpleCall*: bool
    needsCallScope*: bool
    poolCallScope*: bool
    callScopeNeedsSlotNames*: bool
    callScopeNeedsSlotReset*: bool
    paramTypes*: seq[Value]
    hasParamTypes*: bool
    paramDefaults*: seq[ParamDefault]
    restParam*: string
    restType*: Value        # `xs... : T` element type; NIL for an untyped rest
    namedParams*: seq[NamedParam]
    hasNamedParamTypes*: bool
    returnType*: Value
    hasReturnType*: bool
    returnKnownBareInt*: bool
    returnBoundaryRedundant*: bool
    frameNeedsImplValidation*: bool
    fastBindUnaryInt*: bool
    fastBindPositionalInt*: bool
    fastBindRequiredNamed*: bool
    isGenerator*: bool
    isSyntaxFn*: bool
    isMacroBody*: bool # keep the complete live definition environment
    preparedPipelineItem*: bool
    fastBindPositionalScalars*: bool # use trailing flag padding; preserve existing hot offsets
    selfParentSlot*: int
    nativeOp*: NativeCompileOp
    nativeParamIndex*: int
    aotExpr*: Value
    aotParamReprs*: seq[AotRepr]
    aotLocals*: seq[AotLocal]
    aotReturnRepr*: AotRepr
    nativeEntry*: NativeEntryProto
    aotFrameKind*: AotFrameKind
    aotFrameCanSuspend*: bool
    taskFrameKind*: TaskFrameKind
    checksErrors*: bool
    builtinErrorMessage*: bool # private origin of Error's default backing-field accessor
    errorsMode*: ErrorCheckMode
    errorSummary*: CallableErrorSummary
    publicErrorInterface*: bool
    errorTypeCount*: int
    boundExecutionPolicy*: ModuleExecutionPolicy
    declMetaKeys*: seq[string]   # @key value meta on the (fn ...) node,
    declMetaValues*: seq[Value]  #   surfaced on Module/declarations records
    chunk*: Chunk
    scopelessChunk*: Chunk       # opLoadArg rewrite of chunk for leaf
                                 # param-only bodies, or nil (see
                                 # deriveScopelessChunk)
    scopelessNeedsIntArgs*: bool # typed admission: every arg must be vkInt;
                                 # VM sites verify (or trust inst.flag) before
                                 # entering scopelessChunk, else classic path

  ImportSelection* = object
    name*: string         # exported name in the source
    local*: string        # local name to bind (== name unless aliased)

  MacroDefault* = object
    optional*: bool
    hasExpr*: bool
    defaultExpr*: Value

  MacroParam* = object
    pattern*: Value
    defaultValue*: MacroDefault

  MacroNamedParam* = object
    arg*: string
    pattern*: Value
    defaultValue*: MacroDefault

  MacroDef* = ref object
    ## Portable compile-time data carried by library artifacts. Macros are
    ## reader values, not executable host closures, so their definitions can
    ## cross an artifact boundary deterministically.
    params*: seq[MacroParam]
    named*: seq[MacroNamedParam]
    rest*: string
    body*: seq[Value]
    name*: string
    sourceLoc*: SourceLoc
    context*: MacroDefinitionContext
    namespacePath*: seq[string]
    lexicalMacros*: Table[string, MacroDef]
    runtime*: bool
    runtimeParamNames*: seq[string]

  MacroDefinitionContext* = ref object
    ## Source and dependency identity for definition-side execution. Runtime
    ## instances belong to a compilation session, never this portable definition.
    sourceName*: string
    moduleIdentity*: string
    moduleSourcePath*: string # package-relative file path, including extension
    forms*: seq[Value]
    locs*: Table[uint64, SourceLoc]
    importedMacros*: Table[string, Table[string, MacroDef]]
    importedSyntaxFns*: Table[string, seq[string]]
    importedInterfaces*: Table[string, CompileNamespaceInterface]

  MacroBindings* = ref object of RootObj
    definitions*: Table[string, MacroDef]
    hiddenNames*: seq[string]
    exportedNames*: seq[string]
    ownedNames*: seq[string]
    history*: seq[Value] # successful REPL source, for definition-side execution
    capturedDefinitions*: seq[MacroDef] # aligned with Env's owned macro closures

  CompilerPreparationCache* = ref object
    ## Owner-local derived compiler data; excluded from portable artifacts.
    state*: RootRef

  RuntimeExpansionContext* = object
    compilerPreparation*: CompilerPreparationCache
    macros*: MacroBindings
    sourceContext*: MacroDefinitionContext
    sourceLoc*: SourceLoc
    namespacePath*: seq[string]
    letNames*: seq[string]
    inFunction*, inGenerator*, inStatementFn*, selfAvailable*: bool
    loopDepth*: int
    allowAmbientImports*: bool

  RuntimeMacroDefinition* = object
    definition*: MacroDef
    slot*: int

  RuntimeMacroCall* = object
    definition*: MacroDef
    syntax*: Value
    context*: RuntimeExpansionContext
    pipeline*: bool

  CompileBindingCategory* = enum
    cbcValue
    cbcMacro
    cbcSyntaxFn
    cbcType
    cbcProtocol
    cbcNamespace

  CompileImplInterface* = object
    protocolIdentity*: string
    receiverIdentity*: string

  CompileNamespaceInterface* = ref object
    ## Static, guaranteed exports for one module/namespace scope. Interfaces
    ## are compiler input: runtime-only/conditional declarations never enter
    ## this tree.
    entries*: Table[string, CompileInterfaceEntry]
    initializationErrorsKnown*: bool
    initializationErrors*: ErrorEffectSummary
    errorSummaryVersion*: string
    exportedImplsKnown*: bool
    exportedImpls*: seq[CompileImplInterface]

  CompileInterfaceEntry* = object
    category*: CompileBindingCategory
    namespace*: CompileNamespaceInterface
    protocolMessages*: seq[string]
    ffiStruct*: FfiStructProto
    nativeType*: NativeTypeProto
    nativeSpec*: Value
    ## The declaring `(type …)` form. `^native ^wrapper` is validated against
    ## `^repr` and `^props`, so the header path needs the whole declaration to
    ## apply the same rules the compiler does.
    typeForm*: Value
    callableErrors*: CallableErrorSummary
    constructorErrors*: CallableErrorSummary
    messageErrorsKnown*: bool
    messageErrors*: Table[string, CallableErrorSummary]
    protocolMessageErrors*: seq[CallableErrorSummary] # full identity closure, including shadowed names
    errorType*: ErrorTypeSummary

  ImportSpec* = object
    fromModule*: bool                 # true: `^from "path"`; false: namespace path
    modulePath*: string               # the `^from "path"` string
    pkgName*: string                  # `^pkg "owner/name"`, or "" for the
                                      # importing module's own package
    nsSegments*: seq[string]          # namespace-path segments (e.g. std/stream)
    alias*: string                    # `* : alias` / `source : alias`, or ""
    wildcard*: bool                   # bare/aliased `*` or `n/*`
    wildcardSegments*: seq[string]    # namespace subtree inside a file module
    wildcardNames*: seq[string]       # guaranteed runtime exports in that subtree
    sourceLabel*: string              # stable diagnostic label for fallback entries
    reexport*: bool                   # selected/alias binding is intentionally public
    selections*: seq[ImportSelection]

  ImportImplSpec* = object
    modulePath*: string

  DispatchCacheEntry* = object
    ## Per-call-site inline cache for protocol-message dispatch (design §10).
    ## Side storage keyed by the send instruction's index in the
    ## chunk — never a field on `Instruction`, which is bench-frozen at 64
    ## bytes. All fields are plain integers: the cache holds NO owning Value
    ## ref (that would risk an `{.acyclic.}`-Chunk retain cycle through a
    ## recursive impl), so a hit re-materializes an owned callee from
    ## `calleeBits` via `ownedValueFromBits`. `recvTypeBits == 0` marks an
    ## empty slot (a real type Value is never 0/nil). Guard = receiver type
    ## identity + message identity (0 for name-fixed unqualified sends) +
    ## the VM's dispatch epoch; every impl mutation and every released
    ## generation retirement moves it, so any change to the visible impl set,
    ## or a freed receiver Type whose address may be reused, invalidates every
    ## entry.
    recvTypeBits*: uint64
    msgBits*: uint64
    epoch*: uint64
    calleeBits*: uint64

  CompileDiagnostic* = object
    message*: string
    loc*: SourceLoc

  FfiParam* = object
    name*: string
    typeExpr*: Value
    isOut*: bool
      ## Marked by `^out`. Metadata only: `typeExpr` stays the ordinary value
      ## type, and this is what adds one indirection to the emitted
      ## declaration and makes the call site pass an address.

  FfiLibraryProto* = ref object
    name*: string
    linux*: string
    macos*: string
    windows*: string

  FfiFnProto* = ref object
    name*: string
    library*: string
    libraryDeclared*: bool
    symbol*: string
    abi*: string
    calling*: string
    params*: seq[FfiParam]
    paramReprs*: seq[AotRepr]
    returnType*: Value
    returnRepr*: AotRepr
    release*: string

  FfiStructField* = object
    ## `typeExpr` is raw source syntax and means whatever it means *where it was
    ## written*. Re-resolving it in a consuming module let an imported
    ## `Node? next` bind to whatever `Node` the consumer happened to declare, so
    ## the pointee is resolved once, in the declaring module, and recorded here.
    ##
    ## Both identities are needed and neither implies the other: the nominal one
    ## types the pointer for later loads and stores, the ABI one names the
    ## layout and drives C emission. A pointee that is an ordinary C type
    ## (`C/Void`, `C/Char`) or an opaque foreign tag resolves to neither, which
    ## is not an error — those are legitimate and stay as they are.
    name*: string
    typeExpr*: Value
    pointeeTypeIdentity*: string
    pointeeAbiIdentity*: string
    offset*: int
    hasOffset*: bool

  FfiStructProto* = ref object
    name*: string
    identity*: string
    layout*: string
    size*: int
    hasSize*: bool
    align*: int
    hasAlign*: bool
    fields*: seq[FfiStructField]
    fingerprint*: string
      ## Hash of the declared layout descriptor. Type identity implies the ABI
      ## within one build but not across one: a library built before a layout
      ## change carries the same identity and reads obsolete offsets.

  NativeTypeProto* = ref object
    ## Compile-only attachment from a nominal Gene Type to one foreign layout.
    ## `identity` and `abiIdentity` are stable module-qualified dependency keys;
    ## no runtime namespace lookup participates in typed-native lowering.
    name*: string
    identity*: string
    abiIdentity*: string
    abi*: FfiStructProto
    lifecycle*: string
    mutable*: bool
    wrapperField*: string
    wrapperFieldSchema*: string
      ## Canonical label of the declared handle prop — `(C/OwnedPtr CPoint)`.
      ## Changing its ownership flavor changes what a transfer or copy is valid
      ## under, and no layout hash can see that.
    releaseSymbol*: string
    copySymbol*: string
    abiFingerprint*: string
    contractFingerprint*: string
      ## Hash of the *complete* code-generation contract, nesting
      ## `abiFingerprint`. Compiled code bakes in more than the layout:
      ## `copySymbol` and `releaseSymbol` become call targets, `wrapperField`
      ## becomes a string literal at every boundary helper, `mutable` decides
      ## whether a field store lowers at all, and the handle schema decides what
      ## an ownership transfer means. An entry compiled against `^copy old_copy`
      ## would otherwise keep applying it after the live Type was re-registered
      ## with `^copy new_copy` — same ABI, same layout, no signal.

  FfiUnionProto* = ref object
    name*: string
    layout*: string
    size*: int
    hasSize*: bool
    align*: int
    hasAlign*: bool
    fields*: seq[FfiStructField]

  FfiSignatureKind* = enum
    fskCallback
    fskDynamic

  FfiSignatureProto* = ref object
    name*: string
    kind*: FfiSignatureKind
    abi*: string
    params*: seq[FfiParam]
    returnType*: Value
    escaping*: bool
    runtimeConstructible*: bool

  MonomorphizationSpec* = object
    functionName*: string
    typeArgs*: seq[Value]

  DirectProtocolCallSpec* = object
    messageName*: string
    protocolExpr*: Value
    receiverExpr*: Value

  ForProto* = ref object
    pattern*: Value              # loop-variable pattern
    body*: Chunk                 # loop body
    reuseScope*: bool            # body cannot retain its iteration scope

  MatchClause* = object
    pattern*: Value
    body*: Chunk

  MatchProto* = ref object
    clauses*: seq[MatchClause]
    elseBody*: Chunk             # nil when there is no else branch
    tailResult*: bool            # selected arm result is the callable's result

  CatchClause* = object
    errorType*: Value            # source-level type following `catch`
    pattern*: Value              # internal typed `$err` binding pattern
    body*: Chunk

  TryProto* = ref object
    body*: Chunk
    catches*: seq[CatchClause]
    ensureBody*: Chunk           # nil when there is no `ensure`

  NodeBuildProto* = object
    metaNames*: seq[string]
    propNames*: seq[string]
    bodyCount*: int
    bodySplices*: seq[bool]
    immutable*: bool

  PipelineStageBuildProto* = object
    kind*: PipelineStageKind
    metaNames*: seq[string]
    propNames*: seq[string]
    bodyCount*: int
    sourceLoc*: SourceLoc
    slot*: PipelineSlot

  PipelineBuildProto* = object
    stages*: seq[PipelineStageBuildProto]
    immutable*: bool

  PipelineCallProto* = object
    ## The ordinary invocation entry point lives in functions[functionIndex].
    ## Preparation consumes target, descriptor, named values, and body parts.
    functionIndex*: int
    namedNames*: seq[string]
    bodySplices*: seq[bool]
    bodySlot*: int
    namedSlot*: int

  ListBuildProto* = object
    splices*: seq[bool]
    immutable*: bool

  TypeProto* = ref object
    name*: string
    staticTopLevel*: bool
    repr*: TypeRepr              # `^repr native_wrapper`, or ordinary
    nativeType*: NativeTypeProto # `^native {...}`, compile metadata only
    fields*: seq[TypeField]      # own (non-inherited) field schema
    bodyFields*: seq[TypeBodyField] # own (non-inherited) body schema
    requiredImplCount*: int
    deriveProtocolCount*: int
    deriveRequests*: seq[Value]
    messages*: seq[ImplMessageProto] # type-direct messages (docs/spec/protocols.md)
    inlineImpls*: seq[InlineImplProto] # (impl P ...) body items (docs/spec/protocols.md)
    ctorFn*: FunctionProto       # (ctor ...) body item, or nil (design §7.1.1)

  EnumVariantProto* = object
    name*: string
    payloadTypes*: seq[Value]
    hasBacking*: bool
    backing*: Value

  EnumProto* = ref object
    name*: string
    staticTopLevel*: bool
    typeParams*: seq[string]
    backingType*: Value
    variants*: seq[EnumVariantProto]
    messages*: seq[ImplMessageProto]
    inlineImpls*: seq[InlineImplProto]

  ProtocolProto* = ref object
    name*: string
    messages*: seq[ProtocolMessageProto]
    deriveFn*: FunctionProto
    parentCount*: int
    universal*: bool

  ProtocolMessageProto* = object
    name*: string
    fn*: FunctionProto       # declaration signature and optional default body
    hasDefault*: bool

  ImplMessageProto* = object
    name*: string
    declaresOverride*: bool # type-direct messages only
    protocolPath*: seq[string] # qualifier for (message A/do_x ...) or
                               # (message p/A/do_x ...); empty = unqualified
    fn*: FunctionProto

  ImplProto* = ref object
    protocolExpr*: Value
    receiverExpr*: Value
    messages*: seq[ImplMessageProto]
    staticTopLevel*: bool
    staticOperands*: bool
    exported*: bool

    inheritBodies*: bool
    loc*: SourceLoc

  ## An (impl P (message ...) ...) block inside a type body; the receiver is
  ## the enclosing type (docs/spec/protocols.md). The protocol expression is compiled
  ## onto the stack alongside the message error rows.
  InlineImplProto* = object
    messages*: seq[ImplMessageProto]
    inheritBodies*: bool
    protocolExpr*: Value
    loc*: SourceLoc

  ## One `(web_module name ...)` block, captured verbatim by the compiler and
  ## compiled to a web asset by the runtime while its containing module loads.
  ## The forms are the *original* trees, so their positions are the ones the
  ## author wrote — printing them back to text and re-reading would move every
  ## diagnostic, source-map entry, and conformance report off the real source.
  ## `source` is the block's own characters only (host lines blanked out), the
  ## single text a browser is ever allowed to see.
  WebModuleProto* = ref object
    name*: string
    identity*: string          # "<host module>#<name>", a stable devtools name
    forms*: seq[Value]         # the block body, minus the `web_module` header
    formLocs*: seq[SourceLoc]
    nestedLocs*: seq[tuple[bits: uint64, loc: SourceLoc]]
    source*: string
    loc*: SourceLoc

  TopLevelFormInfo* = object
    loc*: SourceLoc
    label*: string
    nodeLike*: bool

  # Chunks, protos, and their loop/match bodies form a strictly nested tree
  # built by the compiler and immutable at runtime: parent chunk → proto →
  # child chunk → …, with the only upward edge (Chunk.owner) already a
  # {.cursor.}. Compile-time Values reachable from here (constants, type
  # exprs, defaults, quoted forms) are reader data and cannot reference
  # code objects. {.acyclic.} matters for VM speed: the runLoop releases a
  # Chunk and a FunctionProto ref on every call/return, and without the
  # pragma each release-not-to-zero registers an ORC cycle candidate.
  Chunk* = ref ChunkObj
  ChunkObj* {.acyclic.} = object
    sourceName*: string
    errorsMode*: ErrorCheckMode
    initializationErrors*: ErrorEffectSummary
    errorSummaryVersion*: string
    errorProofDependencies*: seq[ErrorProofDependency]
    errorChecksComplete*: bool
    constants*: seq[Value]
    instructions*: seq[Instruction]
    instructionLocs*: seq[SourceLoc]
    topLevelForms*: seq[TopLevelFormInfo]
    owner* {.cursor.}: FunctionProto
    functions*: seq[FunctionProto]
    localNames*: seq[string]
    privateLocalSlots*: seq[int] # storage for confined inline macro-result locals
    mirrorSlots*: bool
    immutableBindings*: seq[string]
    moduleRefNames*: seq[string] # predeclared before source-unit execution
    exportExcludedNames*: seq[string] # ^private declarations and non-reexported imports
    subchunks*: seq[Chunk]       # bodies of `ns` declarations
    imports*: seq[ImportSpec]
    importImpls*: seq[ImportImplSpec]
    dispatchCache*: seq[DispatchCacheEntry] # inline send cache; lazily sized to instructions.len
    stdlibCacheSlots*: int # compiler-owned extra slots after instruction cache entries
    ## Runtime state, like dispatchCache: set once a spawn's publication walk
    ## has covered this chunk and found nothing below it that can change, so
    ## later spawns skip it. `spawnPublishedSuperBits` is the superType the
    ## walk saw; a chunk restamped with another type is walked again.
    spawnPublished*: bool
    spawnPublishedSuperBits*: uint64
    ## Run-time note for a `for` body, never stored: 0 = not yet classified,
    ## 1 = an iteration can only change its own slots, 2 = anything else.
    plainLoopBody*: int8
    diagnostics*: seq[CompileDiagnostic]
    forLoops*: seq[ForProto]
    matches*: seq[MatchProto]
    tries*: seq[TryProto]
    listBuilds*: seq[ListBuildProto]
    nodeBuilds*: seq[NodeBuildProto]
    pipelineBuilds*: seq[PipelineBuildProto]
    pipelineCalls*: seq[PipelineCallProto]
    typeProtos*: seq[TypeProto]
    enumProtos*: seq[EnumProto]
    webModules*: seq[WebModuleProto]
    protocolProtos*: seq[ProtocolProto]
    implProtos*: seq[ImplProto]
    ffiLibraries*: seq[FfiLibraryProto]
    ffiFns*: seq[FfiFnProto]
    ffiStructs*: seq[FfiStructProto]
    ffiStructDependencies*: seq[string] # imported layout identities
    ffiUnions*: seq[FfiUnionProto]
    ffiSignatures*: seq[FfiSignatureProto]
    monomorphizations*: seq[MonomorphizationSpec]
    directProtocolCalls*: seq[DirectProtocolCallSpec]
    callSites*: Table[int, Value]   # opCall/opCallSplice index -> source node (design §3 `Call ^site`)
    macroContexts*: seq[MacroBindings] # Env/fexpr sites capture lexical visibility
    runtimeMacroDefinitions*: seq[RuntimeMacroDefinition]
    runtimeMacroCalls*: seq[RuntimeMacroCall]
    runtimeMacroExpansion*: bool # code executing as part of an active expansion
    finalMacroContext*: MacroBindings # persistent top-level compiler state
    superType*: Value        # for a type-direct message body (and closures
                             # nested in it): the enclosing type's nominal parent,
                             # stamped in by opMakeType. `(super .m)` reads it
                             # here rather than resolving a user-visible name,
                             # so a body-local cannot redirect delegation. The
                             # one field written after compilation, and write-
                             # once: a second creation of the same declaration
                             # with a different parent copies the body instead
                             # of re-stamping it (`stampSuperType`), so a stamp
                             # never changes meaning under a running send.
    macroRuntimeLease*: RootRef # runtime-only; destroyed last by `=destroy` below

  CompiledModule* = object
    ## One portable module identity plus everything another package's compiler
    ## or runtime needs. Artifacts carry module bundles, never filesystem
    ## paths or a requirement to re-read dependency source.
    identity*: string
    sourcePath*: string      # normalized package-relative path; never an absolute host path
    chunk*: Chunk
    macroExports*: Table[string, MacroDef]
    syntaxFnExports*: seq[string]
    compileInterface*: CompileNamespaceInterface

  ExecutableGir* = object
    entryIdentity*: string
    modules*: seq[CompiledModule]

proc `=destroy`(chunk: var ChunkObj) =
  ## Release the macro runtime lease after every other field. Its destructor
  ## retires the definition phase only if no generated Value (for example a
  ## spliced function in `constants`) still references it. Nim's own field order
  ## is not stable across releases (2.2.12 destroys in reverse), so state it here.
  ## `owner` is a cursor and owns no reference.
  for name, field in fieldPairs(chunk):
    when name notin ["owner", "macroRuntimeLease"]:
      `=destroy`(field)
  `=destroy`(chunk.macroRuntimeLease)

type InstructionWithoutTail = object
  ## Target-relative layout baseline for the pre-TCO instruction shape.
  op: OpCode
  intArg: int
  depth: int
  name: string
  names: seq[string]
  flag: bool

static:
  doAssert sizeof(Instruction) == sizeof(InstructionWithoutTail),
    "Instruction.tail must fit existing target padding"

proc newChunk*(sourceName = ""): Chunk =
  Chunk(sourceName: sourceName, constants: @[], instructions: @[],
        instructionLocs: @[], topLevelForms: @[], functions: @[], subchunks: @[],
        moduleRefNames: @[],
        imports: @[], importImpls: @[],
        diagnostics: @[], forLoops: @[], matches: @[], tries: @[],
        listBuilds: @[],
        nodeBuilds: @[], pipelineBuilds: @[],
        typeProtos: @[], enumProtos: @[], protocolProtos: @[], implProtos: @[],
        ffiLibraries: @[], ffiFns: @[], ffiStructs: @[], ffiUnions: @[],
        ffiStructDependencies: @[],
        ffiSignatures: @[],
        monomorphizations: @[], directProtocolCalls: @[],
        callSites: initTable[int, Value]())

proc collectMacroValues[T](data: T, values: var seq[Value],
                           seen: var HashSet[pointer]) =
  ## Traverse compiler-owned metadata, stopping at Value edges. Consumers use
  ## their ordinary Value walkers for borrowed-authority checks/publication.
  when T is Value:
    values.add data
  elif T is Scope:
    discard # portable macro metadata never owns a live lexical frame
  elif T is ref:
    if data != nil and not seen.containsOrIncl(cast[pointer](data)):
      collectMacroValues(data[], values, seen)
  elif T is Table:
    for _, item in data: collectMacroValues(item, values, seen)
  elif T is seq or T is array:
    for item in data: collectMacroValues(item, values, seen)
  elif T is object or T is tuple:
    for name, field in fieldPairs(data):
      when name != "locs":
        collectMacroValues(field, values, seen)

proc macroContextValues*(context: RootRef,
                         seen: var HashSet[pointer]): seq[Value] =
  if context != nil and context of MacroBindings:
    collectMacroValues(MacroBindings(context), result, seen)

proc macroContextValues*(context: RootRef): seq[Value] =
  var seen: HashSet[pointer]
  macroContextValues(context, seen)

proc runtimeMacroValues*(chunk: Chunk, seen: var HashSet[pointer]): seq[Value] =
  collectMacroValues(chunk.runtimeMacroDefinitions, result, seen)
  collectMacroValues(chunk.runtimeMacroCalls, result, seen)

proc hasRuntimeMacroCalls*(root: Chunk): bool =
  ## A task snapshot must account for dynamic caller access inside functions
  ## constructed by the task as well as directly executed instructions.
  var seen = initHashSet[pointer]()
  proc visit(chunk: Chunk): bool
  proc visitFunction(fn: FunctionProto): bool =
    if fn == nil: return false
    if visit(fn.chunk): return true
    for value in fn.paramDefaults:
      if visit(value.defaultChunk): return true
    for parameter in fn.namedParams:
      if visit(parameter.defaultValue.defaultChunk): return true
  proc visit(chunk: Chunk): bool =
    if chunk == nil or seen.containsOrIncl(cast[pointer](chunk)): return false
    if chunk.runtimeMacroCalls.len > 0: return true
    for fn in chunk.functions:
      if visitFunction(fn): return true
    for body in chunk.subchunks:
      if visit(body): return true
    for loop in chunk.forLoops:
      if visit(loop.body): return true
    for branch in chunk.matches:
      for clause in branch.clauses:
        if visit(clause.body): return true
      if visit(branch.elseBody): return true
    for attempt in chunk.tries:
      if visit(attempt.body) or visit(attempt.ensureBody): return true
      for clause in attempt.catches:
        if visit(clause.body): return true
    template messages(entries: untyped) =
      for entry in entries:
        if visitFunction(entry.fn): return true
    for typ in chunk.typeProtos:
      if visitFunction(typ.ctorFn): return true
      messages(typ.messages)
      for implementation in typ.inlineImpls: messages(implementation.messages)
    for typ in chunk.enumProtos:
      messages(typ.messages)
      for implementation in typ.inlineImpls: messages(implementation.messages)
    for protocol in chunk.protocolProtos:
      if visitFunction(protocol.deriveFn): return true
      messages(protocol.messages)
    for implementation in chunk.implProtos: messages(implementation.messages)
  visit(root)

proc addListBuild*(chunk: Chunk, lp: ListBuildProto): int =
  result = chunk.listBuilds.len
  chunk.listBuilds.add lp

proc addNodeBuild*(chunk: Chunk, np: NodeBuildProto): int =
  result = chunk.nodeBuilds.len
  chunk.nodeBuilds.add np

proc addPipelineBuild*(chunk: Chunk, pp: PipelineBuildProto): int =
  result = chunk.pipelineBuilds.len
  chunk.pipelineBuilds.add pp

proc addType*(chunk: Chunk, tp: TypeProto): int =
  result = chunk.typeProtos.len
  chunk.typeProtos.add tp

proc addEnum*(chunk: Chunk, ep: EnumProto): int =
  result = chunk.enumProtos.len
  chunk.enumProtos.add ep

proc addWebModule*(chunk: Chunk, wp: WebModuleProto): int =
  result = chunk.webModules.len
  chunk.webModules.add wp

proc addProtocol*(chunk: Chunk, pp: ProtocolProto): int =
  result = chunk.protocolProtos.len
  chunk.protocolProtos.add pp

proc addImpl*(chunk: Chunk, ip: ImplProto): int =
  result = chunk.implProtos.len
  chunk.implProtos.add ip

proc addForLoop*(chunk: Chunk, fp: ForProto): int =
  result = chunk.forLoops.len
  chunk.forLoops.add fp

proc addMatch*(chunk: Chunk, mp: MatchProto): int =
  result = chunk.matches.len
  chunk.matches.add mp

proc addTry*(chunk: Chunk, tp: TryProto): int =
  result = chunk.tries.len
  chunk.tries.add tp

proc addSubchunk*(chunk: Chunk, body: Chunk): int =
  result = chunk.subchunks.len
  chunk.subchunks.add body

proc importKey*(pkgName, modulePath: string): string =
  ## The key a compile phase uses to remember one module dependency. `^pkg`
  ## participates, because the same module path in two different packages is
  ## two different modules — keying on the path alone would let one shadow the
  ## other's macros and compile interface.
  if pkgName.len == 0: modulePath
  else: pkgName & "\x00" & modulePath

proc importKey*(spec: ImportSpec): string =
  importKey(spec.pkgName, spec.modulePath)

proc addImport*(chunk: Chunk, spec: ImportSpec): int =
  result = chunk.imports.len
  chunk.imports.add spec

proc addImportImpl*(chunk: Chunk, spec: ImportImplSpec): int =
  result = chunk.importImpls.len
  chunk.importImpls.add spec

proc addFfiLibrary*(chunk: Chunk, library: FfiLibraryProto): int =
  result = chunk.ffiLibraries.len
  chunk.ffiLibraries.add library

proc addFfiFn*(chunk: Chunk, fn: FfiFnProto): int =
  result = chunk.ffiFns.len
  chunk.ffiFns.add fn

proc addFfiStruct*(chunk: Chunk, structProto: FfiStructProto): int =
  result = chunk.ffiStructs.len
  chunk.ffiStructs.add structProto

proc addFfiStructDependency*(chunk: Chunk, identity: string) =
  if identity.len > 0 and identity notin chunk.ffiStructDependencies:
    chunk.ffiStructDependencies.add identity

proc addFfiUnion*(chunk: Chunk, unionProto: FfiUnionProto): int =
  result = chunk.ffiUnions.len
  chunk.ffiUnions.add unionProto

proc addFfiSignature*(chunk: Chunk, signature: FfiSignatureProto): int =
  result = chunk.ffiSignatures.len
  chunk.ffiSignatures.add signature

proc addMonomorphization*(chunk: Chunk, spec: MonomorphizationSpec): int =
  result = chunk.monomorphizations.len
  chunk.monomorphizations.add spec

proc addDirectProtocolCall*(chunk: Chunk,
                            spec: DirectProtocolCallSpec): int =
  result = chunk.directProtocolCalls.len
  chunk.directProtocolCalls.add spec

proc addConst*(chunk: Chunk, value: Value): int =
  result = chunk.constants.len
  chunk.constants.add value

proc addFunction*(chunk: Chunk, fn: FunctionProto): int =
  result = chunk.functions.len
  chunk.functions.add fn

proc supportsScalarBinding*(proto: FunctionProto): bool =
  ## Compiler-owned admission for the positional scalar/Any binder. Runtime
  ## still checks each supplied value and falls back on mismatch. Keep this
  ## separate from simpleCall: its scopeless lowering has different proofs.
  if proto == nil or proto.isSyntaxFn or proto.isMacroBody or
      proto.isGenerator or proto.checksErrors or proto.typeParams.len != 0 or
      proto.restParam.len != 0 or proto.namedParams.len != 0 or
      proto.requiredPositional != proto.params.len or
      proto.positionalSlots.len != proto.params.len or
      proto.paramTypes.len != proto.params.len or
      proto.paramDefaults.len != proto.params.len or
      (not proto.hasParamTypes and not proto.hasReturnType):
    return false
  template admitted(annotation: Value): bool =
    annotation.kind == vkNil or
      (annotation.kind == vkSymbol and annotation.symVal in
        ["Any", "Int", "Integer", "Float", "F64", "Str", "String",
         "Bool", "Sym", "Symbol", "Char"])
  if not admitted(proto.returnType): return false
  for i, annotation in proto.paramTypes:
    if not admitted(annotation) or proto.paramDefaults[i].optional or
        proto.positionalSlots[i] < 0 or
        proto.positionalSlots[i] >= proto.localNames.len:
      return false
  true

proc emit*(chunk: Chunk, inst: Instruction,
           loc = SourceLoc()): int =
  result = chunk.instructions.len
  chunk.instructions.add inst
  chunk.instructionLocs.add loc

proc patchJump*(chunk: Chunk, at, target: int) =
  chunk.instructions[at].intArg = target

proc formatNames(names: openArray[string]): string =
  "[" & names.join(",") & "]"

proc formatNativeOp(op: NativeCompileOp): string =
  case op
  of ncoNone: "none"
  of ncoIntIdentity: "int_identity"
  of ncoIntAdd: "int_add"
  of ncoIntSub: "int_sub"
  of ncoIntMul: "int_mul"
  of ncoI64Identity: "i64_identity"
  of ncoI64Add: "i64_add"
  of ncoI64Sub: "i64_sub"
  of ncoI64Mul: "i64_mul"
  of ncoF64Identity: "f64_identity"
  of ncoF64Add: "f64_add"
  of ncoF64Sub: "f64_sub"
  of ncoF64Mul: "f64_mul"

proc formatAotFrameKind(kind: AotFrameKind): string =
  case kind
  of afkNone: "none"
  of afkTypedNative: "typed_native"

proc formatTaskFrameKind(kind: TaskFrameKind): string =
  case kind
  of tfkNone: "none"
  of tfkVm: "vm"
  of tfkGenerator: "generator"

proc formatFfiSignatureKind(kind: FfiSignatureKind): string =
  case kind
  of fskCallback: "callback"
  of fskDynamic: "dynamic"

proc formatAotRepr(fn: FunctionProto): string =
  case fn.aotReturnRepr.kind
  of arkI64: "I64"
  of arkI32: "I32"
  of arkCStr: "Str"
  of arkF64: "F64"
  of arkNativePtr: fn.aotReturnRepr.typeName
  of arkNone: ""

proc formatInstruction(inst: Instruction): string =
  result = $inst.op
  case inst.op
  of opPushConst:
    result.add " const=" & $inst.intArg
  of opLoadStdlibPath:
    result.add " const=" & $inst.intArg & " cache=" & $inst.depth
  of opLoadName, opLoadNativeFast, opDefineName, opRedefineName, opSetName,
     opRefBegin, opRefFinish, opRefAbort, opRefGet, opRefGetStructural:
    result.add " name=" & inst.name
  of opLoadLocal, opLoadLocalFast, opLoadArg, opDefineLocal, opRedefineLocal,
     opSetLocal:
    result.add " slot=" & $inst.intArg
    if inst.name.len > 0:
      result.add " name=" & inst.name
  of opLoadOuterLocal, opSetOuterLocal:
    result.add " depth=" & $inst.depth & " slot=" & $inst.intArg
    if inst.name.len > 0:
      result.add " name=" & inst.name
  of opMakeList:
    result.add " count=" & $inst.intArg
    if inst.flag: result.add " immutable=true"
  of opMakeListSplice:
    result.add " list=" & $inst.intArg
  of opMakeMap:
    result.add " count=" & $inst.intArg & " names=" & formatNames(inst.names)
    if inst.flag: result.add " immutable=true"
  of opMakeHashMap:
    result.add " count=" & $inst.intArg
  of opMakeNode:
    result.add " node=" & $inst.intArg
  of opMakePipeline:
    result.add " pipeline=" & $inst.intArg
  of opMakeSelector:
    result.add " count=" & $inst.intArg
  of opApplySelector:
    discard
  of opApplySelectorTop:
    discard
  of opMakeFn:
    result.add " fn=" & $inst.intArg
  of opMakeNamespace:
    result.add " ns=" & $inst.intArg & " name=" & inst.name
  of opSetModuleName:
    result.add " name=" & inst.name
  of opMakeEnv:
    discard
  of opEval:
    discard
  of opCheckType:
    result.add " type=" & $inst.intArg
    if inst.name.len > 0:
      result.add " name=" & inst.name
  of opDeclareType:
    result.add " type=" & $inst.intArg
    if inst.name.len > 0:
      result.add " name=" & inst.name
  of opMakeType:
    result.add " type=" & $inst.intArg
  of opMakeAlias:
    result.add " name=" & inst.name
  of opMakeEnum:
    result.add " enum=" & $inst.intArg
  of opWebModule:
    result.add " web_module=" & $inst.intArg
    if inst.name.len > 0:
      result.add " name=" & inst.name
  of opMakeProtocol:
    result.add " protocol=" & $inst.intArg
  of opMakeImpl:
    result.add " impl=" & $inst.intArg
  of opImport:
    result.add " import=" & $inst.intArg
  of opImportImpl:
    result.add " import_impl=" & $inst.intArg
  of opCall0:
    result.add " argc=0"
  of opCall1:
    result.add " argc=1"
  of opCallName0:
    result.add " name=" & inst.name & " argc=0"
  of opCallName1:
    result.add " name=" & inst.name & " argc=1"
  of opCallNameN:
    result.add " name=" & inst.name & " argc=" & $inst.depth
  of opCallLocal0:
    result.add " slot=" & $inst.intArg & " name=" & inst.name & " argc=0"
  of opCallParentLocal0:
    result.add " slot=" & $inst.intArg & " name=" & inst.name & " argc=0"
  of opCallOuterLocal0:
    result.add " depth=" & $inst.depth & " slot=" & $inst.intArg &
      " name=" & inst.name & " argc=0"
  of opCallLocal1:
    result.add " slot=" & $inst.intArg & " name=" & inst.name & " argc=1"
  of opCallParentLocal1:
    result.add " slot=" & $inst.intArg & " name=" & inst.name & " argc=1"
  of opCallOuterLocal1:
    result.add " depth=" & $inst.depth & " slot=" & $inst.intArg &
      " name=" & inst.name & " argc=1"
  of opCallLocalN:
    result.add " slot=" & $inst.intArg & " name=" & inst.name &
      " argc=" & $inst.depth
  of opRecur1:
    result.add " argc=1"
  of opRecur1LocalIntSubConst:
    result.add " slot=" & $inst.intArg & " name=" & inst.name &
      " const=" & $inst.depth & " argc=1"
  of opRecur1LocalIntSubImm:
    result.add " slot=" & $inst.intArg & " name=" & inst.name &
      " imm=" & $inst.depth & " argc=1"
  of opRecur1LocalIntSubConstSameScope:
    result.add " slot=" & $inst.intArg & " name=" & inst.name &
      " const=" & $inst.depth & " argc=1"
  of opRecur1LocalIntSubImmSameScope:
    result.add " slot=" & $inst.intArg & " name=" & inst.name &
      " imm=" & $inst.depth & " argc=1"
  of opReturnLocalIfIntLtConst:
    result.add " slot=" & $inst.intArg & " name=" & inst.name &
      " const=" & $inst.depth
  of opReturnLocalIfIntLtImm:
    result.add " slot=" & $inst.intArg & " name=" & inst.name &
      " imm=" & $inst.depth
  of opCall2:
    result.add " argc=2"
  of opCall:
    result.add " argc=" & $inst.intArg
    if inst.names.len > 0:
      result.add " names=" & formatNames(inst.names)
  of opCallSplice:
    result.add " list=" & $inst.intArg
    if inst.names.len > 0:
      result.add " names=" & formatNames(inst.names)
  of opPreparePipelineCall:
    result.add " plan=" & $inst.intArg
  of opCallPrepared:
    result.add " receiver=" & $inst.flag
  of opMakePipelineStream, opCheckCallableArguments, opCheckCallableResult:
    discard
  of opNew:
    if inst.flag:
      result.add " list=" & $inst.intArg
    else:
      result.add " argc=" & $inst.intArg
    if inst.names.len > 0:
      result.add " names=" & formatNames(inst.names)
  of opResolveMessage:
    result.add " name=" & inst.name & " candidates=" & $inst.depth
  of opSuperSend, opSuperQualifiedSend:
    result.add " name=" & inst.name
  of opSetPath:
    result.add " segments=" & $inst.intArg
  of opPlaceSendReceiver:
    result.add " named=" & $inst.intArg
  of opIntAdd2, opReturnIntAdd2, opIntSub2, opIntMul2, opIntLt2, opIntGt2,
     opIntLe2, opIntGe2, opIntFast2:
    result.add " name=" & inst.name
  of opIntAddConst, opIntSubConst, opIntMulConst, opIntLtConst,
     opIntGtConst, opIntLeConst, opIntGeConst, opIntFastConst:
    result.add " name=" & inst.name & " const=" & $inst.depth
  of opNativeFast2:
    result.add " name=" & inst.name
  of opNativeFastConst:
    result.add " name=" & inst.name & " const=" & $inst.depth
  of opMatch:
    result.add " match=" & $inst.intArg
  of opMatchBind, opMatchBindReplace:
    result.add " pattern=" & $inst.intArg
  of opForEach:
    result.add " for=" & $inst.intArg
  of opTry:
    result.add " try=" & $inst.intArg
  of opTaskScope, opBlockScope:
    result.add " body=" & $inst.intArg
  of opLoopEnter:
    result.add " break=" & $inst.intArg & " continue=" & $inst.depth
  of opSpawn:
    result.add " body=" & $inst.intArg
    if inst.flag:
      result.add " worker-candidate=true"
  of opSupervisor:
    result.add " body=" & $inst.intArg & " strategy=" & inst.name
    if inst.names.len > 0:
      result.add " sinks=" & formatNames(inst.names)
  of opFail, opPanic:
    discard
  of opJumpIfFalse, opJumpIfFalseOrPop, opJumpIfTrueOrPop,
     opJumpIfPresentOrPop, opJumpIfAbsent, opJump:
    result.add " target=" & $inst.intArg
    if inst.op == opJumpIfAbsent and inst.flag:
      result.add " void-only=true"
  of opSyntaxCall, opRejectSyntaxSend:
    discard
  of opDefineRuntimeMacro, opInvokeRuntimeMacro, opExecuteRuntimeMacro, opRuntimePipelineStage:
    result.add " macro=" & $inst.intArg
  of opResolveQualifiedMessage, opQualifiedSend, opBindMessage:
    result.add " name=" & inst.name
  of opNoop, opPop, opNot, opMakeIterator, opIteratorHasNext, opIteratorNext,
     opIteratorClose, opLoopBreak, opLoopContinue, opLoopLeave, opAwait, opYield,
     opExplicitReturn, opReturn, opReturnBareInt:
    discard
  if inst.tail:
    result.add " tail=true"

proc compilerDiagnostics*(root: Chunk): seq[CompileDiagnostic] =
  var seen = initHashSet[pointer]()
  var found: seq[CompileDiagnostic]
  proc visit(chunk: Chunk) =
    if chunk == nil or seen.containsOrIncl(cast[pointer](chunk)):
      return
    found.add chunk.diagnostics
    for fn in chunk.functions:
      visit(fn.chunk)
      for value in fn.paramDefaults: visit(value.defaultChunk)
      for param in fn.namedParams: visit(param.defaultValue.defaultChunk)
    for body in chunk.subchunks: visit(body)
    for loop in chunk.forLoops: visit(loop.body)
    for branch in chunk.matches:
      for clause in branch.clauses: visit(clause.body)
      visit(branch.elseBody)
    for attempt in chunk.tries:
      visit(attempt.body)
      for clause in attempt.catches: visit(clause.body)
      visit(attempt.ensureBody)
  visit(root)
  found

proc addDisassembly(lines: var seq[string], chunk: Chunk, indent = "") =
  for diagnostic in chunk.diagnostics:
    lines.add indent & "warning: " & diagnostic.message
  lines.add indent & "constants:"
  if chunk.constants.len == 0:
    lines.add indent & "  <none>"
  else:
    for i, value in chunk.constants:
      lines.add indent & "  [" & $i & "] " & value.print()

  if chunk.localNames.len > 0:
    lines.add indent & "locals: " & formatNames(chunk.localNames)

  lines.add indent & "instructions:"
  if chunk.instructions.len == 0:
    lines.add indent & "  <none>"
  else:
    for i, inst in chunk.instructions:
      lines.add indent & "  " & $i & ": " & formatInstruction(inst)

  if chunk.functions.len > 0:
    lines.add indent & "functions:"
    for i, fn in chunk.functions:
      let label = if fn.name.len > 0: fn.name else: "<anon>"
      var header = indent & "  [" & $i & "] " & label &
        " params=" & formatNames(fn.params)
      if fn.typeParams.len > 0:
        header.add " type-params=" & formatNames(fn.typeParams)
      if fn.localNames.len > 0:
        header.add " locals=" & formatNames(fn.localNames)
      if fn.capturePlan != nil:
        var levels: seq[string]
        for names in fn.capturePlan.names:
          levels.add formatNames(names)
        header.add " copies=" & levels.join("/") &
          (if fn.capturePlan.keepDepth: " keep-depth" else: "")
      if fn.paramTypes.len > 0:
        var types: seq[string]
        for t in fn.paramTypes:
          types.add(if t.kind == vkNil: "_" else: t.print())
        header.add " param-types=" & formatNames(types)
      if fn.restParam.len > 0:
        header.add " rest=" & fn.restParam
        if fn.restType.kind != vkNil:
          header.add ":" & fn.restType.print()
      if fn.namedParams.len > 0:
        var names: seq[string]
        for p in fn.namedParams:
          var desc = if p.local == p.arg: p.arg else: p.arg & ":" & p.local
          if p.typeExpr.kind != vkNil:
            desc.add " " & p.typeExpr.print()
          names.add desc
        header.add " named=" & formatNames(names)
      if fn.returnType.kind != vkNil:
        header.add " return=" & fn.returnType.print()
      if fn.nativeOp != ncoNone:
        header.add " native=" & formatNativeOp(fn.nativeOp)
      if fn.aotExpr.kind != vkNil:
        header.add " aot=c"
      if fn.aotFrameKind != afkNone:
        header.add " frame=" & formatAotFrameKind(fn.aotFrameKind)
        if fn.aotFrameCanSuspend:
          header.add " suspend=true"
      if fn.taskFrameKind != tfkNone:
        header.add " task-frame=" & formatTaskFrameKind(fn.taskFrameKind)
      if fn.checksErrors:
        header.add " errors=" & $fn.errorTypeCount
      lines.add header
      addDisassembly(lines, fn.chunk, indent & "    ")

  var aotFns: seq[string]
  for fn in chunk.functions:
    let repr = fn.formatAotRepr
    if fn.aotExpr.kind != vkNil and repr.len > 0:
      var desc = fn.name & " repr=" & repr & " arity=" & $fn.params.len
      if fn.aotFrameKind != afkNone:
        desc.add " frame=" & formatAotFrameKind(fn.aotFrameKind)
      if fn.aotFrameCanSuspend:
        desc.add " suspend=true"
      aotFns.add desc
  if aotFns.len > 0:
    lines.add indent & "typed-module-aot:"
    for i, desc in aotFns:
      lines.add indent & "  [" & $i & "] " & desc

  if chunk.subchunks.len > 0:
    lines.add indent & "namespaces:"
    for i, sub in chunk.subchunks:
      lines.add indent & "  [" & $i & "]"
      addDisassembly(lines, sub, indent & "    ")

  if chunk.forLoops.len > 0:
    lines.add indent & "for-loops:"
    for i, fp in chunk.forLoops:
      lines.add indent & "  [" & $i & "] pattern=" & fp.pattern.print()
      addDisassembly(lines, fp.body, indent & "    ")

  if chunk.matches.len > 0:
    lines.add indent & "matches:"
    for i, mp in chunk.matches:
      lines.add indent & "  [" & $i & "]"
      for cl in mp.clauses:
        lines.add indent & "  when " & cl.pattern.print() & ":"
        addDisassembly(lines, cl.body, indent & "    ")
      if mp.elseBody != nil:
        lines.add indent & "  else:"
        addDisassembly(lines, mp.elseBody, indent & "    ")

  if chunk.tries.len > 0:
    lines.add indent & "tries:"
    for i, tp in chunk.tries:
      lines.add indent & "  [" & $i & "] body:"
      addDisassembly(lines, tp.body, indent & "    ")
      for j, cl in tp.catches:
        lines.add indent & "  catch " & cl.errorType.print() & ":"
        addDisassembly(lines, cl.body, indent & "    ")
      if tp.ensureBody != nil:
        lines.add indent & "  ensure:"
        addDisassembly(lines, tp.ensureBody, indent & "    ")

  if chunk.imports.len > 0:
    lines.add indent & "imports:"
    for i, spec in chunk.imports:
      var src =
        if spec.fromModule: "\"" & spec.modulePath & "\""
        else: spec.nsSegments.join("/")
      var desc = indent & "  [" & $i & "] " & src
      if spec.alias.len > 0:
        desc.add " as=" & spec.alias
      if spec.selections.len > 0:
        var sels: seq[string]
        for s in spec.selections:
          sels.add (if s.name == s.local: s.name else: s.name & ":" & s.local)
        desc.add " " & formatNames(sels)
      lines.add desc

  if chunk.ffiLibraries.len > 0:
    lines.add indent & "ffi-libraries:"
    for i, library in chunk.ffiLibraries:
      var targets: seq[string]
      if library.linux.len > 0:
        targets.add "linux=" & library.linux
      if library.macos.len > 0:
        targets.add "macos=" & library.macos
      if library.windows.len > 0:
        targets.add "windows=" & library.windows
      lines.add indent & "  [" & $i & "] " & library.name &
        " " & formatNames(targets)

  if chunk.ffiFns.len > 0:
    lines.add indent & "ffi-fns:"
    for i, fn in chunk.ffiFns:
      var params: seq[string]
      for p in fn.params:
        params.add p.name & ":" & p.typeExpr.print()
      var desc = indent & "  [" & $i & "] " & fn.name &
        " symbol=" & fn.symbol &
        " abi=" & fn.abi &
        " calling=" & fn.calling &
        " params=" & formatNames(params)
      if fn.library.len > 0:
        desc.add " library=" & fn.library
        if fn.libraryDeclared:
          desc.add " declared-library=true"
      if fn.returnType.kind != vkNil:
        desc.add " return=" & fn.returnType.print()
      if fn.release.len > 0:
        desc.add " release=" & fn.release
      lines.add desc

  if chunk.ffiStructs.len > 0:
    lines.add indent & "ffi-structs:"
    for i, structProto in chunk.ffiStructs:
      var fields: seq[string]
      for field in structProto.fields:
        var desc = field.name & ":" & field.typeExpr.print()
        if field.hasOffset:
          desc.add "@" & $field.offset
        fields.add desc
      var desc = indent & "  [" & $i & "] " & structProto.name &
        " layout=" & structProto.layout &
        " fields=" & formatNames(fields)
      if structProto.hasSize:
        desc.add " size=" & $structProto.size
      if structProto.hasAlign:
        desc.add " align=" & $structProto.align
      lines.add desc

  if chunk.ffiStructDependencies.len > 0:
    lines.add indent & "ffi-struct-dependencies:"
    for identity in chunk.ffiStructDependencies:
      lines.add indent & "  " & identity

  if chunk.ffiUnions.len > 0:
    lines.add indent & "ffi-unions:"
    for i, unionProto in chunk.ffiUnions:
      var fields: seq[string]
      for field in unionProto.fields:
        fields.add field.name & ":" & field.typeExpr.print()
      var desc = indent & "  [" & $i & "] " & unionProto.name &
        " layout=" & unionProto.layout &
        " fields=" & formatNames(fields)
      if unionProto.hasSize:
        desc.add " size=" & $unionProto.size
      if unionProto.hasAlign:
        desc.add " align=" & $unionProto.align
      lines.add desc

  if chunk.ffiSignatures.len > 0:
    lines.add indent & "ffi-signatures:"
    for i, signature in chunk.ffiSignatures:
      var params: seq[string]
      for p in signature.params:
        params.add p.name & ":" & p.typeExpr.print()
      var desc = indent & "  [" & $i & "] " & signature.name &
        " kind=" & formatFfiSignatureKind(signature.kind) &
        " abi=" & signature.abi &
        " params=" & formatNames(params)
      if signature.returnType.kind != vkNil:
        desc.add " return=" & signature.returnType.print()
      if signature.escaping:
        desc.add " escaping=true"
      if signature.runtimeConstructible:
        desc.add " runtime=true"
      lines.add desc

  if chunk.monomorphizations.len > 0:
    lines.add indent & "monomorphizations:"
    for i, spec in chunk.monomorphizations:
      var args: seq[string]
      for arg in spec.typeArgs:
        args.add arg.print()
      lines.add indent & "  [" & $i & "] " & spec.functionName &
        "<" & args.join(",") & ">"

  if chunk.directProtocolCalls.len > 0:
    lines.add indent & "direct-protocol-calls:"
    for i, spec in chunk.directProtocolCalls:
      lines.add indent & "  [" & $i & "] " & spec.messageName &
        " protocol=" & spec.protocolExpr.print() &
        " receiver=" & spec.receiverExpr.print()

  if chunk.protocolProtos.len > 0:
    lines.add indent & "protocols:"
    for i, pp in chunk.protocolProtos:
      var messageNames: seq[string]
      for message in pp.messages:
        messageNames.add message.name
      var desc = indent & "  [" & $i & "] " & pp.name &
        " messages=" & formatNames(messageNames)
      if pp.deriveFn != nil:
        desc.add " derive=true"
      if pp.universal:
        desc.add " universal=true"
      lines.add desc

  if chunk.implProtos.len > 0:
    lines.add indent & "impls:"
    for i, ip in chunk.implProtos:
      var names: seq[string]
      for m in ip.messages:
        names.add m.name
      lines.add indent & "  [" & $i & "] messages=" & formatNames(names)

proc disassemble*(chunk: Chunk): string =
  var lines: seq[string]
  addDisassembly(lines, chunk)
  lines.join("\n")

proc cIdent(name: string, fallback: string): string =
  result = if name.len == 0: fallback else: name
  for i, ch in result:
    if not (ch.isAlphaNumeric or ch == '_'):
      result[i] = '_'
  if result.len == 0 or result[0].isDigit:
    result = "_" & result

proc cStringLiteral(text: string): string =
  result = "\""
  for ch in text:
    case ch
    of '\\':
      result.add "\\\\"
    of '"':
      result.add "\\\""
    of '\n':
      result.add "\\n"
    of '\r':
      result.add "\\r"
    of '\t':
      result.add "\\t"
    else:
      result.add ch
  result.add "\""

proc aotTypeName(fn: FunctionProto): string =
  fn.formatAotRepr

proc aotCType(typeName: string): string =
  case typeName
  of "I64": "int64_t"
  of "I32": "int32_t"
  of "Str": "const char *"
  of "F64": "double"
  else: ""

type FfiStructCNames = Table[string, string]

proc stableCIdentityHash(identity: string): string =
  var hash = 1469598103934665603'u64
  for ch in identity:
    hash = (hash xor uint64(ord(ch))) * 1099511628211'u64
  toHex(hash, 16).toLowerAscii

proc collectFfiStructCNames(chunk: Chunk,
                            identities: var Table[string, seq[string]]) =
  for structProto in chunk.ffiStructs:
    let base = cIdent(structProto.name, "FfiStruct")
    var seen = false
    for identity in identities.getOrDefault(base):
      if identity == structProto.identity:
        seen = true
        break
    if not seen:
      identities.mgetOrPut(base, @[]).add structProto.identity
  for fn in chunk.functions:
    collectFfiStructCNames(fn.chunk, identities)
  for child in chunk.subchunks:
    collectFfiStructCNames(child, identities)

proc buildFfiStructCNames(chunk: Chunk): FfiStructCNames =
  var identities = initTable[string, seq[string]]()
  collectFfiStructCNames(chunk, identities)
  for base, values in identities:
    for identity in values:
      result[identity] =
        if values.len == 1: base
        else: base & "__" & stableCIdentityHash(identity)

proc ffiStructCName(structProto: FfiStructProto,
                    names: FfiStructCNames): string =
  names.getOrDefault(structProto.identity,
                     cIdent(structProto.name, "FfiStruct"))

proc aotCType(repr: AotRepr, names: FfiStructCNames): string =
  case repr.kind
  of arkI64: "int64_t"
  of arkI32: "int32_t"
  of arkCStr: "const char *"
  of arkF64: "double"
  of arkNativePtr:
    if repr.nativeType == nil or repr.nativeType.abi == nil: ""
    else: ffiStructCName(repr.nativeType.abi, names) & " *"
  of arkNone: ""

type AotCFunction = object
  cName: string
  paramCount: int
  cType: string
  checked: bool
  paramNames: seq[string]
  paramReprs: seq[AotRepr]
  returnRepr: AotRepr
  geneName: string
  sourceLoc: SourceLoc
  outParams: seq[bool]
    ## Per-position `^out` flags, so the call site can pass an address where
    ## the declaration takes one. Empty for ordinary functions.

type AotModuleFunction = object
  geneName: string
  cName: string
  entryName: string
  typeName: string
  paramCount: int
  frameName: string

type MonomorphizationCRow = object
  functionName: string
  typeArgs: string

type DirectProtocolCRow = object
  messageName: string
  protocolName: string
  receiverName: string

type TaskFrameCRow = object
  functionName: string
  kind: string
  canSuspend: bool

type FfiLibraryCRow = object
  name: string
  linux: string
  macos: string
  windows: string

type FfiFnCRow = object
  name: string
  library: string
  libraryDeclared: bool
  symbol: string
  abi: string
  calling: string
  wrapperName: string
  release: string
  arity: int
  resultType: string

type FfiStructCRow = object
  name: string
  layout: string
  size: int
  align: int
  fieldCount: int

type FfiStructFieldCRow = object
  structName: string
  fieldName: string
  typeName: string
  offset: int

type FfiUnionCRow = object
  name: string
  layout: string
  size: int
  align: int
  fieldCount: int

type FfiUnionFieldCRow = object
  unionName: string
  fieldName: string
  typeName: string

type FfiSignatureCRow = object
  name: string
  kind: string
  abi: string
  params: string
  resultType: string
  escaping: bool
  runtimeConstructible: bool

type FfiMarshalKind = enum
  fmkUnsupported
  fmkVoid
  fmkScalar
  fmkCStr
  fmkPtr
  fmkConstPtr
  fmkSlice
  fmkBuffer
    ## `C/Slice` and `Buffer` are two lifecycles, not one. A slice borrows the
    ## Gene value's own storage for the call; a Buffer marshals every element
    ## into temporary bytes and must copy them back afterwards, so it needs
    ## storage that outlives the argument helper and an explicit finalize.

proc ffiTypeLabel(expr: Value): string

proc aotSendKey(receiverIdentity, protocolName, messageName: string): string =
  "@typed_send\x1f" & receiverIdentity & "\x1f" & protocolName & "\x1f" &
    messageName

proc aotLoweringGap(expr: Value, detail: string): string =
  ## Emission-time guard for the typed_native backend.
  ##
  ## `isTypedNativeAotExpr` decides what may be lowered; this emitter must be
  ## able to lower everything analysis accepted. The two passes re-derive that
  ## judgement from different data — analysis walks source-ordered compiler
  ## state, emission walks an `available` table built in emission order — so
  ## they can disagree. Reaching here means they did.
  ##
  ## Fail loudly rather than emitting a placeholder. The previous `"0"`
  ## fallback silently produced wrong values, and for pointer-typed results a
  ## `T *x = 0;` initializer followed by a field load, which compiles cleanly
  ## at -Wall -Wextra and dereferences null at runtime.
  raise newException(GeneError,
    "typed_native backend has no lowering for " & expr.print() & " (" &
    detail & "). Analysis accepted this expression but code generation " &
    "cannot emit it; the typed_native analysis and emission passes disagree.")

proc aotMathBuiltinCName*(head: Value): string =
  ## The `<math.h>` function a `$math/...` head lowers to, or "" for anything
  ## outside the exact-match set.
  ##
  ## `$math/floor` reads as `((path gene math floor) v)`, so the head is a path
  ## node rather than a symbol — which is why the callers have to test this
  ## before their `head.kind == vkSymbol` guards rather than inside them.
  ##
  ## Membership is decided by semantic identity with Gene, not by availability
  ## in C. `floor`, `ceil`, `trunc`, and `abs` agree with the VM over their
  ## whole domain. `sqrt`, `log`, `log2`, `log10`, `asin`, and `acos` are
  ## deliberately absent: Gene raises on their domain violations and C returns
  ## NaN, so lowering them would replace a catchable error with a value that
  ## quietly poisons everything downstream.
  if head.kind != vkNode or head.body.len != 3 or
      head.head.kind != vkSymbol or head.head.symVal != "path":
    return ""
  for i, segment in ["gene", "math"]:
    if head.body[i].kind != vkSymbol or head.body[i].symVal != segment:
      return ""
  if head.body[2].kind != vkSymbol:
    return ""
  case head.body[2].symVal
  of "floor": "floor"
  of "ceil": "ceil"
  of "trunc": "trunc"
  of "abs": "fabs"
  else: ""

proc ffiTypeLabel(expr: Value): string =
  case expr.kind
  of vkSymbol:
    expr.symVal
  of vkNode:
    if expr.head.kind == vkSymbol and expr.head.symVal == "path":
      var segments: seq[string]
      for item in expr.body:
        if item.kind == vkSymbol:
          segments.add item.symVal
        else:
          segments.add ffiTypeLabel(item)
      segments.join("/")
    else:
      var parts = @[ffiTypeLabel(expr.head)]
      for item in expr.body:
        parts.add ffiTypeLabel(item)
      "(" & parts.join(" ") & ")"
  else:
    expr.print()

const
  AotManifestVersion* = 2
    ## Version 2 requires checked native results and structured failure helpers.
  AbiFingerprintVersion* = 1
    ## Leads every serialization, so changing the hashing rule invalidates every
    ## previously built library by design.
  FnvOffsetBasis = 0xcbf29ce484222325'u64
  FnvPrime = 0x100000001b3'u64
  FingerprintSep = "\x1f"

proc fingerprintOf(source: string): string =
  ## FNV-1a. Explicitly not Nim's `hash`, which is not guaranteed stable across
  ## builds or versions — this value is compared between a library compiled at
  ## one time and a runtime Type registered at another.
  var h = FnvOffsetBasis
  for ch in source:
    h = h xor uint64(uint8(ch))
    h = h * FnvPrime
  toHex(h, 16).toLowerAscii

proc layoutFingerprintSource*(proto: FfiStructProto): string =
  ## The canonical, human-inspectable serialization the layout hash is taken
  ## over. A pointer field contributes its pointee's *ABI* identity, not the
  ## nominal one: two Types can name the same layout, and it is the layout that
  ## determines the offsets this hash is about.
  ##
  ## Shallow on purpose. A pointee contributes an identity string rather than
  ## its own fingerprint, because `CNode.next : Node` is self-referential and a
  ## transitive hash would not terminate. Completeness comes from every layout
  ## the library depends on appearing in the manifest and being validated
  ## independently.
  var parts = @[$AbiFingerprintVersion, proto.layout,
                (if proto.hasSize: $proto.size else: "-"),
                (if proto.hasAlign: $proto.align else: "-")]
  for field in proto.fields:
    parts.add field.name
    parts.add ffiTypeLabel(field.typeExpr)
    parts.add field.pointeeAbiIdentity
    parts.add (if field.hasOffset: $field.offset else: "-")
  parts.join(FingerprintSep)

proc computeLayoutFingerprint*(proto: FfiStructProto) =
  if proto != nil:
    proto.fingerprint = fingerprintOf(proto.layoutFingerprintSource())

proc contractFingerprintSource*(proto: NativeTypeProto): string =
  ## The complete code-generation contract, nesting the layout hash so any
  ## layout change still moves this value.
  @[$AbiFingerprintVersion, proto.identity, proto.abiIdentity,
    proto.abiFingerprint, proto.lifecycle,
    (if proto.mutable: "mut" else: "const"), proto.wrapperField,
    proto.wrapperFieldSchema, proto.releaseSymbol,
    proto.copySymbol].join(FingerprintSep)

proc computeContractFingerprint*(proto: NativeTypeProto) =
  if proto == nil:
    return
  if proto.abi != nil:
    if proto.abi.fingerprint.len == 0:
      computeLayoutFingerprint(proto.abi)
    proto.abiFingerprint = proto.abi.fingerprint
  proto.contractFingerprint = fingerprintOf(proto.contractFingerprintSource())

proc ffiCType(label: string, paramName = ""): string =
  case label
  of "C/Int8": "int8_t"
  of "C/UInt8": "uint8_t"
  of "C/Int16": "int16_t"
  of "C/UInt16": "uint16_t"
  of "C/Int32": "int32_t"
  of "C/UInt32": "uint32_t"
  of "C/Int64": "int64_t"
  of "C/UInt64": "uint64_t"
  of "C/Char": "char"
  of "C/UChar": "unsigned char"
  of "C/Short": "short"
  of "C/UShort": "unsigned short"
  of "C/Int": "int"
  of "C/UInt": "unsigned int"
  of "C/Long": "long"
  of "C/ULong": "unsigned long"
  of "C/Size": "size_t"
  of "C/PtrDiff": "ptrdiff_t"
  of "C/Float": "float"
  of "C/Double": "double"
  of "C/Bool": "bool"
  of "C/Void": "void"
  of "C/CStr": "const char *"
  else:
    if label.startsWith("(C/ConstPtr ") or label.startsWith("(C/NullableConstPtr "):
      "const void *"
    elif label.startsWith("(C/Ptr ") or label.startsWith("(C/NullablePtr ") or
        label.startsWith("(C/OwnedPtr "):
      "void *"
    elif label.startsWith("(C/Slice ") or label.startsWith("(Buffer "):
      if paramName.len > 0: "const void *"
      else: "void *"
    else:
      "void *"

proc ffiMarshalKind(label: string, isResult = false): FfiMarshalKind =
  case label
  of "C/Void":
    if isResult: fmkVoid else: fmkUnsupported
  of "C/Int8", "C/UInt8", "C/Int16", "C/UInt16", "C/Int32", "C/UInt32",
     "C/Int64", "C/UInt64", "C/Char", "C/UChar", "C/Short", "C/UShort",
     "C/Int", "C/UInt", "C/Long", "C/ULong", "C/Size", "C/PtrDiff",
     "C/Float", "C/Double", "C/Bool":
    fmkScalar
  of "C/CStr":
    fmkCStr
  else:
    if label.startsWith("(C/ConstPtr ") or
        label.startsWith("(C/NullableConstPtr "):
      fmkConstPtr
    elif label.startsWith("(C/Ptr ") or label.startsWith("(C/NullablePtr ") or
        label.startsWith("(C/OwnedPtr "):
      fmkPtr
    elif not isResult and label.startsWith("(C/Slice "):
      fmkSlice
    elif not isResult and label.startsWith("(Buffer "):
      fmkBuffer
    else:
      fmkUnsupported

proc ffiParamCDecls(label, paramName: string): seq[string] =
  let name = cIdent(paramName, "arg")
  case ffiMarshalKind(label)
  of fmkSlice:
    ## Borrowed and not written back, so the callee sees it as const.
    @["const void * " & name, "size_t " & cIdent(name & "_len", "arg_len")]
  of fmkBuffer:
    ## Not const: a Buffer's whole point is that the callee writes it and the
    ## bytes are copied back into the Gene value afterwards. Declaring it
    ## `const void *` misdescribed every mutating C function it was used with.
    @["void * " & name, "size_t " & cIdent(name & "_len", "arg_len")]
  else:
    @[ffiCType(label, name) & " " & name]

proc ffiHelperSuffix(label: string): string =
  case label
  of "C/Int8": "int8"
  of "C/UInt8": "uint8"
  of "C/Int16": "int16"
  of "C/UInt16": "uint16"
  of "C/Int32": "int32"
  of "C/UInt32": "uint32"
  of "C/Int64": "int64"
  of "C/UInt64": "uint64"
  of "C/Char": "char"
  of "C/UChar": "uchar"
  of "C/Short": "short"
  of "C/UShort": "ushort"
  of "C/Int": "int"
  of "C/UInt": "uint"
  of "C/Long": "long"
  of "C/ULong": "ulong"
  of "C/Size": "size"
  of "C/PtrDiff": "ptrdiff"
  of "C/Float": "float"
  of "C/Double": "double"
  of "C/Bool": "bool"
  of "C/CStr": "cstr"
  else:
    case ffiMarshalKind(label)
    of fmkPtr: "ptr"
    of fmkConstPtr: "const_ptr"
    of fmkSlice: "slice"
    of fmkBuffer: "buffer"
    else: "unsupported"

proc ffiResultHelperSuffix(label: string): string =
  case ffiMarshalKind(label, isResult = true)
  of fmkVoid: "void"
  of fmkPtr, fmkConstPtr: "ptr"
  else: ffiHelperSuffix(label)

proc ffiWrapperSupported(fn: FfiFnProto, retLabel: string): bool =
  for p in fn.params:
    if ffiMarshalKind(ffiTypeLabel(p.typeExpr)) == fmkUnsupported:
      return false
    ## An out-parameter has no incoming value to marshal and nowhere to surface
    ## what the callee wrote, so the dynamic entry is not expressible yet
    ## (proposal §6.3.1). Typed-native callers pass an address directly and are
    ## unaffected; reporting unsupported here beats marshalling the slot as an
    ## ordinary argument, which would hand C the value instead of its address.
    if p.isOut:
      return false
  if retLabel.startsWith("(C/OwnedPtr ") and fn.release.len == 0:
    return false
  ffiMarshalKind(retLabel, isResult = true) != fmkUnsupported

proc ffiWrapperName(fn: FfiFnProto, fallback: string): string =
  "gene_ffi_" & cIdent(if fn.name.len > 0: fn.name else: fn.symbol, fallback)

proc ffiCallingMacro(calling: string): string =
  case calling.toLowerAscii
  of "stdcall":
    "GENE_FFI_STDCALL"
  else:
    "GENE_FFI_CDECL"

proc aotModuleManifestName(prefix: string): string =
  "gene_" & cIdent(prefix & "aot_module", "aot_module")

proc monomorphizationManifestName(prefix: string): string =
  "gene_" & cIdent(prefix & "monomorphizations", "monomorphizations")

proc directProtocolManifestName(prefix: string): string =
  "gene_" & cIdent(prefix & "direct_protocol_calls", "direct_protocol_calls")

proc taskFrameManifestName(prefix: string): string =
  "gene_" & cIdent(prefix & "task_frames", "task_frames")

proc ffiLibraryManifestName(prefix: string): string =
  "gene_" & cIdent(prefix & "ffi_libraries", "ffi_libraries")

proc ffiFnManifestName(prefix: string): string =
  "gene_" & cIdent(prefix & "ffi_fns", "ffi_fns")

proc ffiStructManifestName(prefix: string): string =
  "gene_" & cIdent(prefix & "ffi_structs", "ffi_structs")

proc ffiStructFieldManifestName(prefix: string): string =
  "gene_" & cIdent(prefix & "ffi_struct_fields", "ffi_struct_fields")

proc ffiUnionManifestName(prefix: string): string =
  "gene_" & cIdent(prefix & "ffi_unions", "ffi_unions")

proc ffiUnionFieldManifestName(prefix: string): string =
  "gene_" & cIdent(prefix & "ffi_union_fields", "ffi_union_fields")

proc ffiSignatureManifestName(prefix: string): string =
  "gene_" & cIdent(prefix & "ffi_signatures", "ffi_signatures")

proc addFfiWrapper(lines: var seq[string], fn: FfiFnProto, index: int,
                   prefix: string, structNames: FfiStructCNames) =
  let symbol = if fn.symbol.len > 0: fn.symbol else: fn.name
  let cSymbol = cIdent(symbol, "ffi_symbol_" & $index)
  let retLabel =
    if fn.returnType.kind == vkNil: "C/Void" else: ffiTypeLabel(fn.returnType)
  let retType =
    if fn.returnRepr.kind == arkNativePtr:
      fn.returnRepr.aotCType(structNames)
    else: ffiCType(retLabel)
  let supported = ffiWrapperSupported(fn, retLabel)
  var declParams: seq[string]
  for i, p in fn.params:
    let label = ffiTypeLabel(p.typeExpr)
    let name = cIdent(p.name, "arg" & $i)
    if i < fn.paramReprs.len and fn.paramReprs[i].kind == arkNativePtr:
      ## An out-parameter takes one more indirection than its value type: the
      ## declaration still describes the real C signature, `^out` is only what
      ## says so (proposal §6.3.1).
      declParams.add fn.paramReprs[i].aotCType(structNames) &
        (if p.isOut: "*" else: "") & " " & name
    elif p.isOut:
      declParams.add ffiCType(label, name) & " * " & name
    else:
      for cDecl in ffiParamCDecls(label, name):
        declParams.add cDecl
  let paramList = if declParams.len == 0: "void" else: declParams.join(", ")
  lines.add "extern " & retType & " " & ffiCallingMacro(fn.calling) &
    " " & cSymbol & "(" & paramList & ");"
  ## The dynamic entry wrapper is what lets interpreted Gene reach this symbol,
  ## so it calls the gene_ffi_* helpers exported by the Gene host. Guard the
  ## wrapper so standalone typed C callers need not link those dynamic-boundary
  ## helpers. Define GENE_AOT_DYNAMIC_ENTRIES for libraries loaded by aot/load.
  lines.add "#ifdef GENE_AOT_DYNAMIC_ENTRIES"
  ## An owned result's release function is passed as a *pointer*, not a name.
  ## Resolving it by name meant scanning every loaded AOT library and taking the
  ## first match, so an allocation could be paired with a different library's
  ## destructor. The symbol is right here, in the library that declared it, and
  ## the linker resolves it -- exactly as the ^native_entry shims already do.
  var resultRelease = "NULL"
  if fn.release.len > 0 and
      ffiMarshalKind(retLabel, isResult = true) in {fmkPtr, fmkConstPtr}:
    resultRelease = ffiWrapperName(fn, prefix & "ffi_" & $index) & "_release"
    lines.add "extern void " & ffiCallingMacro(fn.calling) & " " &
      fn.release & "(" & retType & " value);"
    lines.add "static void " & resultRelease & "(void *value) {"
    lines.add "  " & fn.release & "((" & retType & ")value);"
    lines.add "}"
  lines.add "GeneStatus " & ffiWrapperName(fn, prefix & "ffi_" & $index) &
    "(GeneContext *ctx, const GeneCall *call, GeneValue *result) {"
  lines.add "  /* library: " & (if fn.library.len > 0: fn.library else: "<linker>") & " */"
  lines.add "  /* abi: " & (if fn.abi.len > 0: fn.abi else: "C") & " */"
  lines.add "  /* calling: " & (if fn.calling.len > 0: fn.calling else: "C") & " */"
  for i, p in fn.params:
    let label = ffiTypeLabel(p.typeExpr)
    let shape =
      case ffiMarshalKind(label)
      of fmkSlice: "const void *, size_t"
      of fmkBuffer: "void *, size_t"
      else: ffiCType(label, p.name)
    lines.add "  /* arg " & $i & " " & p.name & ": " & label &
      " -> " & shape & " */"
  if retLabel != "C/Void":
    lines.add "  /* result: " & retLabel & " -> GeneValue */"
  if fn.release.len > 0:
    lines.add "  /* owned release: " & fn.release & " */"
  if not supported:
    lines.add "  (void)ctx;"
    lines.add "  (void)call;"
    lines.add "  (void)result;"
    lines.add "  return GENE_FFI_WRAPPER_UNIMPLEMENTED;"
    lines.add "}"
    lines.add "#endif"
    lines.add ""
    return
  lines.add "  GeneStatus status = gene_ffi_check_arity(ctx, call, " &
    $fn.params.len & ");"
  lines.add "  if (status != GENE_OK) return status;"
  var callArgs: seq[string]
  var bufferLeases: seq[string]
  for i, p in fn.params:
    let label = ffiTypeLabel(p.typeExpr)
    let name = cIdent(p.name, "arg" & $i)
    case ffiMarshalKind(label)
    of fmkScalar:
      lines.add "  " & ffiCType(label, name) & " " & name & ";"
      lines.add "  status = gene_ffi_arg_" & ffiHelperSuffix(label) &
        "(ctx, call, " & $i & ", " & cStringLiteral(p.name) & ", &" &
        name & ");"
      lines.add "  if (status != GENE_OK) return status;"
      callArgs.add name
    of fmkCStr:
      lines.add "  const char *" & name & ";"
      lines.add "  status = gene_ffi_arg_cstr(ctx, call, " & $i & ", " &
        cStringLiteral(p.name) & ", &" & name & ");"
      lines.add "  if (status != GENE_OK) return status;"
      callArgs.add name
    of fmkPtr:
      lines.add "  void *" & name & ";"
      lines.add "  status = gene_ffi_arg_ptr(ctx, call, " & $i & ", " &
        cStringLiteral(p.name) & ", " & cStringLiteral(label) & ", &" &
        name & ");"
      lines.add "  if (status != GENE_OK) return status;"
      callArgs.add name
    of fmkConstPtr:
      lines.add "  const void *" & name & ";"
      lines.add "  status = gene_ffi_arg_const_ptr(ctx, call, " & $i & ", " &
        cStringLiteral(p.name) & ", " & cStringLiteral(label) & ", &" &
        name & ");"
      lines.add "  if (status != GENE_OK) return status;"
      callArgs.add name
    of fmkSlice:
      ## Borrowed: the view points into the Gene value's own storage and is
      ## valid for the call. Nothing to release and nothing to write back.
      lines.add "  GeneFfiBufferView " & name & "_view;"
      lines.add "  status = gene_ffi_arg_slice(ctx, call, " & $i & ", " &
        cStringLiteral(p.name) & ", " & cStringLiteral(label) & ", &" &
        name & "_view);"
      lines.add "  if (status != GENE_OK) return status;"
      callArgs.add name & "_view.data"
      callArgs.add name & "_view.len"
    of fmkBuffer:
      ## Marshalled: the helper unpacks each element into temporary bytes owned
      ## by the context, so the view stays valid for the call, and returns a
      ## lease. The bytes are written back to the Gene buffer at the matching
      ## finalize below — without it a callee's writes would be discarded.
      lines.add "  GeneFfiBufferView " & name & "_view;"
      lines.add "  GeneFfiBufferLease " & name & "_lease;"
      lines.add "  status = gene_ffi_arg_buffer(ctx, call, " & $i & ", " &
        cStringLiteral(p.name) & ", " & cStringLiteral(label) & ", &" &
        name & "_view, &" & name & "_lease);"
      lines.add "  if (status != GENE_OK) return status;"
      callArgs.add "(void *)" & name & "_view.data"
      callArgs.add name & "_view.len"
      bufferLeases.add name & "_lease"
    else:
      discard
  let args = callArgs.join(", ")

  proc addFinalizeLines(lines: var seq[string]) =
    ## Copy-back runs after the callee and before the result is built, in
    ## parameter order — the same order and position the dynamic path uses.
    for lease in bufferLeases:
      lines.add "  gene_ffi_buffer_finalize(ctx, " & lease & ");"

  case ffiMarshalKind(retLabel, isResult = true)
  of fmkVoid:
    lines.add "  " & cSymbol & "(" & args & ");"
    addFinalizeLines(lines)
    lines.add "  return gene_ffi_result_void(ctx, result);"
  of fmkScalar, fmkCStr:
    lines.add "  " & retType & " native_result = " & cSymbol & "(" &
      args & ");"
    addFinalizeLines(lines)
    lines.add "  return gene_ffi_result_" & ffiResultHelperSuffix(retLabel) &
      "(ctx, native_result, result);"
  of fmkPtr, fmkConstPtr:
    lines.add "  " & retType & " native_result = " & cSymbol & "(" &
      args & ");"
    addFinalizeLines(lines)
    lines.add "  return gene_ffi_result_ptr(ctx, (void *)native_result, " &
      cStringLiteral(retLabel) & ", " & resultRelease & ", result);"
  else:
    lines.add "  return GENE_FFI_WRAPPER_UNIMPLEMENTED;"
  lines.add "}"
  lines.add "#endif"
  lines.add ""

proc nativeEntryName(fnName, fallback: string): string =
  "gene_entry_" & cIdent(fnName, fallback)

proc aotOptionalNilTail(fn: FunctionProto): int =
  for i in countdown(fn.params.high, 0):
    if i >= fn.paramDefaults.len or not fn.paramDefaults[i].optional or
        fn.paramDefaults[i].defaultChunk != nil or i >= fn.aotParamReprs.len or
        fn.aotParamReprs[i].kind != arkNativePtr or not fn.aotParamReprs[i].nullable:
      break
    inc result

include ./aot_checked

proc addNativeEntry(lines: var seq[string], fn: FunctionProto,
                    nativeName, entryName: string,
                    structNames: FfiStructCNames) =
  ## Explicit dynamic → typed-native seam (native-type proposal §6.4). The
  ## runtime helper owns wrapper identity/liveness/ABI validation; generated C
  ## receives only the raw pointer after that check and never boxes implicitly.
  ##
  ## Guarded for the same reason as the ffi/fn wrappers: this adapter is the
  ## boundary itself, so it calls gene_typed_native_* helpers from the host.
  ## The copy/release shims exist only to serve it, so the whole
  ## unit is guarded together.
  lines.add "#ifdef GENE_AOT_DYNAMIC_ENTRIES"
  var paramCopies = newSeq[string](fn.params.len)
  var paramReleases = newSeq[string](fn.params.len)
  for i, repr in fn.aotParamReprs:
    if repr.kind != arkNativePtr or
        fn.nativeEntry.paramOwnership[i] != noCopy:
      continue
    let nativeType = repr.nativeType
    let structName = ffiStructCName(nativeType.abi, structNames)
    let shimName = entryName & "_arg_" & $i &
      "_copy"
    paramCopies[i] = shimName
    lines.add "extern " & structName & " * GENE_FFI_CDECL " &
      nativeType.copySymbol & "(const " & structName & " *value);"
    lines.add "static void *" & shimName & "(const void *value) {"
    lines.add "  return (void *)" & nativeType.copySymbol & "((const " &
      structName & " *)value);"
    lines.add "}"
    let releaseShim = entryName & "_" & cIdent(fn.params[i], "arg" & $i) &
      "_release"
    paramReleases[i] = releaseShim
    lines.add "extern void GENE_FFI_CDECL " & nativeType.releaseSymbol &
      "(" & structName & " *value);"
    lines.add "static void " & releaseShim & "(void *value) {"
    lines.add "  " & nativeType.releaseSymbol & "((" & structName & " *)value);"
    lines.add "}"
    lines.add ""
  var resultRelease = ""
  if fn.aotReturnRepr.kind == arkNativePtr and
      fn.nativeEntry.resultOwnership in {noTransfer, noCopy}:
    let nativeType = fn.aotReturnRepr.nativeType
    let cType = fn.aotReturnRepr.aotCType(structNames)
    resultRelease = entryName & "_result_release"
    lines.add "extern void GENE_FFI_CDECL " & nativeType.releaseSymbol &
      "(" & cType & " value);"
    lines.add "static void " & resultRelease & "(void *value) {"
    lines.add "  " & nativeType.releaseSymbol & "((" & cType & ")value);"
    lines.add "}"
    lines.add ""
  var resultCopy = ""
  if fn.aotReturnRepr.kind == arkNativePtr and
      fn.nativeEntry.resultOwnership == noCopy:
    let nativeType = fn.aotReturnRepr.nativeType
    let structName = ffiStructCName(nativeType.abi, structNames)
    resultCopy = entryName & "_result_copy"
    lines.add "extern " & structName & " * GENE_FFI_CDECL " &
      nativeType.copySymbol & "(const " & structName & " *value);"
    lines.add "static void *" & resultCopy & "(const void *value) {"
    lines.add "  return (void *)" & nativeType.copySymbol & "((const " &
      structName & " *)value);"
    lines.add "}"
    lines.add ""
  lines.add "GeneStatus " & entryName &
    "(GeneContext *ctx, const GeneCall *call, GeneValue *result) {"
  let optionalTail = fn.aotOptionalNilTail
  if optionalTail > 0:
    lines.add "  size_t provided = 0;"
    lines.add "  GeneStatus status = gene_ffi_check_arity_range(ctx, call, " &
      $(fn.params.len - optionalTail) & ", " & $fn.params.len & ", &provided);"
  else:
    lines.add "  GeneStatus status = gene_ffi_check_arity(ctx, call, " &
      $fn.params.len & ");"
  lines.add "  if (status != GENE_OK) return status;"
  var callArgs: seq[string]
  # Declare every acquisition slot before the first fallible conversion so the
  # shared rollback label can safely inspect all of them after any failure.
  for i, param in fn.params:
    let name = "gene_arg_" & $i
    let repr = fn.aotParamReprs[i]
    case repr.kind
    of arkI64:
      lines.add "  int64_t " & name & ";"
    of arkI32:
      lines.add "  int32_t " & name & ";"
    of arkCStr:
      lines.add "  const char * " & name & " = NULL;"
    of arkF64:
      lines.add "  double " & name & ";"
    of arkNativePtr:
      let rawName = name & "_raw"
      lines.add "  void *" & rawName & " = NULL;"
      lines.add "  " & repr.aotCType(structNames) & " " & name & " = NULL;"
      if fn.nativeEntry.paramOwnership[i] in {noTransfer, noCopy}:
        lines.add "  bool " & name & "_acquired = false;"
    of arkNone:
      lines.add "  return GENE_FFI_WRAPPER_UNIMPLEMENTED;"
    callArgs.add name
  for i, param in fn.params:
    let name = "gene_arg_" & $i
    let repr = fn.aotParamReprs[i]
    if i >= fn.params.len - optionalTail:
      lines.add "  if (provided > " & $i & ") {"
    case repr.kind
    of arkI64:
      lines.add "  status = gene_ffi_arg_int64(ctx, call, " & $i & ", " &
        cStringLiteral(param) & ", &" & name & ");"
      lines.add "  if (status != GENE_OK) goto " & entryName & "_arg_error;"
    of arkI32:
      ## Range-checked at the boundary, which is what makes the compiled
      ## signature agree with the interpreter's `I32` annotation.
      lines.add "  status = gene_ffi_arg_int32(ctx, call, " & $i & ", " &
        cStringLiteral(param) & ", &" & name & ");"
      lines.add "  if (status != GENE_OK) goto " & entryName & "_arg_error;"
    of arkCStr:
      ## Borrowed from the argument's own storage, so it stays valid for the
      ## call and must not be retained by the callee.
      lines.add "  status = gene_ffi_arg_cstr(ctx, call, " & $i & ", " &
        cStringLiteral(param) & ", &" & name & ");"
      lines.add "  if (status != GENE_OK) goto " & entryName & "_arg_error;"
    of arkF64:
      lines.add "  status = gene_ffi_arg_double(ctx, call, " & $i & ", " &
        cStringLiteral(param) & ", &" & name & ");"
      lines.add "  if (status != GENE_OK) goto " & entryName & "_arg_error;"
    of arkNativePtr:
      let nativeType = repr.nativeType
      let rawName = name & "_raw"
      case fn.nativeEntry.paramOwnership[i]
      of noBorrow:
        lines.add "  status = gene_typed_native_arg_borrow(ctx, call, " &
          $i & ", " & cStringLiteral(param) & ", " &
          cStringLiteral(nativeType.identity) & ", " &
          cStringLiteral(nativeType.abiIdentity) & ", " &
          cStringLiteral(nativeType.wrapperField) & ", " &
          (if repr.nullable: "true" else: "false") & ", &" & rawName & ");"
        lines.add "  if (status != GENE_OK) goto " & entryName & "_arg_error;"
      of noTransfer:
        lines.add "  status = gene_typed_native_arg_transfer(ctx, call, " &
          $i & ", " & cStringLiteral(param) & ", " &
          cStringLiteral(nativeType.identity) & ", " &
          cStringLiteral(nativeType.abiIdentity) & ", " &
          cStringLiteral(nativeType.wrapperField) & ", " &
          (if repr.nullable: "true" else: "false") & ", &" & rawName & ");"
        lines.add "  if (status != GENE_OK) goto " & entryName & "_arg_error;"
        lines.add "  " & name & "_acquired = true;"
      of noCopy:
        lines.add "  status = gene_typed_native_arg_copy(ctx, call, " &
          $i & ", " & cStringLiteral(param) & ", " &
          cStringLiteral(nativeType.identity) & ", " &
          cStringLiteral(nativeType.abiIdentity) & ", " &
          cStringLiteral(nativeType.wrapperField) & ", " &
          (if repr.nullable: "true" else: "false") & ", " &
          paramCopies[i] & ", &" & rawName & ");"
        lines.add "  if (status != GENE_OK) goto " & entryName & "_arg_error;"
        lines.add "  " & name & "_acquired = true;"
      else:
        lines.add "  (void)" & rawName & ";"
        lines.add "  return GENE_FFI_WRAPPER_UNIMPLEMENTED;"
      lines.add "  " & name & " = (" & repr.aotCType(structNames) & ")" &
        rawName & ";"
    of arkNone:
      discard
    if i >= fn.params.len - optionalTail:
      lines.add "  }"
  lines.add "  GeneNativeError native_error = {0};"
  lines.add "  " & fn.aotReturnRepr.aotCType(structNames) & " native_result = 0;"
  lines.add "  GeneNativeStatus native_status = " & nativeName & "(" &
    (@["&native_error"] & callArgs & @["&native_result"]).join(", ") & ");"
  # Acquisition rollback is no longer legal once the callee has executed:
  # transferred/copied resources may already have been consumed by its effects.
  lines.add "  if (native_status != GENE_NATIVE_OK) return gene_aot_report_error(ctx, &native_error);"
  lines.add "  gene_aot_error_clear(&native_error);"
  case fn.aotReturnRepr.kind
  of arkI64:
    lines.add "  return gene_ffi_result_int64(ctx, native_result, result);"
  of arkI32:
    lines.add "  return gene_ffi_result_int32(ctx, native_result, result);"
  of arkF64:
    lines.add "  return gene_ffi_result_double(ctx, native_result, result);"
  of arkCStr:
    lines.add "  return gene_ffi_result_cstr(ctx, native_result, result);"
  of arkNativePtr:
    let nativeType = fn.aotReturnRepr.nativeType
    case fn.nativeEntry.resultOwnership
    of noTransfer:
      lines.add "  return gene_typed_native_result_transfer(ctx, " &
        "(void *)native_result, " & cStringLiteral(nativeType.identity) &
        ", " & cStringLiteral(nativeType.abiIdentity) & ", " &
        cStringLiteral(nativeType.wrapperField) & ", " &
        (if fn.aotReturnRepr.nullable: "true" else: "false") & ", " &
        resultRelease & ", result);"
    of noCopy:
      lines.add "  return gene_typed_native_result_copy(ctx, " &
        "(void *)native_result, " & cStringLiteral(nativeType.identity) &
        ", " & cStringLiteral(nativeType.abiIdentity) & ", " &
        cStringLiteral(nativeType.wrapperField) & ", " &
        (if fn.aotReturnRepr.nullable: "true" else: "false") & ", " &
        resultCopy & ", " & resultRelease & ", result);"
    else:
      lines.add "  (void)result;"
      lines.add "  return GENE_FFI_WRAPPER_UNIMPLEMENTED;"
  else:
    lines.add "  (void)result;"
    lines.add "  return GENE_FFI_WRAPPER_UNIMPLEMENTED;"
  if fn.params.len > 0:
    lines.add entryName & "_arg_error:"
  for i in countdown(fn.params.high, 0):
    if i >= fn.aotParamReprs.len or
        fn.aotParamReprs[i].kind != arkNativePtr:
      continue
    let name = "gene_arg_" & $i
    let rawName = name & "_raw"
    case fn.nativeEntry.paramOwnership[i]
    of noTransfer:
      lines.add "  if (" & name & "_acquired)"
      lines.add "    gene_typed_native_arg_restore(ctx, call, " & $i & ", " &
        cStringLiteral(fn.aotParamReprs[i].nativeType.wrapperField) & ", " &
        rawName & ");"
    of noCopy:
      lines.add "  if (" & name & "_acquired && " & rawName & " != NULL)"
      lines.add "    " & paramReleases[i] & "(" & rawName & ");"
    else:
      discard
  if fn.params.len > 0:
    lines.add "  return status;"
  lines.add "}"
  lines.add "#endif"
  lines.add ""

proc addCBackend(lines: var seq[string], chunk: Chunk, prefix: string,
                 structNames: FfiStructCNames,
                 available: var Table[string, AotCFunction],
                 declaredStructs, definedStructs: var HashSet[string]) =
  var ffiLibraryRows: seq[FfiLibraryCRow]
  for library in chunk.ffiLibraries:
    ffiLibraryRows.add FfiLibraryCRow(name: library.name,
                                      linux: library.linux,
                                      macos: library.macos,
                                      windows: library.windows)
  if ffiLibraryRows.len > 0:
    let manifestName = ffiLibraryManifestName(prefix)
    lines.add "static const GeneFfiLibraryInfo " & manifestName &
      "[] GENE_MAYBE_UNUSED = {"
    for row in ffiLibraryRows:
      lines.add "  {" & cStringLiteral(row.name) & ", " &
        cStringLiteral(row.linux) & ", " & cStringLiteral(row.macos) &
        ", " & cStringLiteral(row.windows) & "},"
    lines.add "};"
    lines.add "static const size_t " & manifestName & "_count GENE_MAYBE_UNUSED = " &
      $ffiLibraryRows.len & ";"
    lines.add ""
  # Typed FFI prototypes may mention layout typedef names. Declare those names
  # before emitting any extern, then provide the complete definitions below.
  for structProto in chunk.ffiStructs:
    if structProto.layout == "C" and
        structProto.identity notin declaredStructs:
      let cStructName = ffiStructCName(structProto, structNames)
      lines.add "typedef struct " & cStructName & " " & cStructName & ";"
      declaredStructs.incl structProto.identity
  if chunk.ffiStructs.len > 0:
    lines.add ""
  var ffiFnRows: seq[FfiFnCRow]
  for i, fn in chunk.ffiFns:
    let retLabel =
      if fn.returnType.kind == vkNil: "C/Void" else: ffiTypeLabel(fn.returnType)
    ffiFnRows.add FfiFnCRow(
      name: fn.name,
      library: fn.library,
      libraryDeclared: fn.libraryDeclared,
      symbol: if fn.symbol.len > 0: fn.symbol else: fn.name,
      abi: if fn.abi.len > 0: fn.abi else: "C",
      calling: if fn.calling.len > 0: fn.calling else: "C",
      wrapperName: ffiWrapperName(fn, prefix & "ffi_" & $i),
      release: fn.release,
      arity: fn.params.len,
      resultType: retLabel)
    addFfiWrapper(lines, fn, i, prefix, structNames)
    let symbol = if fn.symbol.len > 0: fn.symbol else: fn.name
    var outFlags: seq[bool]
    var parameterNames: seq[string]
    var parameterReprs: seq[AotRepr]
    for p in fn.params:
      outFlags.add p.isOut
      parameterNames.add p.name
      var repr = fn.paramReprs[parameterReprs.len]
      if repr.kind == arkNone:
        case ffiTypeLabel(p.typeExpr)
        of "C/Int", "C/Int32": repr = AotRepr(kind: arkI32, typeName: "I32")
        of "C/Int64": repr = AotRepr(kind: arkI64, typeName: "I64")
        of "C/Double": repr = AotRepr(kind: arkF64, typeName: "F64")
        of "C/CStr": repr = AotRepr(kind: arkCStr, typeName: "Str")
        else: discard
      parameterReprs.add repr
    available[fn.name] = AotCFunction(
      geneName: fn.name,
      cName: cIdent(symbol, "ffi_symbol_" & $i),
      paramCount: fn.params.len,
      outParams: outFlags,
      paramNames: parameterNames,
      paramReprs: parameterReprs,
      returnRepr: fn.returnRepr,
      cType: (if fn.returnRepr.kind == arkNativePtr:
                fn.returnRepr.aotCType(structNames)
              else:
                ffiCType(retLabel)))
  if ffiFnRows.len > 0:
    let manifestName = ffiFnManifestName(prefix)
    ## External linkage for the same reason as the module manifest: a loader
    ## discovers each ffi/fn's generated wrapper through `wrapper_name` here.
    lines.add "const GeneFfiFnInfo " & manifestName &
      "[] GENE_MAYBE_UNUSED = {"
    for row in ffiFnRows:
      lines.add "  {" & cStringLiteral(row.name) & ", " &
        cStringLiteral(row.library) & ", " &
        (if row.libraryDeclared: "true" else: "false") & ", " &
        cStringLiteral(row.symbol) & ", " & cStringLiteral(row.abi) & ", " &
        cStringLiteral(row.calling) & ", " &
        cStringLiteral(row.wrapperName) & ", " &
        cStringLiteral(row.release) & ", " & $row.arity & ", " &
        cStringLiteral(row.resultType) & "},"
    lines.add "};"
    lines.add "const size_t " & manifestName & "_count GENE_MAYBE_UNUSED = " &
      $ffiFnRows.len & ";"
    lines.add ""
  var structRows: seq[FfiStructCRow]
  var structFieldRows: seq[FfiStructFieldCRow]
  for structProto in chunk.ffiStructs:
    let cStructName = ffiStructCName(structProto, structNames)
    if structProto.layout == "C" and structProto.identity notin definedStructs:
      lines.add "typedef struct " & cStructName & " {"
      for i, field in structProto.fields:
        ## A pointer field whose pointee layout is known renders as that
        ## struct's own C type rather than `void *`, so C's type system becomes
        ## a backstop for exactly the substitution this field's recorded
        ## identity prevents. A pointee that resolved to no layout — an ordinary
        ## C type, or an opaque foreign tag — keeps its previous rendering.
        var fieldType = ffiCType(ffiTypeLabel(field.typeExpr))
        if fieldType == "void *" and field.pointeeAbiIdentity.len > 0:
          for pointee in chunk.ffiStructs:
            if pointee.identity == field.pointeeAbiIdentity:
              fieldType = ffiStructCName(pointee, structNames) & " *"
              break
        lines.add "  " & fieldType & " " &
          cIdent(field.name, "field_" & $i) & ";"
      lines.add "} " & cStructName & ";"
      if structProto.hasSize:
        lines.add "_Static_assert(sizeof(" & cStructName & ") == " &
          $structProto.size & ", " &
          cStringLiteral("ffi/struct " & structProto.name & " size mismatch") &
          ");"
      if structProto.hasAlign:
        lines.add "_Static_assert(GENE_ALIGNOF(" & cStructName & ") == " &
          $structProto.align & ", " &
          cStringLiteral("ffi/struct " & structProto.name & " align mismatch") &
          ");"
      for field in structProto.fields:
        if field.hasOffset:
          lines.add "_Static_assert(offsetof(" & cStructName & ", " &
            cIdent(field.name, "field") & ") == " & $field.offset & ", " &
            cStringLiteral("ffi/struct " & structProto.name & "." &
              field.name & " offset mismatch") & ");"
      lines.add ""
      definedStructs.incl structProto.identity
    structRows.add FfiStructCRow(name: structProto.name,
                                 layout: structProto.layout,
                                 size: if structProto.hasSize: structProto.size else: -1,
                                 align: if structProto.hasAlign: structProto.align else: -1,
                                 fieldCount: structProto.fields.len)
    for field in structProto.fields:
      structFieldRows.add FfiStructFieldCRow(
        structName: structProto.name,
        fieldName: field.name,
        typeName: ffiTypeLabel(field.typeExpr),
        offset: if field.hasOffset: field.offset else: -1)
  if structRows.len > 0:
    let manifestName = ffiStructManifestName(prefix)
    lines.add "static const GeneFfiStructInfo " & manifestName &
      "[] GENE_MAYBE_UNUSED = {"
    for row in structRows:
      lines.add "  {" & cStringLiteral(row.name) & ", " &
        cStringLiteral(row.layout) & ", " & $row.size & ", " & $row.align &
        ", " & $row.fieldCount & "},"
    lines.add "};"
    lines.add "static const size_t " & manifestName & "_count GENE_MAYBE_UNUSED = " &
      $structRows.len & ";"
    let fieldManifestName = ffiStructFieldManifestName(prefix)
    lines.add "static const GeneFfiStructFieldInfo " & fieldManifestName &
      "[] GENE_MAYBE_UNUSED = {"
    for row in structFieldRows:
      lines.add "  {" & cStringLiteral(row.structName) & ", " &
        cStringLiteral(row.fieldName) & ", " & cStringLiteral(row.typeName) &
        ", " & $row.offset & "},"
    lines.add "};"
    lines.add "static const size_t " & fieldManifestName &
      "_count GENE_MAYBE_UNUSED = " &
      $structFieldRows.len & ";"
    lines.add ""
  var unionRows: seq[FfiUnionCRow]
  var unionFieldRows: seq[FfiUnionFieldCRow]
  for unionProto in chunk.ffiUnions:
    let cUnionName = cIdent(unionProto.name, "FfiUnion")
    if unionProto.layout == "C":
      lines.add "typedef union " & cUnionName & " {"
      for i, field in unionProto.fields:
        let fieldType = ffiCType(ffiTypeLabel(field.typeExpr))
        lines.add "  " & fieldType & " " &
          cIdent(field.name, "field_" & $i) & ";"
      lines.add "} " & cUnionName & ";"
      if unionProto.hasSize:
        lines.add "_Static_assert(sizeof(" & cUnionName & ") == " &
          $unionProto.size & ", " &
          cStringLiteral("ffi/union " & unionProto.name & " size mismatch") &
          ");"
      if unionProto.hasAlign:
        lines.add "_Static_assert(GENE_ALIGNOF(" & cUnionName & ") == " &
          $unionProto.align & ", " &
          cStringLiteral("ffi/union " & unionProto.name & " align mismatch") &
          ");"
      lines.add ""
    unionRows.add FfiUnionCRow(name: unionProto.name,
                               layout: unionProto.layout,
                               size: if unionProto.hasSize: unionProto.size else: -1,
                               align: if unionProto.hasAlign: unionProto.align else: -1,
                               fieldCount: unionProto.fields.len)
    for field in unionProto.fields:
      unionFieldRows.add FfiUnionFieldCRow(
        unionName: unionProto.name,
        fieldName: field.name,
        typeName: ffiTypeLabel(field.typeExpr))
  if unionRows.len > 0:
    let manifestName = ffiUnionManifestName(prefix)
    lines.add "static const GeneFfiUnionInfo " & manifestName &
      "[] GENE_MAYBE_UNUSED = {"
    for row in unionRows:
      lines.add "  {" & cStringLiteral(row.name) & ", " &
        cStringLiteral(row.layout) & ", " & $row.size & ", " & $row.align &
        ", " & $row.fieldCount & "},"
    lines.add "};"
    lines.add "static const size_t " & manifestName & "_count GENE_MAYBE_UNUSED = " &
      $unionRows.len & ";"
    let fieldManifestName = ffiUnionFieldManifestName(prefix)
    lines.add "static const GeneFfiUnionFieldInfo " & fieldManifestName &
      "[] GENE_MAYBE_UNUSED = {"
    for row in unionFieldRows:
      lines.add "  {" & cStringLiteral(row.unionName) & ", " &
        cStringLiteral(row.fieldName) & ", " & cStringLiteral(row.typeName) &
        "},"
    lines.add "};"
    lines.add "static const size_t " & fieldManifestName &
      "_count GENE_MAYBE_UNUSED = " &
      $unionFieldRows.len & ";"
    lines.add ""
  var signatureRows: seq[FfiSignatureCRow]
  for signature in chunk.ffiSignatures:
    var params: seq[string]
    for p in signature.params:
      params.add p.name & ":" & ffiTypeLabel(p.typeExpr)
    signatureRows.add FfiSignatureCRow(
      name: signature.name,
      kind: formatFfiSignatureKind(signature.kind),
      abi: signature.abi,
      params: params.join(","),
      resultType: if signature.returnType.kind == vkNil: "C/Void" else: ffiTypeLabel(signature.returnType),
      escaping: signature.escaping,
      runtimeConstructible: signature.runtimeConstructible)
  if signatureRows.len > 0:
    let manifestName = ffiSignatureManifestName(prefix)
    lines.add "static const GeneFfiSignatureInfo " & manifestName &
      "[] GENE_MAYBE_UNUSED = {"
    for row in signatureRows:
      lines.add "  {" & cStringLiteral(row.name) & ", " &
        cStringLiteral(row.kind) & ", " & cStringLiteral(row.abi) & ", " &
        cStringLiteral(row.params) & ", " & cStringLiteral(row.resultType) &
        ", " & (if row.escaping: "true" else: "false") & ", " &
        (if row.runtimeConstructible: "true" else: "false") & "},"
    lines.add "};"
    lines.add "static const size_t " & manifestName & "_count GENE_MAYBE_UNUSED = " &
      $signatureRows.len & ";"
    lines.add ""
  var monomorphRows: seq[MonomorphizationCRow]
  for spec in chunk.monomorphizations:
    var args: seq[string]
    for arg in spec.typeArgs:
      args.add ffiTypeLabel(arg)
    lines.add "/* monomorphize " & cIdent(prefix & spec.functionName,
      spec.functionName) & "<" & args.join(",") & "> */"
    monomorphRows.add MonomorphizationCRow(functionName: spec.functionName,
                                           typeArgs: args.join(","))
  if monomorphRows.len > 0:
    let manifestName = monomorphizationManifestName(prefix)
    lines.add "static const GeneMonomorphizationSpec " & manifestName &
      "[] GENE_MAYBE_UNUSED = {"
    for row in monomorphRows:
      lines.add "  {" & cStringLiteral(row.functionName) & ", " &
        cStringLiteral(row.typeArgs) & "},"
    lines.add "};"
    lines.add "static const size_t " & manifestName & "_count GENE_MAYBE_UNUSED = " &
      $monomorphRows.len & ";"
    lines.add ""
  var directRows: seq[DirectProtocolCRow]
  for spec in chunk.directProtocolCalls:
    let protocolName = ffiTypeLabel(spec.protocolExpr)
    let receiverName = ffiTypeLabel(spec.receiverExpr)
    lines.add "/* direct-protocol " & spec.messageName & " " &
      protocolName & "/" & receiverName & " */"
    directRows.add DirectProtocolCRow(messageName: spec.messageName,
                                      protocolName: protocolName,
                                      receiverName: receiverName)
  if directRows.len > 0:
    let manifestName = directProtocolManifestName(prefix)
    lines.add "static const GeneDirectProtocolCall " & manifestName &
      "[] GENE_MAYBE_UNUSED = {"
    for row in directRows:
      lines.add "  {" & cStringLiteral(row.messageName) & ", " &
        cStringLiteral(row.protocolName) & ", " &
        cStringLiteral(row.receiverName) & "},"
    lines.add "};"
    lines.add "static const size_t " & manifestName & "_count GENE_MAYBE_UNUSED = " &
      $directRows.len & ";"
    lines.add ""
  var taskFrameRows: seq[TaskFrameCRow]
  for fn in chunk.functions:
    if fn.taskFrameKind != tfkNone:
      taskFrameRows.add TaskFrameCRow(functionName: fn.name,
                                      kind: formatTaskFrameKind(fn.taskFrameKind),
                                      canSuspend: fn.taskFrameKind == tfkVm)
  if taskFrameRows.len > 0:
    let manifestName = taskFrameManifestName(prefix)
    lines.add "static const GeneTaskFrameInfo " & manifestName &
      "[] GENE_MAYBE_UNUSED = {"
    for row in taskFrameRows:
      lines.add "  {" & cStringLiteral(row.functionName) & ", " &
        cStringLiteral(row.kind) & ", " &
        (if row.canSuspend: "true" else: "false") & "},"
    lines.add "};"
    lines.add "static const size_t " & manifestName & "_count GENE_MAYBE_UNUSED = " &
      $taskFrameRows.len & ";"
    lines.add ""
  ## Only qualified `(recv .P:m)` sends are registered. A bare send is
  ## type-direct and is rejected by analysis; registering a protocol impl under
  ## a bare key here would let emission resolve what analysis refused.
  for implIndex, impl in chunk.implProtos:
    let protocolName = ffiTypeLabel(impl.protocolExpr)
    for messageIndex, message in impl.messages:
      let fn = message.fn
      let cType = fn.aotReturnRepr.aotCType(structNames)
      if fn.aotExpr.kind == vkNil or cType.len == 0 or
          fn.aotParamReprs.len == 0 or
          fn.aotParamReprs[0].kind != arkNativePtr:
        continue
      let cName = "gene_native_" & cIdent(
        prefix & "impl_" & $implIndex & "_" & message.name,
        "impl_" & $implIndex & "_message_" & $messageIndex)
      var params: seq[string]
      var representable = true
      for i, param in fn.params:
        let paramType =
          if i < fn.aotParamReprs.len:
            fn.aotParamReprs[i].aotCType(structNames)
          else:
            ""
        if paramType.len == 0:
          representable = false
          break
        params.add paramType & " " & cIdent(param, "arg" & $i)
      if not representable:
        continue
      let paramList = if params.len == 0: "void" else: params.join(", ")
      emitCheckedAotFunction(lines, fn, cName, available, structNames)
      let target = AotCFunction(cName: cName, paramCount: fn.params.len,
                                cType: cType, checked: true,
                                paramNames: fn.params, paramReprs: fn.aotParamReprs,
                                returnRepr: fn.aotReturnRepr, geneName: fn.name,
                                sourceLoc: fn.sourceLoc)
      let receiverIdentity = fn.aotParamReprs[0].nativeType.identity
      available[aotSendKey(receiverIdentity, protocolName, message.name)] = target
  var moduleFns: seq[AotModuleFunction]
  for i, fn in chunk.functions:
    let typeName = fn.aotTypeName
    let cType = fn.aotReturnRepr.aotCType(structNames)
    if fn.aotExpr.kind != vkNil and cType.len > 0:
      let fnName = cIdent(prefix & fn.name, "fn_" & $i)
      let cName = "gene_native_" & fnName
      let frameName = "gene_frame_" & fnName
      var frameFlags = "GENE_NATIVE_FRAME_TYPED"
      if fn.aotFrameCanSuspend:
        frameFlags.add " | GENE_NATIVE_FRAME_CAN_SUSPEND"
      var params: seq[string]
      for j, param in fn.params:
        let paramType =
          if j < fn.aotParamReprs.len:
            fn.aotParamReprs[j].aotCType(structNames)
          else: ""
        params.add paramType & " " & cIdent(param, "arg" & $j)
      let paramList = if params.len == 0: "void" else: params.join(", ")
      lines.add "static const GeneNativeFrameInfo " & frameName &
        " GENE_MAYBE_UNUSED = {" &
        cStringLiteral(fn.name) & ", " & frameFlags & "};"
      var fnAvailable = available
      fnAvailable[fn.name] = AotCFunction(cName: cName,
                                          paramCount: fn.params.len,
                                          cType: cType, checked: true,
                                          paramNames: fn.params,
                                          paramReprs: fn.aotParamReprs,
                                          returnRepr: fn.aotReturnRepr, geneName: fn.name,
                                          sourceLoc: fn.sourceLoc)
      emitCheckedAotFunction(lines, fn, cName, fnAvailable, structNames, frameName)
      let entryName =
        if fn.nativeEntry.enabled: nativeEntryName(fn.name, "fn_" & $i)
        else: ""
      if entryName.len > 0:
        addNativeEntry(lines, fn, cName, entryName, structNames)
      available[fn.name] = AotCFunction(cName: cName, paramCount: fn.params.len,
                                        cType: cType, checked: true,
                                        paramNames: fn.params,
                                        paramReprs: fn.aotParamReprs,
                                        returnRepr: fn.aotReturnRepr, geneName: fn.name,
                                        sourceLoc: fn.sourceLoc)
      moduleFns.add AotModuleFunction(geneName: fn.name, cName: cName,
                                      entryName: entryName,
                                      typeName: typeName,
                                      paramCount: fn.params.len,
                                      frameName: frameName)
    addCBackend(lines, fn.chunk, prefix & fn.name & "_", structNames,
                available, declaredStructs, definedStructs)
  if moduleFns.len > 0:
    let manifestName = aotModuleManifestName(prefix)
    ## The manifest is the module's public description of itself: an AOT
    ## loader dlsyms it to discover which functions carry a dynamic entry and
    ## what to bind them as. It must therefore have external linkage.
    lines.add "const GeneAotModuleFunction " & manifestName &
      "[] GENE_MAYBE_UNUSED = {"
    for fn in moduleFns:
      lines.add "  {" & cStringLiteral(fn.geneName) & ", " &
        cStringLiteral(fn.cName) & ", " & cStringLiteral(fn.entryName) & ", " &
        cStringLiteral(fn.typeName) & ", " &
        $fn.paramCount & ", &" & fn.frameName & "},"
    lines.add "};"
    lines.add "const size_t " & manifestName & "_count GENE_MAYBE_UNUSED = " &
      $moduleFns.len & ";"
    lines.add ""
  for i, sub in chunk.subchunks:
    addCBackend(lines, sub, prefix & "ns" & $i & "_", structNames,
                available, declaredStructs, definedStructs)

proc addCBackend(lines: var seq[string], chunk: Chunk,
                 structNames: FfiStructCNames, prefix = "") =
  var available = initTable[string, AotCFunction]()
  var declaredStructs = initHashSet[string]()
  var definedStructs = initHashSet[string]()
  addCBackend(lines, chunk, prefix, structNames, available,
              declaredStructs, definedStructs)

proc collectNativeTypeRequirements(chunk: Chunk,
                                   found: var OrderedTable[string, NativeTypeProto]) =
  ## Every native Type this module's compiled code depends on, *transitively*:
  ## not only the ones that cross the dynamic boundary, but every one whose
  ## layout the emitted code dereferences.
  ##
  ## This is the difference between a check that works and one that looks like
  ## it does. Compiled code that takes a `Parent` and reads `parent/child/value`
  ## presents only `Parent` at the boundary; `Node`'s offsets are baked in and
  ## nothing would ever validate them.
  template note(proto: NativeTypeProto) =
    let candidate = proto
    if candidate != nil and candidate.identity.len > 0 and
        not found.hasKey(candidate.identity):
      found[candidate.identity] = candidate

  template noteRepr(repr: AotRepr) =
    let r = repr
    if r.kind == arkNativePtr:
      note(r.nativeType)

  for typeProto in chunk.typeProtos:
    note(typeProto.nativeType)
  for fn in chunk.functions:
    noteRepr(fn.aotReturnRepr)
    for repr in fn.aotParamReprs:
      noteRepr(repr)
    for local in fn.aotLocals:
      noteRepr(local.repr)
    collectNativeTypeRequirements(fn.chunk, found)
  for impl in chunk.implProtos:
    for message in impl.messages:
      noteRepr(message.fn.aotReturnRepr)
      for repr in message.fn.aotParamReprs:
        noteRepr(repr)
      for local in message.fn.aotLocals:
        noteRepr(local.repr)
  for child in chunk.subchunks:
    collectNativeTypeRequirements(child, found)

proc collectLayoutRequirements(chunk: Chunk,
                               found: var OrderedTable[string, FfiStructProto]) =
  for layout in chunk.ffiStructs:
    if layout.identity.len > 0 and not found.hasKey(layout.identity):
      found[layout.identity] = layout
  for fn in chunk.functions:
    collectLayoutRequirements(fn.chunk, found)
  for child in chunk.subchunks:
    collectLayoutRequirements(child, found)

proc addNativeTypeManifests(lines: var seq[string], chunk: Chunk,
                            structNames: FfiStructCNames) =
  ## Two exported manifests. Exported deliberately: `gene_ffi_structs` has
  ## internal linkage and is therefore invisible to a loader, which is why no
  ## such check was possible before.
  var types = initOrderedTable[string, NativeTypeProto]()
  collectNativeTypeRequirements(chunk, types)
  var layouts = initOrderedTable[string, FfiStructProto]()
  collectLayoutRequirements(chunk, layouts)

  ## Emitted unconditionally, including for a library with no native types at
  ## all. Its *presence* is what distinguishes a library built with ABI
  ## validation from one built before it -- a library with zero native types
  ## and a stale library would otherwise look identical, and the loader has to
  ## reject the second while accepting the first.
  lines.add "const size_t gene_aot_manifest_version GENE_MAYBE_UNUSED = " &
    $AotManifestVersion & ";"
  lines.add ""
  if types.len > 0:
    lines.add "const GeneAotNativeType gene_aot_native_types[] GENE_MAYBE_UNUSED = {"
    for _, proto in types:
      lines.add "  {" & cStringLiteral(proto.identity) & ", " &
        cStringLiteral(proto.abiIdentity) & ", " &
        cStringLiteral(proto.abiFingerprint) & ", " &
        cStringLiteral(proto.contractFingerprint) & "},"
    lines.add "};"
    lines.add "const size_t gene_aot_native_types_count GENE_MAYBE_UNUSED = " &
      $types.len & ";"
    lines.add ""

  ## Measured layouts: the C compiler fills these in, so they capture drift a
  ## declaration cannot -- a different `C/Long` width, say. The host VM never
  ## lays out C structs itself, so their use is comparing two libraries that
  ## declare the same layout identity.
  var measuredRows: seq[string]
  var fieldRows: seq[string]
  for identity, layout in layouts:
    if layout.layout != "C":
      continue
    let cName = ffiStructCName(layout, structNames)
    measuredRows.add "  {" & cStringLiteral(identity) & ", " &
      cStringLiteral(layout.fingerprint) & ", sizeof(" & cName &
      "), GENE_ALIGNOF(" & cName & ")},"
    for i, field in layout.fields:
      fieldRows.add "  {" & cStringLiteral(identity) & ", " &
        cStringLiteral(field.name) & ", offsetof(" & cName & ", " &
        cIdent(field.name, "field_" & $i) & ")},"
  if measuredRows.len > 0:
    lines.add "const GeneAotAbiLayout gene_aot_abi_layouts[] GENE_MAYBE_UNUSED = {"
    for row in measuredRows:
      lines.add row
    lines.add "};"
    lines.add "const size_t gene_aot_abi_layouts_count GENE_MAYBE_UNUSED = " &
      $measuredRows.len & ";"
    lines.add "const GeneAotAbiLayoutField gene_aot_abi_layout_fields[] GENE_MAYBE_UNUSED = {"
    for row in fieldRows:
      lines.add row
    lines.add "};"
    lines.add "const size_t gene_aot_abi_layout_fields_count GENE_MAYBE_UNUSED = " &
      $fieldRows.len & ";"
    lines.add ""

const NativeIntegerRuntime = staticRead("native_integer.h")
const NativeCheckedRuntime = staticRead("native_checked.h").replace("#include \"native_integer.h\"", "")

proc emitNativeCHeader*(): string =
  ## Also available from an installed CLI; C callers need no source checkout.
  NativeIntegerRuntime & "\n" & NativeCheckedRuntime & "\n"

proc emitExperimentalC*(chunk: Chunk): string =
  var lines = @[
    "/* Gene experimental typed_native C backend.",
    " * Emits fixed-representation functions and generated FFI adapter wrappers.",
    " *",
    " * Self-contained functions can link without a Gene host. Dynamic entries",
    " * and checked native boundaries use gene_ffi_* / gene_typed_native_*",
    " * helpers exported by src/gene/aot_runtime.nim. Define",
    " * GENE_AOT_DYNAMIC_ENTRIES when building a library for aot/load and",
    " * export those helpers from its host executable (see nim.cfg).",
    " * This backend accepts an experimental subset; consult docs/development.md",
    " * for current semantic and platform limits.",
    " */",
    "#include <stdbool.h>",
    "#include <stddef.h>",
    "#include <stdint.h>",
    # Unconditional rather than emitted only when a `$math/...` call lowered.
    # Deciding that would mean walking every function's body a second time to
    # answer a question whose wrong answer is a link error, and `<math.h>`
    # declares functions without defining anything — an unused include costs a
    # header parse. Callers still need `-lm` where the platform separates it.
    "#include <math.h>",
    "",
    "/* Gene evaluates every floating-point operation separately, so the",
    " * compiled form has to as well. C compilers may contract `a * b + c` into",
    " * a fused multiply-add by default (Clang's -ffp-contract=on), which",
    " * rounds once instead of twice: more accurate, and a different number.",
    " *",
    " * That is not a tolerable difference. A lowered function is supposed to",
    " * be the same function -- a deterministic world generator compiled this",
    " * way would produce different terrain from the interpreter, and a shared",
    " * fixture would start failing with no bug to find. Measured on",
    " * examples/miclone's noise kernels: 405 of 4000 values differed with",
    " * contraction on, and none with it off.",
    " *",
    " * The pragma is standard C99 and Clang honours it. GCC's support is",
    " * incomplete, so builds there should also pass -ffp-contract=off rather",
    " * than rely on this alone. */",
    "#pragma STDC FP_CONTRACT OFF",
    "typedef struct GeneContext GeneContext;",
    "typedef struct GeneCall GeneCall;",
    "typedef struct GeneValue GeneValue;",
    "typedef int GeneStatus;",
    "typedef struct GeneNativeFrameInfo {",
    "  const char *name;",
    "  unsigned flags;",
    "} GeneNativeFrameInfo;",
    "typedef struct GeneAotModuleFunction {",
    "  const char *gene_name;",
    "  const char *c_symbol;",
    "  const char *entry_symbol;",
    "  const char *repr;",
    "  int arity;",
    "  const GeneNativeFrameInfo *frame;",
    "} GeneAotModuleFunction;",
    "/* One row per native Type this library's compiled code depends on,",
    " * transitively -- not merely those crossing the dynamic boundary. The",
    " * contract fingerprint is authoritative; the other two exist so a loader",
    " * can say which part drifted. */",
    "typedef struct GeneAotNativeType {",
    "  const char *type_identity;",
    "  const char *abi_identity;",
    "  const char *abi_fingerprint;",
    "  const char *contract_fingerprint;",
    "} GeneAotNativeType;",
    "typedef struct GeneAotAbiLayout {",
    "  const char *abi_identity;",
    "  const char *fingerprint;",
    "  size_t measured_size;",
    "  size_t measured_align;",
    "} GeneAotAbiLayout;",
    "typedef struct GeneAotAbiLayoutField {",
    "  const char *abi_identity;",
    "  const char *field_name;",
    "  size_t measured_offset;",
    "} GeneAotAbiLayoutField;",
    "typedef struct GeneMonomorphizationSpec {",
    "  const char *function_name;",
    "  const char *type_args;",
    "} GeneMonomorphizationSpec;",
    "typedef struct GeneDirectProtocolCall {",
    "  const char *message_name;",
    "  const char *protocol;",
    "  const char *receiver;",
    "} GeneDirectProtocolCall;",
    "typedef struct GeneTaskFrameInfo {",
    "  const char *function_name;",
    "  const char *kind;",
    "  bool can_suspend;",
    "} GeneTaskFrameInfo;",
    "typedef struct GeneFfiLibraryInfo {",
    "  const char *name;",
    "  const char *linux;",
    "  const char *macos;",
    "  const char *windows;",
    "} GeneFfiLibraryInfo;",
    "typedef struct GeneFfiFnInfo {",
    "  const char *name;",
    "  const char *library;",
    "  bool library_declared;",
    "  const char *symbol;",
    "  const char *abi;",
    "  const char *calling;",
    "  const char *wrapper_name;",
    "  const char *release;",
    "  size_t arity;",
    "  const char *result_type;",
    "} GeneFfiFnInfo;",
    "typedef struct GeneFfiStructInfo {",
    "  const char *name;",
    "  const char *layout;",
    "  int size;",
    "  int align;",
    "  size_t field_count;",
    "} GeneFfiStructInfo;",
    "typedef struct GeneFfiStructFieldInfo {",
    "  const char *struct_name;",
    "  const char *field_name;",
    "  const char *type_name;",
    "  int offset;",
    "} GeneFfiStructFieldInfo;",
    "typedef struct GeneFfiUnionInfo {",
    "  const char *name;",
    "  const char *layout;",
    "  int size;",
    "  int align;",
    "  size_t field_count;",
    "} GeneFfiUnionInfo;",
    "typedef struct GeneFfiUnionFieldInfo {",
    "  const char *union_name;",
    "  const char *field_name;",
    "  const char *type_name;",
    "} GeneFfiUnionFieldInfo;",
    "typedef struct GeneFfiSignatureInfo {",
    "  const char *name;",
    "  const char *kind;",
    "  const char *abi;",
    "  const char *params;",
    "  const char *result_type;",
    "  bool escaping;",
    "  bool runtime_constructible;",
    "} GeneFfiSignatureInfo;",
    "typedef struct GeneFfiAbiTypeInfo {",
    "  const char *gene_type;",
    "  const char *c_type;",
    "  size_t size;",
    "  size_t align;",
    "} GeneFfiAbiTypeInfo;",
    "typedef struct GeneFfiBufferView {",
    "  const void *data;",
    "  size_t len;",
    "} GeneFfiBufferView;",
    "/* Opaque handle to context-owned marshalling storage for one Buffer",
    " * argument. The bytes it names outlive the argument helper and are",
    " * written back to the Gene value at gene_ffi_buffer_finalize. */",
    "typedef size_t GeneFfiBufferLease;",
    "#define GENE_NATIVE_FRAME_TYPED (1u << 0)",
    "#define GENE_NATIVE_FRAME_CAN_SUSPEND (1u << 1)",
    "#define GENE_ALIGNOF(T) offsetof(struct { char c; T x; }, x)",
    "#ifndef GENE_FFI_CDECL",
    "#if defined(_MSC_VER)",
    "#define GENE_FFI_CDECL __cdecl",
    "#else",
    "#define GENE_FFI_CDECL",
    "#endif",
    "#endif",
    "#ifndef GENE_FFI_STDCALL",
    "#if defined(_WIN32) && (defined(_MSC_VER) || defined(__GNUC__))",
    "#define GENE_FFI_STDCALL __stdcall",
    "#else",
    "#define GENE_FFI_STDCALL",
    "#endif",
    "#endif",
    "#ifndef GENE_OK",
    "#define GENE_OK 0",
    "#endif",
    "#ifndef GENE_ERROR",
    "#define GENE_ERROR 1",
    "#endif",
    "#ifndef GENE_PANIC",
    "#define GENE_PANIC 2",
    "#endif",
    "#ifndef GENE_FFI_WRAPPER_UNIMPLEMENTED",
    "#define GENE_FFI_WRAPPER_UNIMPLEMENTED (-1)",
    "#endif",
    "#ifndef GENE_MAYBE_UNUSED",
    "#if defined(__GNUC__) || defined(__clang__)",
    "#define GENE_MAYBE_UNUSED __attribute__((unused))",
    "#else",
    "#define GENE_MAYBE_UNUSED",
    "#endif",
    "#endif",
    "extern GeneStatus gene_typed_native_arg_borrow(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, const char *type_identity, const char *abi_identity, const char *handle_field, bool nullable, void **out);",
    "extern GeneStatus gene_typed_native_arg_transfer(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, const char *type_identity, const char *abi_identity, const char *handle_field, bool nullable, void **out);",
    "extern void gene_typed_native_arg_restore(GeneContext *ctx, const GeneCall *call, size_t index, const char *handle_field, void *value);",
    "typedef void *(*GeneTypedNativeCopyFn)(const void *value);",
    "extern GeneStatus gene_typed_native_arg_copy(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, const char *type_identity, const char *abi_identity, const char *handle_field, bool nullable, GeneTypedNativeCopyFn copy, void **out);",
    "typedef void (*GeneTypedNativeReleaseFn)(void *value);",
    "extern GeneStatus gene_typed_native_result_transfer(GeneContext *ctx, void *value, const char *type_identity, const char *abi_identity, const char *handle_field, bool nullable, GeneTypedNativeReleaseFn release, GeneValue *out);",
    "extern GeneStatus gene_typed_native_result_copy(GeneContext *ctx, const void *value, const char *type_identity, const char *abi_identity, const char *handle_field, bool nullable, GeneTypedNativeCopyFn copy, GeneTypedNativeReleaseFn release, GeneValue *out);",
    "extern GeneStatus gene_ffi_check_arity(GeneContext *ctx, const GeneCall *call, size_t expected);",
    "extern GeneStatus gene_ffi_check_arity_range(GeneContext *ctx, const GeneCall *call, size_t minimum, size_t maximum, size_t *provided);",
    "extern GeneStatus gene_ffi_arg_int8(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, int8_t *out);",
    "extern GeneStatus gene_ffi_arg_uint8(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, uint8_t *out);",
    "extern GeneStatus gene_ffi_arg_int16(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, int16_t *out);",
    "extern GeneStatus gene_ffi_arg_uint16(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, uint16_t *out);",
    "extern GeneStatus gene_ffi_arg_int32(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, int32_t *out);",
    "extern GeneStatus gene_ffi_arg_uint32(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, uint32_t *out);",
    "extern GeneStatus gene_ffi_arg_int64(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, int64_t *out);",
    "extern GeneStatus gene_ffi_arg_uint64(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, uint64_t *out);",
    "extern GeneStatus gene_ffi_arg_char(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, char *out);",
    "extern GeneStatus gene_ffi_arg_uchar(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, unsigned char *out);",
    "extern GeneStatus gene_ffi_arg_short(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, short *out);",
    "extern GeneStatus gene_ffi_arg_ushort(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, unsigned short *out);",
    "extern GeneStatus gene_ffi_arg_int(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, int *out);",
    "extern GeneStatus gene_ffi_arg_uint(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, unsigned int *out);",
    "extern GeneStatus gene_ffi_arg_long(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, long *out);",
    "extern GeneStatus gene_ffi_arg_ulong(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, unsigned long *out);",
    "extern GeneStatus gene_ffi_arg_size(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, size_t *out);",
    "extern GeneStatus gene_ffi_arg_ptrdiff(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, ptrdiff_t *out);",
    "extern GeneStatus gene_ffi_arg_float(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, float *out);",
    "extern GeneStatus gene_ffi_arg_double(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, double *out);",
    "extern GeneStatus gene_ffi_arg_bool(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, bool *out);",
    "extern GeneStatus gene_ffi_arg_cstr(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, const char **out);",
    "extern GeneStatus gene_ffi_arg_ptr(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, const char *type_name, void **out);",
    "extern GeneStatus gene_ffi_arg_const_ptr(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, const char *type_name, const void **out);",
    "extern GeneStatus gene_ffi_arg_slice(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, const char *type_name, GeneFfiBufferView *out);",
    "extern GeneStatus gene_ffi_arg_buffer(GeneContext *ctx, const GeneCall *call, size_t index, const char *name, const char *type_name, GeneFfiBufferView *out, GeneFfiBufferLease *lease);",
    "extern void gene_ffi_buffer_finalize(GeneContext *ctx, GeneFfiBufferLease lease);",
    "extern GeneStatus gene_ffi_result_void(GeneContext *ctx, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_int8(GeneContext *ctx, int8_t value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_uint8(GeneContext *ctx, uint8_t value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_int16(GeneContext *ctx, int16_t value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_uint16(GeneContext *ctx, uint16_t value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_int32(GeneContext *ctx, int32_t value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_uint32(GeneContext *ctx, uint32_t value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_int64(GeneContext *ctx, int64_t value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_uint64(GeneContext *ctx, uint64_t value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_char(GeneContext *ctx, char value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_uchar(GeneContext *ctx, unsigned char value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_short(GeneContext *ctx, short value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_ushort(GeneContext *ctx, unsigned short value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_int(GeneContext *ctx, int value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_uint(GeneContext *ctx, unsigned int value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_long(GeneContext *ctx, long value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_ulong(GeneContext *ctx, unsigned long value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_size(GeneContext *ctx, size_t value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_ptrdiff(GeneContext *ctx, ptrdiff_t value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_float(GeneContext *ctx, float value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_double(GeneContext *ctx, double value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_bool(GeneContext *ctx, bool value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_cstr(GeneContext *ctx, const char *value, GeneValue *result);",
    "extern GeneStatus gene_ffi_result_ptr(GeneContext *ctx, void *value, const char *type_name, GeneTypedNativeReleaseFn release, GeneValue *result);",
    "_Static_assert(sizeof(int8_t) == 1, \"C/Int8 must be 1 byte\");",
    "_Static_assert(sizeof(uint8_t) == 1, \"C/UInt8 must be 1 byte\");",
    "_Static_assert(sizeof(int16_t) == 2, \"C/Int16 must be 2 bytes\");",
    "_Static_assert(sizeof(uint16_t) == 2, \"C/UInt16 must be 2 bytes\");",
    "_Static_assert(sizeof(int32_t) == 4, \"C/Int32 must be 4 bytes\");",
    "_Static_assert(sizeof(uint32_t) == 4, \"C/UInt32 must be 4 bytes\");",
    "_Static_assert(sizeof(int64_t) == 8, \"C/Int64 must be 8 bytes\");",
    "_Static_assert(sizeof(uint64_t) == 8, \"C/UInt64 must be 8 bytes\");",
    "static const GeneFfiAbiTypeInfo gene_ffi_abi_types[] GENE_MAYBE_UNUSED = {",
    "  {\"C/Int8\", \"int8_t\", sizeof(int8_t), GENE_ALIGNOF(int8_t)},",
    "  {\"C/UInt8\", \"uint8_t\", sizeof(uint8_t), GENE_ALIGNOF(uint8_t)},",
    "  {\"C/Int16\", \"int16_t\", sizeof(int16_t), GENE_ALIGNOF(int16_t)},",
    "  {\"C/UInt16\", \"uint16_t\", sizeof(uint16_t), GENE_ALIGNOF(uint16_t)},",
    "  {\"C/Int32\", \"int32_t\", sizeof(int32_t), GENE_ALIGNOF(int32_t)},",
    "  {\"C/UInt32\", \"uint32_t\", sizeof(uint32_t), GENE_ALIGNOF(uint32_t)},",
    "  {\"C/Int64\", \"int64_t\", sizeof(int64_t), GENE_ALIGNOF(int64_t)},",
    "  {\"C/UInt64\", \"uint64_t\", sizeof(uint64_t), GENE_ALIGNOF(uint64_t)},",
    "  {\"C/Char\", \"char\", sizeof(char), GENE_ALIGNOF(char)},",
    "  {\"C/UChar\", \"unsigned char\", sizeof(unsigned char), GENE_ALIGNOF(unsigned char)},",
    "  {\"C/Short\", \"short\", sizeof(short), GENE_ALIGNOF(short)},",
    "  {\"C/UShort\", \"unsigned short\", sizeof(unsigned short), GENE_ALIGNOF(unsigned short)},",
    "  {\"C/Int\", \"int\", sizeof(int), GENE_ALIGNOF(int)},",
    "  {\"C/UInt\", \"unsigned int\", sizeof(unsigned int), GENE_ALIGNOF(unsigned int)},",
    "  {\"C/Long\", \"long\", sizeof(long), GENE_ALIGNOF(long)},",
    "  {\"C/ULong\", \"unsigned long\", sizeof(unsigned long), GENE_ALIGNOF(unsigned long)},",
    "  {\"C/Size\", \"size_t\", sizeof(size_t), GENE_ALIGNOF(size_t)},",
    "  {\"C/PtrDiff\", \"ptrdiff_t\", sizeof(ptrdiff_t), GENE_ALIGNOF(ptrdiff_t)},",
    "  {\"C/Float\", \"float\", sizeof(float), GENE_ALIGNOF(float)},",
    "  {\"C/Double\", \"double\", sizeof(double), GENE_ALIGNOF(double)},",
    "  {\"C/Bool\", \"bool\", sizeof(bool), GENE_ALIGNOF(bool)},",
    "  {\"C/CStr\", \"const char *\", sizeof(const char *), GENE_ALIGNOF(const char *)},",
    "};",
    "static const size_t gene_ffi_abi_types_count GENE_MAYBE_UNUSED = 22;",
    ""
  ]
  lines.add NativeIntegerRuntime
  lines.add NativeCheckedRuntime
  lines.add """
#ifdef GENE_AOT_DYNAMIC_ENTRIES
extern GeneStatus gene_ffi_native_error(GeneContext *, int, const char *,
  const char *, int, const char *, double, bool, const char *,
  const GeneNativeTraceFrame *, size_t, size_t);
GENE_AOT_INLINE GeneStatus gene_aot_report_error(GeneContext *ctx, GeneNativeError *error) {
  char *integer = NULL;
  if (error->actual_kind == GENE_NATIVE_INT || error->actual_kind == GENE_NATIVE_CHAR) {
    integer = gene_aot_int_decimal(&error->actual_int);
    if (integer == NULL) error->status = GENE_NATIVE_NO_MEMORY;
  }
  GeneStatus status = gene_ffi_native_error(ctx, (int)error->status,
    error->where, error->expected, (int)error->actual_kind, integer,
    error->actual_float, error->actual_bool, error->actual_string,
    error->frames, error->frame_count, error->omitted_frames);
  free(integer);
  gene_aot_error_clear(error);
  return status;
}
#endif
"""
  let headerLen = lines.len
  let structNames = buildFfiStructCNames(chunk)
  addCBackend(lines, chunk, structNames)
  addNativeTypeManifests(lines, chunk, structNames)
  if lines.len == headerLen:
    lines.add "/* no fixed-representation native functions or FFI wrappers */"
  lines.add "/* Gene generated module end. */"
  lines.join("\n")

const scopelessOps = {
  opNoop, opPushConst, opPop, opNot,
  opLoadLocal, opLoadLocalFast,
  opJump, opJumpIfFalse, opJumpIfFalseOrPop, opJumpIfTrueOrPop,
  opJumpIfPresentOrPop, opJumpIfAbsent,
  opIntAdd2, opReturnIntAdd2, opIntSub2, opIntMul2,
  opIntLt2, opIntGt2, opIntLe2, opIntGe2,
  opIntAddConst, opIntSubConst, opIntMulConst,
  opIntLtConst, opIntGtConst, opIntLeConst, opIntGeConst,
  opIntFast2, opIntFastConst, opNativeFast2, opNativeFastConst,
  # Stack-only constructors carrying all data on the instruction itself
  # (opMakeListSplice is excluded: it indexes chunk.listBuilds, which the
  # derived scopeless chunk does not copy).
  opMakeList, opMakeMap,
  opExplicitReturn, opReturn, opReturnBareInt}

proc deriveScopelessChunk*(proto: FunctionProto) =
  ## Scopeless calling convention: a leaf, param-only, untyped body can run
  ## with the CALLER's scope register — arguments stay on the shared operand
  ## stack and opLoadArg reads them at base+index — so the call needs no scope
  ## acquire/bind/release at all. The original chunk stays intact for every
  ## scope-based entry point (applyCall, actors, fibers, protocol dispatch);
  ## only the VM's direct-call fast path uses scopelessChunk, so a call path
  ## without the integration degrades to the classic convention instead of
  ## misreading the stack.
  # Typed admission: all-bare-Int params with a body-proven Int return
  # (fastBind*Int + returnKnownBareInt) are as scopeless-safe as untyped —
  # binding-time adaptation reduces to "each arg is vkInt", which the VM
  # sites check on the stack (or trust inst.flag for compile-time-proven
  # int args) and otherwise fall back to the classic convention, whose
  # binding raises the canonical parameter type error.
  let typedIntOk =
    (proto.fastBindUnaryInt or proto.fastBindPositionalInt) and
    proto.returnKnownBareInt
  if proto.isGenerator or proto.isSyntaxFn or proto.checksErrors or
      not (proto.simpleCall or typedIntOk) or proto.restParam.len != 0 or
      proto.namedParams.len != 0 or proto.typeParams.len != 0 or
      (proto.hasParamTypes and not typedIntOk) or
      (proto.hasReturnType and not typedIntOk) or
      proto.requiredPositional != proto.params.len or
      proto.localNames.len != proto.params.len:
    return
  for i, slot in proto.positionalSlots:
    if slot != i:
      return
  let chunk = proto.chunk
  if chunk == nil or chunk.functions.len != 0 or chunk.subchunks.len != 0:
    return
  for inst in chunk.instructions:
    if inst.op notin scopelessOps:
      return
    if inst.op in {opLoadLocal, opLoadLocalFast} and
        (inst.intArg < 0 or inst.intArg >= proto.params.len):
      return
  var rewritten = chunk.instructions
  for i in 0 ..< rewritten.len:
    if rewritten[i].op in {opLoadLocal, opLoadLocalFast}:
      rewritten[i].op = opLoadArg
  let alt = newChunk(chunk.sourceName)
  alt.constants = chunk.constants
  alt.instructions = move rewritten
  alt.instructionLocs = chunk.instructionLocs
  alt.localNames = chunk.localNames
  alt.owner = proto
  proto.scopelessNeedsIntArgs = proto.hasParamTypes
  proto.scopelessChunk = alt
