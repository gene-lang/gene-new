## Gene standard library surface (docs/stdlib.md).
##
## This file is `include`d by vm.nim after the core native helpers are
## defined: the stdlib natives use the VM's require*/applyCall/raise* helpers
## and the socket imports from vm.nim's prelude. Everything user-facing here
## is registered by `registerStdlibNamespaces`, which buildBuiltins calls on
## the built-ins root scope; nothing in this file touches VM dispatch state.

include ./ext/term/stdlib_term_decls

proc biIoFlushStdout(args: openArray[Value]): Value {.nimcall.} =
  if args.len != 0:
    raise newException(GeneError, "io/flush_stdout takes no arguments")
  when not defined(geneWasm): stdout.flushFile()
  NIL

# --- plain filesystem operations ---------------------------------------------
# Thin wrappers over std/os shared by the `fs` natives, the fs-backed `Store`,
# the HTTP client's CA file, and the file logger. Failures surface as OSError or
# IOError; each native maps them to Gene errors at its own boundary.

proc fsReadBytes(path: string): string = readFile(path)

type FsTextPage = object
  text: string
  lastLine, nextLine: int
  binary, truncated: bool

proc fsReadTextPage(path: string, first, lines, maxBytes: int,
                    cancelled: proc(): bool {.gcsafe.} = nil): FsTextPage =
  let file = open(path, fmRead)
  defer: file.close()
  var buffer: array[65536, char]
  var line = 1
  var finished = false
  let last = first + lines - 1
  result.lastLine = first - 1
  while true:
    if cancelled != nil and cancelled(): return
    let count = file.readBuffer(addr buffer[0], buffer.len)
    if count == 0: break
    for index in 0..<count:
      let ch = buffer[index]
      if ch == '\0':
        result.binary = true
        result.text.setLen(0)
        return
      if line >= first:
        if result.text.len >= maxBytes:
          result.truncated = true
          result.nextLine = line + 1
          break
        result.text.add ch
        result.lastLine = line
      if ch == '\n':
        if line >= last:
          var extra: char
          if index + 1 < count or file.readBuffer(addr extra, 1) > 0:
            result.nextLine = line + 1
          finished = true
          break
        inc line
    if result.truncated or finished: break
  if result.text.endsWith("\n"):
    result.text.setLen(result.text.len - 1)
    if result.text.endsWith("\r"): result.text.setLen(result.text.len - 1)
  if result.truncated:
    for _ in 0..<4:
      let invalid = validateUtf8(result.text)
      if invalid < 0 or invalid < result.text.len - 4: break
      result.text.setLen(result.text.len - 1)
  result.binary = validateUtf8(result.text) >= 0
  if result.binary: result.text.setLen(0)

proc fsTextPageValue(page: FsTextPage, first: int): Value =
  var props = initPropTable()
  props["text"] = newStr(page.text)
  props["from"] = newInt(first)
  props["to"] = newInt(page.lastLine)
  props["next"] = if page.nextLine > 0: newInt(page.nextLine) else: NIL
  props["binary"] = newBool(page.binary)
  props["truncated"] = newBool(page.truncated)
  newMap(props)

proc fsWriteBytes(path, content: string) = writeFile(path, content)

var fsAtomicWriteCounter {.threadvar.}: int

proc fsWriteAtomic(path, content: string, ownerOnly = false) =
  ## Write a sibling temporary file, flush it to disk, then rename it over the
  ## destination, so a reader sees the old or the new contents and never a
  ## partial write. A failure leaves the destination untouched. `ownerOnly`
  ## restricts the file to its owner before any content is written.
  inc fsAtomicWriteCounter
  let temporary = path & ".gene-tmp-" & $getCurrentProcessId() & "-" &
    $nativeCallbackLane() & "-" & $fsAtomicWriteCounter
  try:
    var file = open(temporary, fmWrite)
    try:
      if ownerOnly:
        setFilePermissions(temporary, {fpUserRead, fpUserWrite})
      file.write(content)
      file.flushFile()
      when defined(posix) and not defined(emscripten) and not defined(geneWasm):
        if posix.fsync(getFileHandle(file)) != 0:
          raiseOSError(osLastError())
    finally:
      file.close()
    moveFile(temporary, path)
  except CatchableError:
    if fileExists(temporary):
      try: os.removeFile(temporary)
      except CatchableError: discard
    raise

proc fsPathExists(path: string): bool =
  fileExists(path) or dirExists(path) or symlinkExists(path)

proc fsListDir(path: string): seq[string] =
  if not dirExists(path):
    raise newException(OSError, "not a directory: " & path)
  for _, name in walkDir(path, relative = true):
    result.add name
  result.sort()

proc fsMakeDir(path: string) = createDir(path)

proc fsRemoveFile(path: string) =
  if fileExists(path) or symlinkExists(path):
    os.removeFile(path)

proc fsRemoveDir(path: string) =
  ## Removes an empty directory; a missing one is not an error.
  when defined(posix) and not defined(emscripten) and not defined(geneWasm):
    if posix.rmdir(path.cstring) != 0 and errno != ENOENT:
      raiseOSError(osLastError())
  else:
    if dirExists(path):
      os.removeDir(path)

proc fsRestrictDirToOwner(path: string) =
  setFilePermissions(path, {fpUserRead, fpUserWrite, fpUserExec})

proc fsRealPath(path: string): string =
  ## Absolute, symlink-resolved form of a path. A path that does not exist yet
  ## resolves its longest existing ancestor and reattaches the remaining
  ## suffix, so a to-be-created file still resolves correctly. A final symlink
  ## is followed even when its target does not exist yet, so a dangling symlink
  ## resolves to where it would actually write.
  var p = if path.len > 0: path else: "."
  # Follow a chain of final symlinks whose target may not exist (a dangling
  # link fails fileExists/dirExists but symlinkExists still sees it). Bounded
  # against loops.
  var hops = 0
  while symlinkExists(p) and not (fileExists(p) or dirExists(p)):
    var target = expandSymlink(p)
    if not isAbsolute(target):
      target = parentDir(absolutePath(p)) / target
    p = target
    inc hops
    if hops > 64:
      break
  if fileExists(p) or dirExists(p):
    return expandFilename(p)
  var base = normalizedPath(absolutePath(p))
  var tail: seq[string]
  while base.len > 0 and not dirExists(base):
    let (head, name) = splitPath(base)
    if head == base or head.len == 0:
      break
    tail.add name
    base = head
  var resolved = if dirExists(base): expandFilename(base) else: base
  for i in countdown(tail.high, 0):
    resolved = resolved / tail[i]
  normalizedPath(resolved)

when defined(posix) and not defined(emscripten) and not defined(geneWasm):
  proc flockNative(fd: cint, operation: cint): cint
    {.importc: "flock", header: "<sys/file.h>".}

proc fsTryLock(path: string): int =
  ## A lifetime claim on a stable inode. Never unlink lock files: a waiter
  ## opening a replacement inode would otherwise acquire a second lock. The
  ## kernel releases the claim on close or process death. Returns the open
  ## descriptor, or -1 when another holder has the claim.
  when defined(posix) and not defined(emscripten) and not defined(geneWasm):
    const lockExclusive = 2.cint
    const lockNonBlocking = 4.cint
    let fd = posix.open(path.cstring,
      O_WRONLY or O_CREAT or O_APPEND or O_CLOEXEC, 0o666)
    if fd < 0:
      raiseOSError(osLastError())
    if flockNative(fd, lockExclusive or lockNonBlocking) == 0:
      return int(fd)
    let failure = osLastError()
    discard posix.close(fd)
    if errno == EWOULDBLOCK or errno == EAGAIN:
      return -1
    raiseOSError(failure)
  else:
    raise newException(OSError, "filesystem claims require a native POSIX runtime")


# --- gene/bit ----------------------------------------------------------------
# Bitwise operations over Int. These are the primitives a checksum or a binary
# format needs; without them CRC32 and Adler-32 cannot be written in Gene at
# all, which is what kept every binary encoder in the host language.
#
# Operands are the I64 fast path, not the arbitrary-precision range: a bit
# operation on a value wider than 64 bits has no single obvious meaning (two's
# complement of what width?), so it is rejected rather than silently truncated.

proc requireBitInt(name: string, v: Value): int64 =
  if v.kind != vkInt:
    raise newException(GeneError, name & " expects an Int, got " & $v.kind)
  v.intVal

proc requireBitTwo(name: string, args: openArray[Value]): (int64, int64) =
  if args.len != 2:
    raise newException(GeneError,
      name & " expects 2 arguments, got " & $args.len)
  (requireBitInt(name, args[0]), requireBitInt(name, args[1]))

proc requireShift(name: string, v: Value): int64 =
  let n = requireBitInt(name, v)
  if n < 0 or n > 63:
    raise newException(GeneError, name & " shift count must be in 0..63")
  n

proc biBitAnd(args: openArray[Value]): Value {.nimcall.} =
  let (a, b) = requireBitTwo("bit/and", args)
  newInt(a and b)

proc biBitOr(args: openArray[Value]): Value {.nimcall.} =
  let (a, b) = requireBitTwo("bit/or", args)
  newInt(a or b)

proc biBitXor(args: openArray[Value]): Value {.nimcall.} =
  let (a, b) = requireBitTwo("bit/xor", args)
  newInt(a xor b)

proc biBitNot(args: openArray[Value]): Value {.nimcall.} =
  requireOne("bit/not", args)
  newInt(not requireBitInt("bit/not", args[0]))

proc biBitShl(args: openArray[Value]): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError, "bit/shl expects 2 arguments")
  let v = requireBitInt("bit/shl", args[0])
  newInt(v shl requireShift("bit/shl", args[1]))

proc biBitShr(args: openArray[Value]): Value {.nimcall.} =
  ## Logical (zero-filling) shift, so it composes with masking the way a
  ## checksum expects. An arithmetic shift on a negative value would sign-extend
  ## and corrupt the high byte.
  if args.len != 2:
    raise newException(GeneError, "bit/shr expects 2 arguments")
  let v = cast[uint64](requireBitInt("bit/shr", args[0]))
  newInt(cast[int64](v shr uint64(requireShift("bit/shr", args[1]))))

# --- gene/binary -------------------------------------------------------------
# Operations on the immutable `Bytes` value (design §7.5). Building one is a
# two-step job: accumulate into an ordinary mutable List of Int, then convert
# once. That keeps the value type honest and avoids a second mutable sequence
# type whose only purpose is construction.
#
# The namespace is `binary` rather than the obvious `bytes` because `bytes` is
# already a global function — `(bytes "hi")` gives a Str's bytes as a List of
# Int — and shadowing a shipped name to gain a tidier spelling is not a trade
# worth making.

proc requireBytes(name: string, v: Value) =
  if v.kind != vkBytes:
    raise newException(GeneError, name & " expects Bytes, got " & $v.kind)

proc biBytesFromList(args: openArray[Value]): Value {.nimcall.} =
  requireOne("binary/from_list", args)
  if args[0].kind != vkList:
    raise newException(GeneError, "bytes/from_list expects a List")
  var acc = newStringOfCap(args[0].listItems.len)
  for item in args[0].listItems:
    if item.kind != vkInt:
      raise newException(GeneError,
        "bytes/from_list expects Int elements, got " & $item.kind)
    let b = item.intVal
    if b < 0 or b > 255:
      raise newException(GeneError,
        "bytes/from_list element acc of range 0..255: " & $b)
    acc.add char(b)
  newBytes(acc)

proc biBytesToBuffer(args: openArray[Value]): Value {.nimcall.} =
  ## (binary/to_buffer bytes) -> (Buffer U8). The inverse of Buffer/to_bytes,
  ## and the other half of the bridge a portable codec needs: `Bytes` does not
  ## exist in the web profile, so a module that both backends run works over a
  ## `(Buffer U8)` and converts only at the VM's I/O boundary.
  requireOne("binary/to_buffer", args)
  requireBytes("binary/to_buffer bytes", args[0])
  let raw = args[0].bytesVal
  newByteBuffer(raw, newSym("U8"))

proc biBytesToList(args: openArray[Value]): Value {.nimcall.} =
  requireOne("binary/to_list", args)
  requireBytes("binary/to_list", args[0])
  var items: seq[Value]
  for ch in args[0].bytesVal:
    items.add newInt(int(uint8(ch)))
  newList(items)

proc biBytesSize(args: openArray[Value]): Value {.nimcall.} =
  requireOne("binary/size", args)
  requireBytes("binary/size", args[0])
  newInt(args[0].bytesVal.len)

proc biBytesGet(args: openArray[Value]): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError, "bytes/get expects (bytes, index)")
  requireBytes("binary/get", args[0])
  if args[1].kind != vkInt:
    raise newException(GeneError, "bytes/get index must be an Int")
  let i = args[1].intVal
  if i < 0 or i >= args[0].bytesVal.len:
    raise newException(GeneError, "bytes/get index out of range: " & $i)
  newInt(int(uint8(args[0].bytesVal[int(i)])))

proc biBytesConcat(args: openArray[Value]): Value {.nimcall.} =
  requireOne("binary/concat", args)
  if args[0].kind != vkList:
    raise newException(GeneError, "bytes/concat expects a List of Bytes")
  var acc = ""
  for item in args[0].listItems:
    requireBytes("bytes/concat item", item)
    acc.add item.bytesVal
  newBytes(acc)

proc biBytesSlice(args: openArray[Value]): Value {.nimcall.} =
  if args.len != 3:
    raise newException(GeneError, "bytes/slice expects (bytes, start, len)")
  requireBytes("binary/slice", args[0])
  if args[1].kind != vkInt or args[2].kind != vkInt:
    raise newException(GeneError, "bytes/slice start and len must be Int")
  let total = args[0].bytesVal.len
  let start = args[1].intVal
  let count = args[2].intVal
  if start < 0 or count < 0 or start + count > total:
    raise newException(GeneError, "bytes/slice range out of bounds")
  newBytes(args[0].bytesVal[int(start) ..< int(start + count)])

proc biBytesFromStr(args: openArray[Value]): Value {.nimcall.} =
  ## The string's UTF-8 encoding, which is what a wire format wants.
  requireOne("binary/from_str", args)
  requireStr("binary/from_str", args[0])
  newBytes(args[0].strVal)

proc biBytesToStr(args: openArray[Value]): Value {.nimcall.} =
  requireOne("binary/to_str", args)
  requireBytes("binary/to_str", args[0])
  newStr(args[0].bytesVal)

proc biBytesDecodeUtf8(args: openArray[Value]): Value {.nimcall.} =
  ## Unlike the raw byte/string view, decoding at an input boundary must not
  ## admit malformed UTF-8 into a JSON request or user-visible document.
  requireOne("binary/decode_utf8", args)
  requireBytes("binary/decode_utf8", args[0])
  let raw = args[0].bytesVal
  var invalid = unicode.validateUtf8(raw)
  # Nim's validator checks byte structure but accepts some overlong encodings
  # and surrogate/out-of-range scalar values. A strict decoder rejects those.
  if invalid < 0:
    var i = 0
    while i < raw.len:
      let first = uint8(raw[i])
      if first >= 0xE0 and first <= 0xEF:
        let second = uint8(raw[i + 1])
        if (first == 0xE0 and second < 0xA0) or
            (first == 0xED and second >= 0xA0):
          invalid = i
          break
        i += 3
      elif first >= 0xF0:
        let second = uint8(raw[i + 1])
        if first > 0xF4 or (first == 0xF0 and second < 0x90) or
            (first == 0xF4 and second >= 0x90):
          invalid = i
          break
        i += 4
      elif first >= 0xC2:
        i += 2
      else:
        inc i
  if invalid >= 0:
    raise newException(GeneError,
      "binary/decode_utf8: invalid UTF-8 at byte " & $invalid)
  newStr(raw)

# --- base64 ------------------------------------------------------------------
#
# The text encoding a JSON or HTTP payload needs for binary data, such as an
# image sent to a multimodal model. RFC 4648 standard alphabet with padding
# and no line breaks; decoding accepts exactly what encoding produces.

proc biBase64Encode(args: openArray[Value]): Value {.nimcall.} =
  requireOne("base64/encode", args)
  case args[0].kind
  of vkBytes: newStr(base64.encode(args[0].bytesVal))
  of vkString: newStr(base64.encode(args[0].strVal))
  else:
    raise newException(GeneError, "base64/encode expects Bytes or a Str")

proc biBase64Decode(args: openArray[Value]): Value {.nimcall.} =
  requireOne("base64/decode", args)
  requireStr("base64/decode", args[0])
  let encoded = args[0].strVal
  var decoded = ""
  try:
    decoded = base64.decode(encoded)
  except ValueError:
    raise newException(GeneError, "base64/decode expects canonical base64 text")
  # std/base64 skips characters it does not know. Requiring the round trip
  # rejects that input, missing padding, and a non-zero trailing bit pattern.
  if base64.encode(decoded) != encoded:
    raise newException(GeneError, "base64/decode expects canonical base64 text")
  newBytes(decoded)

# --- binary number codecs ----------------------------------------------------
#
# `binary` could slice and concatenate but could not read a `u16` or write an
# `f32`, so every binary format in Gene rebuilt that from `$bit` — arithmetic
# that is easy to get subtly wrong once per format.
#
# **Little-endian, always.** Not a preference: it is what every architecture
# Gene runs on stores natively, what `DataView` defaults to in the web profile,
# and what SQLite and the common on-disk formats use. Offering both would double
# the surface to make the rarer case one character shorter, and a format that
# needs big-endian can compose two `put_u8` calls.
#
# Offsets are byte offsets, not element indices. A record with a `u8` tag
# followed by a `u32` reads the second at offset 1, which no element index can
# name — and a per-type index would silently reinterpret a mixed buffer.

proc bytesOffset(name: string, args: openArray[Value], width: int): int =
  ## Shared bounds check. Reading past the end is the mistake this family exists
  ## to make impossible, so it raises with the offset rather than returning a
  ## garbage value assembled from whatever followed.
  if args.len != 2:
    raise newException(GeneError, name & " expects (bytes, offset)")
  requireBytes(name, args[0])
  if args[1].kind != vkInt:
    raise newException(GeneError, name & " offset must be an Int")
  let off = args[1].intVal
  if off < 0 or off + width > args[0].bytesVal.len:
    raise newException(GeneError,
      name & " reads " & $width & " bytes at offset " & $off &
      ", past the end of a " & $args[0].bytesVal.len & "-byte value")
  int(off)

template byteAt(v: Value, i: int): uint64 = uint64(uint8(v.bytesVal[i]))

proc biBytesGetU16(args: openArray[Value]): Value {.nimcall.} =
  let o = bytesOffset("binary/get_u16", args, 2)
  newInt(int(args[0].byteAt(o) or (args[0].byteAt(o + 1) shl 8)))

proc biBytesGetU32(args: openArray[Value]): Value {.nimcall.} =
  let o = bytesOffset("binary/get_u32", args, 4)
  newInt(int(args[0].byteAt(o) or (args[0].byteAt(o + 1) shl 8) or
             (args[0].byteAt(o + 2) shl 16) or (args[0].byteAt(o + 3) shl 24)))

proc biBytesGetI32(args: openArray[Value]): Value {.nimcall.} =
  ## Two's complement, so a block coordinate below the origin round trips.
  let o = bytesOffset("binary/get_i32", args, 4)
  let raw = args[0].byteAt(o) or (args[0].byteAt(o + 1) shl 8) or
            (args[0].byteAt(o + 2) shl 16) or (args[0].byteAt(o + 3) shl 24)
  newInt(int(cast[int32](uint32(raw))))

proc biBytesGetF64(args: openArray[Value]): Value {.nimcall.} =
  let o = bytesOffset("binary/get_f64", args, 8)
  var raw: uint64 = 0
  for i in 0 ..< 8:
    raw = raw or (args[0].byteAt(o + i) shl (8 * i))
  newFloat(cast[float64](raw))

proc biBytesGetF32(args: openArray[Value]): Value {.nimcall.} =
  ## Widens to the `Float` Gene has. A value that made the round trip through
  ## `f32` is exactly representable as `f64`, so nothing is lost here — the
  ## precision was spent on the way in, which is what `put_f32` documents.
  let o = bytesOffset("binary/get_f32", args, 4)
  var raw: uint32 = 0
  for i in 0 ..< 4:
    raw = raw or (uint32(args[0].byteAt(o + i)) shl (8 * i))
  newFloat(float64(cast[float32](raw)))

proc putRequireInt(name: string, args: openArray[Value]): int64 =
  if args.len != 1:
    raise newException(GeneError, name & " expects one value")
  if args[0].kind != vkInt:
    raise newException(GeneError, name & " expects an Int, got " & $args[0].kind)
  args[0].intVal

proc putRequireFloat(name: string, args: openArray[Value]): float64 =
  ## Accepts an integral Int as well, for the same reason `Buffer/set` does
  ## (design.md §D7.1): a caller holding a whole number should not have to
  ## convert it to hand it to a float field.
  if args.len != 1:
    raise newException(GeneError, name & " expects one value")
  case args[0].kind
  of vkFloat: args[0].floatVal
  of vkInt: float64(args[0].intVal)
  else:
    raise newException(GeneError,
      name & " expects a Float, got " & $args[0].kind)

proc requireRange(name: string, v: int64, lo, hi: int64) =
  ## Out-of-range **raises** rather than truncating. A silently wrapped node id
  ## is a corrupt world that reads back cleanly, which is the worst shape a
  ## storage bug can take.
  if v < lo or v > hi:
    raise newException(GeneError,
      name & " value out of range " & $lo & ".." & $hi & ": " & $v)

proc biBytesPutU8(args: openArray[Value]): Value {.nimcall.} =
  let v = putRequireInt("binary/put_u8", args)
  requireRange("binary/put_u8", v, 0, 255)
  newBytes($char(uint8(v)))

proc biBytesPutU16(args: openArray[Value]): Value {.nimcall.} =
  let v = putRequireInt("binary/put_u16", args)
  requireRange("binary/put_u16", v, 0, 65535)
  let u = uint16(v)
  newBytes($char(uint8(u and 0xFF)) & $char(uint8(u shr 8)))

proc biBytesPutU32(args: openArray[Value]): Value {.nimcall.} =
  let v = putRequireInt("binary/put_u32", args)
  requireRange("binary/put_u32", v, 0, 4294967295'i64)
  let u = uint32(v)
  var s = newStringOfCap(4)
  for i in 0 ..< 4:
    s.add char(uint8((u shr (8 * i)) and 0xFF'u32))
  newBytes(s)

proc biBytesPutI32(args: openArray[Value]): Value {.nimcall.} =
  let v = putRequireInt("binary/put_i32", args)
  requireRange("binary/put_i32", v, -2147483648'i64, 2147483647'i64)
  let u = cast[uint32](int32(v))
  var s = newStringOfCap(4)
  for i in 0 ..< 4:
    s.add char(uint8((u shr (8 * i)) and 0xFF'u32))
  newBytes(s)

proc biBytesPutF64(args: openArray[Value]): Value {.nimcall.} =
  let raw = cast[uint64](putRequireFloat("binary/put_f64", args))
  var s = newStringOfCap(8)
  for i in 0 ..< 8:
    s.add char(uint8((raw shr (8 * i)) and 0xFF'u64))
  newBytes(s)

proc biBytesPutF32(args: openArray[Value]): Value {.nimcall.} =
  ## **Lossy, and deliberately so.** Half the width for values that do not need
  ## the precision is the whole point; a caller who cannot afford the rounding
  ## wants `put_f64`. Not rejected as out of range, because unlike an integer
  ## overflow the rounding is the documented behaviour of the type.
  let raw = cast[uint32](float32(putRequireFloat("binary/put_f32", args)))
  var s = newStringOfCap(4)
  for i in 0 ..< 4:
    s.add char(uint8((raw shr (8 * i)) and 0xFF'u32))
  newBytes(s)

# --- gene/math ---------------------------------------------------------------
# Numeric model (design §7.4) decides the return kinds here, and the choice is
# not obvious, so it is stated once:
#
# `floor`, `ceil`, `round`, `trunc`, and `abs` are **kind-preserving**: an Int
# argument yields an Int, a Float yields a Float. `(floor 3.7)` is `3.0`, not
# `3`. That follows C and JavaScript rather than the arguably tidier "rounding
# produces an integer", for two reasons. Kind-strict equality (`(== 1 1.0)` is
# false) makes a silent Float->Int hop a real hazard in a comparison chain, and
# the web profile lowers Int to `bigint`, so a rounding step that returned Int
# would drop a bigint into the middle of otherwise-`number` arithmetic and
# throw at the first mixed operation. Use `to_int` when an Int is wanted.
#
# The transcendental functions always return Float, because that is the only
# honest result kind for them.

proc requireNum(name: string, v: Value) =
  if v.kind notin {vkInt, vkFloat}:
    raise newException(GeneError, name & " expects a number, got " & $v.kind)

proc requireNumOne(name: string, args: openArray[Value]): Value =
  requireOne(name, args)
  requireNum(name, args[0])
  args[0]

proc requireNumTwo(name: string, args: openArray[Value]) =
  if args.len != 2:
    raise newException(GeneError,
      name & " expects 2 arguments, got " & $args.len)
  requireNum(name, args[0])
  requireNum(name, args[1])

## Apply a float rounding op while preserving the argument's numeric kind.
template mathRounding(name: string, op: untyped): Value =
  let v = requireNumOne(name, args)
  if v.kind == vkInt: v            # an Int is already integral
  else: newFloat(op(v.floatVal))

proc biMathFloor(args: openArray[Value]): Value {.nimcall.} =
  mathRounding("math/floor", floor)

proc biMathCeil(args: openArray[Value]): Value {.nimcall.} =
  mathRounding("math/ceil", ceil)

proc biMathTrunc(args: openArray[Value]): Value {.nimcall.} =
  mathRounding("math/trunc", trunc)

proc biMathRound(args: openArray[Value]): Value {.nimcall.} =
  ## Half away from zero, matching Nim's `round` — not banker's rounding.
  mathRounding("math/round", round)

proc biMathAbs(args: openArray[Value]): Value {.nimcall.} =
  let v = requireNumOne("math/abs", args)
  if v.kind == vkInt:
    let i = v.intVal
    if i < 0: newInt(-i) else: v
  else:
    newFloat(abs(v.floatVal))

proc biMathSign(args: openArray[Value]): Value {.nimcall.} =
  ## -1, 0, or 1, kind-preserving so it composes with the argument.
  let v = requireNumOne("math/sign", args)
  if v.kind == vkInt:
    let i = v.intVal
    newInt(if i > 0: 1 elif i < 0: -1 else: 0)
  else:
    let f = v.floatVal
    newFloat(if f > 0.0: 1.0 elif f < 0.0: -1.0 else: 0.0)

## Float-in, float-out: the transcendentals have no integral result to preserve.
template mathFloatFn(name: string, op: untyped): Value =
  let v = requireNumOne(name, args)
  newFloat(op(v.toFloat))

proc biMathSqrt(args: openArray[Value]): Value {.nimcall.} =
  let v = requireNumOne("math/sqrt", args)
  let f = v.toFloat
  if f < 0.0:
    raise newException(GeneError, "math/sqrt expects a non-negative number")
  newFloat(sqrt(f))

proc biMathExp(args: openArray[Value]): Value {.nimcall.} =
  mathFloatFn("math/exp", exp)

proc biMathLog(args: openArray[Value]): Value {.nimcall.} =
  let v = requireNumOne("math/log", args)
  let f = v.toFloat
  if f <= 0.0:
    raise newException(GeneError, "math/log expects a positive number")
  newFloat(ln(f))

proc biMathLog2(args: openArray[Value]): Value {.nimcall.} =
  let v = requireNumOne("math/log2", args)
  let f = v.toFloat
  if f <= 0.0:
    raise newException(GeneError, "math/log2 expects a positive number")
  newFloat(log2(f))

proc biMathLog10(args: openArray[Value]): Value {.nimcall.} =
  let v = requireNumOne("math/log10", args)
  let f = v.toFloat
  if f <= 0.0:
    raise newException(GeneError, "math/log10 expects a positive number")
  newFloat(log10(f))

proc biMathSin(args: openArray[Value]): Value {.nimcall.} =
  mathFloatFn("math/sin", sin)

proc biMathCos(args: openArray[Value]): Value {.nimcall.} =
  mathFloatFn("math/cos", cos)

proc biMathTan(args: openArray[Value]): Value {.nimcall.} =
  mathFloatFn("math/tan", tan)

proc biMathAsin(args: openArray[Value]): Value {.nimcall.} =
  let v = requireNumOne("math/asin", args)
  let f = v.toFloat
  if f < -1.0 or f > 1.0:
    raise newException(GeneError, "math/asin expects a number in -1..1")
  newFloat(arcsin(f))

proc biMathAcos(args: openArray[Value]): Value {.nimcall.} =
  let v = requireNumOne("math/acos", args)
  let f = v.toFloat
  if f < -1.0 or f > 1.0:
    raise newException(GeneError, "math/acos expects a number in -1..1")
  newFloat(arccos(f))

proc biMathAtan(args: openArray[Value]): Value {.nimcall.} =
  mathFloatFn("math/atan", arctan)

proc biMathAtan2(args: openArray[Value]): Value {.nimcall.} =
  requireNumTwo("math/atan2", args)
  newFloat(arctan2(args[0].toFloat, args[1].toFloat))

proc biMathPow(args: openArray[Value]): Value {.nimcall.} =
  requireNumTwo("math/pow", args)
  newFloat(pow(args[0].toFloat, args[1].toFloat))

proc biMathHypot(args: openArray[Value]): Value {.nimcall.} =
  requireNumTwo("math/hypot", args)
  newFloat(hypot(args[0].toFloat, args[1].toFloat))

## `min`/`max` keep both kinds when they agree and widen to Float when mixed,
## so `(min 1 2)` is an Int while `(min 1 2.0)` is a Float. Returning the
## winning *argument* rather than a rebuilt value keeps Int precision beyond
## the Float mantissa.
template mathExtremum(name: string, keepFirst: untyped): Value =
  requireNumTwo(name, args)
  let a = args[0]
  let b = args[1]
  if a.kind == vkInt and b.kind == vkInt:
    if keepFirst(a.intVal, b.intVal): a else: b
  else:
    if keepFirst(a.toFloat, b.toFloat): a.toFloat.newFloat
    else: b.toFloat.newFloat

proc biMathMin(args: openArray[Value]): Value {.nimcall.} =
  mathExtremum("math/min", `<=`)

proc biMathMax(args: openArray[Value]): Value {.nimcall.} =
  mathExtremum("math/max", `>=`)

proc biMathClamp(args: openArray[Value]): Value {.nimcall.} =
  ## Three-argument clamp, the shape every graphics and UI path re-derives.
  if args.len != 3:
    raise newException(GeneError,
      "math/clamp expects 3 arguments, got " & $args.len)
  requireNum("math/clamp", args[0])
  requireNum("math/clamp", args[1])
  requireNum("math/clamp", args[2])
  let lo = args[1].toFloat
  let hi = args[2].toFloat
  if lo > hi:
    raise newException(GeneError, "math/clamp lower bound exceeds upper bound")
  let x = args[0].toFloat
  if x < lo: args[1] elif x > hi: args[2] else: args[0]

proc biStrJoin(args: openArray[Value]): Value {.nimcall.} =
  if args.len notin 1..2:
    raise newException(GeneError, "str/join expects 1..2 arguments, got " & $args.len)
  if args[0].kind != vkList:
    raise newException(GeneError, "str/join expects a List")
  let sep =
    if args.len == 2:
      requireStr("str/join separator", args[1])
      args[1].strVal
    else:
      ""
  var parts: seq[string]
  for item in args[0].listItems:
    requireStr("str/join item", item)
    parts.add item.strVal
  newStr(parts.join(sep))

proc biStrSplit(args: openArray[Value]): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError, "str/split expects 2 arguments, got " & $args.len)
  requireStr("str/split", args[0])
  requireStr("str/split separator", args[1])
  if args[1].strVal.len == 0:
    raise newException(GeneError, "str/split separator must not be empty")
  var items: seq[Value]
  for part in args[0].strVal.split(args[1].strVal):
    items.add newStr(part)
  newList(items)

proc biStrTrim(args: openArray[Value]): Value {.nimcall.} =
  requireOne("str/trim", args)
  requireStr("str/trim", args[0])
  newStr(args[0].strVal.strip())

proc biStrLower(args: openArray[Value]): Value {.nimcall.} =
  requireOne("str/lower", args)
  requireStr("str/lower", args[0])
  newStr(args[0].strVal.toLowerAscii())

proc biStrUpper(args: openArray[Value]): Value {.nimcall.} =
  requireOne("str/upper", args)
  requireStr("str/upper", args[0])
  newStr(args[0].strVal.toUpperAscii())

proc biStrByteSize(args: openArray[Value]): Value {.nimcall.} =
  requireOne("str/byte_size", args)
  requireStr("str/byte_size", args[0])
  newInt(args[0].strVal.len)

# --- portable UTF-8 -----------------------------------------------------------
#
# `str/to_utf8` and `str/from_utf8` exist under the same names in the web
# profile, which is the whole point of them: a module compiled for both
# backends can put a string on a wire without knowing which side it is on.
# `binary/from_str` already does this on the VM, but `Bytes` has no counterpart
# in the profile, so the portable pair speaks `(Buffer U8)` instead.
#
# Gene strings are already UTF-8 internally, so the VM side is a widening of
# each byte into a buffer cell rather than an encode.

proc biStrToUtf8(args: openArray[Value]): Value {.nimcall.} =
  requireOne("str/to_utf8", args)
  requireStr("str/to_utf8", args[0])
  let raw = args[0].strVal
  newByteBuffer(raw, newSym("U8"))

proc biStrFromUtf8(args: openArray[Value]): Value {.nimcall.} =
  requireOne("str/from_utf8", args)
  if args[0].kind != vkBuffer:
    raise newException(GeneError,
      "str/from_utf8 expects a (Buffer U8), got " & $args[0].kind)
  if args[0].bufferStorageKind == bskU8:
    return newStr(args[0].bufferByteString)
  var raw = newString(args[0].bufferLen)
  for i in 0 ..< raw.len:
    let item = args[0].bufferItem(i)
    if item.kind != vkInt:
      raise newException(GeneError,
        "str/from_utf8 element " & $i & " is not an Int")
    let v = item.intVal
    if v < 0 or v > 255:
      raise newException(GeneError,
        "str/from_utf8 element " & $i & " out of range 0..255: " & $v)
    raw[i] = char(byte(v))
  newStr(raw)

proc biStrSliceBytes(args: openArray[Value]): Value {.nimcall.} =
  if args.len != 3:
    raise newException(GeneError,
      "str/slice_bytes expects 3 arguments, got " & $args.len)
  requireStr("str/slice_bytes", args[0])
  let start = int(requireInt64("str/slice_bytes start", args[1]))
  let maxBytes = int(requireInt64("str/slice_bytes max_bytes", args[2]))
  if start < 0 or maxBytes < 0:
    raise newException(GeneError,
      "str/slice_bytes start and max_bytes must be non-negative")
  let value = args[0].strVal
  if start > value.len:
    raise newException(GeneError,
      "str/slice_bytes start exceeds string byte size")
  if start < value.len and (ord(value[start]) and 0xC0) == 0x80:
    raise newException(GeneError,
      "str/slice_bytes start must be a UTF-8 boundary")
  var stop =
    if maxBytes > value.len - start: value.len
    else: start + maxBytes
  while stop > start and stop < value.len and
      (ord(value[stop]) and 0xC0) == 0x80:
    dec stop
  if stop <= start:
    return newStr("")
  newStr(value[start ..< stop])

proc biStrStartsWith(args: openArray[Value]): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError,
      "str/starts_with? expects 2 arguments, got " & $args.len)
  requireStr("str/starts_with?", args[0])
  requireStr("str/starts_with? prefix", args[1])
  if args[0].strVal.startsWith(args[1].strVal): TRUE else: FALSE

proc biStrEndsWith(args: openArray[Value]): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError,
      "str/ends_with? expects 2 arguments, got " & $args.len)
  requireStr("str/ends_with?", args[0])
  requireStr("str/ends_with? suffix", args[1])
  if args[0].strVal.endsWith(args[1].strVal): TRUE else: FALSE

proc biStrContains(args: openArray[Value]): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError,
      "str/contains? expects 2 arguments, got " & $args.len)
  requireStr("str/contains?", args[0])
  requireStr("str/contains? needle", args[1])
  if args[0].strVal.contains(args[1].strVal): TRUE else: FALSE

proc biParseInt(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("parse_int", args)
  let scope = if call == nil: nil else: call.dispatchScope
  if args[0].kind != vkString:
    raiseReaderError("parse_int", "expects a Str", "ParseError", scope)
  let s = args[0].strVal.strip()
  try:
    newInt(parseBiggestInt(s))
  except ValueError:
    raiseReaderError("parse_int", "invalid integer: " & args[0].strVal,
                     "ParseError", scope)
    NIL

proc biHtmlEscape(args: openArray[Value]): Value {.nimcall.} =
  requireOne("html/escape", args)
  requireStr("html/escape", args[0])
  var escaped = newStringOfCap(args[0].strVal.len)
  for c in args[0].strVal:
    case c
    of '&': escaped.add "&amp;"
    of '<': escaped.add "&lt;"
    of '>': escaped.add "&gt;"
    of '"': escaped.add "&quot;"
    of '\'': escaped.add "&#39;"
    else: escaped.add c
  newStr(escaped)

proc htmlTextEscape(value: string): string =
  result = newStringOfCap(value.len)
  for c in value:
    case c
    of '&': result.add "&amp;"
    of '<': result.add "&lt;"
    of '>': result.add "&gt;"
    else: result.add c

proc htmlAttrEscape(value: string): string =
  result = newStringOfCap(value.len)
  for c in value:
    case c
    of '&': result.add "&amp;"
    of '<': result.add "&lt;"
    of '>': result.add "&gt;"
    of '"': result.add "&quot;"
    of '\'': result.add "&#39;"
    else: result.add c

proc htmlNameValid(name: string): bool =
  if name.len == 0 or not (name[0] in {'A'..'Z', 'a'..'z'}):
    return false
  for c in name:
    if c notin {'A'..'Z', 'a'..'z', '0'..'9', '-', '_', ':', '.'}:
      return false
  true

proc htmlVoidElement(tag: string): bool =
  tag.toLowerAscii() in ["area", "base", "br", "col", "embed", "hr", "img",
                             "input", "link", "meta", "param", "source",
                             "track", "wbr"]

proc htmlBooleanAttr(name: string): bool =
  name.toLowerAscii() in [
    "allowfullscreen", "async", "autofocus", "autoplay", "checked",
    "controls", "default", "defer", "disabled", "formnovalidate", "hidden",
    "inert", "ismap", "itemscope", "loop", "multiple", "muted",
    "nomodule", "novalidate", "open", "playsinline", "readonly",
    "required", "reversed", "selected"]

proc htmlRawText(value: Value, tag: string, scope: Scope): string =
  case value.kind
  of vkNil, vkVoid:
    discard
  of vkString:
    let needle = "</" & tag.toLowerAscii()
    let source = value.strVal
    let lowered = source.toLowerAscii()
    var start = 0
    while true:
      let found = lowered.find(needle, start)
      if found < 0:
        result.add source[start .. ^1]
        break
      result.add source[start ..< found]
      result.add "<\\/"
      result.add source[found + 2 ..< found + needle.len]
      start = found + needle.len
  of vkList:
    for item in value.listItems:
      result.add htmlRawText(item, tag, scope)
  of vkNode:
    raise newException(GeneError,
      "html/render raw-text element '" & tag & "' cannot contain a node")
  else:
    result = displayStr(value, scope)

proc renderHtmlValue(value: Value, scope: Scope): string =
  case value.kind
  of vkNil, vkVoid:
    result = ""
  of vkString:
    result = htmlTextEscape(value.strVal)
  of vkList:
    for item in value.listItems:
      result.add renderHtmlValue(item, scope)
  of vkNode:
    let tag =
      case value.head.kind
      of vkSymbol: value.head.symVal
      of vkString: value.head.strVal
      else:
        raise newException(GeneError,
          "html/render expects a Symbol or Str node head")
    if not htmlNameValid(tag):
      raise newException(GeneError, "html/render invalid tag name: " & tag)
    result.add '<'
    result.add tag
    for name, attr in value.props:
      if not htmlNameValid(name):
        raise newException(GeneError,
          "html/render invalid attribute name: " & name)
      if htmlBooleanAttr(name):
        if attr.kind in {vkNil, vkVoid} or
            (attr.kind == vkBool and not attr.boolVal):
          continue
        result.add ' '
        result.add name
        continue
      if attr.kind in {vkNil, vkVoid}:
        continue
      result.add ' '
      result.add name
      result.add "=\""
      result.add htmlAttrEscape(displayStr(attr, scope))
      result.add '"'
    result.add '>'
    if htmlVoidElement(tag):
      if value.body.len > 0:
        raise newException(GeneError,
          "html/render void element '" & tag & "' cannot have children")
      return
    if tag.toLowerAscii() in ["script", "style"]:
      for child in value.body:
        result.add htmlRawText(child, tag, scope)
    else:
      for child in value.body:
        result.add renderHtmlValue(child, scope)
    result.add "</"
    result.add tag
    result.add '>'
  else:
    result = htmlTextEscape(displayStr(value, scope))

proc biHtmlRender(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("html/render", args)
  let scope = if call == nil: nil else: call.dispatchScope
  newStr(renderHtmlValue(args[0], scope))

when not defined(geneWasm):
  # Composition needs the compiled assets, which are host-only.
  # --- web: placing generated assets in a page ---------------------------------
  #
  # The whole author-facing surface for embedded web modules
  # (docs/workflows.md). Two things: a composition operation
  # that returns a finished node, and the base those nodes' URLs are built from.
  # Application code never sees JavaScript, a source map, a hash, or a route
  # table — and cannot forget to publish one, because referring to an asset is
  # what publishes it.

  proc webAssetArgument(label: string, value: Value, scope: Scope): WebAsset =
    let app = scope.application()
    result = app.webAssetFor(value)
    if result == nil:
      raise newException(GeneError, label & " expects a web_module or web/load asset")

  proc biWebLoad(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
    requireOne("web/load", args)
    requireStr("web/load path", args[0])
    let scope = if call == nil: nil else: call[].dispatchScope
    let readSource = proc(path: string): string =
      fsReadBytes(path)
    let asset = compileWebFileAsset(args[0].strVal, readSource)
    let app = scope.application()
    app.webAssets[webAssetIdentity(asset)] = asset
    for route in webAssetRoutes(asset):
      app.publishWebRoute(route)
    webAssetValue(asset)

  proc biWebScript(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
    ## (web/script asset ^mount "id") -> the complete script node.
    ##
    ## The entry is an external module by default: inlining buys no authoring
    ## property — one file, one command, either way — while dragging nonce/hash
    ## plumbing, script-data escaping, and a base64 map in every page response
    ## onto the critical path. `script-src 'self'` admits this with no nonce.
    requireOne("web/script", args)
    let scope = if call == nil: nil else: call[].dispatchScope
    let asset = webAssetArgument("web/script", args[0], scope)
    var mountId = ""
    if call != nil:
      for name in call[].namedNames:
        if name != "mount":
          raise newException(GeneError,
            "web/script got unexpected named argument: " & name)
      let index = nativeNamedIndex(call, "mount")
      if index >= 0:
        requireStr("web/script ^mount", call[].namedValues[index])
        mountId = call[].namedValues[index].strVal
    if mountId.len == 0:
      raise newException(GeneError, "web/script requires a non-empty ^mount element id")
    var props = initPropTable()
    props["type"] = newStr("module")
    props["src"] = newStr(scope.application().webMountScriptUrl(asset, mountId))
    newNode(newSym("script"), props = props)

  proc biWebStylesheet(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
    ## (web/stylesheet "name" css_text) -> the complete link node.
    ##
    ## The other half of the CSP story. An inline `<style>` needs a nonce or hash
    ## on every response, and a page function that returns `Str` has nowhere to
    ## carry one; a generated `.css` route needs only `style-src 'self'`.
    if args.len != 2:
      raise newException(GeneError,
        "web/stylesheet expects (name, css), got " & $args.len & " arguments")
    requireStr("web/stylesheet name", args[0])
    requireStr("web/stylesheet css", args[1])
    let scope = if call == nil: nil else: call[].dispatchScope
    var props = initPropTable()
    props["rel"] = newStr("stylesheet")
    props["href"] = newStr(scope.application().publishWebStylesheet(
      args[0].strVal, args[1].strVal))
    newNode(newSym("link"), props = props)

  proc biWebAssetBase(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
    if args.len != 0:
      raise newException(GeneError, "web/asset_base takes no arguments")
    let scope = if call == nil: nil else: call[].dispatchScope
    newStr(scope.application().webAssetBase())

  proc biWebSetAssetBase(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
    ## Relocate every generated route at once — what a reverse-proxy subpath
    ## deployment needs, and the reason the base is not a process root.
    requireOne("web/set_asset_base", args)
    requireStr("web/set_asset_base", args[0])
    let scope = if call == nil: nil else: call[].dispatchScope
    scope.application().webAssetBase = args[0].strVal
    NIL

  proc biWebSetSourceMaps(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
    ## Whether this application answers for `.map` routes. Dev publishes the
    ## redacted map; production may withhold it. The maps only ever contain the
    ## embedded block, so this is a policy knob rather than the safety boundary.
    requireOne("web/set_source_maps", args)
    if args[0].kind != vkBool:
      raise newException(GeneError, "web/set_source_maps expects a Bool")
    let scope = if call == nil: nil else: call[].dispatchScope
    scope.application().webSourceMapsEnabled = args[0].boolVal
    NIL

  proc biWebPublishedRoutes(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
    ## (web/published_routes) -> the generated files this application answers
    ## for, sorted by file name, each `{^file ^content_type ^body ^source_map}`.
    ##
    ## What a static export writes beside the page it rendered. It reads the
    ## table the HTTP server reads, source-map policy included, so an export
    ## can neither miss a file its page names nor ship one the server would
    ## withhold. Publishing is still a side effect of referring to an asset:
    ## render the page first, then ask.
    if args.len != 0:
      raise newException(GeneError, "web/published_routes takes no arguments")
    let scope = if call == nil: nil else: call[].dispatchScope
    let app = scope.application()
    var fileNames: seq[string]
    for fileName, route in app.webRoutes:
      if route.isSourceMap and not app.webSourceMapsEnabled(): continue
      fileNames.add fileName
    fileNames.sort()
    var items: seq[Value]
    for fileName in fileNames:
      let route = app.webRoutes[fileName]
      var props = initPropTable()
      props["file"] = newStr(route.fileName)
      props["content_type"] = newStr(route.contentType)
      props["body"] = newStr(route.body)
      props["source_map"] = if route.isSourceMap: TRUE else: FALSE
      items.add newMap(props)
    newList(items)

# CSS is ordered node data. Declarations deliberately live in the body rather
# than a PropTable: duplicate fallbacks and interleaving with nested rules are
# observable CSS semantics (docs/workflows.md).
proc cssNode(head: string, body: openArray[Value]): Value =
  newNode(newSym(head), body = @body)

proc biCss(args: openArray[Value]): Value {.nimcall.} =
  cssNode("css", args)

proc biCssRule(args: openArray[Value]): Value {.nimcall.} =
  if args.len < 1 or args[0].kind != vkString:
    raise newException(GeneError,
      "css/rule expects a Str selector followed by CSS nodes")
  cssNode("rule", args)

proc biCssMedia(args: openArray[Value]): Value {.nimcall.} =
  if args.len < 1 or args[0].kind != vkString:
    raise newException(GeneError,
      "css/media expects a Str query followed by CSS nodes")
  cssNode("media", args)

proc biCssKeyframes(args: openArray[Value]): Value {.nimcall.} =
  if args.len < 2 or args[0].kind != vkString:
    raise newException(GeneError,
      "css/keyframes expects a Str name followed by frame nodes")
  cssNode("keyframes", args)

proc biCssFrame(args: openArray[Value]): Value {.nimcall.} =
  if args.len < 2 or args[0].kind != vkString:
    raise newException(GeneError,
      "css/frame expects a Str selector followed by declarations")
  cssNode("frame", args)

proc biCssDeclValue(args: openArray[Value]): Value {.nimcall.} =
  if args.len != 2 or args[0].kind notin {vkSymbol, vkString}:
    raise newException(GeneError,
      "css/decl expects a Symbol or Str property name and one value")
  cssNode("decl", args)

proc sha256Hex(data: string): string

proc cssCanonical(value: Value): string =
  ## Length-prefixed, kind-tagged, source-meta-blind serialization. Node props
  ## retain insertion order and bodies retain duplicates/order; node metadata
  ## is deliberately absent because source locations and docs do not affect CSS.
  template field(tag, payload: string) =
    result.add tag
    result.add $payload.len
    result.add ':'
    result.add payload
  case value.kind
  of vkNode:
    field("N", cssCanonical(value.head))
    result.add "P" & $value.props.len & ":"
    for key, item in value.props:
      field("K", key)
      field("V", cssCanonical(item))
    result.add "B" & $value.body.len & ":"
    for item in value.body:
      field("V", cssCanonical(item))
  of vkList:
    result.add "L" & $value.listItems.len & ":"
    for item in value.listItems:
      field("V", cssCanonical(item))
  of vkMap:
    result.add "M" & $value.mapEntries.len & ":"
    for key, item in value.mapEntries:
      field("K", key)
      field("V", cssCanonical(item))
  of vkSymbol:
    field("Y", value.symVal)
  of vkString:
    field("S", value.strVal)
  of vkNil:
    result = "Z"
  of vkVoid:
    result = "V"
  of vkBool:
    result = if value.boolVal: "T" else: "F"
  of vkInt, vkFloat, vkChar:
    field("Q" & $ord(value.kind), value.print())
  else:
    raise newException(GeneError,
      "css/scoped canonical serialization rejects " & $value.kind)

proc cssSafeLabel(label: string): string =
  for c in label:
    if c in {'A'..'Z', 'a'..'z', '0'..'9', '_', '-'}:
      result.add c
    else:
      result.add '_'
  if result.len == 0:
    result = "scope"
  if result[0] notin {'A'..'Z', 'a'..'z', '_'}:
    result = "g_" & result

proc cssScopedCanonical(value: Value): string =
  if value.kind != vkNode or not value.head.isSymbol("scoped") or
      not value.props.hasKey("name") or
      value.props["name"].kind != vkString:
    raise newException(GeneError, "css/scoped expects a scoped CSS node")
  result = "gene-css-scope-v1:"
  result.add cssCanonical(value.props["name"])
  for child in value.body:
    result.add cssCanonical(child)

proc cssScopedClass(value: Value): string =
  let canonical = cssScopedCanonical(value)
  cssSafeLabel(value.props["name"].strVal) & "__" & sha256Hex(canonical)[0 .. 11]

proc biCssScoped(args: openArray[Value]): Value {.nimcall.} =
  if args.len < 2 or args[0].kind != vkString:
    raise newException(GeneError,
      "css/scoped expects a Str label followed by CSS node data")
  var props = initPropTable()
  props["name"] = args[0]
  newNode(newSym("scoped"), props = props, body = @args[1 .. ^1])

proc biCssClassName(args: openArray[Value]): Value {.nimcall.} =
  requireOne("css/class_name", args)
  newStr(cssScopedClass(args[0]))

proc cssPropertyName(value: Value): string =
  case value.kind
  of vkSymbol:
    result = value.symVal.replace("_", "-")
  of vkString:
    result = value.strVal
  else:
    raise newException(GeneError,
      "css/render declaration name must be a Symbol or Str")
  if result.len == 0:
    raise newException(GeneError, "css/render declaration name is empty")
  for c in result:
    if c in {' ', '\t', '\r', '\n', ':', ';', '{', '}'}:
      raise newException(GeneError,
        "css/render invalid declaration name: " & result)

proc cssIndent(depth: int): string =
  repeat(' ', depth * 2)

proc cssSelectorParts(selector: string): seq[string] =
  var start = 0
  var depth = 0
  var quote = '\0'
  var escaped = false
  for i, c in selector:
    if quote != '\0':
      if escaped:
        escaped = false
      elif c == '\\':
        escaped = true
      elif c == quote:
        quote = '\0'
    else:
      case c
      of '\'', '"': quote = c
      of '[', '(': inc depth
      of ']', ')': depth = max(0, depth - 1)
      of ',':
        if depth == 0:
          result.add selector[start ..< i].strip()
          start = i + 1
      else: discard
  result.add selector[start .. ^1].strip()

proc cssSelector(parent, child: string): string =
  if parent.len == 0:
    return child
  var combined: seq[string]
  for parentPart in cssSelectorParts(parent):
    for childPart in cssSelectorParts(child):
      if '&' in childPart:
        combined.add childPart.replace("&", parentPart)
      else:
        combined.add parentPart & " " & childPart
  combined.join(", ")

proc collectCssKeyframes(value: Value, names: var seq[string]) =
  case value.kind
  of vkNode:
    if value.head.isSymbol("keyframes") and value.body.len > 0 and
        value.body[0].kind == vkString and value.body[0].strVal notin names:
      names.add value.body[0].strVal
    for child in value.body:
      collectCssKeyframes(child, names)
  of vkList:
    for child in value.listItems:
      collectCssKeyframes(child, names)
  else:
    discard

proc cssNameChar(c: char): bool =
  c in {'A'..'Z', 'a'..'z', '0'..'9', '_', '-'}

proc replaceCssToken(source, token, replacement: string): string =
  var start = 0
  while start < source.len:
    let found = source.find(token, start)
    if found < 0:
      result.add source[start .. ^1]
      return
    let beforeOk = found == 0 or not cssNameChar(source[found - 1])
    let afterAt = found + token.len
    let afterOk = afterAt >= source.len or not cssNameChar(source[afterAt])
    if beforeOk and afterOk:
      result.add source[start ..< found]
      result.add replacement
      start = afterAt
    else:
      result.add source[start .. found]
      start = found + 1
  if start == source.len:
    discard

proc transformScopedCss(value: Value,
                        keyframes: Table[string, string]): Value =
  case value.kind
  of vkNode:
    var body: seq[Value]
    for child in value.body:
      body.add transformScopedCss(child, keyframes)
    if value.head.isSymbol("keyframes") and body.len > 0 and
        body[0].kind == vkString and keyframes.hasKey(body[0].strVal):
      body[0] = newStr(keyframes[body[0].strVal])
    elif value.head.isSymbol("decl") and body.len == 2 and
        body[1].kind == vkString and
        cssPropertyName(body[0]) in ["animation", "animation-name"]:
      var rendered = body[1].strVal
      for name, replacement in keyframes:
        rendered = replaceCssToken(rendered, name, replacement)
      body[1] = newStr(rendered)
    result = newNode(value.head, props = value.props, body = body,
                     immutable = value.nodeImmutable)
  of vkList:
    var items: seq[Value]
    for child in value.listItems:
      items.add transformScopedCss(child, keyframes)
    result = newList(items, immutable = value.listImmutable)
  else:
    result = value

proc renderCssNode(value: Value, parent: string, depth: int,
                   scope: Scope): string

proc renderCssRule(value: Value, parent: string, depth: int,
                   scope: Scope): string =
  if value.kind != vkNode or not value.head.isSymbol("rule") or
      value.body.len < 1 or value.body[0].kind != vkString:
    raise newException(GeneError, "css/render expected a rule node")
  let selector = cssSelector(parent, value.body[0].strVal)
  var declarations: seq[Value]
  var nested: seq[Value]
  for i in 1 ..< value.body.len:
    let child = value.body[i]
    if child.kind == vkNode and child.head.isSymbol("decl"):
      declarations.add child
    else:
      nested.add child
  if declarations.len > 0:
    result.add cssIndent(depth) & selector & " {\n"
    for decl in declarations:
      if decl.body.len != 2:
        raise newException(GeneError,
          "css/render declaration must contain a name and value")
      result.add cssIndent(depth + 1)
      result.add cssPropertyName(decl.body[0])
      result.add ": "
      result.add displayStr(decl.body[1], scope)
      result.add ";\n"
    result.add cssIndent(depth) & "}\n"
  for child in nested:
    result.add renderCssNode(child, selector, depth, scope)

proc renderCssMedia(value: Value, parent: string, depth: int,
                    scope: Scope): string =
  if value.body.len < 1 or value.body[0].kind != vkString:
    raise newException(GeneError, "css/render expected a media query")
  result.add cssIndent(depth) & "@media " & value.body[0].strVal & " {\n"
  for i in 1 ..< value.body.len:
    result.add renderCssNode(value.body[i], parent, depth + 1, scope)
  result.add cssIndent(depth) & "}\n"

proc renderCssKeyframes(value: Value, depth: int, scope: Scope): string =
  if value.body.len < 2 or value.body[0].kind != vkString:
    raise newException(GeneError, "css/render expected keyframes data")
  result.add cssIndent(depth) & "@keyframes " & value.body[0].strVal & " {\n"
  for i in 1 ..< value.body.len:
    let frame = value.body[i]
    if frame.kind != vkNode or not frame.head.isSymbol("frame") or
        frame.body.len < 2 or frame.body[0].kind != vkString:
      raise newException(GeneError,
        "css/render keyframes may contain only frame nodes")
    result.add cssIndent(depth + 1) & frame.body[0].strVal & " {\n"
    for j in 1 ..< frame.body.len:
      let decl = frame.body[j]
      if decl.kind != vkNode or not decl.head.isSymbol("decl") or
          decl.body.len != 2:
        raise newException(GeneError,
          "css/render frame may contain only declarations")
      result.add cssIndent(depth + 2)
      result.add cssPropertyName(decl.body[0])
      result.add ": " & displayStr(decl.body[1], scope) & ";\n"
    result.add cssIndent(depth + 1) & "}\n"
  result.add cssIndent(depth) & "}\n"

proc renderCssNode(value: Value, parent: string, depth: int,
                   scope: Scope): string =
  if value.kind == vkNil or value.kind == vkVoid:
    return ""
  if value.kind == vkList:
    for item in value.listItems:
      result.add renderCssNode(item, parent, depth, scope)
    return
  if value.kind != vkNode or value.head.kind != vkSymbol:
    raise newException(GeneError, "css/render expects CSS node data")
  case value.head.symVal
  of "css":
    for child in value.body:
      result.add renderCssNode(child, parent, depth, scope)
  of "rule":
    result = renderCssRule(value, parent, depth, scope)
  of "media":
    result = renderCssMedia(value, parent, depth, scope)
  of "keyframes":
    result = renderCssKeyframes(value, depth, scope)
  of "scoped":
    let className = cssScopedClass(value)
    let digest = className.split("__")[^1]
    var names: seq[string]
    for child in value.body:
      collectCssKeyframes(child, names)
    var keyframes = initTable[string, string]()
    for name in names:
      keyframes[name] = name & "__" & digest
    let scopeSelector =
      if parent.len == 0: "." & className
      else: parent & " ." & className
    for child in value.body:
      result.add renderCssNode(transformScopedCss(child, keyframes),
                               scopeSelector, depth, scope)
  of "decl", "frame":
    raise newException(GeneError,
      "css/render declaration must be inside a rule")
  else:
    raise newException(GeneError,
      "css/render unknown CSS node: " & value.head.symVal)

proc validateCssScopeCollisions(value: Value,
                                seen: var Table[string, string]) =
  case value.kind
  of vkNode:
    if value.head.isSymbol("scoped"):
      let className = cssScopedClass(value)
      let canonical = cssScopedCanonical(value)
      if seen.hasKey(className) and seen[className] != canonical:
        raise newException(GeneError,
          "css/render scoped class hash collision: " & className)
      seen[className] = canonical
    for child in value.body:
      validateCssScopeCollisions(child, seen)
  of vkList:
    for child in value.listItems:
      validateCssScopeCollisions(child, seen)
  else:
    discard

proc biCssRender(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("css/render", args)
  let scope = if call == nil: nil else: call.dispatchScope
  var scopedClasses = initTable[string, string]()
  validateCssScopeCollisions(args[0], scopedClasses)
  newStr(renderCssNode(args[0], "", 0, scope))

proc ownedHandleField*(scope: Scope, target: string): TypeField =
  ## The `^handle (C/OwnedPtr <target>)` field every in-tree native wrapper
  ## declares. `target` names the foreign type (`sqlite3`, `PGconn`); it is
  ## compared structurally against the pointer's own target, so the two ends of
  ## a binding cannot be crossed.
  TypeField(name: "handle", optional: false,
            typeExpr: newNode(newSym("C/OwnedPtr"), body = @[newSym(target)]),
            scope: scope)

proc nativeReceiverIs*(scope: Scope, value: Value, typeName: string): bool =
  ## Receiver identity for a native surface. The value's head must be *the*
  ## canonical Type registered under that name — or a nominal descendant of it,
  ## which inherits the wrapper rule (design §16.6) and is therefore a
  ## legitimate receiver.
  ##
  ## A name comparison is not enough, and that is a safety property rather than
  ## tidiness: these guards turn a prop into an index into a native session
  ## table, so any user declaration of the same name would otherwise reach a PTY
  ## or store the program never opened. The name fallback only runs when the
  ## canonical Type is unavailable (`builtInTypeHead` answers with a symbol),
  ## which is the bootstrap case, before any user type can exist.
  if value.kind != vkNode or value.head.kind != vkType:
    return false
  let canonical = builtInTypeHead(scope, typeName)
  if canonical.kind == vkType:
    return value.head.typeInheritsFrom(canonical)
  value.head.typeName == typeName

const urlUnreserved = {'A'..'Z', 'a'..'z', '0'..'9', '-', '.', '_', '~'}

proc urlEncodeComponent(s: string): string =
  result = newStringOfCap(s.len)
  for c in s:
    if c in urlUnreserved:
      result.add c
    else:
      result.add '%'
      result.add toHex(ord(c), 2)

proc raiseUrlError(message: string, scope: Scope) =
  var props = initPropTable()
  props["message"] = newStr(message)
  var e: ref GeneError
  new(e)
  e.msg = message
  e.errVal = newNode(builtInTypeHead(scope, "UrlError"), props = props)
  e.hasErrVal = true
  raise e

proc urlDecodeComponent(s: string, plusIsSpace: bool, scope: Scope): string =
  result = newStringOfCap(s.len)
  var i = 0
  while i < s.len:
    let c = s[i]
    if c == '%':
      if i + 2 > s.high:
        raiseUrlError("url/decode_component: truncated percent escape", scope)
      let hi = s[i + 1]
      let lo = s[i + 2]
      if hi notin HexDigits or lo notin HexDigits:
        raiseUrlError("url/decode_component: invalid percent escape: %" &
                      hi & lo, scope)
      result.add chr(fromHex[int]("" & hi & lo))
      i += 3
    elif plusIsSpace and c == '+':
      result.add ' '
      inc i
    else:
      result.add c
      inc i

proc biUrlEncodeComponent(args: openArray[Value]): Value {.nimcall.} =
  requireOne("url/encode_component", args)
  requireStr("url/encode_component", args[0])
  newStr(urlEncodeComponent(args[0].strVal))

proc biUrlDecodeComponent(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("url/decode_component", args)
  requireStr("url/decode_component", args[0])
  let scope = if call == nil: nil else: call.dispatchScope
  newStr(urlDecodeComponent(args[0].strVal, plusIsSpace = false, scope))

proc parseQueryEntries(query: string,
                       scope: Scope): PropTable =
  if query.len == 0:
    return
  for pair in query.split('&'):
    if pair.len == 0:
      continue
    let eq = pair.find('=')
    if eq < 0:
      result[urlDecodeComponent(pair, plusIsSpace = true, scope)] = newStr("")
    else:
      let key = urlDecodeComponent(pair[0 ..< eq], plusIsSpace = true, scope)
      let val = urlDecodeComponent(pair[eq + 1 .. ^1], plusIsSpace = true,
                                   scope)
      result[key] = newStr(val)

proc biUrlParseQuery(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("url/parse_query", args)
  requireStr("url/parse_query", args[0])
  let scope = if call == nil: nil else: call.dispatchScope
  newMap(parseQueryEntries(args[0].strVal, scope))

proc biUrlFormatQuery(args: openArray[Value]): Value {.nimcall.} =
  requireOne("url/format_query", args)
  if args[0].kind != vkMap:
    raise newException(GeneError, "url/format_query expects a Map")
  var parts: seq[string]
  for key, val in args[0].mapEntries:
    requireStr("url/format_query value", val)
    parts.add urlEncodeComponent(key) & "=" & urlEncodeComponent(val.strVal)
  newStr(parts.join("&"))

proc biEach(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  ## The generic `each` (design §6.2): runs `f` on every item and returns
  ## `nil`. Streams pull lazily; the eager kinds iterate their own items —
  ## a Map's callback sees the value, like its `map`/`filter`.
  var scope: Scope = nil
  if call != nil: scope = call.dispatchScope
  if args.len != 2:
    raise newException(GeneError, "each expects 2 arguments, got " & $args.len)
  let receiver = args[0]
  if receiver.kind notin {vkStream, vkList, vkMap, vkHashMap, vkSet}:
    return dispatchGenericForward("each", receiver, args[1 .. args.high], scope)
  if activeVmFiber != nil and receiver.kind != vkStream:
    requestCollectionFrame("each", receiver, args[1], scope)
  # The private driver stays within this consuming call. Its resumable item
  # frame allows ordinary callbacks to await even inside a spawned consumer.
  let driver = newLazyStream(receiver, pullMapStream,
    callable = args[1], close = closeStreamCallback)
  try:
    case receiver.kind
    of vkStream:
      while receiver.streamHasNext:
        discard invokeStreamCallback(driver,
          checkedStreamNext(receiver, "each item"))
    of vkList:
      for item in receiver.listItems:
        discard invokeStreamCallback(driver, item)
    of vkMap:
      for _, item in receiver.mapEntries:
        discard invokeStreamCallback(driver, item)
    of vkHashMap:
      for entry in receiver.hashMapEntries:
        discard invokeStreamCallback(driver, entry.val)
    of vkSet:
      for item in receiver.setItems:
        discard invokeStreamCallback(driver, item)
    else:
      discard
  except CatchableError as primaryError:
    try:
      driver.closeStream()
    except CatchableError:
      discard
    raise primaryError
  driver.closeStream()
  NIL



# net/http server implementation (event loop, dispatch, helpers).
proc biPkgDependency(args: openArray[Value],
                     call: ptr NativeCall): Value {.nimcall.}
proc biPkgNativeBinary(args: openArray[Value],
                       call: ptr NativeCall): Value {.nimcall.}
proc biMaterializedPath(args: openArray[Value],
                        call: ptr NativeCall): Value {.nimcall.}
include ./ext/http_server

include ./ext/csv
include ./ext/fs_walk
include ./ext/temporal
include ./ext/tzif
proc packageValue*(pkg: Package): Value

# --- package-relative immutable resources -----------------------------------

proc raisePackageResourceError(scope: Scope, message: string) {.noreturn.} =
  var props = initPropTable()
  props["message"] = newStr(message)
  var error: ref GeneError
  new(error)
  error.msg = message
  error.errVal = newNode(builtInTypeHead(scope, "PackageResourceError"),
                         props = props)
  error.hasErrVal = true
  raise error

proc selectedPackageValue(scope: Scope, value: Value): Package =
  if scope == nil or value.kind != vkMap:
    raisePackageResourceError(scope, "pkg: expected a Package value")
  let id = value.mapEntries.getOrDefault("id", NIL)
  if id.kind != vkString or not scope.application().packagesById.hasKey(id.strVal):
    raisePackageResourceError(scope, "pkg: package is not in this Application")
  result = scope.application().packagesById[id.strVal]

proc requirePackageAuthority(scope: Scope, authority, operation: string) =
  ## Immutable resource reads are capabilities supplied by the host. Creating
  ## a filesystem lease or loading native code additionally needs the same
  ## namespace authority as the direct fs/ffi API. `pkg` must not bypass an
  ## empty-grant descriptor sandbox through an indirect spelling.
  var gene, granted: Value
  if scope == nil or not scope.lookupOptional("gene", gene) or
      gene.kind != vkNamespace or
      not gene.nsScope.lookupOptional(authority, granted):
    raisePackageResourceError(scope, operation & " requires " & authority & " authority")

proc biPkgApplication(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 0:
    raise newException(GeneError, "pkg/application expects no arguments")
  let scope = if call == nil: nil else: call[].dispatchScope
  if scope == nil:
    raise newException(GeneError, "pkg/application requires an Application")
  let app = scope.application()
  var fields = initPropTable()
  fields["root"] = newStr(app.appPackage.root)
  fields["source_root"] = newStr(
    if app.executionSourceRoot.len > 0: app.executionSourceRoot
    else: app.appPackage.root)
  fields["provenance"] =
    if app.executionProvenance.kind == vkMap: app.executionProvenance else: NIL
  freezeValue(newMap(fields))

proc biPkgCanonicalDigest(args: openArray[Value]): Value {.nimcall.} =
  requireOne("pkg/canonical_digest", args)
  newStr(canonicalDigest(args[0]))

proc packageResourceBytes(args: openArray[Value], call: ptr NativeCall,
                          text: bool): Value =
  let scope = if call == nil: nil else: call[].dispatchScope
  if args.len != 2 or args[1].kind != vkString:
    raisePackageResourceError(scope, "pkg/read requires a Package and path Str")
  let pkg = selectedPackageValue(scope, args[0])
  var maxBytes = 16 * 1024 * 1024
  if call != nil:
    for i, name in call[].namedNames:
      if name != "max_bytes":
        raisePackageResourceError(scope, "pkg/read unknown option: " & name)
      let value = call[].namedValues[i]
      if value.kind != vkInt or not value.intFitsInt64 or value.intVal < 1 or
          value.intVal > 64 * 1024 * 1024:
        raisePackageResourceError(scope, "pkg/read ^max_bytes must be bounded Int")
      maxBytes = int(value.intVal)
  var path: string
  try:
    path = normalizeRelativePath(args[1].strVal, "resource", pkg.manifestPath)
  except PackageError as error:
    raisePackageResourceError(scope, "pkg/read: " & error.msg)
  let app = scope.application()
  if path.len == 0 or not app.resourceIndex.hasKey(pkg.id) or
      not app.resourceIndex[pkg.id].hasKey(path):
    raisePackageResourceError(scope, "pkg/read resource is not selected: " & path)
  let selected = app.resourceIndex[pkg.id][path]
  if selected.size > maxBytes:
    raisePackageResourceError(scope, "pkg/read resource exceeds max_bytes")
  let absolute = selected.sourcePath
  try:
    if not fileExists(absolute) or symlinkExists(absolute) or
        not containsPath(canonicalPath(selected.sourceRoot),
                         canonicalPath(absolute)):
      raisePackageResourceError(scope, "pkg/read resource is missing: " & path)
    let bytes = readFile(absolute)
    if bytes.len != selected.size or
        "sha256:" & sha256Hex(bytes) != selected.digest:
      raisePackageResourceError(scope, "pkg/read resource digest mismatch: " & path)
    if text:
      if unicode.validateUtf8(bytes) >= 0:
        raisePackageResourceError(scope, "pkg/read_text requires UTF-8: " & path)
      result = newStr(bytes)
    else:
      result = newBytes(bytes)
  except OSError as error:
    raisePackageResourceError(scope, "pkg/read: " & error.msg)

proc biPkgReadBytes(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  result = packageResourceBytes(args, call, false)

proc biPkgReadText(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  result = packageResourceBytes(args, call, true)

proc biPkgDependency(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  let scope = if call == nil: nil else: call[].dispatchScope
  if args.len != 2 or args[1].kind != vkString:
    raisePackageResourceError(scope, "pkg/dependency expects Package and alias Str")
  let pkg = selectedPackageValue(scope, args[0])
  if not pkg.dependencyEdges.hasKey(args[1].strVal):
    raisePackageResourceError(scope, "pkg/dependency alias is not declared")
  let id = pkg.dependencyEdges[args[1].strVal]
  if not scope.application().packagesById.hasKey(id):
    raisePackageResourceError(scope, "pkg/dependency is not materialized")
  result = scope.application().packagesById[id].packageValue()

proc biPkgMaterialize(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  let scope = if call == nil: nil else: call[].dispatchScope
  requirePackageAuthority(scope, "fs", "pkg/materialize")
  when defined(emscripten) or defined(geneWasm):
    raisePackageResourceError(scope, "pkg/materialize is unavailable on this target")
  else:
    if args.len != 2 or args[1].kind != vkString:
      raisePackageResourceError(scope, "pkg/materialize expects Package and path Str")
    let pkg = selectedPackageValue(scope, args[0])
    var path: string
    try:
      path = normalizeRelativePath(args[1].strVal, "resource", pkg.manifestPath)
    except PackageError as error:
      raisePackageResourceError(scope, "pkg/materialize: " & error.msg)
    let app = scope.application()
    if path.len == 0 or not app.resourceIndex.hasKey(pkg.id) or
        not app.resourceIndex[pkg.id].hasKey(path):
      raisePackageResourceError(scope, "pkg/materialize resource is not selected")
    let selected = app.resourceIndex[pkg.id][path]
    if not selected.digest.startsWith("sha256:") or
        selected.digest.len != 71:
      raisePackageResourceError(scope, "pkg/materialize invalid resource digest")
    let source = selected.sourcePath
    let cache = app.userStoreRoot / "resources" / "sha256"
    let cached = cache / selected.digest[7 .. ^1]
    try:
      if not fileExists(source) or symlinkExists(source) or
          not containsPath(canonicalPath(selected.sourceRoot),
                           canonicalPath(source)):
        raisePackageResourceError(scope, "pkg/materialize resource is missing")
      createDir(cache)
      fsRestrictDirToOwner(app.userStoreRoot / "resources")
      fsRestrictDirToOwner(cache)
      let claim = acquireProcessFileLock(cached & ".lock")
      try:
        var valid = fileExists(cached) and getFileSize(cached) == selected.size
        if valid:
          valid = "sha256:" & sha256File(cached) == selected.digest
        if not valid:
          let temporary = cached & ".tmp-" & $getCurrentProcessId()
          if fileExists(temporary): removeFile(temporary)
          try:
            copyFile(source, temporary)
            setFilePermissions(temporary, {fpUserRead, fpUserWrite})
            if getFileSize(temporary) != selected.size or
                "sha256:" & sha256File(temporary) != selected.digest:
              raisePackageResourceError(scope,
                "pkg/materialize source changed during copy")
            moveFile(temporary, cached)
          except CatchableError:
            if fileExists(temporary): removeFile(temporary)
            raise
      finally:
        claim.release()
      let id = nextRuntimeResourceId()
      result = newRuntimeResourceHandle(scope, "MaterializedResource", id)
      acquire(resourceRecordLock)
      try:
        materializedResourceRecords[id] = MaterializedResourceRecord(
          application: app, path: cached, digest: selected.digest)
        materializedLeaseCounts[cached] =
          materializedLeaseCounts.getOrDefault(cached) + 1
      finally:
        release(resourceRecordLock)
    except OSError as error:
      raisePackageResourceError(scope, "pkg/materialize: " & error.msg)

proc biPkgNativeBinary(args: openArray[Value],
                       call: ptr NativeCall): Value {.nimcall.} =
  let scope = if call == nil: nil else: call[].dispatchScope
  if args.len != 2 or args[1].kind != vkString:
    raisePackageResourceError(scope,
      "pkg/native_binary expects Package and recipe alias Str")
  let pkg = selectedPackageValue(scope, args[0])
  let app = scope.application()
  if not app.nativeBinaryIndex.hasKey(pkg.id) or
      not app.nativeBinaryIndex[pkg.id].hasKey(args[1].strVal):
    raisePackageResourceError(scope,
      "native binary recipe is not selected: " & args[1].strVal)
  let selected = app.nativeBinaryIndex[pkg.id][args[1].strVal]
  if selected.target != hostCPU & "-" & hostOS:
    raisePackageResourceError(scope,
      "native binary target is incompatible with this runtime")
  biPkgMaterialize([args[0], newStr(selected.path)], call)

proc requireMaterialized(scope: Scope, value: Value):
                         MaterializedResourceRecord =
  let expected = builtInTypeHead(scope, "MaterializedResource")
  if value.kind != vkNode or value.nodeResourceId == 0 or
      not value.head.typeInheritsFrom(expected):
    raisePackageResourceError(scope, "expected a MaterializedResource")
  acquire(resourceRecordLock)
  try:
    result = materializedResourceRecords.getOrDefault(value.nodeResourceId)
    if result == nil or result.application != scope.application():
      raisePackageResourceError(scope, "materialized resource is unavailable")
  finally:
    release(resourceRecordLock)

proc biMaterializedPath(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  let scope = if call == nil: nil else: call[].dispatchScope
  if args.len != 1:
    raisePackageResourceError(scope, "MaterializedResource/path expects receiver")
  let record = requireMaterialized(scope, args[0])
  if record.closed:
    raisePackageResourceError(scope, "materialized resource is closed")
  result = newStr(record.path)

proc biMaterializedClose(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  let scope = if call == nil: nil else: call[].dispatchScope
  if args.len != 1:
    raisePackageResourceError(scope, "MaterializedResource/close expects receiver")
  let record = requireMaterialized(scope, args[0])
  acquire(resourceRecordLock)
  try:
    if not record.closed:
      record.closed = true
      let count = materializedLeaseCounts.getOrDefault(record.path)
      if count <= 1: materializedLeaseCounts.del(record.path)
      else: materializedLeaseCounts[record.path] = count - 1
  finally:
    release(resourceRecordLock)
  result = NIL

proc closeMaterializedResourceFromNative*(lease: Value, scope: Scope) =
  var call = NativeCall(dispatchScope: scope)
  discard biMaterializedClose([lease], addr call)

var nativeModuleRuntimeIdentity = ""
var nativeModuleRuntimeIdentityLock: Lock
initLock(nativeModuleRuntimeIdentityLock)

proc currentNativeModuleRuntimeIdentity(): string =
  acquire(nativeModuleRuntimeIdentityLock)
  try:
    if nativeModuleRuntimeIdentity.len == 0:
      nativeModuleRuntimeIdentity =
        "gene-phase1/abi-1/sha256:" & sha256File(getAppFilename())
    result = nativeModuleRuntimeIdentity
  finally:
    release(nativeModuleRuntimeIdentityLock)

proc biPkgNativeModule(args: openArray[Value],
                       call: ptr NativeCall): Value {.nimcall.} =
  let scope = if call == nil: nil else: call[].dispatchScope
  requirePackageAuthority(scope, "ffi", "pkg/native_module")
  if scope == nil or args.len != 2 or args[1].kind != vkString:
    raisePackageResourceError(scope,
      "pkg/native_module expects Package and recipe alias Str")
  if nativeModuleAdapter.open == nil:
    raisePackageResourceError(scope,
      "managed native module loader is unavailable")
  let pkg = selectedPackageValue(scope, args[0])
  let app = scope.application()
  if not app.nativeBinaryIndex.hasKey(pkg.id) or
      not app.nativeBinaryIndex[pkg.id].hasKey(args[1].strVal):
    raisePackageResourceError(scope,
      "native module recipe is not selected: " & args[1].strVal)
  let selected = app.nativeBinaryIndex[pkg.id][args[1].strVal]
  if selected.abiKind != "gene_api" or
      selected.abiVersion != nativeModuleAdapter.abiVersion:
    raisePackageResourceError(scope,
      "native module requires the supported gene_api ABI")
  if selected.runtimeIdentity != currentNativeModuleRuntimeIdentity():
    raisePackageResourceError(scope,
      "native module runtime identity is incompatible")
  let lease = biPkgNativeBinary(args, call)
  try:
    let path = requireMaterialized(scope, lease).path
    result = nativeModuleAdapter.open(lease, path, selected.alias, scope)
  except CatchableError:
    closeMaterializedResourceFromNative(lease, scope)
    raise


# --- paths: lexical native-platform path operations ---------------------------

proc raisePathError(message: string, scope: Scope) =
  var props = initPropTable()
  props["message"] = newStr(message)
  var e: ref GeneError
  new(e)
  e.msg = message
  e.errVal = newNode(builtInTypeHead(scope, "PathError"), props = props)
  e.hasErrVal = true
  raise e

proc pathPieces(path: string): seq[string] =
  var part = ""
  for ch in path:
    let separator =
      when defined(windows): ch == '/' or ch == '\\'
      else: ch == '/'
    if separator:
      if part.len > 0:
        result.add part
        part = ""
    else:
      part.add ch
  if part.len > 0:
    result.add part

proc pathLexicalNormalize(raw: string): string =
  when defined(windows):
    # Windows drive/UNC semantics need a separately qualified path profile.
    # Refuse those inputs instead of treating them as a relative POSIX path.
    if raw.len >= 2 and raw[1] == ':':
      raise newException(ValueError, "drive-qualified paths are not yet supported")
    if raw.startsWith("\\\\") or raw.startsWith("//"):
      raise newException(ValueError, "UNC paths are not yet supported")
  let absolute = raw.len > 0 and raw[0] == '/'
  var parts: seq[string]
  for part in pathPieces(raw):
    if part == ".":
      continue
    if part == "..":
      if parts.len > 0 and parts[^1] != "..":
        parts.setLen(parts.len - 1)
      elif not absolute:
        parts.add part
    else:
      parts.add part
  result = parts.join("/")
  if absolute:
    result = "/" & result
  elif result.len == 0:
    result = "."

proc pathInput(name: string, value: Value, scope: Scope): string =
  if value.kind != vkString:
    raisePathError(name & " expects Str path", scope)
  result = value.strVal
  if '\0' in result:
    raisePathError(name & " rejects NUL in a path", scope)

proc pathBaseName(path: string): string =
  let normalized = pathLexicalNormalize(path)
  if normalized in ["/", "."]:
    return ""
  let slash = normalized.rfind('/')
  result = if slash < 0: normalized else: normalized[slash + 1 .. ^1]

proc biPathNormalize(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  let scope = if call == nil: nil else: call[].dispatchScope
  if args.len != 1: raisePathError("path/normalize expects one path", scope)
  try:
    result = newStr(pathLexicalNormalize(pathInput("path/normalize", args[0], scope)))
  except ValueError as e:
    raisePathError("path/normalize: " & e.msg, scope)

proc biPathJoin(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  let scope = if call == nil: nil else: call[].dispatchScope
  if args.len == 0: raisePathError("path/join expects at least one path", scope)
  var joined = pathInput("path/join", args[0], scope)
  for i in 1 ..< args.len:
    let part = pathInput("path/join", args[i], scope)
    if part.len > 0 and (isAbsolute(part) or
        (when defined(windows): part.len >= 2 and part[1] == ':'
         else: false)):
      raisePathError("path/join rejects an absolute later component", scope)
    if part.len > 0:
      if joined.len > 0 and joined[^1] != '/': joined.add '/'
      joined.add part
  try:
    result = newStr(pathLexicalNormalize(joined))
  except ValueError as e:
    raisePathError("path/join: " & e.msg, scope)

proc biPathParent(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  let scope = if call == nil: nil else: call[].dispatchScope
  if args.len != 1: raisePathError("path/parent expects one path", scope)
  try:
    let p = pathLexicalNormalize(pathInput("path/parent", args[0], scope))
    let slash = p.rfind('/')
    result = newStr(if p == "/": "/"
                    elif p == "." or slash < 0: "."
                    elif slash == 0: "/"
                    else: p[0 ..< slash])
  except ValueError as e:
    raisePathError("path/parent: " & e.msg, scope)

proc biPathName(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  let scope = if call == nil: nil else: call[].dispatchScope
  if args.len != 1: raisePathError("path/name expects one path", scope)
  try:
    result = newStr(pathBaseName(pathInput("path/name", args[0], scope)))
  except ValueError as e:
    raisePathError("path/name: " & e.msg, scope)

proc biPathExtension(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  let scope = if call == nil: nil else: call[].dispatchScope
  if args.len != 1: raisePathError("path/extension expects one path", scope)
  try:
    let name = pathBaseName(pathInput("path/extension", args[0], scope))
    let dot = name.rfind('.')
    result = newStr(if dot <= 0: "" else: name[dot .. ^1])
  except ValueError as e:
    raisePathError("path/extension: " & e.msg, scope)

proc biPathRelative(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  let scope = if call == nil: nil else: call[].dispatchScope
  if args.len != 2: raisePathError("path/relative expects target and base", scope)
  try:
    let target = pathLexicalNormalize(pathInput("path/relative", args[0], scope))
    let base = pathLexicalNormalize(pathInput("path/relative", args[1], scope))
    if target.startsWith("/") != base.startsWith("/"):
      raisePathError("path/relative requires compatible roots", scope)
    let toParts = pathPieces(target)
    let fromParts = pathPieces(base)
    if (toParts.len > 0 and toParts[0] == "..") or
        (fromParts.len > 0 and fromParts[0] == ".."):
      raisePathError("path/relative cannot resolve a leading parent segment", scope)
    var common = 0
    while common < toParts.len and common < fromParts.len and
        toParts[common] == fromParts[common]:
      inc common
    var relativeParts: seq[string]
    for _ in common ..< fromParts.len: relativeParts.add ".."
    for i in common ..< toParts.len: relativeParts.add toParts[i]
    result = newStr(if relativeParts.len == 0: "." else: relativeParts.join("/"))
  except ValueError as e:
    raisePathError("path/relative: " & e.msg, scope)

# --- os: environment, subprocess, and line input (docs/stdlib.md "Module Layout") ---
#
# Errors are the typed `OsError`.

proc raiseOsError(message: string, scope: Scope) =
  var props = initPropTable()
  props["message"] = newStr(message)
  var e: ref GeneError
  new(e)
  e.msg = message
  e.errVal = newNode(builtInTypeHead(scope, "OsError"), props = props)
  e.hasErrVal = true
  raise e

proc raiseFilesystemOperationError(name: string, error: ref CatchableError,
                                   scope: Scope) {.noreturn.} =
  if error of GeneError:
    raise error
  raiseOsError(name & ": " & error.msg, scope)

proc biOsGetEnv(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len notin 1..2:
    raise newException(GeneError,
      "os/get_env expects (name) or (name, default), got " &
      $args.len & " arguments")
  let scope = if call == nil: nil else: call[].dispatchScope
  requireStr("os/get_env name", args[0])
  if existsEnv(args[0].strVal):
    newStr(getEnv(args[0].strVal))
  elif args.len == 2:
    args[1]
  else:
    raiseOsError("os/get_env: environment variable not set: " &
                 args[0].strVal, scope)
    NIL

proc biOsEnvOpt(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 1:
    raise newException(GeneError, "os/env? expects (name)")
  requireStr("os/env? name", args[0])
  if existsEnv(args[0].strVal): newStr(getEnv(args[0].strVal)) else: NIL

proc biOsExecutablePath(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 0:
    raise newException(GeneError,
      "os/executable_path expects no arguments, got " & $args.len)
  newStr(getAppFilename())

proc biOsLaunchDir(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 0:
    raise newException(GeneError,
      "os/launch_dir expects no arguments, got " & $args.len)
  let app = (if call == nil: nil else: call[].dispatchScope).application()
  if app == nil:
    raise newException(GeneError,
      "os/launch_dir requires an application runtime")
  newStr(app.launchDir)

proc biOsSetCwd(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("os/set_cwd", args)
  requireStr("os/set_cwd", args[0])
  let scope = if call == nil: nil else: call.dispatchScope
  try:
    setCurrentDir(args[0].strVal)
  except OSError as error:
    raiseOsError("os/set_cwd: " & error.msg, scope)
  NIL

const osExecDefaultOutputCap = 1024 * 1024
const osExecPollMs = 5

proc osExecText(name: string, value: Value, scope: Scope): string =
  requireStr(name, value)
  result = value.strVal
  if '\0' in result:
    raiseOsError(name & " must not contain NUL", scope)

proc osExecEnvironmentKey(name: string): string =
  when defined(windows): name.toUpperAscii()
  else: name

proc osExecEnvironment(name: string, value: Value,
                       scope: Scope): Option[seq[string]] =
  requirePropMap(name & " ^env", value)
  if value.mapEntries.len == 0: return none(seq[string])
  var values = initOrderedTable[string, tuple[name, value: string]]()
  for key, text in envPairs():
    values[osExecEnvironmentKey(key)] = (key, text)
  var seen = initHashSet[string]()
  for key, item in value.mapEntries:
    if key.len == 0 or '=' in key or '\0' in key:
      raiseOsError(name & " ^env has an invalid variable name", scope)
    let canonical = osExecEnvironmentKey(key)
    if canonical in seen:
      raiseOsError(name & " ^env has conflicting variable names: " & key, scope)
    seen.incl canonical
    if item.kind == vkNil:
      values.del(canonical)
    else:
      let text = osExecText(name & " ^env ^" & key, item, scope)
      if canonical == "PATH":
        if text.len == 0: continue
        let inherited = values.getOrDefault(canonical).value
        values[canonical] = (key, text &
          (if inherited.len > 0: $PathSep & inherited else: ""))
      else:
        values[canonical] = (key, text)
  var entries: seq[string]
  for _, item in values:
    entries.add item.name & "=" & item.value
  some(entries)

proc parseOsExecCommand(name: string, args: openArray[Value],
                        call: ptr NativeCall): tuple[cmd: string, args: seq[string],
                        full: bool, directory: string, environment: Option[seq[string]]] =
  ## Positional argv is literal. Shell parsing requires an explicit ^^full and
  ## exactly one command string. Keep the named form for existing callers, but
  ## do not guess how to combine it with positional arguments.
  let scope = if call == nil: nil else: call.dispatchScope
  var namedCmd, namedArgs, full = false
  if call != nil:
    for i, key in call.namedNames:
      let value = call.namedValues[i]
      case key
      of "cmd":
        namedCmd = true
        result.cmd = osExecText(name & " ^cmd", value, scope)
      of "args":
        namedArgs = true
        if value.kind != vkList:
          raiseOsError(name & " ^args must be a List of Str", scope)
        for item in value.listItems:
          result.args.add osExecText(name & " ^args item", item, scope)
      of "full":
        if value.kind != vkBool:
          raiseOsError(name & " ^full expects Bool", scope)
        full = value.boolVal
      of "dir":
        result.directory = osExecText(name & " ^dir", value, scope)
        if result.directory.len > 0:
          try:
            when defined(posix) and not defined(emscripten) and not defined(geneWasm):
              result.directory = resolveProcessDirectory(result.directory)
            else:
              result.directory = absolutePath(result.directory)
          except OSError as error:
            raiseOsError(name & " ^dir: " & error.msg, scope)
      of "env":
        result.environment = osExecEnvironment(name, value, scope)
      else: discard # Each exec variant validates its own remaining options.
  if namedCmd or namedArgs:
    if args.len != 0 or full:
      raiseOsError(name & " cannot combine ^cmd/^args with positional arguments or ^^full", scope)
    if not namedCmd or result.cmd.len == 0:
      raiseOsError(name & " requires a non-empty command", scope)
    return
  if args.len == 0:
    raiseOsError(name & " requires a command followed by string arguments", scope)
  if full and args.len != 1:
    raiseOsError(name & " ^^full expects exactly one command string", scope)
  result.cmd = osExecText(name & " command", args[0], scope)
  if result.cmd.len == 0:
    raiseOsError(name & " requires a non-empty command", scope)
  if full:
    result.full = true
    when defined(windows):
      result.args = @["/d", "/s", "/c", result.cmd]
      if result.environment.isSome:
        result.cmd = "cmd.exe"
        for entry in result.environment.get:
          if entry.len >= 8 and entry[0 .. 7].toUpperAscii() == "COMSPEC=":
            result.cmd = entry[8 .. ^1]
      else:
        result.cmd = getEnv("COMSPEC", "cmd.exe")
    else:
      result.args = @["-c", result.cmd]
      result.cmd = "/bin/sh"
  else:
    for i in 1 ..< args.len:
      result.args.add osExecText(name & " argument " & $i, args[i], scope)

const nativeProcessBackend = defined(posix) and not defined(emscripten) and
                             not defined(geneWasm)
when nativeProcessBackend:
  type OsExecProcess = ProcessHandle
else:
  type OsExecProcess = Process

proc startOsExecProcess(cmd, workingDir: string, args: seq[string], full: bool,
                         options: set[ProcessOption],
                         environment = none(seq[string])): OsExecProcess =
  when nativeProcessBackend:
    launchProcess(cmd, args, workingDir, environment,
      inheritStdio = poParentStreams in options,
      mergeStderr = poStdErrToStdOut in options, ownGroup = poDaemon in options)
  else:
    var childEnv: StringTableRef
    if environment.isSome:
      childEnv = newStringTable(when defined(windows): modeCaseInsensitive
                                else: modeCaseSensitive)
      for entry in environment.get:
        let separator = entry.find('=')
        childEnv[entry[0 ..< separator]] = entry[separator + 1 .. ^1]
    when defined(windows):
      if full:
        # Preserve cmd.exe's raw command-tail quoting.
        return startProcess(quoteShellWindows(cmd) & " /d /s /c \"" & args[^1] & "\"",
          workingDir = workingDir, env = childEnv,
          options = options + {poEvalCommand})
    startProcess(cmd, workingDir = workingDir, args = args,
                 env = childEnv, options = options)

proc biOsExecAsyncImpl(name: string, wantChan, inheritStdio: bool,
                       args: openArray[Value], call: ptr NativeCall): Value

proc biOsExec(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  ## Run a subprocess and return {^status ^stdout ^stderr ^timed_out}.
  ## The program and its arguments are positional Str values. ^^full selects
  ## one shell command string. ^timeout_ms bounds the run and captured output
  ## is truncated at ^max_bytes; ^cmd/^args remains a compatibility form.
  when compileOption("threads"):
    if activeVmFiber != nil:
      if activeVmFiber.nativeTask.kind != vkTask:
        let task = biOsExecAsyncImpl("os/exec", false, false, args, call)
        activeVmFiber.nativeTask = task
        call.dispatchScope.registerOwnedTask(task)
      return finishNativeTask()
  let scope = if call == nil: nil else: call[].dispatchScope
  let command = parseOsExecCommand("os/exec", args, call)
  let cmd = command.cmd
  let procArgs = command.args
  var timeoutMs = -1
  var maxBytes = osExecDefaultOutputCap
  let workdir = command.directory
  if call != nil:
    for i, name in call[].namedNames:
      let v = call[].namedValues[i]
      case name
      of "cmd", "args", "full", "dir", "env": discard
      of "timeout_ms": timeoutMs = int(requireInt64("os/exec ^timeout_ms", v))
      of "max_bytes": maxBytes = int(requireInt64("os/exec ^max_bytes", v))
      else:
        raiseOsError("os/exec got unexpected named argument: " & name, scope)
  if maxBytes <= 0:
    maxBytes = osExecDefaultOutputCap
  var process: OsExecProcess
  try:
    process = startOsExecProcess(cmd, workdir, procArgs, command.full, {poUsePath},
                                 command.environment)
  except OSError as e:
    raiseOsError("os/exec could not start '" & cmd & "': " & e.msg, scope)
  when nativeProcessBackend:
    process.closeInput()
  var outText = ""
  var errText = ""
  var outTruncated = false
  var errTruncated = false
  var timedOut = false
  let deadline =
    if timeoutMs >= 0: getMonoTime() + initDuration(milliseconds = timeoutMs)
    else: getMonoTime()

  proc appendCapped(into: var string, truncated: var bool, chunk: string) =
    if into.len >= maxBytes:
      if chunk.len > 0:
        truncated = true
      return
    if into.len + chunk.len <= maxBytes:
      into.add chunk
    else:
      truncated = true
      into.add chunk.substr(0, maxBytes - into.len - 1)

  # POSIX: drain the child's stdout/stderr *concurrently* with waiting, using
  # non-blocking reads. Reading as the child writes keeps the OS pipe buffer
  # from filling — otherwise a child emitting more than the ~64 KB pipe buffer
  # (a large API response) blocks on write, never exits, and hits the timeout
  # with its output lost. Non-blocking reads also let the wall-clock timeout
  # fire on a child that produces no output (the `sleep` case).
  when nativeProcessBackend:
    var exitCode: int
    try:
      let pump = newProcessPump(process, maxBytes, timeoutMs)
      pump.runProcessPump()
      exitCode = pump.status
      outText = pump.output[0]
      errText = pump.output[1]
      outTruncated = pump.truncated[0]
      errTruncated = pump.truncated[1]
      timedOut = pump.timedOut
      if pump.failure.len > 0: raiseOsError("os/exec " & pump.failure, scope)
    finally:
      process.close()
  elif defined(posix):
    let outFd = process.outputHandle.cint
    let errFd = process.errorHandle.cint
    discard fcntl(outFd, F_SETFL, fcntl(outFd, F_GETFL, 0) or O_NONBLOCK)
    discard fcntl(errFd, F_SETFL, fcntl(errFd, F_GETFL, 0) or O_NONBLOCK)
    var buf: array[4096, char]
    proc drainAvailable(fd: cint, into: var string, truncated: var bool) =
      while true:
        let n = read(fd, addr buf[0], buf.len)
        if n > 0:
          var chunk = newString(n)
          copyMem(addr chunk[0], addr buf[0], n)
          appendCapped(into, truncated, chunk)
        else:
          break                       # EAGAIN, EOF, or error: nothing right now
    while process.running:
      drainAvailable(outFd, outText, outTruncated)
      drainAvailable(errFd, errText, errTruncated)
      if timeoutMs >= 0 and getMonoTime() >= deadline:
        timedOut = true
        process.terminate()
        break
      os.sleep(osExecPollMs)
    var exitCode = 0
    try:
      exitCode = if timedOut: (discard process.waitForExit(); -1)
                 else: process.waitForExit()
      drainAvailable(outFd, outText, outTruncated) # final sweep after exit
      drainAvailable(errFd, errText, errTruncated)
    finally:
      process.close()
  else:
    # Non-POSIX fallback: enforce the timeout via waitForExit, then read to EOF.
    # (Windows is a documented non-goal for the agent; this keeps exec usable.)
    var exitCode = process.waitForExit(if timeoutMs >= 0: timeoutMs else: -1)
    if process.running:
      timedOut = true
      process.terminate()
      exitCode = -1
    appendCapped(outText, outTruncated, process.outputStream.readAll())
    appendCapped(errText, errTruncated, process.errorStream.readAll())
    process.close()
  var props = initPropTable()
  props["status"] = newInt(exitCode)
  props["stdout"] = newStr(outText)
  props["stderr"] = newStr(errText)
  props["stdout_truncated"] = if outTruncated: TRUE else: FALSE
  props["stderr_truncated"] = if errTruncated: TRUE else: FALSE
  props["truncated"] = if outTruncated or errTruncated: TRUE else: FALSE
  props["timed_out"] = if timedOut: TRUE else: FALSE
  newMap(props)

proc biOsExecStream(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  ## Run a subprocess like os/exec, but invoke optional callbacks as output
  ## arrives: ^stdout receives raw chunks and ^stdout_line receives complete
  ## stdout lines without the trailing newline. The final return value keeps the
  ## same captured-output shape as os/exec.
  let scope = if call == nil: nil else: call[].dispatchScope
  let command = parseOsExecCommand("os/exec_stream", args, call)
  let cmd = command.cmd
  let procArgs = command.args
  var timeoutMs = -1
  var maxBytes = osExecDefaultOutputCap
  let workdir = command.directory
  var stdoutCb = NIL
  var stdoutLineCb = NIL
  var stderrCb = NIL
  if call != nil:
    for i, name in call[].namedNames:
      let v = call[].namedValues[i]
      case name
      of "cmd", "args", "full", "dir", "env": discard
      of "timeout_ms": timeoutMs = int(requireInt64("os/exec_stream ^timeout_ms", v))
      of "max_bytes": maxBytes = int(requireInt64("os/exec_stream ^max_bytes", v))
      of "stdout":
        stdoutCb = v
      of "stdout_line":
        stdoutLineCb = v
      of "stderr":
        stderrCb = v
      else:
        raiseOsError("os/exec_stream got unexpected named argument: " & name, scope)
  if maxBytes <= 0:
    maxBytes = osExecDefaultOutputCap

  var process: OsExecProcess
  try:
    process = startOsExecProcess(cmd, workdir, procArgs, command.full, {poUsePath},
                                 command.environment)
  except OSError as e:
    raiseOsError("os/exec_stream could not start '" & cmd & "': " & e.msg, scope)
  when nativeProcessBackend:
    process.closeInput()

  var outText = ""
  var errText = ""
  var outTruncated = false
  var errTruncated = false
  var timedOut = false
  var stdoutLineBuf = ""
  let deadline =
    if timeoutMs >= 0: getMonoTime() + initDuration(milliseconds = timeoutMs)
    else: getMonoTime()

  proc appendCapped(into: var string, truncated: var bool, chunk: string) =
    if into.len >= maxBytes:
      if chunk.len > 0:
        truncated = true
      return
    if into.len + chunk.len <= maxBytes:
      into.add chunk
    else:
      truncated = true
      into.add chunk.substr(0, maxBytes - into.len - 1)

  proc callChunk(cb: Value, chunk: string) =
    if cb.kind != vkNil:
      discard applyCall(cb, [newStr(chunk)], NamedArgs(), scope)

  proc callStdoutLines(chunk: string) =
    if stdoutLineCb.kind == vkNil:
      return
    for ch in chunk:
      if ch == '\n':
        if stdoutLineBuf.len > 0 and stdoutLineBuf[^1] == '\r':
          stdoutLineBuf.setLen(stdoutLineBuf.len - 1)
        discard applyCall(stdoutLineCb, [newStr(stdoutLineBuf)], NamedArgs(), scope)
        stdoutLineBuf.setLen(0)
      else:
        stdoutLineBuf.add ch

  proc finishStdoutLine() =
    if stdoutLineCb.kind != vkNil and stdoutLineBuf.len > 0:
      discard applyCall(stdoutLineCb, [newStr(stdoutLineBuf)], NamedArgs(), scope)
      stdoutLineBuf.setLen(0)

  proc handleStdoutChunk(chunk: string) =
    callChunk(stdoutCb, chunk)
    callStdoutLines(chunk)
    appendCapped(outText, outTruncated, chunk)

  proc handleStderrChunk(chunk: string) =
    callChunk(stderrCb, chunk)
    appendCapped(errText, errTruncated, chunk)

  try:
    when nativeProcessBackend:
      let pump = newProcessPump(process, 0, timeoutMs,
        stdout = handleStdoutChunk, stderr = handleStderrChunk)
      pump.runProcessPump()
      timedOut = pump.timedOut
      if pump.failure.len > 0: raiseOsError("os/exec_stream " & pump.failure, scope)
      finishStdoutLine()
      var props = initPropTable()
      props["status"] = newInt(pump.status)
      props["stdout"] = newStr(outText)
      props["stderr"] = newStr(errText)
      props["stdout_truncated"] = newBool(outTruncated)
      props["stderr_truncated"] = newBool(errTruncated)
      props["truncated"] = newBool(outTruncated or errTruncated)
      props["timed_out"] = newBool(timedOut)
      return newMap(props)
    elif defined(posix):
      let outFd = process.outputHandle.cint
      let errFd = process.errorHandle.cint
      discard fcntl(outFd, F_SETFL, fcntl(outFd, F_GETFL, 0) or O_NONBLOCK)
      discard fcntl(errFd, F_SETFL, fcntl(errFd, F_GETFL, 0) or O_NONBLOCK)
      var buf: array[4096, char]
      proc drainAvailable(fd: cint, handle: proc(chunk: string)) =
        while true:
          let n = read(fd, addr buf[0], buf.len)
          if n > 0:
            var chunk = newString(n)
            copyMem(addr chunk[0], addr buf[0], n)
            handle(chunk)
          else:
            break
      while process.running:
        drainAvailable(outFd, handleStdoutChunk)
        drainAvailable(errFd, handleStderrChunk)
        if timeoutMs >= 0 and getMonoTime() >= deadline:
          timedOut = true
          process.terminate()
          break
        os.sleep(osExecPollMs)
      var exitCode = 0
      exitCode = if timedOut: (discard process.waitForExit(); -1)
                 else: process.waitForExit()
      drainAvailable(outFd, handleStdoutChunk)
      drainAvailable(errFd, handleStderrChunk)
      finishStdoutLine()
      var props = initPropTable()
      props["status"] = newInt(exitCode)
      props["stdout"] = newStr(outText)
      props["stderr"] = newStr(errText)
      props["stdout_truncated"] = if outTruncated: TRUE else: FALSE
      props["stderr_truncated"] = if errTruncated: TRUE else: FALSE
      props["truncated"] = if outTruncated or errTruncated: TRUE else: FALSE
      props["timed_out"] = if timedOut: TRUE else: FALSE
      return newMap(props)
    else:
      var exitCode = process.waitForExit(if timeoutMs >= 0: timeoutMs else: -1)
      if process.running:
        timedOut = true
        process.terminate()
        exitCode = -1
      let allOut = process.outputStream.readAll()
      let allErr = process.errorStream.readAll()
      handleStdoutChunk(allOut)
      handleStderrChunk(allErr)
      finishStdoutLine()
      var props = initPropTable()
      props["status"] = newInt(exitCode)
      props["stdout"] = newStr(outText)
      props["stderr"] = newStr(errText)
      props["stdout_truncated"] = if outTruncated: TRUE else: FALSE
      props["stderr_truncated"] = if errTruncated: TRUE else: FALSE
      props["truncated"] = if outTruncated or errTruncated: TRUE else: FALSE
      props["timed_out"] = if timedOut: TRUE else: FALSE
      return newMap(props)
  except:
    if process.running:
      process.terminate()
    raise
  finally:
    process.close()

when compileOption("threads"):
  when defined(posix) and not nativeProcessBackend:
    {.emit: """
#include <signal.h>
#include <pthread.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
static ssize_t gene_os_exec_pipe_write(int fd, const void *data, size_t len) {
  sigset_t blocked;
  sigset_t oldmask;
  sigset_t pending;
  sigemptyset(&blocked);
  sigaddset(&blocked, SIGPIPE);
  int mask_error = pthread_sigmask(SIG_BLOCK, &blocked, &oldmask);
  if (mask_error != 0) { errno = mask_error; return -1; }
  ssize_t count = write(fd, data, len);
  int saved_errno = errno;
  if (count < 0 && saved_errno == EPIPE &&
      !sigismember(&oldmask, SIGPIPE) &&
      sigpending(&pending) == 0 && sigismember(&pending, SIGPIPE)) {
    int received;
    sigwait(&blocked, &received);
  }
  pthread_sigmask(SIG_SETMASK, &oldmask, NULL);
  errno = saved_errno;
  return count;
}
static int gene_os_exec_finish_stdin(int fd) {
  int replacement = open("/dev/null", O_WRONLY | O_CLOEXEC);
  if (replacement < 0) return -1;
  int result = dup2(replacement, fd);
  int saved_errno = errno;
  close(replacement);
  errno = saved_errno;
  return result < 0 ? -1 : 0;
}
""".}
    proc osExecPipeWrite(fd: cint, data: pointer, len: csize_t): int
      {.importc: "gene_os_exec_pipe_write", nodecl.}
    proc osExecFinishStdin(fd: cint): cint
      {.importc: "gene_os_exec_finish_stdin", nodecl.}

  # The sync and async inherited-stream variants share one physical terminal
  # and manipulate process-wide SIGINT disposition. Serialize both surfaces.
  var osExecStdioLock: Lock
  initLock(osExecStdioLock)
  when nativeProcessBackend:
    # The monitor lease lasts for the process lifetime. A synchronous handoff
    # can therefore wake queued async handoffs safely after releasing the lock.
    var osExecStdioWake: Atomic[pointer]
    proc wakeOsExecStdioWaiters() =
      signalWake(cast[NativeWakeSignal](osExecStdioWake.load(moAcquire)))

proc biOsExecStdio(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  ## Run a subprocess attached to this process's stdin/stdout/stderr and return
  ## its exit status. This is for terminal handoff cases where captured
  ## `os/exec` would break interactive behavior.
  let scope = if call == nil: nil else: call[].dispatchScope
  let command = parseOsExecCommand("os/exec_stdio", args, call)
  let cmd = command.cmd
  let procArgs = command.args
  let workdir = command.directory
  if call != nil:
    for i, name in call[].namedNames:
      let v = call[].namedValues[i]
      case name
      of "cmd", "args", "full", "dir", "env": discard
      else:
        raiseOsError("os/exec_stdio got unexpected named argument: " & name, scope)
  when compileOption("threads"):
    acquire(osExecStdioLock)
  var process: OsExecProcess
  try:
    process = startOsExecProcess(cmd, workdir, procArgs, command.full,
                                {poUsePath, poParentStreams}, command.environment)
  except OSError as e:
    when compileOption("threads"):
      release(osExecStdioLock)
      when nativeProcessBackend: wakeOsExecStdioWaiters()
    raiseOsError("os/exec_stdio could not start '" & cmd & "': " & e.msg, scope)
  # system(3) semantics: the child owns the terminal, so Ctrl-C must reach the
  # child (and whatever it runs), not kill this process while it waits.
  when defined(posix):
    var ignoreInt, oldInt: Sigaction
    ignoreInt.sa_handler = SIG_IGN
    discard sigemptyset(ignoreInt.sa_mask)
    ignoreInt.sa_flags = 0
    let intIgnored = sigaction(SIGINT, ignoreInt, oldInt) == 0
  try:
    newInt(process.waitForExit())
  finally:
    when defined(posix):
      if intIgnored:
        discard sigaction(SIGINT, oldInt, nil)
    when compileOption("threads"):
      release(osExecStdioLock)
      when nativeProcessBackend: wakeOsExecStdioWaiters()
    process.close()

# --- Async exec: native monitoring with owning-lane Task settlement ---
# POSIX children share one readiness monitor, with inherited terminal handoffs
# serialized. Legacy platforms use workers. Producers never run Gene
# code or operate on GC-managed objects owned by the scheduler.

when compileOption("threads"):
  # Job records cross the scheduler->worker thread boundary. On the default
  # orc build the only rc-safe discipline is: the worker performs ZERO
  # refcount operations on anything the scheduler thread can also touch.
  # Gene's manual-rc payloads (strings, lists, maps) are atomic once
  # markSharedValue'd, but OBJECT_TAG payloads — Task and Channel, exactly
  # what an exec job must hold — retain/release through plain GC_ref/GC_unref:
  # non-atomic ORC ops whose cycle bookkeeping also mutates a global buffer.
  # A worker-side retain or release of those races the scheduler and corrupts
  # the heap (crashes surface later in unrelated Value ops or allocations).
  # So the worker never dereferences task/channel Values and publishes only
  # plain shared-memory buffers; scheduler polling handles cancellation,
  # Gene-value construction, channel delivery, and settlement. Scheduler-only
  # pending refs own Task/Channel values; the worker ctx is plain shared memory.
  type
    SharedExecText = object
      data: pointer
      len: int
    SharedExecLine = object
      next: ptr SharedExecLine
      text: SharedExecText
    SharedExecArg = object
      next: ptr SharedExecArg
      text: SharedExecText
    OsExecAsyncCtx = object
      fileOperation: NativeFileOperation
      fileOwnerOnly: bool
      fileFirst, fileLines: int
      resultPageNext: int
      resultPageBinary: bool
      name: SharedExecText
      cmd: SharedExecText
      procArgs: ptr SharedExecArg
      processEnv: ptr SharedExecArg
      hasEnvironment: bool
      workdir: SharedExecText
      inheritStdio: bool
      full: bool
      mergeStderr: bool
      timeoutMs: int
      maxBytes: int
      taskBits: uint64      # external Task (OBJECT_TAG bits), worker-borrowed
      lineChanBits: uint64  # 0, or a Channel (bits) receiving stdout lines
      stdoutPipeFd: cint    # duplicate of an io/pipe writer, worker-owned
      stderrPipeFd: cint
      stdinPipeFd: cint     # duplicate of an io/pipe reader, worker-owned
      lineLock: Lock
      lineHead: ptr SharedExecLine
      lineTail: ptr SharedExecLine
      resultStatus: int
      resultStdout: SharedExecText
      resultStderr: SharedExecText
      resultStdoutTruncated: bool
      resultStderrTruncated: bool
      resultTimedOut: bool
      resultFailed: bool
      resultFailure: SharedExecText
      resultCancelled: bool
      cancelRequested: bool
      # The spawner's scheduler, captured at spawn time. NOT the dispatch scope:
      # call scopes are pooled and their .application is nilled on release, so a
      # scope captured here would resolve to no scheduler by the time the worker
      # settles — wakes would be lost and fibers parked on the task/channel
      # would never resume.
      schedulerPtr: pointer
      notified: bool
      producerQueued: bool
      when nativeProcessBackend:
        completionWake: NativeWakeSignal
        controlWake: NativeWakeSignal
        nextMonitor: ptr OsExecAsyncCtx
      # Release-stored by the worker loop AFTER its final access to this job;
      # the scheduler frees the ctx (and drops the task/channel refs) only after
      # acquiring it. The scheduler then materializes and publishes the result.
      workerDone: bool
    OsExecPending {.acyclic.} = ref object
      ctx: ptr OsExecAsyncCtx
      schedulerOwner: SchedulerState
      fileErrorScope: Scope
      filePath: string
      taskOwner: Value
      lineChanOwner: Value
      pipeWriterOwner: Value
      pipeBorrow: IoPipeBorrow
      pipeScope: Scope
      stderrWriterOwner: Value
      stderrBorrow: IoPipeBorrow
      stderrScope: Scope
      stdinReaderOwner: Value
      stdinBorrow: IoPipeBorrow
      stdinScope: Scope

  proc sharedExecText(text: string): SharedExecText =
    result.len = text.len
    if text.len > 0:
      result.data = allocShared0(text.len)
      copyMem(result.data, unsafeAddr text[0], text.len)

  proc consumeSharedExecText(text: var SharedExecText): string =
    if text.len > 0:
      result = newString(text.len)
      copyMem(addr result[0], text.data, text.len)
    if text.data != nil:
      deallocShared(text.data)
    text = SharedExecText()

  proc readSharedExecText(text: SharedExecText): string =
    if text.len > 0:
      result = newString(text.len)
      copyMem(addr result[0], text.data, text.len)

  proc freeSharedExecLines(head: ptr SharedExecLine) =
    var current = head
    while current != nil:
      let next = current.next
      if current.text.data != nil:
        deallocShared(current.text.data)
      deallocShared(current)
      current = next

  proc freeOsExecCtx(ctx: ptr OsExecAsyncCtx) =
    if ctx == nil:
      return
    when nativeProcessBackend:
      if ctx.completionWake != nil:
        if not ctx.producerQueued: releaseWake(ctx.completionWake)
        releaseWake(ctx.completionWake)
      releaseWake(ctx.controlWake)
    when defined(posix):
      if ctx.stdoutPipeFd >= 0:
        discard posix.close(ctx.stdoutPipeFd)
        ctx.stdoutPipeFd = -1
      if ctx.stderrPipeFd >= 0:
        discard posix.close(ctx.stderrPipeFd)
        ctx.stderrPipeFd = -1
      if ctx.stdinPipeFd >= 0:
        discard posix.close(ctx.stdinPipeFd)
        ctx.stdinPipeFd = -1
    discard consumeSharedExecText(ctx.name)
    discard consumeSharedExecText(ctx.cmd)
    discard consumeSharedExecText(ctx.workdir)
    discard consumeSharedExecText(ctx.resultStdout)
    discard consumeSharedExecText(ctx.resultStderr)
    discard consumeSharedExecText(ctx.resultFailure)
    freeSharedExecLines(ctx.lineHead)
    for head in [ctx.procArgs, ctx.processEnv]:
      var arg = head
      while arg != nil:
        let next = arg.next
        if arg.text.data != nil:
          deallocShared(arg.text.data)
        deallocShared(arg)
        arg = next
    deinitLock(ctx.lineLock)
    deallocShared(ctx)

  # Persistent workers handle file jobs and legacy process backends.
  # Native POSIX children bypass this queue and do
  # not occupy a worker while they wait or stream.
  const osExecAsyncMaxWorkers = 32

  var osExecAsyncLock: Lock
  var osExecAsyncCond: Cond
  var osExecAsyncQueue: seq[pointer]   # borrowed OsExecAsyncCtx; registry owns
  var osExecAsyncThreads: seq[ref Thread[void]]
  var osExecAsyncIdle = 0
  # Inherited-terminal children share process-wide signal disposition and one
  # physical terminal. Serialize them even though captured exec jobs may run
  # concurrently on the rest of the worker pool.
  initLock(osExecAsyncLock)
  initCond(osExecAsyncCond)

  # Exec workers never touch this registry. Calls may nevertheless originate
  # from more than one scheduler lane, so the exec lock serializes prune/add.
  # Strong pending refs live only on scheduler lanes; workers borrow raw ctx
  # pointers and never touch the pending Task/Channel Value owners.
  var osExecAsyncPending: seq[OsExecPending]

  proc requestOsExecCancellation(task: Value): bool =
    ## The adapter owns settlement until the child has been reaped and its
    ## pipes/channel have closed. `join` must not outrun physical cleanup.
    withLock osExecAsyncLock:
      for pending in osExecAsyncPending:
        if pending.ctx != nil and pending.ctx.taskBits == task.bits:
          atomicStoreN(addr pending.ctx.cancelRequested, true, ATOMIC_RELEASE)
          when nativeProcessBackend:
            signalWake(pending.ctx.controlWake)
            signalWake(pending.ctx.completionWake)
          return true

  proc reapStoppedOsExec(process: OsExecProcess) =
    ## terminate was already requested. A child ignoring it must not strand
    ## cancellation or a configured execution timeout indefinitely.
    when nativeProcessBackend:
      discard process.waitExit(1000)
    else:
      discard process.waitForExit(1000)
    if process.running: process.kill()
    discard process.waitForExit()

  type CapturedOsExecProcess = OsExecProcess

  proc startCapturedOsExec(cmd, workingDir: string,
                          args: seq[string], mergeStderr, full: bool,
                          environment = none(seq[string])): CapturedOsExecProcess =
    startOsExecProcess(cmd, workingDir, args, full,
      if mergeStderr: {poUsePath, poDaemon, poStdErrToStdOut}
      else: {poUsePath, poDaemon}, environment)

  proc stopOsExecGroup(process: CapturedOsExecProcess) =
    ## Captured children own a process group, so shells cannot leave pipeline
    ## or background children running after timeout/cancellation.
    when nativeProcessBackend:
      process.terminateGroup()
    elif defined(posix):
      let pid = Pid(process.processID)
      if posix.kill(-pid, SIGTERM) != 0:
        # Older/fork-based osproc implementations do not honor poDaemon.
        # Keep cancellation effective even when no child group exists.
        process.terminate()
    else:
      process.terminate()

  proc reapStoppedOsExecGroup(process: CapturedOsExecProcess) =
    when nativeProcessBackend:
      discard process.waitExit(1000)
      process.killGroup()
      if process.running: process.kill()
      discard process.waitForExit()
    else:
      discard process.waitForExit(1000)
    when defined(posix) and not nativeProcessBackend:
      # Also catch descendants that ignored TERM after their shell exited.
      discard posix.kill(-Pid(process.processID), SIGKILL)
      if process.running: process.kill()
    elif not nativeProcessBackend:
      if process.running: process.kill()
    when not nativeProcessBackend:
      if process.running: discard process.waitForExit()

  proc pollOsExecAsyncCompletions() =
    pollStdinLineCompletions()
    ## Materialize Gene values and release completed jobs on the scheduler
    ## thread. Worker threads publish only native strings/ints; allocating a
    ## Gene value on a worker and freeing it on another thread corrupts ORC's
    ## thread-local allocator even when its manual refcount is atomic.
    withLock osExecAsyncLock:
      var i = 0
      while i < osExecAsyncPending.len:
        let pending {.cursor.} = osExecAsyncPending[i]
        let ctx = pending.ctx
        let owner {.cursor.} = cast[SchedulerState](ctx.schedulerPtr)
        if owner != nil and currentEventLane() != owner.rootLane:
          inc i
          continue
        var task {.cursor.}: Value
        task.bits = ctx.taskBits
        let taskCancelled = task.taskCancelled or task.taskCancelRequested
        if taskCancelled:
          atomicStoreN(addr ctx.cancelRequested, true, ATOMIC_RELEASE)
          when nativeProcessBackend: signalWake(ctx.controlWake)
        let workerDone = atomicLoadN(addr ctx.workerDone, ATOMIC_ACQUIRE)
        let cancelling = taskCancelled or (workerDone and ctx.resultCancelled)
        var lineHead, lineTail: ptr SharedExecLine
        withLock ctx.lineLock:
          lineHead = ctx.lineHead
          lineTail = ctx.lineTail
          ctx.lineHead = nil
          ctx.lineTail = nil
        var channelBlocked = false
        if cancelling:
          freeSharedExecLines(lineHead)
          lineHead = nil
        elif ctx.lineChanBits != 0:
          var channel {.cursor.}: Value
          channel.bits = ctx.lineChanBits
          while lineHead != nil:
            let line = consumeSharedExecText(lineHead.text)
            let pushed = channel.tryPushChannel(newStr(line))
            if pushed.closed:
              freeSharedExecLines(lineHead)
              lineHead = nil
              break
            if not pushed.pushed:
              lineHead.text = sharedExecText(line)
              channelBlocked = true
              break
            let consumed = lineHead
            lineHead = lineHead.next
            deallocShared(consumed)
            wakeChannelWaitersIn(
              cast[SchedulerState](ctx.schedulerPtr), channel,
              wakeSenders = false)
        if lineHead != nil:
          withLock ctx.lineLock:
            lineTail.next = ctx.lineHead
            ctx.lineHead = lineHead
            if ctx.lineTail == nil:
              ctx.lineTail = lineTail
        if workerDone and not channelBlocked:
          if pending.pipeBorrow.resourceId != 0:
            finishIoPipeOutputBorrow(pending.pipeBorrow, pending.pipeScope)
          if pending.stderrBorrow.resourceId != 0:
            finishIoPipeOutputBorrow(pending.stderrBorrow, pending.stderrScope)
          if pending.stdinBorrow.resourceId != 0:
            finishIoPipeInputBorrow(pending.stdinBorrow, pending.stdinScope)
          var channel {.cursor.}: Value
          channel.bits = ctx.lineChanBits
          if ctx.lineChanBits != 0:
            closeChannel(channel)
            let scheduler = cast[SchedulerState](ctx.schedulerPtr)
            wakeAllChannelWaitersIn(scheduler, channel, wakeSenders = false)
            wakeAllChannelWaitersIn(scheduler, channel, wakeSenders = true)
          if not cancelling:
            if ctx.resultFailed:
              let failure = consumeSharedExecText(ctx.resultFailure)
              var value = NIL
              if ctx.fileOperation != nfoNone:
                var props = initPropTable()
                props["message"] = newStr(failure)
                value = newNode(builtInTypeHead(pending.fileErrorScope, "OsError"),
                                props = props)
              if tryFailTask(task, failure, value, hasValue = value.kind != vkNil):
                wakeTaskWaitersIn(cast[SchedulerState](ctx.schedulerPtr), task)
            elif ctx.fileOperation != nfoNone:
              let value = if ctx.fileOperation == nfoReadPage:
                            fsTextPageValue(FsTextPage(
                              text: consumeSharedExecText(ctx.resultStdout),
                              lastLine: ctx.resultStatus, nextLine: ctx.resultPageNext,
                              binary: ctx.resultPageBinary,
                              truncated: ctx.resultStdoutTruncated), ctx.fileFirst)
                          elif ctx.fileOperation == nfoRead:
                            newStr(consumeSharedExecText(ctx.resultStdout))
                          else: NIL
              if tryCompleteTask(task, value):
                wakeTaskWaitersIn(cast[SchedulerState](ctx.schedulerPtr), task)
            elif ctx.inheritStdio:
              if tryCompleteTask(task, newInt(ctx.resultStatus)):
                wakeTaskWaitersIn(cast[SchedulerState](ctx.schedulerPtr), task)
            else:
              var props = initPropTable()
              props["status"] = newInt(ctx.resultStatus)
              props["stdout"] = newStr(consumeSharedExecText(ctx.resultStdout))
              props["stderr"] = newStr(consumeSharedExecText(ctx.resultStderr))
              props["stdout_truncated"] = newBool(ctx.resultStdoutTruncated)
              props["stderr_truncated"] = newBool(ctx.resultStderrTruncated)
              props["truncated"] = newBool(ctx.resultStdoutTruncated or
                                             ctx.resultStderrTruncated)
              props["timed_out"] = newBool(ctx.resultTimedOut)
              if tryCompleteTask(task, newMap(props)):
                wakeTaskWaitersIn(cast[SchedulerState](ctx.schedulerPtr), task)
          else:
            discard consumeSharedExecText(ctx.resultStdout)
            discard consumeSharedExecText(ctx.resultStderr)
            discard consumeSharedExecText(ctx.resultFailure)
            if tryCancelTask(task):
              wakeTaskWaitersIn(cast[SchedulerState](ctx.schedulerPtr), task)
          endExternalNativeOp(ctx.notified)
          pending.ctx = nil
          freeOsExecCtx(ctx)
          let last = osExecAsyncPending.high
          if i != last:
            osExecAsyncPending[i] = move osExecAsyncPending[last]
          osExecAsyncPending.setLen(last)
        else:
          inc i
    pollIoFileCompletions()
    pollHttpClientCompletions()
    pollOwnedHttpClientCompletions()
    pollHttpTlsReloadCompletions()
    pollCursesInputCompletions()
    pollNativeIngressHook()

  when nativeProcessBackend:
    type
      ExecLineState = ref object
        ctx: ptr OsExecAsyncCtx
        buffer: string
      NativeExecState = ref object
        ctx: ptr OsExecAsyncCtx
        pump: ProcessPump
        lines: ExecLineState
        oldInt: Sigaction
        intIgnored: bool

    proc publishExecLines(ctx: ptr OsExecAsyncCtx,
                          head, tail: ptr SharedExecLine) =
      if head == nil: return
      withLock ctx.lineLock:
        if ctx.lineTail == nil: ctx.lineHead = head
        else: ctx.lineTail.next = head
        ctx.lineTail = tail
      signalWake(ctx.completionWake)

    proc publishExecLine(ctx: ptr OsExecAsyncCtx, line: string) =
      let node = cast[ptr SharedExecLine](allocShared0(sizeof(SharedExecLine)))
      node.text = sharedExecText(line)
      publishExecLines(ctx, node, node)

    proc closeExecAdapters(ctx: ptr OsExecAsyncCtx) =
      for fd in [addr ctx.stdoutPipeFd, addr ctx.stderrPipeFd, addr ctx.stdinPipeFd]:
        if fd[] >= 0:
          discard posix.close(fd[])
          fd[] = -1

    proc failNativeExec(ctx: ptr OsExecAsyncCtx, message: string) =
      if ctx.resultFailed: return
      ctx.resultFailed = true
      ctx.resultFailure = sharedExecText(readSharedExecText(ctx.name) & " " & message)

    proc startNativeExec(ctx: ptr OsExecAsyncCtx): NativeExecState =
      if atomicLoadN(addr ctx.cancelRequested, ATOMIC_ACQUIRE):
        ctx.resultCancelled = true
        closeExecAdapters(ctx)
        return
      # Keep the existing async timeout origin: dequeue, before launch.
      let started = getMonoTime()
      let command = readSharedExecText(ctx.cmd)
      var args: seq[string]
      var argument = ctx.procArgs
      while argument != nil:
        args.add readSharedExecText(argument.text)
        argument = argument.next
      var environment = none(seq[string])
      if ctx.hasEnvironment:
        var entries: seq[string]
        var entry = ctx.processEnv
        while entry != nil:
          entries.add readSharedExecText(entry.text)
          entry = entry.next
        environment = some(entries)
      var process: ProcessHandle
      try:
        process = launchProcess(command, args, readSharedExecText(ctx.workdir),
          environment, ctx.inheritStdio, ctx.mergeStderr, not ctx.inheritStdio)
        let lines = ExecLineState(ctx: ctx)
        var onOutput: ProcessChunk
        if ctx.lineChanBits != 0:
          onOutput = proc(chunk: string) =
            var head, tail: ptr SharedExecLine
            for ch in chunk:
              if ch == '\n':
                if lines.buffer.len > 0 and lines.buffer[^1] == '\r':
                  lines.buffer.setLen(lines.buffer.len - 1)
                let node = cast[ptr SharedExecLine](allocShared0(sizeof(SharedExecLine)))
                node.text = sharedExecText(lines.buffer)
                if tail == nil: head = node
                else: tail.next = node
                tail = node
                lines.buffer.setLen(0)
              else: lines.buffer.add ch
            # One publication/wake per ready chunk, not one syscall per line.
            publishExecLines(lines.ctx, head, tail)
        result = NativeExecState(ctx: ctx, lines: lines,
          pump: newProcessPump(process, ctx.maxBytes, ctx.timeoutMs, started,
            ctx.stdinPipeFd, ctx.stdoutPipeFd, ctx.stderrPipeFd, onOutput))
        if ctx.inheritStdio:
          var ignoreInt: Sigaction
          ignoreInt.sa_handler = SIG_IGN
          discard sigemptyset(ignoreInt.sa_mask)
          result.intIgnored = sigaction(SIGINT, ignoreInt, result.oldInt) == 0
      except CatchableError as error:
        if process != nil: process.close()
        closeExecAdapters(ctx)
        failNativeExec(ctx, "could not start '" & command & "': " & error.msg)
        result = nil

    proc finishNativeExec(state: NativeExecState) =
      let ctx = state.ctx
      defer:
        if ctx.inheritStdio:
          release(osExecStdioLock)
          wakeOsExecStdioWaiters()
      let pump = state.pump
      if state.lines.buffer.len > 0:
        publishExecLine(ctx, state.lines.buffer)
        state.lines.buffer.setLen(0)
      if pump.failure.len > 0: failNativeExec(ctx, pump.failure)
      ctx.resultCancelled = pump.cancelled
      ctx.resultStatus = pump.status
      ctx.resultTimedOut = pump.timedOut
      ctx.resultStdout = sharedExecText(pump.output[0])
      ctx.resultStderr = sharedExecText(pump.output[1])
      ctx.resultStdoutTruncated = pump.truncated[0]
      ctx.resultStderrTruncated = pump.truncated[1]
      if state.intIgnored: discard sigaction(SIGINT, state.oldInt, nil)
      pump.process.close()
      closeExecAdapters(ctx)

    proc runNativeExecJob(ctx: ptr OsExecAsyncCtx) =
      if ctx.inheritStdio: acquire(osExecStdioLock)
      let state = startNativeExec(ctx)
      if state == nil:
        if ctx.inheritStdio:
          release(osExecStdioLock)
          wakeOsExecStdioWaiters()
        return
      try:
        var descriptors: seq[TPollfd]
        while not state.pump.done:
          drainWake(ctx.controlWake)
          state.pump.advance(atomicLoadN(addr ctx.cancelRequested, ATOMIC_ACQUIRE))
          if state.pump.done: break
          descriptors.setLen(0)
          state.pump.addInterests(descriptors)
          descriptors.add TPollfd(fd: wakeFd(ctx.controlWake), events: POLLIN)
          waitProcessIo(descriptors, state.pump.waitTimeout())
      except CatchableError as error:
        failNativeExec(ctx, "failed: " & error.msg)
      finally:
        finishNativeExec(state)

    proc publishExecDone(ctx: ptr OsExecAsyncCtx) =
      let wake = ctx.completionWake
      atomicStoreN(addr ctx.workerDone, true, ATOMIC_RELEASE)
      # Publication is the final ctx access. The separate producer lease keeps
      # the endpoint alive if the scheduler frees the context immediately.
      signalWake(wake)
      releaseWake(wake)

    var execMonitorLock: Lock
    var execMonitorThread: Thread[void]
    var execMonitorStarted = false
    var execMonitorWake: NativeWakeSignal
    var execMonitorHead, execMonitorTail: ptr OsExecAsyncCtx
    initLock(execMonitorLock)
    when defined(geneExecTests):
      var execMonitorActive, execMonitorPeak: Atomic[int]
      var execMonitorPaused: Atomic[bool]
      var execRejectSubmission: Atomic[bool]

    proc execMonitorMain() {.thread.} =
      {.cast(gcsafe).}:
        # This thread constructs and destroys every ProcessHandle/ProcessPump
        # it owns. Only raw contexts cross the scheduler/monitor boundary.
        var active: seq[NativeExecState]
        var terminalQueue: seq[ptr OsExecAsyncCtx]
        var terminalActive = false
        var descriptors: seq[TPollfd]
        while true:
          drainWake(execMonitorWake)
          # Bound launch work as well as I/O so bursts cannot indefinitely hide
          # existing deadlines or a ready child behind new submissions.
          for launch in 0..<8:
            when defined(geneExecTests):
              if execMonitorPaused.load(moAcquire): break
            var ctx: ptr OsExecAsyncCtx
            withLock execMonitorLock:
              ctx = execMonitorHead
              if ctx != nil:
                execMonitorHead = ctx.nextMonitor
                if execMonitorHead == nil: execMonitorTail = nil
                ctx.nextMonitor = nil
            if ctx == nil: break
            if ctx.inheritStdio:
              terminalQueue.add ctx
              continue
            let state = startNativeExec(ctx)
            if state == nil: publishExecDone(ctx)
            else: active.add state
          when defined(geneExecTests):
            execMonitorActive.store(active.len, moRelease)
            if active.len > execMonitorPeak.load(moRelaxed):
              execMonitorPeak.store(active.len, moRelease)
          var i = 0
          while i < active.len:
            let state = active[i]
            let ctx = state.ctx
            var failed = false
            try:
              drainWake(ctx.controlWake)
              state.pump.advance(atomicLoadN(addr ctx.cancelRequested, ATOMIC_ACQUIRE))
            except CatchableError as error:
              failNativeExec(ctx, "failed: " & error.msg)
              failed = true
            if state.pump.done or failed:
              if ctx.inheritStdio: terminalActive = false
              finishNativeExec(state)
              # Release monitor-local objects before publishing completion.
              active.delete(i)
              publishExecDone(ctx)
            else: inc i
          i = 0
          while i < terminalQueue.len:
            let ctx = terminalQueue[i]
            drainWake(ctx.controlWake)
            if atomicLoadN(addr ctx.cancelRequested, ATOMIC_ACQUIRE):
              ctx.resultCancelled = true
              closeExecAdapters(ctx)
              terminalQueue.delete(i)
              publishExecDone(ctx)
            else: inc i
          var retryTerminal = false
          if not terminalActive and terminalQueue.len > 0 and tryAcquire(osExecStdioLock):
            let ctx = terminalQueue[0]
            terminalQueue.delete(0)
            let state = startNativeExec(ctx)
            if state == nil:
              release(osExecStdioLock)
              publishExecDone(ctx)
              retryTerminal = terminalQueue.len > 0
            else:
              terminalActive = true
              active.add state
          when defined(geneExecTests):
            execMonitorActive.store(active.len, moRelease)
            if active.len > execMonitorPeak.load(moRelaxed):
              execMonitorPeak.store(active.len, moRelease)
          descriptors.setLen(0)
          descriptors.add TPollfd(fd: wakeFd(execMonitorWake), events: POLLIN)
          var timeout = -1
          for state in active:
            state.pump.addInterests(descriptors)
            descriptors.add TPollfd(fd: wakeFd(state.ctx.controlWake), events: POLLIN)
            let delay = state.pump.waitTimeout()
            if delay >= 0: timeout = if timeout < 0: delay else: min(timeout, delay)
          for ctx in terminalQueue:
            descriptors.add TPollfd(fd: wakeFd(ctx.controlWake), events: POLLIN)
          if retryTerminal: timeout = 0
          withLock execMonitorLock:
            if execMonitorHead != nil:
              when defined(geneExecTests):
                if not execMonitorPaused.load(moAcquire): timeout = 0
              else: timeout = 0
          waitProcessIo(descriptors, timeout)

    proc enqueueExecMonitor(ctx: ptr OsExecAsyncCtx) =
      withLock execMonitorLock:
        if not execMonitorStarted:
          let owner = newNativeWake(-1)
          execMonitorWake = owner.signal
          retainWake(execMonitorWake) # process-lifetime monitor lease
          try: createThread(execMonitorThread, execMonitorMain)
          except CatchableError:
            releaseWake(execMonitorWake)
            execMonitorWake = nil
            raise
          execMonitorStarted = true
          osExecStdioWake.store(cast[pointer](execMonitorWake), moRelease)
        if execMonitorTail == nil: execMonitorHead = ctx
        else: execMonitorTail.nextMonitor = ctx
        execMonitorTail = ctx
        signalWake(execMonitorWake)

    when defined(geneExecTests):
      proc execRejectNextSubmission*() =
        execRejectSubmission.store(true, moRelease)

      proc execPauseMonitor*(paused: bool) =
        withLock execMonitorLock:
          execMonitorPaused.store(paused, moRelease)
          signalWake(execMonitorWake)

      proc execMonitorStats*(): tuple[active, peak, threads: int] =
        withLock execMonitorLock:
          result = (execMonitorActive.load(moAcquire),
                    execMonitorPeak.load(moAcquire), int(execMonitorStarted))

  when not nativeProcessBackend:
    proc runLegacyExecJob(ctx: ptr OsExecAsyncCtx) {.gcsafe.} =
      {.cast(gcsafe).}:
        defer:
          when defined(posix):
            if ctx.stdoutPipeFd >= 0:
              discard posix.close(ctx.stdoutPipeFd)
              ctx.stdoutPipeFd = -1
            if ctx.stderrPipeFd >= 0:
              discard posix.close(ctx.stderrPipeFd)
              ctx.stderrPipeFd = -1
            if ctx.stdinPipeFd >= 0:
              discard posix.close(ctx.stdinPipeFd)
              ctx.stdinPipeFd = -1
        let nativeName = readSharedExecText(ctx.name)
        let nativeCmd = readSharedExecText(ctx.cmd)
        let nativeWorkdir = readSharedExecText(ctx.workdir)
        var nativeArgs: seq[string]
        var nativeArg = ctx.procArgs
        while nativeArg != nil:
          nativeArgs.add readSharedExecText(nativeArg.text)
          nativeArg = nativeArg.next
        var nativeEnvironment = none(seq[string])
        if ctx.hasEnvironment:
          var entries: seq[string]
          var entry = ctx.processEnv
          while entry != nil:
            entries.add readSharedExecText(entry.text)
            entry = entry.next
          nativeEnvironment = some(entries)
        var outText = ""
        var errText = ""
        var outTruncated = false
        var errTruncated = false
        var timedOut = false
        var cancelled = false
        var stdoutPipeFailed = false
        var stderrPipeFailed = false
        var stdinPipeFailed = false
        var lineBuf = ""
        var exitCode = 0
        var chanGone = ctx.lineChanBits == 0
        let deadline =
          if ctx.timeoutMs >= 0:
            getMonoTime() + initDuration(milliseconds = ctx.timeoutMs)
          else:
            getMonoTime()

        template appendCapped(into: var string, truncated: var bool,
                              chunk: string) =
          block:
            if into.len >= ctx.maxBytes:
              if chunk.len > 0:
                truncated = true
            elif into.len + chunk.len <= ctx.maxBytes:
              into.add chunk
            else:
              truncated = true
              into.add chunk.substr(0, ctx.maxBytes - into.len - 1)

        template sendLine(line: string) =
          ## Publish native text only. The scheduler turns it into Gene strings.
          block sendBlock:
            if not chanGone:
              let node = cast[ptr SharedExecLine](allocShared0(sizeof(SharedExecLine)))
              node.text = sharedExecText(line)
              withLock ctx.lineLock:
                if ctx.lineTail == nil:
                  ctx.lineHead = node
                  ctx.lineTail = node
                else:
                  ctx.lineTail.next = node
                  ctx.lineTail = node
              when nativeProcessBackend: signalWake(ctx.completionWake)

        template writeOutputPipe(pipeFd: cint, chunk: string,
                                 failed: var bool) =
          block:
            when defined(posix):
              if pipeFd >= 0 and not failed:
                var written = 0
                while written < chunk.len:
                  let count = osExecPipeWrite(pipeFd,
                    unsafeAddr chunk[written], csize_t(chunk.len - written))
                  if count > 0:
                    written += count
                  elif errno == EAGAIN or errno == EWOULDBLOCK:
                    if atomicLoadN(addr ctx.cancelRequested, ATOMIC_ACQUIRE):
                      cancelled = true
                      break
                    os.sleep(2)
                  else:
                    failed = true
                    break

        template handleStdoutChunk(chunk: string) =
          block:
            if ctx.stdoutPipeFd < 0:
              appendCapped(outText, outTruncated, chunk)
            writeOutputPipe(ctx.stdoutPipeFd, chunk, stdoutPipeFailed)
            if not chanGone:
              for ch in chunk:
                if ch == '\n':
                  if lineBuf.len > 0 and lineBuf[^1] == '\r':
                    lineBuf.setLen(lineBuf.len - 1)
                  sendLine(lineBuf)
                  lineBuf.setLen(0)
                else:
                  lineBuf.add ch

        template handleStderrChunk(chunk: string) =
          block:
            if ctx.stderrPipeFd < 0:
              appendCapped(errText, errTruncated, chunk)
            writeOutputPipe(ctx.stderrPipeFd, chunk, stderrPipeFailed)

        template settleFail(message: string) =
          block:
            ctx.resultFailed = true
            ctx.resultFailure = sharedExecText(message)

        template cancellationRequested(): bool =
          atomicLoadN(addr ctx.cancelRequested, ATOMIC_ACQUIRE)

        if cancellationRequested():
          ctx.resultCancelled = true
          return

        if ctx.inheritStdio:
          # Parent-stream handoff is intentionally a separate path: attempting
          # to inspect output handles from a poParentStreams Process is invalid,
          # and inherited terminal bytes must never be captured or materialized
          # as Gene values on this worker thread.
          acquire(osExecStdioLock)
          try:
            if cancellationRequested():
              ctx.resultCancelled = true
              return
            var process: OsExecProcess
            try:
              process = startOsExecProcess(nativeCmd, nativeWorkdir, nativeArgs,
                                           ctx.full, {poUsePath, poParentStreams},
                                           nativeEnvironment)
            except CatchableError as e:
              settleFail(nativeName & " could not start '" & nativeCmd & "': " &
                         e.msg)
              return
            # system(3) semantics: after the child inherited the current signal
            # handlers, ignore terminal Ctrl-C in the parent until handoff ends.
            # The lock above prevents overlapping handoffs from restoring one
            # another's signal disposition out of order.
            when defined(posix):
              var ignoreInt, oldInt: Sigaction
              ignoreInt.sa_handler = SIG_IGN
              discard sigemptyset(ignoreInt.sa_mask)
              ignoreInt.sa_flags = 0
              let intIgnored = sigaction(SIGINT, ignoreInt, oldInt) == 0
            try:
              while process.running:
                if cancellationRequested():
                  cancelled = true
                  process.terminate()
                  break
                os.sleep(osExecPollMs)
              if cancelled:
                reapStoppedOsExec(process)
                ctx.resultCancelled = true
              else:
                ctx.resultStatus = process.waitForExit()
            except CatchableError as e:
              settleFail(nativeName & " failed: " & e.msg)
            finally:
              when defined(posix):
                if intIgnored:
                  discard sigaction(SIGINT, oldInt, nil)
              try:
                process.close()
              except CatchableError:
                discard
          finally:
            release(osExecStdioLock)
          return

        var process: CapturedOsExecProcess
        try:
          process = startCapturedOsExec(nativeCmd, nativeWorkdir, nativeArgs,
                                       ctx.mergeStderr, ctx.full, nativeEnvironment)
        except CatchableError as e:
          settleFail(nativeName & " could not start '" & nativeCmd & "': " & e.msg)
          return
        try:
          try:
            when defined(posix):
              let outFd = process.outputHandle.cint
              let errFd = process.errorHandle.cint
              let inFd = process.inputHandle.cint
              discard fcntl(outFd, F_SETFL,
                            fcntl(outFd, F_GETFL, 0) or O_NONBLOCK)
              discard fcntl(errFd, F_SETFL,
                            fcntl(errFd, F_GETFL, 0) or O_NONBLOCK)
              if ctx.stdinPipeFd >= 0:
                if inFd < 0 or fcntl(inFd, F_SETFL,
                    fcntl(inFd, F_GETFL, 0) or O_NONBLOCK) < 0:
                  stdinPipeFailed = true
              var buf: array[4096, char]
              var stdinBuf: array[4096, char]
              var stdinCount = 0
              var stdinOffset = 0
              var stdinDone = ctx.stdinPipeFd < 0
              if stdinDone:
                if osExecFinishStdin(inFd) != 0: stdinPipeFailed = true
              template finishInput() =
                block:
                  if not stdinDone:
                    stdinDone = true
                    if osExecFinishStdin(inFd) != 0:
                      stdinPipeFailed = true
                    discard posix.close(ctx.stdinPipeFd)
                    ctx.stdinPipeFd = -1
              template pumpInput() =
                block:
                  if not stdinDone and not stdinPipeFailed:
                    if stdinOffset >= stdinCount:
                      let received = posix.read(ctx.stdinPipeFd,
                                                addr stdinBuf[0], stdinBuf.len)
                      if received > 0:
                        stdinCount = received
                        stdinOffset = 0
                      elif received == 0:
                        finishInput()
                      elif errno != EAGAIN and errno != EWOULDBLOCK:
                        stdinPipeFailed = true
                    if not stdinDone and stdinOffset < stdinCount:
                      let accepted = osExecPipeWrite(inFd,
                        addr stdinBuf[stdinOffset],
                        csize_t(stdinCount - stdinOffset))
                      if accepted > 0:
                        stdinOffset += accepted
                      elif errno == EPIPE:
                        finishInput()
                      elif errno != EAGAIN and errno != EWOULDBLOCK:
                        stdinPipeFailed = true
              # Template, not a nested proc: a proc would capture the cursor
              # views through the expanded helpers into a closure env.
              template drainAvailable(fd: cint, isOut: bool) =
                while true:
                  let n = read(fd, addr buf[0], buf.len)
                  if n > 0:
                    var chunk = newString(n)
                    copyMem(addr chunk[0], addr buf[0], n)
                    when isOut:
                      handleStdoutChunk(chunk)
                    else:
                      handleStderrChunk(chunk)
                  else:
                    break
              while process.running:
                drainAvailable(outFd, true)
                if not ctx.mergeStderr: drainAvailable(errFd, false)
                pumpInput()
                if stdoutPipeFailed or stderrPipeFailed or stdinPipeFailed:
                  stopOsExecGroup(process)
                  break
                if cancellationRequested():
                  cancelled = true
                  stopOsExecGroup(process)
                  break
                if ctx.timeoutMs >= 0 and getMonoTime() >= deadline:
                  timedOut = true
                  stopOsExecGroup(process)
                  break
                os.sleep(osExecPollMs)
              exitCode = if timedOut or cancelled or stdoutPipeFailed or
                            stderrPipeFailed or stdinPipeFailed:
                           (reapStoppedOsExecGroup(process); -1)
                         else:
                           process.waitForExit()
              drainAvailable(outFd, true)
              if not ctx.mergeStderr: drainAvailable(errFd, false)
            else:
              while process.running:
                if cancellationRequested():
                  cancelled = true
                  stopOsExecGroup(process)
                  break
                if ctx.timeoutMs >= 0 and getMonoTime() >= deadline:
                  timedOut = true
                  stopOsExecGroup(process)
                  break
                os.sleep(osExecPollMs)
              exitCode = if timedOut or cancelled:
                           (reapStoppedOsExecGroup(process); -1)
                         else:
                           process.waitForExit()
              handleStdoutChunk(process.outputStream.readAll())
              handleStderrChunk(process.errorStream.readAll())
            if lineBuf.len > 0:
              sendLine(lineBuf)
              lineBuf.setLen(0)
            if stdoutPipeFailed:
              settleFail(nativeName & " stdout pipe closed during write")
              return
            if stderrPipeFailed:
              settleFail(nativeName & " stderr pipe closed during write")
              return
            if stdinPipeFailed:
              settleFail(nativeName & " stdin pipe transfer failed")
              return
            if cancelled:
              ctx.resultCancelled = true
              return
            ctx.resultStatus = exitCode
            ctx.resultStdout = sharedExecText(outText)
            ctx.resultStderr = sharedExecText(errText)
            ctx.resultStdoutTruncated = outTruncated
            ctx.resultStderrTruncated = errTruncated
            ctx.resultTimedOut = timedOut
          except CatchableError as e:
            settleFail(nativeName & " failed: " & e.msg)
        finally:
          try:
            if process.running:
              stopOsExecGroup(process)
              reapStoppedOsExecGroup(process)
            process.close()
          except CatchableError:
            discard

  proc runOsExecAsyncJob(jobPtr: pointer) {.gcsafe.} =
    {.cast(gcsafe).}:
      # The worker owns only local Nim data and explicitly shared raw buffers.
      # It never constructs a Gene Value or touches an ORC-managed object from
      # the scheduler heap.
      let ctx = cast[ptr OsExecAsyncCtx](jobPtr)
      if ctx.fileOperation != nfoNone:
        try:
          if atomicLoadN(addr ctx.cancelRequested, ATOMIC_ACQUIRE):
            ctx.resultCancelled = true
            return
          let path = readSharedExecText(ctx.cmd)
          case ctx.fileOperation
          of nfoRead:
            ctx.resultStdout = sharedExecText(fsReadBytes(path))
          of nfoWrite:
            fsWriteBytes(path, readSharedExecText(ctx.workdir))
          of nfoAtomicWrite:
            fsWriteAtomic(path, readSharedExecText(ctx.workdir), ctx.fileOwnerOnly)
          of nfoReadPage:
            let page = fsReadTextPage(path, ctx.fileFirst, ctx.fileLines, ctx.maxBytes,
              proc(): bool {.gcsafe.} = atomicLoadN(addr ctx.cancelRequested, ATOMIC_ACQUIRE))
            ctx.resultStdout = sharedExecText(page.text)
            ctx.resultStatus = page.lastLine
            ctx.resultPageNext = page.nextLine
            ctx.resultPageBinary = page.binary
            ctx.resultStdoutTruncated = page.truncated
            if atomicLoadN(addr ctx.cancelRequested, ATOMIC_ACQUIRE): ctx.resultCancelled = true
          of nfoNone: discard
        except CatchableError as error:
          ctx.resultFailed = true
          ctx.resultFailure = sharedExecText(readSharedExecText(ctx.name) & ": " & error.msg)
        return
      when nativeProcessBackend: runNativeExecJob(ctx)
      else: runLegacyExecJob(ctx)

when compileOption("threads"):
  proc osExecAsyncWorkerMain() {.thread.} =
    {.cast(gcsafe).}:
      while true:
        var jobPtr: pointer = nil
        withLock osExecAsyncLock:
          while osExecAsyncQueue.len == 0:
            inc osExecAsyncIdle
            wait(osExecAsyncCond, osExecAsyncLock)
            dec osExecAsyncIdle
          jobPtr = osExecAsyncQueue[0]
          osExecAsyncQueue.delete(0)
        runOsExecAsyncJob(jobPtr)
        # Must be this worker's final access to the job: once the scheduler
        # acquires the flag it frees the ctx and drops the task/channel refs.
        let doneCtx = cast[ptr OsExecAsyncCtx](jobPtr)
        when nativeProcessBackend:
          let wake = doneCtx.completionWake
        atomicStoreN(addr doneCtx.workerDone, true, ATOMIC_RELEASE)
        when nativeProcessBackend:
          signalWake(wake)
          releaseWake(wake) # The producer lease survives publication of done.

  proc enqueueOsExecAsyncJob(jobPtr: pointer) =
    when nativeProcessBackend:
      when defined(geneExecTests):
        if execRejectSubmission.exchange(false, moAcquireRelease):
          raiseOSError(OSErrorCode(EAGAIN), "injected exec submission failure")
      let ctx = cast[ptr OsExecAsyncCtx](jobPtr)
      if ctx.fileOperation == nfoNone:
        enqueueExecMonitor(ctx)
        return
    withLock osExecAsyncLock:
      if osExecAsyncIdle == 0 and
          osExecAsyncThreads.len < osExecAsyncMaxWorkers:
        var tr: ref Thread[void]
        new(tr)
        try:
          # Publish work only after the first worker exists. New workers block
          # on this lock; failed growth can use an already existing worker.
          createThread(tr[], osExecAsyncWorkerMain)
          osExecAsyncThreads.add tr
        except CatchableError:
          if osExecAsyncThreads.len == 0: raise
      osExecAsyncQueue.add jobPtr
      signal(osExecAsyncCond)

else:
  proc requestOsExecCancellation(task: Value): bool = false

  proc pollOsExecAsyncCompletions() =
    pollStdinLineCompletions()
    pollIoFileCompletions()
    pollHttpClientCompletions()
    pollOwnedHttpClientCompletions()
    pollHttpTlsReloadCompletions()
    pollCursesInputCompletions()
    pollNativeIngressHook()

proc startNativeFileTask(name, path, text: string, operation: NativeFileOperation,
                         scope: Scope, ownerOnly = false, first = 1,
                         lines = 400, maxBytes = 1048576): Value =
  when compileOption("threads"):
    if scope == nil:
      raise newException(GeneError, name & " requires a scheduler scope")
    let task = newExternalTask()
    let ctx = cast[ptr OsExecAsyncCtx](allocShared0(sizeof(OsExecAsyncCtx)))
    ctx.fileOperation = operation
    ctx.fileOwnerOnly = ownerOnly
    ctx.fileFirst = first
    ctx.fileLines = lines
    ctx.maxBytes = maxBytes
    ctx.stdoutPipeFd = -1
    ctx.stderrPipeFd = -1
    ctx.stdinPipeFd = -1
    ctx.taskBits = task.bits
    ctx.schedulerPtr = cast[pointer](schedulerForScope(scope))
    ctx.name = sharedExecText(name)
    ctx.cmd = sharedExecText(absolutePath(path))
    ctx.workdir = sharedExecText(text)
    initLock(ctx.lineLock)
    let watchPath =
      try: fsRealPath(parentDir(absolutePath(path))) / extractFilename(path)
      except CatchableError: absolutePath(path)
    let pending = OsExecPending(ctx: ctx,
                               fileErrorScope: scope.application().builtinsScope(),
                               filePath: watchPath)
    pending.taskOwner = retainedCopy(task)
    withLock osExecAsyncLock:
      osExecAsyncPending.add pending
    beginExternalNativeOp()
    try:
      enqueueOsExecAsyncJob(ctx)
    except CatchableError:
      endExternalNativeOp()
      withLock osExecAsyncLock:
        for i in 0..<osExecAsyncPending.len:
          if osExecAsyncPending[i] == pending:
            let last = osExecAsyncPending.high
            if i != last: osExecAsyncPending[i] = move osExecAsyncPending[last]
            osExecAsyncPending.setLen(last)
            break
      pending.ctx = nil
      freeOsExecCtx(ctx)
      raise
    task
  else:
    newFailedTask(name & " requires a threaded runtime build")

proc biOsExecAsyncImpl(name: string, wantChan: bool,
                       inheritStdio: bool,
                       args: openArray[Value],
                       call: ptr NativeCall): Value =
  let scope = if call == nil: nil else: call[].dispatchScope
  let command = parseOsExecCommand(name, args, call)
  let cmd = command.cmd
  let procArgs = command.args
  var timeoutMs = -1
  var maxBytes = osExecDefaultOutputCap
  let workdir = command.directory
  var lineChan = NIL
  var stdoutPipe = NIL
  var stderrPipe = NIL
  var stdinPipe = NIL
  var mergeStderr = false
  if call != nil:
    for i, argName in call[].namedNames:
      let v = call[].namedValues[i]
      case argName
      of "cmd", "args", "full", "dir", "env": discard
      of "timeout_ms":
        if inheritStdio:
          raiseOsError(name & " got unexpected named argument: timeout_ms", scope)
        timeoutMs = int(requireInt64(name & " ^timeout_ms", v))
      of "max_bytes":
        if inheritStdio:
          raiseOsError(name & " got unexpected named argument: max_bytes", scope)
        maxBytes = int(requireInt64(name & " ^max_bytes", v))
      of "merge_stderr":
        if inheritStdio or v.kind != vkBool:
          raiseOsError(name & " ^merge_stderr expects Bool on captured execution", scope)
        mergeStderr = v.boolVal
      of "stdout_chan":
        if not wantChan:
          raiseOsError(name & " got unexpected named argument: stdout_chan",
                       scope)
        requireChannel(name & " ^stdout_chan", v)
        lineChan = v
      of "stdout_pipe":
        if not wantChan or inheritStdio:
          raiseOsError(name & " got unexpected named argument: stdout_pipe", scope)
        stdoutPipe = v
      of "stderr_pipe":
        if not wantChan or inheritStdio:
          raiseOsError(name & " got unexpected named argument: stderr_pipe", scope)
        stderrPipe = v
      of "stdin_pipe":
        if not wantChan or inheritStdio:
          raiseOsError(name & " got unexpected named argument: stdin_pipe", scope)
        stdinPipe = v
      else:
        raiseOsError(name & " got unexpected named argument: " & argName,
                     scope)
  if maxBytes <= 0:
    maxBytes = osExecDefaultOutputCap
  if wantChan and lineChan.kind == vkNil and stdoutPipe.kind == vkNil and
      stderrPipe.kind == vkNil and stdinPipe.kind == vkNil:
    raiseOsError(name & " requires a stream channel or pipe",
                 scope)
  if lineChan.kind != vkNil and stdoutPipe.kind != vkNil:
    raiseOsError(name & " accepts one stdout destination at a time", scope)
  when compileOption("threads"):
    if scope == nil or scope.application == nil:
      raiseOsError(name & " requires a scheduler scope", scope)
    pollOsExecAsyncCompletions()
    let task = newExternalTask()
    markSharedValue(task)
    if lineChan.kind != vkNil:
      markSharedValue(lineChan)
    let ctx = cast[ptr OsExecAsyncCtx](allocShared0(sizeof(OsExecAsyncCtx)))
    ctx.stdoutPipeFd = -1
    ctx.stderrPipeFd = -1
    ctx.stdinPipeFd = -1
    ctx.name = sharedExecText(name)
    ctx.cmd = sharedExecText(cmd)
    ctx.workdir = sharedExecText(workdir)
    ctx.inheritStdio = inheritStdio
    ctx.full = command.full
    ctx.mergeStderr = mergeStderr
    ctx.timeoutMs = timeoutMs
    ctx.maxBytes = maxBytes
    ctx.taskBits = task.bits
    ctx.lineChanBits = if lineChan.kind == vkNil: 0'u64 else: lineChan.bits
    ctx.schedulerPtr = cast[pointer](schedulerForScope(scope))
    var argTail: ptr SharedExecArg
    for arg in procArgs:
      let argNode = cast[ptr SharedExecArg](allocShared0(sizeof(SharedExecArg)))
      argNode.text = sharedExecText(arg)
      if argTail == nil:
        ctx.procArgs = argNode
      else:
        argTail.next = argNode
      argTail = argNode
    if command.environment.isSome:
      ctx.hasEnvironment = true
      var envTail: ptr SharedExecArg
      for entry in command.environment.get:
        let node = cast[ptr SharedExecArg](allocShared0(sizeof(SharedExecArg)))
        node.text = sharedExecText(entry)
        if envTail == nil: ctx.processEnv = node
        else: envTail.next = node
        envTail = node
    initLock(ctx.lineLock)
    # `dup` is deliberate: task/lineChan are also returned/owned by the caller.
    # A sink into the ctx without the explicit retain would leave two logical
    # owners sharing one ref and completion cleanup would free the caller's
    # live handle.
    let pending = OsExecPending(ctx: ctx)
    pending.schedulerOwner = schedulerForScope(scope)
    when nativeProcessBackend:
      try:
        ctx.completionWake = schedulerNativeWake(pending.schedulerOwner)
        retainWake(ctx.completionWake) # pending-context lease
        retainWake(ctx.completionWake) # producer lease, handed off on enqueue
        let control = newNativeWake(-1)
        ctx.controlWake = control.signal
        retainWake(ctx.controlWake)
        ctx.notified = true
      except CatchableError as error:
        pending.ctx = nil
        freeOsExecCtx(ctx)
        raiseOsError(name & " could not create process notification: " & error.msg, scope)
    pending.taskOwner = retainedCopy(task)
    pending.lineChanOwner = retainedCopy(lineChan)
    if stdoutPipe.kind != vkNil:
      try:
        pending.pipeBorrow = beginIoPipeOutputBorrow(stdoutPipe, scope, task,
                                                     "stdout_pipe")
        pending.pipeWriterOwner = retainedCopy(stdoutPipe)
        pending.pipeScope = scope.application().builtinsScope()
        ctx.stdoutPipeFd = pending.pipeBorrow.fd
      except CatchableError:
        freeOsExecCtx(ctx)
        raise
    if stderrPipe.kind != vkNil:
      try:
        pending.stderrBorrow = beginIoPipeOutputBorrow(stderrPipe, scope, task,
                                                       "stderr_pipe")
        pending.stderrWriterOwner = retainedCopy(stderrPipe)
        pending.stderrScope = scope.application().builtinsScope()
        ctx.stderrPipeFd = pending.stderrBorrow.fd
      except CatchableError:
        freeOsExecCtx(ctx)
        if task.kind == vkTask and not task.taskDone:
          discard nativeTaskCancel(task, scope)
        if pending.pipeBorrow.resourceId != 0:
          finishIoPipeOutputBorrow(pending.pipeBorrow, pending.pipeScope)
        raise
    if stdinPipe.kind != vkNil:
      try:
        pending.stdinBorrow = beginIoPipeInputBorrow(stdinPipe, scope, task)
        pending.stdinReaderOwner = retainedCopy(stdinPipe)
        pending.stdinScope = scope.application().builtinsScope()
        ctx.stdinPipeFd = pending.stdinBorrow.fd
      except CatchableError:
        freeOsExecCtx(ctx)
        if task.kind == vkTask and not task.taskDone:
          discard nativeTaskCancel(task, scope)
        if pending.pipeBorrow.resourceId != 0:
          finishIoPipeOutputBorrow(pending.pipeBorrow, pending.pipeScope)
        if pending.stderrBorrow.resourceId != 0:
          finishIoPipeOutputBorrow(pending.stderrBorrow, pending.stderrScope)
        raise
    # Scheduler-side ownership: the pending ref retains task/channel while the
    # worker borrows their raw bits. The worker ctx itself is shared raw memory.
    withLock osExecAsyncLock:
      osExecAsyncPending.add(pending)
    beginExternalNativeOp(ctx.notified)
    try:
      ctx.producerQueued = true
      enqueueOsExecAsyncJob(cast[pointer](ctx))
    except CatchableError as e:
      ctx.producerQueued = false
      endExternalNativeOp(ctx.notified)
      withLock osExecAsyncLock:
        for i in 0..<osExecAsyncPending.len:
          if osExecAsyncPending[i] == pending:
            let last = osExecAsyncPending.high
            if i != last: osExecAsyncPending[i] = move osExecAsyncPending[last]
            osExecAsyncPending.setLen(last)
            break
      pending.ctx = nil
      freeOsExecCtx(ctx)
      if pending.pipeBorrow.resourceId != 0:
        finishIoPipeOutputBorrow(pending.pipeBorrow, pending.pipeScope)
      if pending.stderrBorrow.resourceId != 0:
        finishIoPipeOutputBorrow(pending.stderrBorrow, pending.stderrScope)
      if pending.stdinBorrow.resourceId != 0:
        finishIoPipeInputBorrow(pending.stdinBorrow, pending.stdinScope)
      if task.kind == vkTask and not task.taskDone:
        failTask(task, name & " could not start a worker thread")
      raiseOsError(name & " could not start a worker thread: " & e.msg, scope)
    task
  else:
    raiseOsError(name & " requires a threaded runtime build", scope)
    NIL

proc biOsExecAsync(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  ## os/exec contract, but returns a Task settled off-thread: the scheduler
  ## keeps running fibers while the child executes. Await for the result map.
  biOsExecAsyncImpl("os/exec_async", false, false, args, call)

proc biOsExecStreamAsync(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  ## os/exec_async plus live stdout lines: each complete line (CR stripped) is
  ## sent to ^stdout_chan as it arrives; the channel is closed when the child
  ## exits, then the Task settles with the captured result map.
  biOsExecAsyncImpl("os/exec_stream_async", true, false, args, call)

proc biOsExecStdioAsync(args: openArray[Value],
                        call: ptr NativeCall): Value {.nimcall.} =
  ## Scheduler-friendly terminal handoff. The child inherits this process's
  ## stdin/stdout/stderr while a worker thread waits for it; await the returned
  ## Task for its integer exit status. Cancellation terminates the child.
  biOsExecAsyncImpl("os/exec_stdio_async", false, true, args, call)

# --- net/http_client: native libcurl client ---------------------------------
#
# libcurl owns TLS, certificate verification, proxies, and HTTP
# framing. The perform call runs on a persistent worker. Its callbacks only
# copy bytes into explicitly shared native buffers; Gene strings/maps/channels
# are created and touched exclusively by pollHttpClientCompletions on the
# scheduler thread.

when defined(macosx):
  const curlLibCandidates = ["libcurl.4.dylib", "/usr/lib/libcurl.4.dylib",
                             "libcurl.dylib"]
elif defined(windows):
  const curlLibCandidates = ["libcurl.dll", "curl.dll"]
else:
  const curlLibCandidates = ["libcurl.so.4", "libcurl.so"]

const
  CurlGlobalDefault = 3.clong
  CurlOk = 0.cint
  CurlWriteError = 23.cint
  CurlWritePause = csize_t(0x10000001)
  CurlReadPause = csize_t(0x10000001)
  CurlReadAbort = csize_t(0x10000000)
  CurlOperationTimedOut = 28.cint
  CurlAbortedByCallback = 42.cint
  CurlOptWriteData = 10001.cint
  CurlOptUrl = 10002.cint
  CurlOptProxy = 10004.cint
  CurlOptPreProxy = 10262.cint
  CurlOptRequestTarget = 10266.cint
  CurlOptPathAsIs = 234.cint
  CurlOptHttpVersion = 84.cint
  CurlOptNetrc = 51.cint
  CurlOptHttpAuth = 107.cint
  CurlOptProxyAuth = 111.cint
  CurlOptFreshConnect = 74.cint
  CurlOptForbidReuse = 75.cint
  CurlOptSslVerifyPeer = 64.cint
  CurlOptSslVerifyHost = 81.cint
  CurlOptProtocols = 181.cint
  CurlOptHttpProxyTunnel = 61.cint
  CurlOptSuppressConnectHeaders = 265.cint
  CurlOptNoBody = 44.cint
  CurlOptWriteFunction = 20011.cint
  CurlOptReadFunction = 20012.cint
  CurlOptReadData = 10009.cint
  CurlOptUpload = 46.cint
  CurlOptInfileSizeLarge = 30115.cint
  CurlOptPostFields = 10015.cint
  CurlOptHttpHeader = 10023.cint
  CurlOptHeaderData = 10029.cint
  CurlOptCustomRequest = 10036.cint
  CurlOptNoProgress = 43.cint
  CurlOptFollowLocation = 52.cint
  CurlOptNoSignal = 99.cint
  CurlOptCaInfoBlob = 40309.cint
  CurlOptAcceptEncoding = 10102.cint
  CurlOptTimeoutMs = 155.cint
  CurlOptConnectTimeoutMs = 156.cint
  CurlOptNoProxy = 10177.cint
  CurlOptMaxAgeConn = 288.cint
  CurlOptHeaderFunction = 20079.cint
  CurlOptXferInfoData = 10057.cint
  CurlOptXferInfoFunction = 20219.cint
  CurlOptPostFieldSizeLarge = 30120.cint
  CurlInfoEffectiveUrl = 0x100001.cint
  CurlInfoResponseCode = 0x200002.cint
  CurlMultiOk = 0.cint
  CurlMultiDone = 1.cint
  CurlMultiOptMaxConnects = 6.cint
  CurlMultiOptMaxHostConnections = 7.cint
  CurlMultiOptMaxTotalConnections = 13.cint
  HttpDefaultTimeoutMs = 60_000
  HttpDefaultMaxBytes = 4_000_000
  HttpDefaultPendingBytes = 1_000_000
  HttpHeaderMaxBytes = 256_000
  HttpHardMaxBytes = 64 * 1024 * 1024
  HttpHardPendingBytes = 16 * 1024 * 1024

type
  CurlBlob {.bycopy.} = object
    data: pointer
    len: csize_t
    flags: cuint

  CurlApi = object
    lib: LibHandle
    globalInit: proc(flags: clong): cint {.cdecl.}
    easyInit: proc(): pointer {.cdecl.}
    easyCleanup: proc(handle: pointer) {.cdecl.}
    easyPerform: proc(handle: pointer): cint {.cdecl.}
    easyStrerror: proc(code: cint): cstring {.cdecl.}
    setoptAddr: pointer
    getinfoAddr: pointer
    slistAppend: proc(list: pointer, value: cstring): pointer {.cdecl.}
    slistFreeAll: proc(list: pointer) {.cdecl.}

  CurlMultiMessage {.bycopy.} = object
    kind: cint
    easy: pointer
    resultCode: cint # low member of CURLMsg.data union

  CurlMultiApi = object
    init: proc(): pointer {.cdecl.}
    cleanup: proc(multi: pointer): cint {.cdecl.}
    addHandle: proc(multi, easy: pointer): cint {.cdecl.}
    removeHandle: proc(multi, easy: pointer): cint {.cdecl.}
    perform: proc(multi: pointer, running: ptr cint): cint {.cdecl.}
    poll: proc(multi, extraFds: pointer, extraCount: cuint,
               timeoutMs: cint, numFds: ptr cint): cint {.cdecl.}
    wakeup: proc(multi: pointer): cint {.cdecl.}
    infoRead: proc(multi: pointer, remaining: ptr cint): ptr CurlMultiMessage
      {.cdecl.}
    easyPause: proc(easy: pointer, action: cint): cint {.cdecl.}
    setoptAddr: pointer

var gCurlApi: CurlApi
var gCurlMultiApi: CurlMultiApi

# AArch64 (notably Apple Silicon) gives variadic arguments a different ABI
# treatment from fixed-signature arguments. Calling curl_easy_setopt/getinfo by
# casting the variadic symbol directly to a fixed Nim proc therefore appears to
# work but passes corrupt values. These tiny C shims make the actual variadic
# call in C while keeping every Nim call site typed by value shape.
{.emit: """
typedef int (*gene_curl_vararg_fn)(void *, int, ...);
static int gene_curl_setopt_str(void *fn, void *h, int o, const char *v) {
  return ((gene_curl_vararg_fn)fn)(h, o, v);
}
static int gene_curl_setopt_long(void *fn, void *h, int o, long v) {
  return ((gene_curl_vararg_fn)fn)(h, o, v);
}
static int gene_curl_setopt_off(void *fn, void *h, int o, long long v) {
  return ((gene_curl_vararg_fn)fn)(h, o, v);
}
static int gene_curl_setopt_ptr(void *fn, void *h, int o, void *v) {
  return ((gene_curl_vararg_fn)fn)(h, o, v);
}
static int gene_curl_getinfo_ptr(void *fn, void *h, int o, void *v) {
  return ((gene_curl_vararg_fn)fn)(h, o, v);
}
static int gene_curl_multi_setopt_long(void *fn, void *h, int o, long v) {
  return ((gene_curl_vararg_fn)fn)(h, o, v);
}
""".}

proc cCurlSetoptStr(fn, handle: pointer, option: cint,
                    value: cstring): cint
  {.importc: "gene_curl_setopt_str", nodecl.}
proc cCurlSetoptLong(fn, handle: pointer, option: cint,
                     value: clong): cint
  {.importc: "gene_curl_setopt_long", nodecl.}
proc cCurlSetoptOff(fn, handle: pointer, option: cint,
                    value: int64): cint
  {.importc: "gene_curl_setopt_off", nodecl.}
proc cCurlSetoptPtr(fn, handle: pointer, option: cint,
                    value: pointer): cint
  {.importc: "gene_curl_setopt_ptr", nodecl.}
proc cCurlGetinfoPtr(fn, handle: pointer, option: cint,
                     value: pointer): cint
  {.importc: "gene_curl_getinfo_ptr", nodecl.}
proc cCurlMultiSetoptLong(fn, handle: pointer, option: cint,
                          value: clong): cint
  {.importc: "gene_curl_multi_setopt_long", nodecl.}

proc raiseHttpClientError(message: string, scope: Scope,
                          kind = "usage") =
  ## `^kind "unavailable"` marks libcurl load/init failures — the only errors
  ## a caller should treat as "fall back to curl(1)". Everything else
  ## (`"usage"`: authority, argument, and option mistakes) must surface so a
  ## typo cannot silently reroute every request to the subprocess transport.
  var props = initPropTable()
  props["message"] = newStr(message)
  props["kind"] = newStr(kind)
  var e: ref GeneError
  new(e)
  e.msg = message
  e.errVal = newNode(builtInTypeHead(scope, "HttpClientError"), props = props)
  e.hasErrVal = true
  raise e

proc loadCurlApi(scope: Scope) =
  if gCurlApi.lib != nil:
    return
  when defined(emscripten) or defined(geneWasm):
    raiseHttpClientError("net/http_client is unavailable in WebAssembly; use " &
                         "the host fetch bridge", scope,
                         kind = "unavailable")
  else:
    var lib: LibHandle
    let override = getEnv("GENE_LIBCURL")
    if override.len > 0:
      lib = loadLib(override)
      if lib == nil:
        raiseHttpClientError("could not load GENE_LIBCURL=" & override, scope,
                             kind = "unavailable")
    else:
      for candidate in curlLibCandidates:
        lib = loadLib(candidate)
        if lib != nil:
          break
    if lib == nil:
      raiseHttpClientError("could not load libcurl; set GENE_LIBCURL to its path",
                           scope, kind = "unavailable")
    template sym(name: string): pointer =
      block:
        let address = symAddr(lib, name)
        if address == nil:
          unloadLib(lib)
          raiseHttpClientError("libcurl is missing symbol " & name, scope,
                               kind = "unavailable")
        address
    var api: CurlApi
    api.globalInit = cast[typeof(api.globalInit)](sym"curl_global_init")
    api.easyInit = cast[typeof(api.easyInit)](sym"curl_easy_init")
    api.easyCleanup = cast[typeof(api.easyCleanup)](sym"curl_easy_cleanup")
    api.easyPerform = cast[typeof(api.easyPerform)](sym"curl_easy_perform")
    api.easyStrerror = cast[typeof(api.easyStrerror)](sym"curl_easy_strerror")
    let setoptAddress = sym"curl_easy_setopt"
    api.setoptAddr = setoptAddress
    api.getinfoAddr = sym"curl_easy_getinfo"
    api.slistAppend = cast[typeof(api.slistAppend)](sym"curl_slist_append")
    api.slistFreeAll = cast[typeof(api.slistFreeAll)](sym"curl_slist_free_all")
    if api.globalInit(CurlGlobalDefault) != CurlOk:
      unloadLib(lib)
      raiseHttpClientError("curl_global_init failed", scope,
                           kind = "unavailable")
    api.lib = lib
    gCurlApi = api

proc loadCurlMultiApi(scope: Scope) =
  loadCurlApi(scope)
  if gCurlMultiApi.init != nil:
    return
  let lib = gCurlApi.lib
  template multiSym(name: string): pointer =
    block:
      let address = symAddr(lib, name)
      if address == nil:
        raiseHttpClientError("libcurl is missing symbol " & name, scope,
                             kind = "unavailable")
      address
  var api: CurlMultiApi
  api.init = cast[typeof(api.init)](multiSym"curl_multi_init")
  api.cleanup = cast[typeof(api.cleanup)](multiSym"curl_multi_cleanup")
  api.addHandle = cast[typeof(api.addHandle)](multiSym"curl_multi_add_handle")
  api.removeHandle = cast[typeof(api.removeHandle)](multiSym"curl_multi_remove_handle")
  api.perform = cast[typeof(api.perform)](multiSym"curl_multi_perform")
  api.poll = cast[typeof(api.poll)](multiSym"curl_multi_poll")
  api.wakeup = cast[typeof(api.wakeup)](multiSym"curl_multi_wakeup")
  api.infoRead = cast[typeof(api.infoRead)](multiSym"curl_multi_info_read")
  api.easyPause = cast[typeof(api.easyPause)](multiSym"curl_easy_pause")
  api.setoptAddr = multiSym"curl_multi_setopt"
  gCurlMultiApi = api

proc moduleFetchWrite(data: pointer, size, count: csize_t,
                      userData: pointer): csize_t {.cdecl.} =
  ## Write callback for the blocking module fetch below. Runs on the calling
  ## thread inside curl_easy_perform; appends into a caller-owned Nim string.
  let buf = cast[ptr string](userData)
  if size != 0 and count > high(csize_t) div size:
    return 0
  let total = size * count
  if total > csize_t(HttpHardMaxBytes) or
      buf[].len + int(total) > HttpHardMaxBytes:
    return 0                       # abort transfer -> CURLE_WRITE_ERROR
  if total > 0:
    let old = buf[].len
    buf[].setLen(old + int(total))
    copyMem(addr buf[][old], data, int(total))
  total

proc geneFetchModuleUrl*(url: string): tuple[finalUrl, body: string] =
  ## Blocking GET for the experimental URL module loader (design §15.9).
  ## Follows redirects and reports the effective URL so a redirected module's
  ## relative imports resolve against its final location. libcurl owns TLS,
  ## matching net/http_client; under wasm loadCurlApi raises "unavailable".
  loadCurlApi(nil)
  let handle = gCurlApi.easyInit()
  if handle == nil:
    raise newException(GeneError, "curl_easy_init failed")
  var body = ""
  try:
    discard cCurlSetoptStr(gCurlApi.setoptAddr, handle, CurlOptUrl,
                           url.cstring)
    discard cCurlSetoptPtr(gCurlApi.setoptAddr, handle, CurlOptWriteFunction,
                           cast[pointer](moduleFetchWrite))
    discard cCurlSetoptPtr(gCurlApi.setoptAddr, handle, CurlOptWriteData,
                           addr body)
    discard cCurlSetoptLong(gCurlApi.setoptAddr, handle,
                            CurlOptFollowLocation, 1)
    discard cCurlSetoptLong(gCurlApi.setoptAddr, handle, CurlOptNoSignal, 1)
    discard cCurlSetoptLong(gCurlApi.setoptAddr, handle, CurlOptNoProgress, 1)
    discard cCurlSetoptLong(gCurlApi.setoptAddr, handle, CurlOptTimeoutMs,
                            clong(HttpDefaultTimeoutMs))
    discard cCurlSetoptStr(gCurlApi.setoptAddr, handle, CurlOptAcceptEncoding,
                           "".cstring)
    let code = gCurlApi.easyPerform(handle)
    if code != CurlOk:
      let detail =
        if code == CurlWriteError:
          "response exceeds the module size limit"
        else:
          $gCurlApi.easyStrerror(code)
      raise newException(GeneError, "fetching " & url & " failed: " & detail)
    var status: clong = 0
    discard cCurlGetinfoPtr(gCurlApi.getinfoAddr, handle,
                            CurlInfoResponseCode, addr status)
    if status != 200:
      raise newException(GeneError,
        "fetching " & url & " failed: HTTP " & $status)
    var effective: cstring = nil
    discard cCurlGetinfoPtr(gCurlApi.getinfoAddr, handle,
                            CurlInfoEffectiveUrl, addr effective)
    result = (finalUrl: (if effective != nil: $effective else: url),
              body: body)
  finally:
    gCurlApi.easyCleanup(handle)

when compileOption("threads"):
  type
    SharedHttpBuffer = object
      data: pointer
      len: int
      cap: int
      allocated: int
    HttpClientCtx = object
      httpMethod: SharedExecText
      url: SharedExecText
      requestTarget: SharedExecText
      body: SharedExecText
      caData: SharedExecText
      headers: ptr SharedExecArg
      taskBits: uint64
      chunkChanBits: uint64
      schedulerPtr: pointer
      timeoutMs: int
      maxBytes: int
      maxPendingBytes: int
      responseBody: SharedHttpBuffer
      responseHeaders: SharedHttpBuffer
      responseTruncated: bool
      headersTruncated: bool
      responseStatus: int
      effectiveUrl: SharedExecText
      chunkLock: Lock
      chunkHead: ptr SharedExecLine
      chunkTail: ptr SharedExecLine
      queuedBytes: int
      streamGone: bool
      bufferOverflow: bool
      resultFailed: bool
      resultFailure: SharedExecText
      resultCancelled: bool
      resultTimedOut: bool
      cancelRequested: bool
      workerDone: bool
      protocolUpgrade: bool
      unsupportedTransport: bool
    HttpClientPending {.acyclic.} = ref object
      ctx: ptr HttpClientCtx
      taskOwner: Value
      channelOwner: Value
      scope: Scope

  const httpClientMaxWorkers = 16
  var httpClientLock: Lock
  var httpClientCond: Cond
  var httpClientQueue: seq[pointer]
  var httpClientThreads: seq[ref Thread[void]]
  var httpClientIdle = 0
  var httpClientStarting = 0
  var httpClientPending: seq[HttpClientPending]
  var httpClientPendingCount = 0
  initLock(httpClientLock)
  initCond(httpClientCond)

  proc freeHttpBuffer(buffer: var SharedHttpBuffer) =
    if buffer.data != nil:
      deallocShared(buffer.data)
    buffer = SharedHttpBuffer()

  proc consumeHttpBuffer(buffer: var SharedHttpBuffer): string =
    if buffer.len > 0:
      result = newString(buffer.len)
      copyMem(addr result[0], buffer.data, buffer.len)
    freeHttpBuffer(buffer)

  proc appendHttpBuffer(buffer: var SharedHttpBuffer, source: pointer,
                        size: int): int {.inline.} =
    if size <= 0 or buffer.len >= buffer.cap:
      return 0
    result = min(size, buffer.cap - buffer.len)
    let needed = buffer.len + result
    if needed > buffer.allocated:
      var nextCapacity = max(16_384, buffer.allocated * 2)
      if nextCapacity < needed:
        nextCapacity = needed
      nextCapacity = min(nextCapacity, buffer.cap)
      buffer.data = reallocShared(buffer.data, nextCapacity)
      buffer.allocated = nextCapacity
    copyMem(cast[pointer](cast[uint](buffer.data) + uint(buffer.len)),
            source, result)
    inc buffer.len, result

  proc httpWriteCallback(data: pointer, size, count: csize_t,
                         userData: pointer): csize_t {.cdecl, gcsafe.} =
    let ctx = cast[ptr HttpClientCtx](userData)
    if size != 0 and count > high(csize_t) div size:
      return 0
    let total = size * count
    if total > csize_t(high(int)):
      return 0
    let copied = appendHttpBuffer(ctx.responseBody, data, int(total))
    if copied < int(total):
      ctx.responseTruncated = true
    if copied > 0 and ctx.chunkChanBits != 0 and
        not atomicLoadN(addr ctx.streamGone, ATOMIC_ACQUIRE):
      let node = cast[ptr SharedExecLine](allocShared0(sizeof(SharedExecLine)))
      node.text.data = allocShared0(copied)
      node.text.len = copied
      copyMem(node.text.data, data, copied)
      withLock ctx.chunkLock:
        if ctx.queuedBytes + copied > ctx.maxPendingBytes:
          if node.text.data != nil:
            deallocShared(node.text.data)
          deallocShared(node)
          ctx.bufferOverflow = true
          return 0
        if ctx.chunkTail == nil:
          ctx.chunkHead = node
          ctx.chunkTail = node
        else:
          ctx.chunkTail.next = node
          ctx.chunkTail = node
        inc ctx.queuedBytes, copied
    total

  proc httpHeaderCallback(data: pointer, size, count: csize_t,
                          userData: pointer): csize_t {.cdecl, gcsafe.} =
    let ctx = cast[ptr HttpClientCtx](userData)
    if size != 0 and count > high(csize_t) div size:
      return 0
    let total = size * count
    if total > csize_t(high(int)):
      return 0
    var line = newString(int(total))
    if line.len > 0:
      copyMem(addr line[0], data, line.len)
    if line.startsWith("HTTP/"):
      let parts = strutils.splitWhitespace(line)
      if parts.len >= 2 and parts[1] == "101":
        ctx.protocolUpgrade = true
        return 0
    let copied = appendHttpBuffer(ctx.responseHeaders, data, int(total))
    if copied < int(total):
      ctx.headersTruncated = true
    total

  proc httpProgressCallback(userData: pointer, dlTotal, dlNow, ulTotal,
                            ulNow: int64): cint {.cdecl, gcsafe.} =
    let ctx = cast[ptr HttpClientCtx](userData)
    if atomicLoadN(addr ctx.cancelRequested, ATOMIC_ACQUIRE): 1 else: 0

  proc freeHttpClientCtx(ctx: ptr HttpClientCtx) =
    if ctx == nil:
      return
    discard consumeSharedExecText(ctx.httpMethod)
    discard consumeSharedExecText(ctx.url)
    discard consumeSharedExecText(ctx.requestTarget)
    discard consumeSharedExecText(ctx.body)
    discard consumeSharedExecText(ctx.caData)
    discard consumeSharedExecText(ctx.effectiveUrl)
    discard consumeSharedExecText(ctx.resultFailure)
    freeHttpBuffer(ctx.responseBody)
    freeHttpBuffer(ctx.responseHeaders)
    freeSharedExecLines(ctx.chunkHead)
    var header = ctx.headers
    while header != nil:
      let next = header.next
      if header.text.data != nil:
        deallocShared(header.text.data)
      deallocShared(header)
      header = next
    deinitLock(ctx.chunkLock)
    deallocShared(ctx)

  proc parseCurlHeaders(raw: string): PropTable =
    result = initPropTable()
    for rawLine in raw.splitLines:
      let line = rawLine.strip(chars = {'\r', ' ', '\t'})
      if line.startsWith("HTTP/"):
        result = initPropTable()
      elif line.len > 0:
        let separator = line.find(':')
        if separator > 0:
          let name = line[0 ..< separator].strip.toLowerAscii
          let value = line[separator + 1 .. ^1].strip
          if result.hasKey(name):
            result[name] = newStr(result[name].strVal & ", " & value)
          else:
            result[name] = newStr(value)

  proc pollHttpClientCompletions() =
    # Every scheduler safepoint reaches this probe through the existing async
    # exec poll. Keep the unused-client path lock-free so ordinary VM workloads
    # do not acquire a new global lock.
    if atomicLoadN(addr httpClientPendingCount, ATOMIC_ACQUIRE) == 0:
      return
    withLock httpClientLock:
      var i = 0
      while i < httpClientPending.len:
        let pending {.cursor.} = httpClientPending[i]
        let ctx = pending.ctx
        if ctx.schedulerPtr != cast[pointer](currentScheduler()):
          inc i
          continue
        var task {.cursor.}: Value
        task.bits = ctx.taskBits
        let cancelled = task.taskCancelled
        if task.taskCancelled:
          atomicStoreN(addr ctx.cancelRequested, true, ATOMIC_RELEASE)
        var head, tail: ptr SharedExecLine
        withLock ctx.chunkLock:
          head = ctx.chunkHead
          tail = ctx.chunkTail
          ctx.chunkHead = nil
          ctx.chunkTail = nil
          ctx.queuedBytes = 0
        var channelBlocked = false
        if cancelled:
          freeSharedExecLines(head)
          head = nil
        elif ctx.chunkChanBits != 0:
          var channel {.cursor.}: Value
          channel.bits = ctx.chunkChanBits
          while head != nil:
            let chunk = consumeSharedExecText(head.text)
            let pushed = channel.tryPushChannel(newStr(chunk))
            if pushed.closed:
              atomicStoreN(addr ctx.streamGone, true, ATOMIC_RELEASE)
              freeSharedExecLines(head)
              head = nil
              break
            if not pushed.pushed:
              head.text = sharedExecText(chunk)
              channelBlocked = true
              break
            let consumed = head
            head = head.next
            deallocShared(consumed)
            wakeChannelWaitersIn(cast[SchedulerState](ctx.schedulerPtr), channel,
                                 wakeSenders = false)
        if head != nil:
          var bytes = 0
          var node = head
          while node != nil:
            inc bytes, node.text.len
            node = node.next
          withLock ctx.chunkLock:
            tail.next = ctx.chunkHead
            ctx.chunkHead = head
            if ctx.chunkTail == nil:
              ctx.chunkTail = tail
            inc ctx.queuedBytes, bytes
        let workerDone = atomicLoadN(addr ctx.workerDone, ATOMIC_ACQUIRE)
        if workerDone and not channelBlocked:
          var channel {.cursor.}: Value
          channel.bits = ctx.chunkChanBits
          if ctx.chunkChanBits != 0:
            closeChannel(channel)
            let scheduler = cast[SchedulerState](ctx.schedulerPtr)
            wakeAllChannelWaitersIn(scheduler, channel, wakeSenders = false)
            wakeAllChannelWaitersIn(scheduler, channel, wakeSenders = true)
          if not cancelled and not task.taskCancelled:
            if ctx.resultFailed:
              let failure = consumeSharedExecText(ctx.resultFailure)
              try:
                raiseHttpClientError(failure, pending.scope, "transport")
              except GeneError as error:
                if tryFailTask(task, error.msg,
                    admitErrorValue(error.errVal,
                      pending.scope.application().builtinsScope()), hasValue = true):
                  wakeTaskWaitersIn(cast[SchedulerState](ctx.schedulerPtr), task)
            else:
              var response = initPropTable()
              response["status"] = newInt(ctx.responseStatus)
              response["headers"] =
                newMap(parseCurlHeaders(consumeHttpBuffer(ctx.responseHeaders)))
              response["body"] = newStr(consumeHttpBuffer(ctx.responseBody))
              response["effective_url"] =
                newStr(consumeSharedExecText(ctx.effectiveUrl))
              response["truncated"] = newBool(ctx.responseTruncated)
              response["headers_truncated"] = newBool(ctx.headersTruncated)
              if tryCompleteTask(task, newMap(response)):
                wakeTaskWaitersIn(cast[SchedulerState](ctx.schedulerPtr), task)
          endExternalNativeOp()
          pending.ctx = nil
          freeHttpClientCtx(ctx)
          let last = httpClientPending.high
          if i != last:
            httpClientPending[i] = move httpClientPending[last]
          httpClientPending.setLen(last)
          discard atomicFetchSub(addr httpClientPendingCount, 1,
                                 ATOMIC_ACQ_REL)
        else:
          inc i

  proc runHttpClientJob(jobPtr: pointer) {.gcsafe.} =
    {.cast(gcsafe).}:
      let ctx = cast[ptr HttpClientCtx](jobPtr)
      template fail(message: string) =
        ctx.resultFailed = true
        ctx.resultFailure = sharedExecText("net/http_client: " & message)
      if atomicLoadN(addr ctx.cancelRequested, ATOMIC_ACQUIRE):
        ctx.resultCancelled = true
        return
      let httpMethod = readSharedExecText(ctx.httpMethod)
      let url = readSharedExecText(ctx.url)
      let requestTarget = readSharedExecText(ctx.requestTarget)
      let body = readSharedExecText(ctx.body)
      let easy = gCurlApi.easyInit()
      if easy == nil:
        fail("curl_easy_init failed")
        return
      var headerList: pointer
      try:
        template setopt(call: untyped, label: string) =
          if call != CurlOk:
            ctx.unsupportedTransport = true
            fail("could not set " & label)
            return
        setopt(cCurlSetoptStr(gCurlApi.setoptAddr, easy, CurlOptUrl, url.cstring), "URL")
        setopt(cCurlSetoptStr(gCurlApi.setoptAddr, easy, CurlOptRequestTarget,
                              requestTarget.cstring), "request target")
        setopt(cCurlSetoptLong(gCurlApi.setoptAddr, easy, CurlOptPathAsIs, 1),
               "path preservation")
        setopt(cCurlSetoptLong(gCurlApi.setoptAddr, easy, CurlOptHttpVersion, 2),
               "HTTP/1.1")
        setopt(cCurlSetoptLong(gCurlApi.setoptAddr, easy, CurlOptProtocols, 3),
               "HTTP/HTTPS protocols")
        setopt(cCurlSetoptStr(gCurlApi.setoptAddr, easy, CurlOptProxy, ""),
               "no proxy")
        setopt(cCurlSetoptStr(gCurlApi.setoptAddr, easy, CurlOptPreProxy, ""),
               "no pre-proxy")
        for option in [CurlOptHttpProxyTunnel, CurlOptNetrc, CurlOptHttpAuth,
                       CurlOptProxyAuth]:
          setopt(cCurlSetoptLong(gCurlApi.setoptAddr, easy, option, 0),
                 "no tunnels or managed authentication")
        for option in [CurlOptFreshConnect, CurlOptForbidReuse, CurlOptSslVerifyPeer]:
          setopt(cCurlSetoptLong(gCurlApi.setoptAddr, easy, option, 1),
                 "fresh verified connection")
        setopt(cCurlSetoptLong(gCurlApi.setoptAddr, easy, CurlOptSslVerifyHost, 2),
               "TLS hostname verification")
        setopt(cCurlSetoptStr(gCurlApi.setoptAddr, easy, CurlOptCustomRequest,
                              httpMethod.cstring),
               "method")
        setopt(cCurlSetoptLong(gCurlApi.setoptAddr, easy, CurlOptNoSignal, 1),
               "no-signal")
        # Transparently following a redirect would connect to a second URL the
        # caller did not name; return the redirect response instead.
        setopt(cCurlSetoptLong(gCurlApi.setoptAddr, easy, CurlOptFollowLocation, 0),
               "redirect policy")
        setopt(cCurlSetoptLong(gCurlApi.setoptAddr, easy, CurlOptTimeoutMs,
                               ctx.timeoutMs.clong),
               "timeout")
        setopt(cCurlSetoptStr(gCurlApi.setoptAddr, easy, CurlOptAcceptEncoding, ""),
               "content decoding")
        var caBlob: CurlBlob
        if ctx.caData.len > 0:
          caBlob = CurlBlob(data: ctx.caData.data,
                            len: csize_t(ctx.caData.len), flags: 0)
          setopt(cCurlSetoptPtr(gCurlApi.setoptAddr, easy, CurlOptCaInfoBlob,
                                addr caBlob), "CA data")
        setopt(cCurlSetoptPtr(gCurlApi.setoptAddr, easy, CurlOptWriteFunction,
                              cast[pointer](httpWriteCallback)), "write callback")
        setopt(cCurlSetoptPtr(gCurlApi.setoptAddr, easy, CurlOptWriteData, ctx),
               "write data")
        setopt(cCurlSetoptPtr(gCurlApi.setoptAddr, easy, CurlOptHeaderFunction,
                              cast[pointer](httpHeaderCallback)), "header callback")
        setopt(cCurlSetoptPtr(gCurlApi.setoptAddr, easy, CurlOptHeaderData, ctx),
               "header data")
        setopt(cCurlSetoptLong(gCurlApi.setoptAddr, easy, CurlOptNoProgress, 0),
               "progress")
        setopt(cCurlSetoptPtr(gCurlApi.setoptAddr, easy, CurlOptXferInfoFunction,
                              cast[pointer](httpProgressCallback)),
               "progress callback")
        setopt(cCurlSetoptPtr(gCurlApi.setoptAddr, easy, CurlOptXferInfoData, ctx),
               "progress data")
        if body.len > 0:
          setopt(cCurlSetoptPtr(gCurlApi.setoptAddr, easy, CurlOptPostFields,
                                ctx.body.data),
                 "request body")
          setopt(cCurlSetoptOff(gCurlApi.setoptAddr, easy,
                                CurlOptPostFieldSizeLarge, body.len.int64),
                 "request body size")
        if httpMethod == "HEAD":
          setopt(cCurlSetoptLong(gCurlApi.setoptAddr, easy, CurlOptNoBody, 1),
                 "HEAD response")
        # libcurl can retry a 417 response after an Expect: 100-continue
        # handshake. Suppress that automatic mode so one call sends one request.
        headerList = gCurlApi.slistAppend(nil, "Expect:")
        if headerList == nil:
          fail("could not disable the Expect handshake")
          return
        var header = ctx.headers
        while header != nil:
          let text = readSharedExecText(header.text)
          let nextList = gCurlApi.slistAppend(headerList, text.cstring)
          if nextList == nil:
            fail("could not allocate request headers")
            return
          headerList = nextList
          header = header.next
        if headerList != nil:
          setopt(cCurlSetoptPtr(gCurlApi.setoptAddr, easy, CurlOptHttpHeader,
                                headerList),
                 "request headers")
        if atomicLoadN(addr ctx.cancelRequested, ATOMIC_ACQUIRE):
          ctx.resultCancelled = true
          return
        let code = gCurlApi.easyPerform(easy)
        if code != CurlOk:
          if code == CurlAbortedByCallback and
              atomicLoadN(addr ctx.cancelRequested, ATOMIC_ACQUIRE):
            ctx.resultCancelled = true
          else:
            ctx.resultTimedOut = code == CurlOperationTimedOut
            let detail = if ctx.protocolUpgrade:
                "protocol upgrades are unsupported"
              elif ctx.bufferOverflow:
                "stream buffer exceeded its configured byte cap"
              elif gCurlApi.easyStrerror(code) == nil:
                "libcurl error " & $code
              else:
                $gCurlApi.easyStrerror(code)
            fail(detail)
          return
        var status: clong
        if cCurlGetinfoPtr(gCurlApi.getinfoAddr, easy, CurlInfoResponseCode,
                           addr status) != CurlOk:
          fail("could not read response status")
          return
        ctx.responseStatus = int(status)
        # No redirects are followed. Report the exact requested URL, including
        # a present empty query, rather than reserializing curl's URL parser.
        ctx.effectiveUrl = sharedExecText(url)
      except CatchableError as e:
        fail(e.msg)
      finally:
        if headerList != nil:
          gCurlApi.slistFreeAll(headerList)
        gCurlApi.easyCleanup(easy)

  proc httpClientWorkerMain() {.thread.} =
    {.cast(gcsafe).}:
      while true:
        var jobPtr: pointer
        withLock httpClientLock:
          while httpClientQueue.len == 0:
            inc httpClientIdle
            wait(httpClientCond, httpClientLock)
            dec httpClientIdle
          jobPtr = httpClientQueue[0]
          httpClientQueue.delete(0)
        runHttpClientJob(jobPtr)
        let ctx = cast[ptr HttpClientCtx](jobPtr)
        atomicStoreN(addr ctx.workerDone, true, ATOMIC_RELEASE)

  proc enqueueHttpClientJob(jobPtr: pointer) =
    var needThread = false
    withLock httpClientLock:
      httpClientQueue.add(jobPtr)
      if httpClientIdle == 0 and
          httpClientThreads.len + httpClientStarting < httpClientMaxWorkers:
        needThread = true
        inc httpClientStarting
      else:
        signal(httpClientCond)
    if needThread:
      var thread: ref Thread[void]
      new(thread)
      try:
        createThread(thread[], httpClientWorkerMain)
        withLock httpClientLock:
          dec httpClientStarting
          httpClientThreads.add thread
      except:
        var removed = false
        withLock httpClientLock:
          dec httpClientStarting
          for i in 0 ..< httpClientQueue.len:
            if httpClientQueue[i] == jobPtr:
              httpClientQueue.delete(i)
              removed = true
              break
        if removed:
          raise

else:
  proc pollHttpClientCompletions() =
    discard

proc validHttpMethod(httpMethod: string): bool =
  if httpMethod.len == 0:
    return false
  for ch in httpMethod:
    if not (ch in {'A'..'Z', 'a'..'z', '0'..'9', '-', '_'}):
      return false
  true

proc httpRequestTarget(url: string): string =
  ## Origin-form request target (path plus query) of an absolute URL.
  let schemeEnd = url.find("://")
  let authorityStart = if schemeEnd >= 0: schemeEnd + 3 else: 0
  let pathStart = url.find({'/', '?', '#'}, authorityStart)
  if pathStart < 0: return "/"
  result = url[pathStart .. ^1]
  let fragment = result.find('#')
  if fragment >= 0: result.setLen(fragment)
  if result.len == 0 or result[0] != '/': result = "/" & result

proc biHttpClientStart(name: string, streaming: bool,
                       args: openArray[Value], call: ptr NativeCall): Value =
  let scope = if call == nil: nil else: call[].dispatchScope
  when not compileOption("threads"):
    raiseHttpClientError(name & " requires a threaded runtime build", scope)
  if args.len != 0:
    raiseHttpClientError(name & " expects only named arguments", scope)
  var httpMethod = "GET"
  var url = ""
  var headers: seq[string]
  var body = ""
  var caFile = ""
  var caData = ""
  var timeoutMs = HttpDefaultTimeoutMs
  var maxBytes = HttpDefaultMaxBytes
  var pendingBytes = HttpDefaultPendingBytes
  var channelCapacity = 256
  if call != nil:
    for i, argName in call[].namedNames:
      let value = call[].namedValues[i]
      case argName
      of "method":
        requireStr(name & " ^method", value)
        httpMethod = value.strVal
      of "url":
        requireStr(name & " ^url", value)
        url = value.strVal
      of "headers":
        case value.kind
        of vkMap:
          for headerName, headerValue in value.mapEntries:
            requireStr(name & " ^headers value", headerValue)
            headers.add headerName & ": " & headerValue.strVal
        of vkList:
          for item in value.listItems:
            requireStr(name & " ^headers item", item)
            headers.add item.strVal
        else:
          raiseHttpClientError(name & " ^headers must be a Map or List of Str",
                               scope)
      of "body":
        requireStr(name & " ^body", value)
        body = value.strVal
      of "ca_file":
        requireStr(name & " ^ca_file", value)
        caFile = value.strVal
      of "timeout_ms":
        timeoutMs = int(requireInt64(name & " ^timeout_ms", value))
      of "max_bytes":
        maxBytes = int(requireInt64(name & " ^max_bytes", value))
      of "max_pending_bytes":
        if not streaming:
          raiseHttpClientError(name & " got unexpected named argument: " & argName,
                               scope)
        pendingBytes = int(requireInt64(name & " ^max_pending_bytes", value))
      of "channel_capacity":
        if not streaming:
          raiseHttpClientError(name & " got unexpected named argument: " & argName,
                               scope)
        channelCapacity = int(requireInt64(name & " ^channel_capacity", value))
      else:
        raiseHttpClientError(name & " got unexpected named argument: " & argName,
                             scope)
  if not validHttpMethod(httpMethod):
    raiseHttpClientError(name & " ^method contains invalid characters", scope)
  if not (url.startsWith("http://") or url.startsWith("https://")):
    raiseHttpClientError(name & " ^url must use http:// or https://", scope)
  if timeoutMs <= 0 or maxBytes <= 0 or pendingBytes <= 0 or channelCapacity <= 0:
    raiseHttpClientError(name & " limits must be positive", scope)
  if timeoutMs > 86_400_000 or maxBytes > HttpHardMaxBytes or
      pendingBytes > HttpHardPendingBytes or channelCapacity > 65_536:
    raiseHttpClientError(name & " limits exceed the native client safety cap",
                         scope)
  if url.len > 16_384 or body.len > HttpHardMaxBytes or caFile.len > 4096:
    raiseHttpClientError(name & " request data exceeds the native client safety cap",
                         scope)
  if headers.len > 256:
    raiseHttpClientError(name & " accepts at most 256 headers", scope)
  for header in headers:
    if header.len > 65_536:
      raiseHttpClientError(name & " header exceeds 65536 bytes", scope)
    if '\r' in header or '\n' in header:
      raiseHttpClientError(name & " rejects newline characters in headers", scope)
  if caFile.len > 0:
    try:
      caData = fsReadBytes(caFile)
    except CatchableError as error:
      raiseHttpClientError(name & " ^ca_file: " & error.msg, scope)
  loadCurlApi(scope)
  when compileOption("threads"):
    if scope == nil or scope.application == nil:
      raiseHttpClientError(name & " requires a scheduler scope", scope)
    pollHttpClientCompletions()
    let task = newExternalTask()
    let channel = if streaming: newChannel(channelCapacity) else: NIL
    markSharedValue(task)
    if streaming:
      markSharedValue(channel)
    let ctx = cast[ptr HttpClientCtx](allocShared0(sizeof(HttpClientCtx)))
    ctx.httpMethod = sharedExecText(httpMethod)
    ctx.url = sharedExecText(url)
    ctx.requestTarget = sharedExecText(httpRequestTarget(url))
    ctx.body = sharedExecText(body)
    ctx.caData = sharedExecText(caData)
    ctx.taskBits = task.bits
    ctx.chunkChanBits = if streaming: channel.bits else: 0'u64
    ctx.schedulerPtr = cast[pointer](schedulerForScope(scope))
    ctx.timeoutMs = timeoutMs
    ctx.maxBytes = maxBytes
    ctx.maxPendingBytes = pendingBytes
    ctx.responseBody.cap = maxBytes
    ctx.responseHeaders.cap = HttpHeaderMaxBytes
    initLock(ctx.chunkLock)
    var headerTail: ptr SharedExecArg
    for header in headers:
      let node = cast[ptr SharedExecArg](allocShared0(sizeof(SharedExecArg)))
      node.text = sharedExecText(header)
      if headerTail == nil:
        ctx.headers = node
      else:
        headerTail.next = node
      headerTail = node
    let pending = HttpClientPending(ctx: ctx, scope: scope)
    pending.taskOwner = retainedCopy(task)
    pending.channelOwner = retainedCopy(channel)
    withLock httpClientLock:
      httpClientPending.add pending
      discard atomicFetchAdd(addr httpClientPendingCount, 1, ATOMIC_RELEASE)
    beginExternalNativeOp()
    try:
      enqueueHttpClientJob(ctx)
    except CatchableError as e:
      endExternalNativeOp()
      withLock httpClientLock:
        httpClientPending.setLen(httpClientPending.len - 1)
        discard atomicFetchSub(addr httpClientPendingCount, 1,
                               ATOMIC_ACQ_REL)
      pending.ctx = nil
      freeHttpClientCtx(ctx)
      raiseHttpClientError(name & " could not start worker: " & e.msg, scope)
    if streaming:
      var streamResult = initPropTable()
      streamResult["task"] = task
      streamResult["channel"] = channel
      newMap(streamResult)
    else:
      task
  else:
    raiseHttpClientError(name & " requires a threaded runtime build", scope)
    NIL

proc biHttpClientRequest(args: openArray[Value],
                         call: ptr NativeCall): Value {.nimcall.} =
  biHttpClientStart("net/http_client/request", false, args, call)

proc biHttpClientStream(args: openArray[Value],
                         call: ptr NativeCall): Value {.nimcall.} =
  biHttpClientStart("net/http_client/stream", true, args, call)

include ./ext/http_client_multi

proc biOsBeginInterrupt(args: openArray[Value]): Value {.nimcall.} =
  if args.len != 0:
    raise newException(GeneError, "os/begin_interrupt takes no arguments")
  when defined(posix) and not defined(emscripten) and not defined(geneWasm):
    if cTurnInterruptBegin() == 0: TRUE else: FALSE
  else:
    FALSE

proc biOsTakeInterrupt(args: openArray[Value]): Value {.nimcall.} =
  if args.len != 0:
    raise newException(GeneError, "os/take_interrupt takes no arguments")
  when defined(posix) and not defined(emscripten) and not defined(geneWasm):
    if cTurnInterruptTake() != 0: TRUE else: FALSE
  else:
    FALSE

proc biOsEndInterrupt(args: openArray[Value]): Value {.nimcall.} =
  if args.len != 0:
    raise newException(GeneError, "os/end_interrupt takes no arguments")
  when defined(posix) and not defined(emscripten) and not defined(geneWasm):
    cTurnInterruptEnd()
  NIL

proc biOsMonotonicMs(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 0:
    raise newException(GeneError, "os/monotonic_ms takes no arguments")
  newInt(getMonoTime().ticks div 1_000_000)

proc biOsWallMs(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  ## Wall-clock time as Unix epoch milliseconds. Unlike `monotonic_ms` it
  ## means the same thing in another process or after a restart — what a
  ## stored expiry needs — and unlike it, it can jump when the clock is set.
  if args.len != 0:
    raise newException(GeneError, "os/wall_ms takes no arguments")
  let t = getTime()
  newInt(t.toUnix * 1000 + int64(t.nanosecond div 1_000_000))

proc biOsProcessId(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 0:
    raise newException(GeneError, "os/process_id takes no arguments")
  newInt(getCurrentProcessId())

proc biOsExit(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  let scope = if call == nil: nil else: call[].dispatchScope
  requireOne("os/exit", args)
  let status = requireInt64("os/exit", args[0])
  if status < 0 or status > 255:
    raiseOsError("os/exit status must be within 0..255", scope)
  when defined(emscripten) or defined(geneWasm):
    raiseOsError("os/exit is unavailable in the WebAssembly host", scope)
  else:
    # Explicit process termination does not unwind Gene ensure scopes.
    # The caller is responsible for flushing its durable state first.
    quit(int(status))
  NIL

proc biOsStdinTty(args: openArray[Value]): Value {.nimcall.} =
  if args.len != 0:
    raise newException(GeneError, "os/stdin_tty? takes no arguments")
  when defined(posix):
    if isatty(STDIN_FILENO) != 0: TRUE else: FALSE
  else:
    FALSE

proc cClearErr(f: File) {.importc: "clearerr", header: "<stdio.h>".}

proc biOsStdoutTty(args: openArray[Value]): Value {.nimcall.} =
  if args.len != 0: raise newException(GeneError, "os/stdout_tty? takes no arguments")
  when defined(posix): newBool(isatty(STDOUT_FILENO) != 0)
  else: FALSE

when defined(posix) and not defined(emscripten) and not defined(geneWasm):
  var stdinLineTask {.threadvar.}: Value
  var stdinLineScheduler {.threadvar.}: SchedulerState
  var stdinLineBuffer {.threadvar.}: string

  proc pollStdinLineCompletions() =
    if stdinLineTask.kind != vkTask:
      return
    if stdinLineTask.taskDone:
      stdinLineTask = NIL
      stdinLineBuffer.setLen(0)
      endExternalNativeOp()
      return
    for _ in 0..<4096:
      var ready = TPollfd(fd: STDIN_FILENO,
                         events: cshort(POLLIN or POLLHUP or POLLERR))
      if posix.poll(addr ready, 1, 0) <= 0:
        return
      var ch: char
      let count = posix.read(STDIN_FILENO, addr ch, 1)
      if count < 0:
        if errno == EINTR or errno == EAGAIN:
          return
        let error = "stdin read failed: " & osErrorMsg(osLastError())
        discard tryFailTask(stdinLineTask, error)
      elif count == 0 or ch == '\n':
        if stdinLineBuffer.endsWith("\r"):
          stdinLineBuffer.setLen(stdinLineBuffer.len - 1)
        let value = if count == 0 and stdinLineBuffer.len == 0: NIL
                    else: newStr(stdinLineBuffer)
        discard tryCompleteTask(stdinLineTask, value)
      else:
        stdinLineBuffer.add ch
        if stdinLineBuffer.len <= 1048576:
          continue
        discard tryFailTask(stdinLineTask, "stdin line exceeds 1048576 bytes")
      wakeTaskWaitersIn(stdinLineScheduler, stdinLineTask)
      stdinLineTask = NIL
      stdinLineBuffer.setLen(0)
      endExternalNativeOp()
      return

  proc biOsReadLineAsync(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
    if args.len != 0:
      raise newException(GeneError, "os/read_line_async takes no arguments")
    flushFile(stdout)
    pollStdinLineCompletions()
    if stdinLineTask.kind == vkTask:
      raise newException(GeneError, "stdin already has a pending line read")
    let scope = if call == nil: nil else: call.dispatchScope
    stdinLineTask = newExternalTask()
    if scope != nil:
      scope.registerIoTask(stdinLineTask)
    stdinLineScheduler = schedulerForScope(scope)
    stdinLineBuffer.setLen(0)
    result = stdinLineTask
    beginExternalNativeOp()
    pollStdinLineCompletions()
else:
  proc pollStdinLineCompletions() = discard
  proc biOsReadLineAsync(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
    raise newException(GeneError, "os/read_line_async requires a POSIX host")

proc biOsReadLine(args: openArray[Value], call: ptr NativeCall = nil): Value {.nimcall.} =
  ## Read one line from stdin; returns nil at EOF.
  if args.len != 0:
    raise newException(GeneError, "os/read_line takes no arguments")
  try:
    newStr(stdin.readLine())
  except EOFError:
    when defined(posix):
      if isatty(STDIN_FILENO) != 0:
        cClearErr(stdin)
    NIL

include ./ext/term/stdlib_term

# --- repl: reusable interactive evaluator ---

type IncrementalReplSession = ref object of RootObj
  scope: Scope
  pendingSource: string
  pendingError: string
  closed: bool
  busy: bool

var incrementalReplSessions = initTable[int, IncrementalReplSession]()
var nextIncrementalReplId = 0

proc incrementalReplId(name: string, value: Value, scope: Scope,
                       requireOpen = true): int =
  if not nativeReceiverIs(scope, value, "ReplSession"):
    raise newException(GeneError, name & " expects a repl/Session")
  let id = value.props.getOrDefault("id", VOID)
  let closed = value.props.getOrDefault("closed", VOID)
  if id.kind != vkInt or closed.kind != vkCell or id.intVal <= 0 or
      id.intVal > nextIncrementalReplId:
    raise newException(GeneError, name & " received an invalid repl/Session")
  result = int(id.intVal)
  let session = incrementalReplSessions.getOrDefault(result)
  if (session == nil and (requireOpen or not closed.cellValue.isTruthy)) or
      (requireOpen and (session.closed or closed.cellValue.isTruthy)):
    raise newException(GeneError, name & ": Session is closed")

proc replEvalResult(status, text: string): Value =
  var props = initPropTable()
  props["status"] = newStr(status)
  props["text"] = newStr(text)
  newMap(props)

proc biReplFormat(args: openArray[Value]): Value {.nimcall.} =
  requireOne("repl/format", args)
  newStr(args[0].print())

proc biReplOpen(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("repl/open", args)
  if args[0].kind != vkEnv:
    raise newException(GeneError, "repl/open expects an Env")
  let dispatchScope = if call == nil: nil else: call[].dispatchScope
  let evalScope = incrementalReplScopeForEnv(args[0],
    if dispatchScope == nil: nil else: dispatchScope.application())
  let session = IncrementalReplSession(scope: evalScope)
  inc nextIncrementalReplId
  incrementalReplSessions[nextIncrementalReplId] = session
  newNativeWrapper(builtInTypeHead(dispatchScope, "ReplSession"),
    {"id": newInt(nextIncrementalReplId),
     "closed": newCell(FALSE)})

when not defined(geneWasm):
  type ReplFrameCall = ref object of RootObj
    session: IncrementalReplSession
    chunk: Chunk
    budget: EvalBudget
    requiredTypesLen: int
    started: bool
    successful: bool

  proc finishReplFrame(context: RootRef, args: openArray[Value],
                       call: ptr NativeCall): Value {.nimcall.} =
    let state = ReplFrameCall(context)
    if not state.started:
      return NIL
    try:
      if not state.successful:
        abandonReplInput(state.session.scope, state.chunk, state.requiredTypesLen)
    finally:
      state.session.scope.evalBudget = nil
      state.session.busy = false
      state.started = false
    NIL

  proc succeedReplFrame(context: RootRef, args: openArray[Value],
                        call: ptr NativeCall): Value {.nimcall.} =
    ReplFrameCall(context).successful = true
    NIL

  proc executeReplFrame(context: RootRef, args: openArray[Value],
                        call: ptr NativeCall): Value {.nimcall.} =
    let state = ReplFrameCall(context)
    if state.session.closed:
      raise newException(GeneError, "repl/eval: Session is closed")
    if state.session.busy:
      raise newException(GeneError, "repl/eval: Session is busy")
    # Claim execution only after the wrapper's ensure handler is installed.
    # Cancellation before its first instruction must not strand a busy session.
    state.session.busy = true
    state.started = true
    state.requiredTypesLen = state.session.scope.requiredImplTypes.len
    state.session.scope.evalBudget = state.budget
    state.session.scope.prepareChunkScope(state.chunk)
    var request: ref NativeFrameRequest
    new(request)
    request.chunk = state.chunk
    request.scope = state.session.scope
    request.label = "repl input"
    request.validateImpls = true
    raise request

  proc biReplEvalFrame(args: openArray[Value],
                       call: ptr NativeCall): Value {.nimcall.} =
    if args.len != 2:
      raise newException(GeneError, "repl/eval expects (repl/Session, Str)")
    let caller = if call == nil: nil else: call[].dispatchScope
    let id = incrementalReplId("repl/eval", args[0], caller)
    requireStr("repl/eval source", args[1])
    let session = incrementalReplSessions[id]
    if session.busy:
      raise newException(GeneError, "repl/eval: Session is busy")
    let wrapper = newScope(caller)
    # Only trusted bookkeeping runs in this wrapper. User code receives the
    # caller budget below; an exhausted input budget must not skip repl_finish.
    wrapper.evalBudget = EvalBudget(remaining: high(int64))
    let wrapperChunk = compileEvalSource(
      "(try (let value (repl_execute)) (repl_success) value ensure (repl_finish))",
      useLocalSlots = false)
    session.scope.evalBudget =
      if activeVmBudget != nil: activeVmBudget[]
      elif caller != nil: caller.evalBudget
      else: nil
    var compiled: Chunk
    let context = scopeMacroBindings(session.scope)
    var existingValues: seq[string]
    for name in session.scope.vars.keys: existingValues.add name
    for index, name in session.scope.slotNames:
      if index notin session.scope.privateSlots and name notin existingValues:
        existingValues.add name
    session.busy = true
    try:
      compiled = compileReplSource(args[1].strVal, macros = context,
        history = if context != nil: context.history else: @[],
        existingValues = existingValues)
      for diagnostic in compiled.compilerDiagnostics:
        if diagnostic.message.startsWith("unused lazy pipeline:") or
            diagnostic.message.startsWith("error checking:"):
          stderr.writeLine(formatDiagnostic("Warning", diagnostic.message,
                                            diagnostic.loc))
    except:
      session.scope.evalBudget = nil
      session.busy = false
      raise
    let state = ReplFrameCall(session: session, chunk: compiled,
      budget: session.scope.evalBudget,
      requiredTypesLen: session.scope.requiredImplTypes.len)
    session.scope.evalBudget = nil
    session.busy = false
    wrapper.define("repl_execute", newNativeContextFn("repl/execute", state,
      executeReplFrame, acceptsNamed = false))
    wrapper.define("repl_finish", newNativeContextFn("repl/finish", state,
      finishReplFrame, acceptsNamed = false))
    wrapper.define("repl_success", newNativeContextFn("repl/success", state,
      succeedReplFrame, acceptsNamed = false))
    var request: ref NativeFrameRequest
    new(request)
    request.chunk = wrapperChunk
    request.scope = wrapper
    request.label = "repl eval"
    raise request

  proc biReplBind(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
    if args.len != 3:
      raise newException(GeneError, "repl/bind expects (repl/Session, Str, Any)")
    let caller = if call == nil: nil else: call[].dispatchScope
    let id = incrementalReplId("repl/bind", args[0], caller)
    requireStr("repl/bind name", args[1])
    let session = incrementalReplSessions[id]
    if session.busy:
      raise newException(GeneError, "repl/bind: Session is busy")
    session.scope.parent.defineOverlay(args[1].strVal, args[2])
    NIL
else:
  proc biReplEvalFrame(args: openArray[Value],
                       call: ptr NativeCall): Value {.nimcall.} =
    raise newException(GeneError, "repl/eval requires a native host")
  proc biReplBind(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
    raise newException(GeneError, "repl/bind requires a native host")

proc biReplEval(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError,
      "repl/eval_source expects (repl/Session, Str)")
  let dispatchScope = if call == nil: nil else: call[].dispatchScope
  let id = incrementalReplId("repl/eval_source", args[0], dispatchScope)
  requireStr("repl/eval_source source", args[1])
  let session = incrementalReplSessions[id]
  if session.busy:
    raise newException(GeneError, "repl/eval_source: Session is busy")
  let source =
    if session.pendingSource.len == 0: args[1].strVal
    else: session.pendingSource & "\n" & args[1].strVal
  if source.strip().len == 0:
    return replEvalResult("ok", "")
  try:
    let value = run(compileEvalSource(source, useLocalSlots = false,
                                      sourceName = "<repl-pane>"),
                    session.scope)
    session.pendingSource.setLen(0)
    session.pendingError.setLen(0)
    replEvalResult("ok", value.print())
  except ReadIncompleteError as error:
    session.pendingSource = source
    session.pendingError = error.msg
    replEvalResult("incomplete", error.msg)
  except ReadError as error:
    session.pendingSource.setLen(0)
    session.pendingError.setLen(0)
    replEvalResult("error", formatDiagnostic("Read error", error.msg,
      SourceLoc(sourceName: error.sourceName, line: error.line,
                col: error.col)))
  except GenePanic as error:
    session.pendingSource.setLen(0)
    session.pendingError.setLen(0)
    replEvalResult("panic", "Panic: " & error.msg)
  except GeneError as error:
    session.pendingSource.setLen(0)
    session.pendingError.setLen(0)
    if error.msg == "interrupted":
      replEvalResult("cancelled", "[cancelled]")
    else:
      replEvalResult("error", formatDiagnostic("Error", error.msg, error.loc))

proc biReplClose(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("repl/close", args)
  let dispatchScope = if call == nil: nil else: call[].dispatchScope
  let id = incrementalReplId("repl/close", args[0], dispatchScope,
                             requireOpen = false)
  let closed = args[0].props["closed"]
  if not closed.cellValue.isTruthy:
    let session = incrementalReplSessions.getOrDefault(id)
    if session != nil:
      if session.busy:
        raise newException(GeneError, "repl/close: Session is busy")
      session.closed = true
      session.scope = nil
      session.pendingSource.setLen(0)
      session.pendingError.setLen(0)
      incrementalReplSessions.del(id)
    closed.setCellValue(TRUE)
  NIL

proc biReplDiscardPending(args: openArray[Value],
                          call: ptr NativeCall): Value {.nimcall.} =
  ## Drop a session's buffered incomplete-form source (§C7 Escape rung).
  ## Returns true when pending source existed.
  requireOne("repl/discard_pending", args)
  let dispatchScope = if call == nil: nil else: call[].dispatchScope
  let id = incrementalReplId("repl/discard_pending", args[0], dispatchScope)
  let session = incrementalReplSessions[id]
  result = if session.pendingSource.len > 0: TRUE else: FALSE
  session.pendingSource.setLen(0)
  session.pendingError.setLen(0)

when defined(posix) and not defined(emscripten) and not defined(geneWasm):
  # §C7 in-VM cancellation: while a pane REPL eval is in flight the TUI runs
  # in a no-ISIG terminal mode, so Ctrl-C arrives as a dead keystroke once the
  # cooperative scheduler is starved by a non-yielding eval. The guard enables
  # ISIG and routes SIGINT to the VM interrupt flag, which consumeEvalStep
  # polls on the budgeted-dispatch path; eval_guard_end restores both.
  import std/termios as pane_termios
  var paneEvalOldSigint: Sigaction
  var paneEvalOldTermios: pane_termios.Termios
  var paneEvalGuardActive = false
  var paneEvalTermiosChanged = false

  proc paneEvalSigintHandler(sig: cint) {.noconv.} =
    volatileStore(addr gVmInterrupt, true)

  proc biReplEvalGuardBegin(args: openArray[Value],
                            call: ptr NativeCall): Value {.nimcall.} =
    if paneEvalGuardActive:
      return FALSE
    var act: Sigaction
    act.sa_handler = paneEvalSigintHandler
    discard sigemptyset(act.sa_mask)
    act.sa_flags = SA_RESTART
    if sigaction(SIGINT, act, paneEvalOldSigint) != 0:
      return FALSE
    paneEvalGuardActive = true
    volatileStore(addr gVmInterrupt, false)
    paneEvalTermiosChanged = false
    if isatty(STDIN_FILENO) != 0:
      var attrs: pane_termios.Termios
      if pane_termios.tcGetAttr(STDIN_FILENO, addr attrs) == 0:
        paneEvalOldTermios = attrs
        if (attrs.c_lflag.uint64 and pane_termios.ISIG.uint64) == 0'u64:
          attrs.c_lflag = pane_termios.Cflag(
            attrs.c_lflag.uint64 or pane_termios.ISIG.uint64)
          if pane_termios.tcSetAttr(STDIN_FILENO, pane_termios.TCSANOW,
                                    addr attrs) == 0:
            paneEvalTermiosChanged = true
    TRUE

  proc biReplEvalGuardEnd(args: openArray[Value],
                          call: ptr NativeCall): Value {.nimcall.} =
    if not paneEvalGuardActive:
      return FALSE
    if paneEvalTermiosChanged:
      discard pane_termios.tcSetAttr(STDIN_FILENO, pane_termios.TCSANOW,
                                     addr paneEvalOldTermios)
      paneEvalTermiosChanged = false
    discard sigaction(SIGINT, paneEvalOldSigint, nil)
    paneEvalGuardActive = false
    volatileStore(addr gVmInterrupt, false)
    TRUE
else:
  proc biReplEvalGuardBegin(args: openArray[Value],
                            call: ptr NativeCall): Value {.nimcall.} = FALSE
  proc biReplEvalGuardEnd(args: openArray[Value],
                          call: ptr NativeCall): Value {.nimcall.} = FALSE

proc biReplRun(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 1:
    raise newException(GeneError, "repl/run expects one Env argument")
  if args[0].kind != vkEnv:
    raise newException(GeneError, "repl/run expects an Env")
  var prompt = "gene> "
  var interactive =
    when defined(posix):
      isatty(STDIN_FILENO) != 0
    else:
      false
  if call != nil:
    for i, name in call[].namedNames:
      let v = call[].namedValues[i]
      case name
      of "prompt":
        requireStr("repl/run ^prompt", v)
        prompt = v.strVal
      of "interactive":
        if v.kind != vkBool:
          raise newException(GeneError, "repl/run ^interactive must be Bool")
        interactive = v.boolVal
      else:
        raise newException(GeneError,
          "repl/run got unexpected named argument: " & name)
  let reader = proc(line: var string): bool =
    result = stdin.readLine(line)
    when defined(posix):
      if not result and isatty(STDIN_FILENO) != 0:
        cClearErr(stdin)
  let writeOut = proc(text: string) =
    stdout.write(text)
    stdout.flushFile()
  let writeErr = proc(text: string) =
    stderr.write(text)
    stderr.flushFile()
  newInt(runReplSessionForEnv(args[0], reader, writeOut, writeErr,
                              ReplOptions(interactive: interactive,
                                          prompt: prompt)))

# --- fs: synchronous read + directory listing (docs/stdlib.md "Module Layout") ---

proc biFsTryLock(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("fs/try_lock", args)
  requireStr("fs/try_lock path", args[0])
  let scope = if call == nil: nil else: call[].dispatchScope
  try:
    let fd = fsTryLock(args[0].strVal)
    if fd < 0:
      return NIL
    let id = nextRuntimeResourceId()
    acquire(resourceRecordLock)
    try:
      fsFileLockRecords[id] = FsFileLockRecord(
        application: scope.application(), ownerLane: currentEventLane(), fd: fd)
    finally:
      release(resourceRecordLock)
    newRuntimeResourceHandle(scope, "FsFileLock", id)
  except CatchableError as error:
    raiseFilesystemOperationError("fs/try_lock", error, scope)

proc biFsFileLockClose(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("FsFileLock/close", args)
  let scope = if call == nil: nil else: call[].dispatchScope
  if args[0].kind != vkNode or args[0].nodeResourceId == 0:
    raise newException(GeneError, "FsFileLock/close expects an FsFileLock")
  acquire(resourceRecordLock)
  try:
    let record = fsFileLockRecords.getOrDefault(args[0].nodeResourceId)
    if record == nil:
      raise newException(GeneError, "invalid filesystem claim")
    if record.fd >= 0:
      if record.application != scope.application() or record.ownerLane != currentEventLane():
        raise newException(GeneError, "filesystem claim belongs to another application or lane")
      closeFileLock(record.fd)
      record.fd = -1
      record.application = nil
  finally:
    release(resourceRecordLock)
  NIL

proc fsWatcherRecord(name: string, handle: Value,
                     call: ptr NativeCall): FsWatcherRecord =
  if handle.kind != vkNode or handle.nodeResourceId == 0:
    raise newException(GeneError, name & " expects an FsWatcher")
  let id = handle.nodeResourceId
  acquire(resourceRecordLock)
  try:
    if fsWatcherRecords.hasKey(id):
      result = fsWatcherRecords[id]
  finally:
    release(resourceRecordLock)
  if result == nil:
    raise newException(GeneError, name & " received an invalid FsWatcher")
  let scope = if call == nil: nil else: call[].dispatchScope
  if result.application != nil and
      (scope == nil or scope.application != result.application):
    raise newException(GeneError, name & " watcher belongs to another application")
  if currentEventLane() != result.ownerLane:
    raise newException(GeneError, name & " watcher is owned by another lane")

proc fsWatchRelative(root, path: string): string =
  relativePath(path, root).replace(DirSep, '/')

proc nativeFileWritePending(path: string): bool =
  ## Polling watchers see a completed stdlib write as one change. Do not
  ## publish a writer's truncation or an atomic writer's temporary sibling.
  when compileOption("threads"):
    let absolute = absolutePath(path)
    withLock osExecAsyncLock:
      for pending in osExecAsyncPending:
        if pending.ctx.fileOperation in {nfoWrite, nfoAtomicWrite} and
            (pending.filePath == absolute or
             (pending.ctx.fileOperation == nfoAtomicWrite and
              absolute.startsWith(pending.filePath & ".gene-tmp-"))):
          return true

proc fsWatchScan(record: FsWatcherRecord): Table[string, FsWatchStamp] =
  var pending = @[record.root]
  var index = 0
  while index < pending.len:
    let directory = pending[index]
    inc index
    for name in fsListDir(directory):
      let path = directory / name
      let relative = fsWatchRelative(record.root, path)
      if nativeFileWritePending(path):
        if record.snapshot.hasKey(relative):
          result[relative] = record.snapshot[relative]
        continue
      var info: FileInfo
      try:
        info = getFileInfo(path, followSymlink = false)
      except OSError:
        # The entry disappeared between the descriptor-backed directory read
        # and metadata sampling. The next scan observes the stable result.
        continue
      let kind = info.kind
      result[relative] = FsWatchStamp(
        kind: info.kind,
        size: info.size,
        device: info.id.device,
        fileId: info.id.file,
        modified: info.lastWriteTime)
      if record.recursive and kind == pcDir:
        pending.add path

proc sameFsWatchStamp(a, b: FsWatchStamp): bool =
  a.kind == b.kind and a.size == b.size and a.device == b.device and
    a.fileId == b.fileId and a.modified == b.modified

proc sameFsWatchIdentity(a, b: FsWatchStamp): bool =
  a.kind == b.kind and a.device == b.device and a.fileId == b.fileId

proc fsChange(record: FsWatcherRecord, kind, path: string,
              fromPath = ""): Value =
  var props = initPropTable()
  props["kind"] = newSym(kind)
  if path.len > 0:
    props["path"] = newStr(path)
  if fromPath.len > 0:
    props["from"] = newStr(fromPath)
  newNode(record.changeType, props = props, immutable = true,
          deepFrozen = true)

proc refreshFsWatcher(record: FsWatcherRecord) =
  let current = record.fsWatchScan()
  var removed: seq[string]
  var created: seq[string]
  var modified: seq[string]
  for path, oldStamp in record.snapshot:
    if not current.hasKey(path):
      removed.add path
    elif not sameFsWatchStamp(oldStamp, current[path]):
      modified.add path
  for path in current.keys:
    if not record.snapshot.hasKey(path):
      created.add path
  removed.sort()
  created.sort()
  modified.sort()

  var changes: seq[Value]
  var usedCreated = initHashSet[string]()
  for oldPath in removed:
    var renamed = ""
    for newPath in created:
      if newPath notin usedCreated and
          sameFsWatchIdentity(record.snapshot[oldPath], current[newPath]):
        renamed = newPath
        break
    if renamed.len > 0:
      usedCreated.incl renamed
      changes.add record.fsChange("renamed", renamed, oldPath)
    else:
      changes.add record.fsChange("removed", oldPath)
  for path in created:
    if path notin usedCreated:
      changes.add record.fsChange("created", path)
  for path in modified:
    changes.add record.fsChange("modified", path)

  record.snapshot = current
  if changes.len > record.capacity:
    record.queue.setLen(0)
    record.queue.add record.fsChange("rescan_required", "")
  else:
    for change in changes:
      record.queue.add change

proc raiseWatcherClosed(scope: Scope) {.noreturn.} =
  let message = "filesystem watcher is closed"
  var props = initPropTable()
  props["message"] = newStr(message)
  var head = newSym("WatcherClosed")
  let typ = builtinBinding(scope, "WatcherClosed")
  if typ.kind == vkType:
    head = typ
  var error: ref GeneError
  new(error)
  error.msg = message
  error.errVal = newNode(head, props = props)
  error.hasErrVal = true
  raise error

proc biFsWatch(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 1:
    raise newException(GeneError, "fs/watch expects one path")
  requireStr("fs/watch path", args[0])
  var recursive = false
  var capacity = 256
  if call != nil:
    for i, name in call[].namedNames:
      let value = call[].namedValues[i]
      case name
      of "recursive":
        if value.kind != vkBool:
          raise newException(GeneError, "fs/watch ^recursive must be Bool")
        recursive = value.boolVal
      of "capacity":
        if value.kind != vkInt or not value.intFitsInt64 or
            value.intVal <= 0 or value.intVal > 65536:
          raise newException(GeneError,
            "fs/watch ^capacity must be an Int from 1 through 65536")
        capacity = int(value.intVal)
      else:
        raise newException(GeneError,
          "fs/watch got unexpected named argument: " & name)
  let scope = if call == nil: nil else: call[].dispatchScope
  try:
    let root = fsRealPath(args[0].strVal)
    let changeType = builtinBinding(scope, "FsChange")
    if changeType.kind != vkType:
      raise newException(GeneError, "FsChange type is unavailable")
    let record = FsWatcherRecord(
      application: scope.application(),
      ownerLane: currentEventLane(),
      root: root,
      recursive: recursive,
      capacity: capacity,
      changeType: changeType)
    record.snapshot = record.fsWatchScan()
    let id = nextRuntimeResourceId()
    acquire(resourceRecordLock)
    try:
      fsWatcherRecords[id] = record
    finally:
      release(resourceRecordLock)
    newRuntimeResourceHandle(scope, "FsWatcher", id)
  except CatchableError as error:
    raiseFilesystemOperationError("fs/watch", error, scope)

proc biFsWatcherRecv(args: openArray[Value],
                            call: ptr NativeCall): Value {.nimcall.} =
  requireOne("FsWatcher/recv", args)
  let scope = if call == nil: nil else: call[].dispatchScope
  let record = fsWatcherRecord("FsWatcher/recv", args[0], call)
  var workerLease: SchedulerWorkerLease
  var workerLeaseOpen = false
  defer:
    if workerLeaseOpen:
      endSchedulerWorkerLease(workerLease)
  while true:
    if record.queue.len > 0:
      result = record.queue[0]
      record.queue.delete(0)
      return
    if record.closed:
      raiseWatcherClosed(scope)
    try:
      record.refreshFsWatcher()
    except CatchableError as error:
      raiseFilesystemOperationError("FsWatcher/recv", error, scope)
    if record.queue.len > 0:
      continue
    let deadline = timerDeadline(25)
    if currentFiberActive:
      var suspended: ref SuspendError
      new(suspended)
      suspended.msg = "FsWatcher/recv waits for a filesystem change"
      suspended.timer = true
      suspended.retry = true
      suspended.resourceId = args[0].nodeResourceId
      suspended.deadline = deadline
      raise suspended
    if not workerLeaseOpen:
      workerLease = beginSchedulerWorkerLease()
      workerLeaseOpen = true
    if not schedulerRunOneRootUntil(deadline, workerLease):
      os.sleep(25)

proc biFsWatcherClose(args: openArray[Value],
                      call: ptr NativeCall): Value {.nimcall.} =
  requireOne("FsWatcher/close", args)
  let record = fsWatcherRecord("FsWatcher/close", args[0], call)
  record.closed = true
  record.snapshot.clear()
  record.application = nil
  record.changeType = NIL
  wakeResourceWaiters(args[0].nodeResourceId)
  NIL

proc biFsReadTextSync(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 1:
    raise newException(GeneError, "fs/read_text expects (path)")
  let scope = if call == nil: nil else: call[].dispatchScope
  requireStr("fs/read_text path", args[0])
  if activeVmFiber != nil:
    if activeVmFiber.nativeTask.kind != vkTask:
      let task = biFsReadTextAsync(args)
      activeVmFiber.nativeTask = task
      scope.registerOwnedTask(task)
    try:
      return finishNativeTask()
    except GeneError as error:
      raiseOsError("fs/read_text: " & error.msg, scope)
  try:
    newStr(fsReadBytes(args[0].strVal))
  except CatchableError as e:
    raiseFilesystemOperationError("fs/read_text", e, scope)

proc biFsReadBytesSync(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  ## The binary sibling of fs/read_text, and the read half `fs/write_bytes` has
  ## been missing (design.md §D7.3). The difference is that the result is Bytes, so a byte with the high bit set
  ## survives instead of being interpreted as UTF-8 and mangled.
  if args.len != 1:
    raise newException(GeneError, "fs/read_bytes expects (path)")
  let scope = if call == nil: nil else: call[].dispatchScope
  requireStr("fs/read_bytes path", args[0])
  if activeVmFiber != nil:
    if activeVmFiber.nativeTask.kind != vkTask:
      let task = biFsReadTextAsync(args)
      activeVmFiber.nativeTask = task
      scope.registerOwnedTask(task)
    return newBytes(finishNativeTask().strVal)
  try:
    newBytes(fsReadBytes(args[0].strVal))
  except CatchableError as e:
    raiseFilesystemOperationError("fs/read_bytes", e, scope)

proc biFsReadTextPage(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("fs/read_text_page", args)
  requireStr("fs/read_text_page path", args[0])
  let scope = if call == nil: nil else: call.dispatchScope
  var first = 1'i64
  var lines = 400'i64
  var maxBytes = 1048576'i64
  if call != nil:
    for index, name in call.namedNames:
      let value = requireInt64("fs/read_text_page ^" & name, call.namedValues[index])
      case name
      of "from": first = value
      of "lines": lines = value
      of "max_bytes": maxBytes = value
      else: raiseOsError("fs/read_text_page got unexpected argument " & name, scope)
  if first < 1 or lines < 1 or lines > 10000 or maxBytes < 1 or
      maxBytes > 16777216 or first > int64(high(int)) - lines:
    raiseOsError("fs/read_text_page needs positive bounded page arguments", scope)
  if activeVmFiber != nil:
    if activeVmFiber.nativeTask.kind != vkTask:
      let task = startNativeFileTask("fs/read_text_page", args[0].strVal, "",
        nfoReadPage, scope, first = int(first), lines = int(lines), maxBytes = int(maxBytes))
      activeVmFiber.nativeTask = task
      scope.registerOwnedTask(task)
    return finishNativeTask()
  try:
    fsTextPageValue(fsReadTextPage(args[0].strVal, int(first), int(lines), int(maxBytes)), int(first))
  except CatchableError as error:
    raiseFilesystemOperationError("fs/read_text_page", error, scope)

proc biFsWriteBytesSync(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  ## The binary sibling of fs/write_text. The only difference is that the payload is Bytes, so a byte
  ## with the high bit set survives instead of being mangled by UTF-8 handling.
  if args.len != 2:
    raise newException(GeneError, "fs/write_bytes expects (path, bytes)")
  let scope = if call == nil: nil else: call[].dispatchScope
  requireStr("fs/write_bytes path", args[0])
  if args[1].kind != vkBytes:
    raise newException(GeneError,
      "fs/write_bytes expects Bytes, got " & $args[1].kind)
  if activeVmFiber != nil:
    if activeVmFiber.nativeTask.kind != vkTask:
      let task = biFsWriteTextAsync([args[0], newStr(args[1].bytesVal)])
      activeVmFiber.nativeTask = task
      scope.registerOwnedTask(task)
    return finishNativeTask()
  try:
    fsWriteBytes(args[0].strVal, args[1].bytesVal)
  except CatchableError as e:
    raiseFilesystemOperationError("fs/write_bytes", e,
                                  scope)
  NIL

proc biFsWriteTextSync(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError, "fs/write_text expects (path, text)")
  let scope = if call == nil: nil else: call[].dispatchScope
  requireStr("fs/write_text path", args[0])
  requireStr("fs/write_text text", args[1])
  if activeVmFiber != nil:
    if activeVmFiber.nativeTask.kind != vkTask:
      let task = biFsWriteTextAsync(args)
      activeVmFiber.nativeTask = task
      scope.registerOwnedTask(task)
    try:
      return finishNativeTask()
    except GeneError as error:
      raiseOsError("fs/write_text: " & error.msg, scope)
  try:
    fsWriteBytes(args[0].strVal, args[1].strVal)
  except CatchableError as e:
    raiseFilesystemOperationError("fs/write_text", e,
                                  scope)
  NIL

proc biFsWriteTextAtomicSync(args: openArray[Value],
                             call: ptr NativeCall): Value {.nimcall.} =
  ## (fs/write_text_atomic path text ^!owner_only). `^^owner_only`
  ## restricts the staged file to its owner before any content is written, so
  ## a secret is never readable by others, even briefly.
  if args.len != 2:
    raise newException(GeneError,
      "fs/write_text_atomic expects (path, text)")
  let scope = if call == nil: nil else: call[].dispatchScope
  requireStr("fs/write_text_atomic path", args[0])
  requireStr("fs/write_text_atomic text", args[1])
  var ownerOnly = false
  if call != nil:
    for i, name in call[].namedNames:
      let value = call[].namedValues[i]
      case name
      of "owner_only":
        if value.kind != vkBool:
          raise newException(GeneError,
            "fs/write_text_atomic ^owner_only expects a Bool")
        ownerOnly = value.boolVal
      else:
        raise newException(GeneError,
          "fs/write_text_atomic got unexpected named argument: " & name)
  when compileOption("threads"):
    if activeVmFiber != nil:
      if activeVmFiber.nativeTask.kind != vkTask:
        let task = startNativeFileTask("fs/write_text_atomic", args[0].strVal,
                                      args[1].strVal, nfoAtomicWrite, scope, ownerOnly)
        activeVmFiber.nativeTask = task
        scope.registerOwnedTask(task)
      return finishNativeTask()
  try:
    fsWriteAtomic(args[0].strVal, args[1].strVal, ownerOnly = ownerOnly)
  except CatchableError as e:
    raiseFilesystemOperationError("fs/write_text_atomic", e, scope)
  NIL

proc biFsWriteBytesAtomicSync(args: openArray[Value],
                              call: ptr NativeCall): Value {.nimcall.} =
  ## The binary sibling of fs/write_text_atomic: stage beside the destination,
  ## synchronize, then rename, so a reader sees the old file or the complete
  ## new one. An immutable artifact store publishes its blobs this way.
  if args.len != 2:
    raise newException(GeneError,
      "fs/write_bytes_atomic expects (path, bytes)")
  let scope = if call == nil: nil else: call[].dispatchScope
  requireStr("fs/write_bytes_atomic path", args[0])
  if args[1].kind != vkBytes:
    raise newException(GeneError,
      "fs/write_bytes_atomic expects Bytes, got " & $args[1].kind)
  when compileOption("threads"):
    if activeVmFiber != nil:
      if activeVmFiber.nativeTask.kind != vkTask:
        let task = startNativeFileTask("fs/write_bytes_atomic", args[0].strVal,
                                      args[1].bytesVal, nfoAtomicWrite, scope, false)
        activeVmFiber.nativeTask = task
        scope.registerOwnedTask(task)
      return finishNativeTask()
  try:
    fsWriteAtomic(args[0].strVal, args[1].bytesVal)
  except CatchableError as e:
    raiseFilesystemOperationError("fs/write_bytes_atomic", e, scope)
  NIL

when defined(posix) and not defined(geneWasm) and not defined(emscripten):
  proc renamePath(source, destination: cstring): cint
    {.importc: "rename", header: "<stdio.h>".}

proc biFsRename(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError, "fs/rename expects source and destination paths")
  requireStr("fs/rename source", args[0])
  requireStr("fs/rename destination", args[1])
  let scope = if call == nil: nil else: call.dispatchScope
  try:
    when defined(posix) and not defined(geneWasm) and not defined(emscripten):
      if renamePath(args[0].strVal.cstring, args[1].strVal.cstring) != 0:
        raiseOSError(osLastError())
    else:
      moveFile(args[0].strVal, args[1].strVal)
  except CatchableError as error:
    raiseFilesystemOperationError("fs/rename", error, scope)
  NIL

proc biFsExists(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 1:
    raise newException(GeneError, "fs/exists? expects (path)")
  let scope = if call == nil: nil else: call[].dispatchScope
  requireStr("fs/exists? path", args[0])
  try:
    newBool(fsPathExists(args[0].strVal))
  except CatchableError as e:
    raiseFilesystemOperationError("fs/exists?", e, scope)

proc biFsInfo(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 1:
    raise newException(GeneError, "fs/info expects (path)")
  requireStr("fs/info path", args[0])
  let scope = if call == nil: nil else: call.dispatchScope
  var follow = true
  if call != nil:
    for index, name in call.namedNames:
      if name != "follow" or call.namedValues[index].kind != vkBool:
        raiseOsError("fs/info accepts only ^follow Bool", scope)
      follow = call.namedValues[index].boolVal
  try:
    let info = getFileInfo(args[0].strVal, followSymlink = follow)
    var fields = initPropTable()
    fields["kind"] = newStr(
      if not follow and symlinkExists(args[0].strVal): "symlink"
      elif info.kind in {pcDir, pcLinkToDir}: "directory" else: "file")
    fields["size"] = newInt(info.size)
    fields["symlink"] = newBool(symlinkExists(args[0].strVal))
    if symlinkExists(args[0].strVal):
      fields["link_target"] = newStr(expandSymlink(args[0].strVal))
    var mode = 0
    when defined(posix) and not defined(geneWasm) and not defined(emscripten):
      var metadata: Stat
      let status = if follow: posix.stat(args[0].strVal.cstring, metadata)
                   else: posix.lstat(args[0].strVal.cstring, metadata)
      if status != 0: raiseOSError(osLastError())
      mode = int(metadata.st_mode) and 0o7777
    else:
      for (permission, bit) in [(fpUserRead, 256), (fpUserWrite, 128), (fpUserExec, 64),
          (fpGroupRead, 32), (fpGroupWrite, 16), (fpGroupExec, 8),
          (fpOthersRead, 4), (fpOthersWrite, 2), (fpOthersExec, 1)]:
        if permission in info.permissions: mode = mode or bit
    fields["mode"] = newInt(mode)
    newMap(fields)
  except CatchableError as error:
    raiseFilesystemOperationError("fs/info", error, scope)

proc biFsSetMode(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2: raise newException(GeneError, "fs/set_mode expects (path, mode)")
  requireStr("fs/set_mode path", args[0])
  let scope = if call == nil: nil else: call.dispatchScope
  let mode = requireInt64("fs/set_mode mode", args[1])
  if mode < 0 or mode > 0o7777: raiseOsError("fs/set_mode mode must be within 0..4095", scope)
  try:
    when defined(posix) and not defined(geneWasm) and not defined(emscripten):
      if posix.chmod(args[0].strVal.cstring, Mode(mode)) != 0: raiseOSError(osLastError())
    else:
      var permissions: set[FilePermission]
      for (permission, bit) in [(fpUserRead, 256), (fpUserWrite, 128), (fpUserExec, 64),
          (fpGroupRead, 32), (fpGroupWrite, 16), (fpGroupExec, 8),
          (fpOthersRead, 4), (fpOthersWrite, 2), (fpOthersExec, 1)]:
        if (mode and bit) != 0: permissions.incl permission
      setFilePermissions(args[0].strVal, permissions)
  except CatchableError as error: raiseFilesystemOperationError("fs/set_mode", error, scope)
  NIL

proc biFsCreateSymlink(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2: raise newException(GeneError, "fs/create_symlink expects (target, path)")
  requireStr("fs/create_symlink target", args[0])
  requireStr("fs/create_symlink path", args[1])
  let scope = if call == nil: nil else: call.dispatchScope
  try: createSymlink(args[0].strVal, args[1].strVal)
  except CatchableError as error: raiseFilesystemOperationError("fs/create_symlink", error, scope)
  NIL

proc biFsListDir(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 1:
    raise newException(GeneError, "fs/list_dir expects (path)")
  let scope = if call == nil: nil else: call[].dispatchScope
  requireStr("fs/list_dir path", args[0])
  try:
    var names: seq[Value]
    for name in fsListDir(args[0].strVal):
      names.add newStr(name)
    newList(names)
  except CatchableError as e:
    raiseFilesystemOperationError("fs/list_dir", e, scope)

proc biFsMakeDir(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 1:
    raise newException(GeneError, "fs/make_dir expects (path)")
  let scope = if call == nil: nil else: call[].dispatchScope
  requireStr("fs/make_dir path", args[0])
  try:
    fsMakeDir(args[0].strVal)
  except CatchableError as e:
    raiseFilesystemOperationError("fs/make_dir", e, scope)
  NIL

proc biFsRemove(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 1:
    raise newException(GeneError, "fs/remove expects (path)")
  let scope = if call == nil: nil else: call[].dispatchScope
  requireStr("fs/remove path", args[0])
  try:
    fsRemoveFile(args[0].strVal)
  except CatchableError as e:
    raiseFilesystemOperationError("fs/remove", e, scope)
  NIL

proc biFsRealPath(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 1:
    raise newException(GeneError, "fs/real_path expects (path)")
  let scope = if call == nil: nil else: call[].dispatchScope
  requireStr("fs/real_path path", args[0])
  try:
    newStr(fsRealPath(args[0].strVal))
  except CatchableError as e:
    raiseFilesystemOperationError("fs/real_path", e, scope)

proc biFsRemoveDir(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 1:
    raise newException(GeneError, "fs/remove_dir expects (path)")
  requireStr("fs/remove_dir path", args[0])
  let scope = if call == nil: nil else: call[].dispatchScope
  try:
    if symlinkExists(args[0].strVal):
      raise newException(IOError, "refusing to remove a directory symlink")
    when not defined(posix):
      if dirExists(args[0].strVal):
        for entry in walkDir(args[0].strVal):
          raise newException(IOError, "directory is not empty")
    fsRemoveDir(args[0].strVal)
  except CatchableError as e:
    raiseFilesystemOperationError("fs/remove_dir", e, scope)
  NIL

# --- json: parse and stringify over Gene value kinds (docs/stdlib.md "Module Layout") ---

const jsonMaxDepth = 200

const jsonKeyCacheSize = 32

type
  JsonKeyCacheEntry = object
    text: string
    id: int32       # key id plus one; 0 marks an empty entry

  JsonParser = object
    input: string
    pos: int
    scope: Scope
    # `^^strict` rejects a repeated object key instead of keeping the last
    # one: a peer's message then means exactly one thing to every parser.
    strict: bool
    maxDepth: int
    # Object keys repeat: an array of records spells the same few names once
    # per element. Remembering each spelling's key id saves a string
    # allocation, a hash, and the intern lock on every later occurrence.
    keyCache: array[jsonKeyCacheSize, JsonKeyCacheEntry]
    lastObjectSize: int

proc raiseJsonError(p: var JsonParser, message: string) =
  var props = initPropTable()
  props["message"] = newStr("json/parse: " & message & " at offset " & $p.pos)
  var e: ref GeneError
  new(e)
  e.msg = "json/parse: " & message
  e.errVal = newNode(builtInTypeHead(p.scope, "JsonError"), props = props)
  e.hasErrVal = true
  raise e

proc raiseJsonValueError(scope: Scope, message: string) =
  var props = initPropTable()
  props["message"] = newStr(message)
  var e: ref GeneError
  new(e)
  e.msg = message
  e.errVal = newNode(builtInTypeHead(scope, "JsonError"), props = props)
  e.hasErrVal = true
  raise e

proc jsonSkipWs(p: var JsonParser) =
  while p.pos < p.input.len and p.input[p.pos] in {' ', '\t', '\n', '\r'}:
    inc p.pos

proc parseJsonValue(p: var JsonParser, depth: int): Value

proc parseJsonString(p: var JsonParser): string =
  inc p.pos                             # opening quote
  # Most strings contain no escape. Find the end of the plain run first and
  # take it in one copy; only an escape, a control character, or the end of
  # input hands the rest to the character loop, which reports those as before.
  let runStart = p.pos
  while p.pos < p.input.len:
    let c = p.input[p.pos]
    if c == '"' or c == '\\' or c < ' ':
      break
    inc p.pos
  if p.pos < p.input.len and p.input[p.pos] == '"':
    result = p.input[runStart ..< p.pos]
    inc p.pos
    return
  var s = p.input[runStart ..< p.pos]
  while true:
    if p.pos >= p.input.len:
      raiseJsonError(p, "unterminated string")
    let c = p.input[p.pos]
    if c == '"':
      inc p.pos
      return s
    elif c == '\\':
      inc p.pos
      if p.pos >= p.input.len:
        raiseJsonError(p, "unterminated escape")
      let e = p.input[p.pos]
      case e
      of '"': s.add '"'
      of '\\': s.add '\\'
      of '/': s.add '/'
      of 'b': s.add '\b'
      of 'f': s.add '\f'
      of 'n': s.add '\n'
      of 'r': s.add '\r'
      of 't': s.add '\t'
      of 'u':
        if p.pos + 4 >= p.input.len:
          raiseJsonError(p, "truncated \\u escape")
        let hex = p.input[p.pos + 1 .. p.pos + 4]
        var code = 0
        try:
          code = fromHex[int](hex)
        except ValueError:
          raiseJsonError(p, "invalid \\u escape")
        s.add toUTF8(Rune(code))
        p.pos += 4
      else:
        raiseJsonError(p, "invalid escape \\" & e)
      inc p.pos
    elif c < ' ':
      raiseJsonError(p, "control character in string")
    else:
      s.add c
      inc p.pos

proc parseJsonKeyId(p: var JsonParser): int32 =
  ## The key id of the object key at `p.pos` (an opening quote), leaving
  ## `p.pos` after its closing quote.
  let keyStart = p.pos + 1
  var keyEnd = keyStart
  while keyEnd < p.input.len:
    let c = p.input[keyEnd]
    if c == '"' or c == '\\' or c < ' ':
      break
    inc keyEnd
  if keyEnd >= p.input.len or p.input[keyEnd] != '"':
    # Escaped, malformed, or unterminated: the general string path.
    return propKeyId(parseJsonString(p))
  let n = keyEnd - keyStart
  var slot = n
  if n > 0:
    slot = n * 31 + ord(p.input[keyStart]) * 7 + ord(p.input[keyEnd - 1])
  slot = slot and (jsonKeyCacheSize - 1)
  p.pos = keyEnd + 1
  if p.keyCache[slot].id != 0 and p.keyCache[slot].text.len == n and
      (n == 0 or equalMem(unsafeAddr p.keyCache[slot].text[0],
                          unsafeAddr p.input[keyStart], n)):
    return p.keyCache[slot].id - 1
  let key = p.input[keyStart ..< keyEnd]
  result = propKeyId(key)
  p.keyCache[slot] = JsonKeyCacheEntry(text: key, id: result + 1)

proc parseJsonNumber(p: var JsonParser): Value =
  let start = p.pos
  block plainInt:
    # An optional sign and at most 18 digits cannot overflow, and such a
    # number is by far the usual one. Anything else — longer, fractional,
    # exponent, or malformed — is parsed from `start` by the general path.
    var i = start
    let negative = i < p.input.len and p.input[i] == '-'
    if negative:
      inc i
    let digitsStart = i
    var magnitude = 0'i64
    while i < p.input.len and p.input[i] in {'0'..'9'} and
        i - digitsStart < 18:
      magnitude = magnitude * 10 + int64(ord(p.input[i]) - ord('0'))
      inc i
    if i == digitsStart:
      break plainInt
    if i < p.input.len and
        p.input[i] in {'0'..'9', '.', 'e', 'E', '+', '-'}:
      break plainInt
    p.pos = i
    return newInt(if negative: -magnitude else: magnitude)
  var isFloat = false
  if p.pos < p.input.len and p.input[p.pos] == '-':
    inc p.pos
  while p.pos < p.input.len:
    let c = p.input[p.pos]
    if c in {'0'..'9'}:
      inc p.pos
    elif c in {'.', 'e', 'E', '+', '-'}:
      isFloat = true
      inc p.pos
    else:
      break
  let text = p.input[start ..< p.pos]
  if isFloat:
    try: newFloat(parseFloat(text))
    except ValueError: (raiseJsonError(p, "invalid number"); NIL)
  else:
    try: newInt(parseBiggestInt(text))
    except ValueError:
      try: newFloat(parseFloat(text))
      except ValueError: (raiseJsonError(p, "invalid number"); NIL)

proc jsonLiteral(p: var JsonParser, word: string, value: Value): Value =
  if p.pos + word.len <= p.input.len and
      p.input[p.pos ..< p.pos + word.len] == word:
    p.pos += word.len
    value
  else:
    raiseJsonError(p, "invalid literal")
    NIL

proc parseJsonValue(p: var JsonParser, depth: int): Value =
  if depth > p.maxDepth:
    raiseJsonError(p, "nesting too deep")
  jsonSkipWs(p)
  if p.pos >= p.input.len:
    raiseJsonError(p, "unexpected end of input")
  let c = p.input[p.pos]
  case c
  of '{':
    inc p.pos
    var entries = initPropTable()
    jsonSkipWs(p)
    if p.pos < p.input.len and p.input[p.pos] == '}':
      inc p.pos
      return newMap(entries)
    # Sibling objects are usually the same shape.
    entries.reserve(p.lastObjectSize)
    while true:
      jsonSkipWs(p)
      if p.pos >= p.input.len or p.input[p.pos] != '"':
        raiseJsonError(p, "expected object key string")
      let keyId = parseJsonKeyId(p)
      jsonSkipWs(p)
      if p.pos >= p.input.len or p.input[p.pos] != ':':
        raiseJsonError(p, "expected ':' after object key")
      inc p.pos
      if p.strict and entries.hasId(keyId):
        raiseJsonError(p, "duplicate object key " & propKeyText(keyId))
      entries.putById(keyId, parseJsonValue(p, depth + 1))
      jsonSkipWs(p)
      if p.pos >= p.input.len:
        raiseJsonError(p, "unterminated object")
      if p.input[p.pos] == ',':
        inc p.pos
      elif p.input[p.pos] == '}':
        inc p.pos
        break
      else:
        raiseJsonError(p, "expected ',' or '}' in object")
    p.lastObjectSize = entries.len
    newMap(entries)
  of '[':
    inc p.pos
    var items: seq[Value]
    jsonSkipWs(p)
    if p.pos < p.input.len and p.input[p.pos] == ']':
      inc p.pos
      return newList(items)
    while true:
      items.add parseJsonValue(p, depth + 1)
      jsonSkipWs(p)
      if p.pos >= p.input.len:
        raiseJsonError(p, "unterminated array")
      if p.input[p.pos] == ',':
        inc p.pos
      elif p.input[p.pos] == ']':
        inc p.pos
        break
      else:
        raiseJsonError(p, "expected ',' or ']' in array")
    newList(items)
  of '"':
    newStr(parseJsonString(p))
  of '-', '0'..'9':
    parseJsonNumber(p)
  of 't':
    jsonLiteral(p, "true", TRUE)
  of 'f':
    jsonLiteral(p, "false", FALSE)
  of 'n':
    jsonLiteral(p, "null", NIL)
  else:
    raiseJsonError(p, "unexpected character '" & c & "'")
    NIL

proc biParseReadAll(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  ## (parse/read_all text ^source "" ^!locs ^max_depth 0
  ##                 ^!reject_duplicate_props)
  ## The reader as a data boundary. Without the last two options this is the
  ## root `read_all`. `^^reject_duplicate_props` refuses a repeated
  ## property, map key, or metadata key, which the reader otherwise resolves
  ## by keeping the last value; `^max_depth` bounds nesting. Both are for text
  ## from an untrusted peer, such as a model response read as domain data.
  requireOne("parse/read_all", args)
  var options = ReadOptions()
  var source = ""
  var located = false
  if call != nil:
    for i, name in call.namedNames:
      let value = call.namedValues[i]
      case name
      of "source":
        requireStr("parse/read_all ^source", value)
        source = value.strVal
      of "locs":
        if value.kind != vkBool:
          raise newException(GeneError, "parse/read_all ^locs expects Bool")
        located = value.boolVal
      of "max_depth":
        let depth = requireInt64("parse/read_all ^max_depth", value)
        if depth < 0 or depth > 100000:
          raise newException(GeneError,
            "parse/read_all ^max_depth must be between 0 and 100000")
        options.maxDepth = int(depth)
      of "reject_duplicate_props":
        if value.kind != vkBool:
          raise newException(GeneError,
            "parse/read_all ^reject_duplicate_props expects Bool")
        options.rejectDuplicateProps = value.boolVal
      else:
        raise newException(GeneError,
          "parse/read_all got unexpected named argument: " & name)
  if options.maxDepth == 0 and not options.rejectDuplicateProps:
    return biReadAll(args, call)
  if located:
    raise newException(GeneError,
      "parse/read_all ^locs is not available with ^max_depth or " &
      "^reject_duplicate_props")
  requireStr("parse/read_all", args[0])
  let scope = if call == nil: nil else: call.dispatchScope
  try:
    return newStream(readAll(args[0].strVal, source, options))
  except ReadError as e:
    raiseReaderError("parse/read_all", e.msg, "ParseError", scope,
                     e.sourceName, e.line, e.col, e.contextFrames)

proc biJsonParse(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  ## (json/parse text ^!strict ^max_depth 200). `^^strict` rejects
  ## duplicate object keys and text that is not valid UTF-8 (RFC 8259 §8.1),
  ## so bytes from a binary WebSocket frame and a text frame meet the same
  ## decoder; `^max_depth` lowers the nesting limit for input from an
  ## untrusted peer.
  requireOne("json/parse", args)
  requireStr("json/parse", args[0])
  let scope = if call == nil: nil else: call[].dispatchScope
  var p = JsonParser(input: args[0].strVal, pos: 0, scope: scope,
                     maxDepth: jsonMaxDepth)
  if call != nil:
    for i, name in call[].namedNames:
      let value = call[].namedValues[i]
      case name
      of "strict":
        if value.kind != vkBool:
          raise newException(GeneError, "json/parse ^strict expects a Bool")
        p.strict = value.boolVal
      of "max_depth":
        let depth = requireInt64("json/parse ^max_depth", value)
        if depth < 1 or depth > jsonMaxDepth:
          raise newException(GeneError,
            "json/parse ^max_depth must be between 1 and " & $jsonMaxDepth)
        p.maxDepth = int(depth)
      else:
        raise newException(GeneError,
          "json/parse got unexpected named argument: " & name)
  if p.strict:
    let bad = unicode.validateUtf8(p.input)
    if bad >= 0:
      p.pos = bad
      raiseJsonError(p, "text is not valid UTF-8")
  result = parseJsonValue(p, 0)
  jsonSkipWs(p)
  if p.pos != p.input.len:
    raiseJsonError(p, "trailing characters after JSON value")

proc jsonEscapeInto(s: string, into: var string) =
  into.add '"'
  # Text that needs no escaping is appended a run at a time rather than a
  # character at a time; each escape flushes the run before it.
  var runStart = 0
  template flushRun(upTo: int) =
    if upTo > runStart:
      let count = upTo - runStart
      let base = into.len
      into.setLen(base + count)
      copyMem(addr into[base], unsafeAddr s[runStart], count)
  for i in 0 ..< s.len:
    let c = s[i]
    if c != '"' and c != '\\' and c >= ' ':
      continue
    flushRun(i)
    runStart = i + 1
    case c
    of '"': into.add "\\\""
    of '\\': into.add "\\\\"
    of '\b': into.add "\\b"
    of '\f': into.add "\\f"
    of '\n': into.add "\\n"
    of '\r': into.add "\\r"
    of '\t': into.add "\\t"
    else:
      into.add "\\u"
      into.add toHex(ord(c), 4).toLowerAscii()
  flushRun(s.len)
  into.add '"'

proc jsonStringifyInto(value: Value, into: var string, scope: Scope,
                       depth: int) =
  if depth > jsonMaxDepth:
    raiseJsonValueError(scope, "json/stringify: nesting too deep")
  case value.kind
  of vkNil, vkVoid: into.add "null"
  of vkBool: into.add (if value.boolVal: "true" else: "false")
  of vkInt: into.addInt value.intVal
  of vkFloat: into.add $value.floatVal
  of vkString: jsonEscapeInto(value.strVal, into)
  of vkSymbol: jsonEscapeInto(value.symVal, into)
  of vkList:
    into.add '['
    var first = true
    for item in value.listItems:
      if not first: into.add ','
      first = false
      jsonStringifyInto(item, into, scope, depth + 1)
    into.add ']'
  of vkMap:
    into.add '{'
    var first = true
    # By key id: the text is read in place instead of copied out per entry.
    for keyId, item in value.mapEntries.idPairs:
      if not first: into.add ','
      first = false
      jsonEscapeInto(propKeyText(keyId), into)
      into.add ':'
      jsonStringifyInto(item, into, scope, depth + 1)
    into.add '}'
  else:
    raiseJsonValueError(scope, "json/stringify: cannot serialize a " &
                        $value.kind)

proc biJsonStringify(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("json/stringify", args)
  let scope = if call == nil: nil else: call[].dispatchScope
  var buffer = ""
  jsonStringifyInto(args[0], buffer, scope, 0)
  newStr(buffer)


# --- log: structured application/runtime diagnostics ------------------------

const LogReservedPayloadKeys = [
  "schema", "time", "level", "logger", "message", "payload", "seq",
  "pid", "thread", "task", "actor", "source"]

proc requireLogger(name: string, value: Value) =
  if value.kind != vkLogger:
    raise newException(GeneError, name & " expects a Logger")

proc requireLogNamed(name: string, call: ptr NativeCall,
                     allowed: openArray[string]) =
  if call == nil: return
  for actual in call[].namedNames:
    if actual notin allowed:
      raise newException(GeneError,
        name & " got unexpected named argument: " & actual)

proc namedLogPayload(call: ptr NativeCall): Value =
  if call == nil: return newMap(immutable = true)
  for i, name in call[].namedNames:
    if name == "payload":
      # NativeCall owns namedValues. Force a retained copy: under ORC, returning
      # an indexed value can otherwise be sink-optimized as though this helper
      # owned the sequence element, leaving the call frame with a dangling box.
      return retainedCopy(call[].namedValues[i])
  newMap(immutable = true)

proc namedLogValue(call: ptr NativeCall, key: string,
                   fallback: Value): Value =
  if call != nil:
    for i, name in call[].namedNames:
      if name == key: return retainedCopy(call[].namedValues[i])
  fallback

proc logLevelFromValue(name: string, value: Value,
                       allowOff = false): LogLevel =
  if value.kind != vkEnumVariant or
      value.enumVariantEnum.typeName != "LogLevel":
    raise newException(GeneError, name & " expects a LogLevel")
  case value.enumVariantName
  of "error": llError
  of "warn": llWarn
  of "info": llInfo
  of "debug": llDebug
  of "trace": llTrace
  of "off":
    if allowOff: llOff
    else: raise newException(GeneError, name & " cannot emit LogLevel/off")
  else:
    raise newException(GeneError, name & " got an unknown LogLevel")

proc normalizeLogValue(value: Value, depth: int, items: var int,
                       active: var HashSet[uint64], maxDepth, maxItems,
                       maxStringBytes: int): tuple[value: Value,
                                                   json: JsonNode]

proc enterLogContainer(value: Value, active: var HashSet[uint64]) =
  if active.contains(value.bits):
    raise newException(GeneError, "log payload contains a cycle")
  active.incl value.bits

proc normalizeLogMap(value: Value, depth: int, items: var int,
                     active: var HashSet[uint64], maxDepth, maxItems,
                     maxStringBytes: int): tuple[value: Value,
                                                 json: JsonNode] =
  if value.kind notin {vkMap, vkHashMap}:
    raise newException(GeneError, "log payload must be a PropMap or HashMap")
  enterLogContainer(value, active)
  defer: active.excl value.bits
  var entries = initPropTable()
  result.json = newJObject()
  template addEntry(key: string, item: Value) =
    if entries.hasKey(key):
      raise newException(GeneError, "duplicate log payload key: " & key)
    if key.toLowerAscii() in LogReservedPayloadKeys:
      raise newException(GeneError, "reserved log payload key: " & key)
    if loggingRedactsKey(key):
      entries[key] = newStr("[redacted]")
      result.json[key] = newJString("[redacted]")
    else:
      let normalized = normalizeLogValue(item, depth + 1, items, active,
        maxDepth, maxItems, maxStringBytes)
      entries[key] = normalized.value
      result.json[key] = normalized.json
  if value.kind == vkMap:
    for key in value.mapEntries.keys:
      addEntry(key, value.mapEntries[key])
  else:
    for entry in value.hashMapEntries:
      let key =
        case entry.key.kind
        of vkString: entry.key.strVal
        of vkSymbol: entry.key.symVal
        else:
          raise newException(GeneError,
            "log payload keys must be strings or symbols")
      addEntry(key, entry.val)
  result.value = newMap(entries, immutable = true)

proc normalizeLogValue(value: Value, depth: int, items: var int,
                       active: var HashSet[uint64], maxDepth, maxItems,
                       maxStringBytes: int): tuple[value: Value,
                                                   json: JsonNode] =
  if depth > maxDepth:
    raise newException(GeneError, "log payload nesting exceeds limit")
  inc items
  if items > maxItems:
    raise newException(GeneError, "log payload item count exceeds limit")
  case value.kind
  of vkNil, vkVoid:
    result = (NIL, newJNull())
  of vkBool:
    result = (value, newJBool(value.boolVal))
  of vkInt:
    result = (value, newJInt(value.intVal))
  of vkFloat:
    let number = value.floatVal
    if number.classify in {fcNan, fcInf, fcNegInf}:
      result = (value, newJString(value.print()))
    else:
      result = (value, newJFloat(number))
  of vkString:
    if value.strVal.len > maxStringBytes:
      raise newException(GeneError, "log payload string exceeds limit")
    result = (value, newJString(value.strVal))
  of vkSymbol:
    if value.symVal.len > maxStringBytes:
      raise newException(GeneError, "log payload symbol exceeds limit")
    result = (value, newJString(value.symVal))
  of vkChar:
    result = (value, newJString($value.charVal))
  of vkBytes, vkRegex, vkRange, vkDate, vkTime, vkDateTime, vkTimezone,
     vkDuration:
    result = (value, newJString(value.print()))
  of vkList:
    enterLogContainer(value, active)
    defer: active.excl value.bits
    var values: seq[Value]
    let json = newJArray()
    for item in value.listItems:
      let normalized = normalizeLogValue(item, depth + 1, items, active,
        maxDepth, maxItems, maxStringBytes)
      values.add normalized.value
      json.add normalized.json
    result = (newList(values, immutable = true), json)
  of vkMap, vkHashMap:
    result = normalizeLogMap(value, depth, items, active,
      maxDepth, maxItems, maxStringBytes)
  of vkSet:
    enterLogContainer(value, active)
    defer: active.excl value.bits
    var values: seq[Value]
    let json = newJArray()
    for item in value.setItems:
      let normalized = normalizeLogValue(item, depth + 1, items, active,
        maxDepth, maxItems, maxStringBytes)
      values.add normalized.value
      json.add normalized.json
    result = (newSet(values), json)
  of vkNode:
    enterLogContainer(value, active)
    defer: active.excl value.bits
    let normalizedHead = normalizeLogValue(value.head, depth + 1, items,
      active, maxDepth, maxItems, maxStringBytes)
    let normalizedProps = normalizeLogMap(newMap(value.props), depth + 1,
      items, active, maxDepth, maxItems, maxStringBytes)
    let normalizedMeta = normalizeLogMap(newMap(value.meta), depth + 1,
      items, active, maxDepth, maxItems, maxStringBytes)
    var body: seq[Value]
    for item in value.body:
      body.add normalizeLogValue(item, depth + 1, items, active,
        maxDepth, maxItems, maxStringBytes).value
    let frozen = newNode(normalizedHead.value,
      props = normalizedProps.value.mapEntries,
      body = body,
      meta = normalizedMeta.value.mapEntries,
      immutable = true)
    result = (frozen, newJString(frozen.print()))
  else:
    raise newException(GeneError,
      "log payload cannot contain " & $value.kind)

proc normalizeLogPayload(value: Value): tuple[value: Value, json: JsonNode] =
  var items = 0
  var active = initHashSet[uint64]()
  var maxDepth, maxItems, maxStringBytes: int
  loggingLimitValues(maxDepth, maxItems, maxStringBytes)
  normalizeLogMap(value, 0, items, active,
    maxDepth, maxItems, maxStringBytes)

proc mergeLogPayload(base, event: Value): Value =
  var entries = initPropTable()
  if base.kind == vkMap:
    for key, value in base.mapEntries: entries[key] = value
  if event.kind == vkMap:
    for key, value in event.mapEntries: entries[key] = value
  newMap(entries, immutable = true)

proc logSource(call: ptr NativeCall): LogSource =
  if call == nil or not call[].loc.hasSourceLoc:
    return LogSource()
  LogSource(module: call[].loc.sourceName, line: call[].loc.line,
            column: call[].loc.col)

proc emitLogger(name: string, logger: Value, level: LogLevel, message: Value,
                payload: Value, call: ptr NativeCall): Value =
  requireLogger(name, logger)
  requireStr(name & " message", message)
  let eventPayload = normalizeLogPayload(payload).value
  let merged = normalizeLogPayload(
    mergeLogPayload(logger.loggerPayload, eventPayload))
  emitLog(logger.loggerRouteId, logger.loggerName, level, message.strVal,
          merged.json, logSource(call))
  NIL

proc biLogNewLogger(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("log/new_logger", args)
  requireLogNamed("log/new_logger", call, ["payload"])
  requireStr("log/new_logger name", args[0])
  let name = args[0].strVal
  if name != "app" and not name.startsWith("app/"):
    raise newException(GeneError,
      "log/new_logger names must be in the app/* namespace")
  if not validLoggerName(name):
    raise newException(GeneError, "log/new_logger invalid name: " & name)
  let normalizedPayload = normalizeLogPayload(namedLogPayload(call))
  let routeId = resolveRouteId(name)
  newLogger(name, routeId, normalizedPayload.value)

proc biLogNewFileLogger(args: openArray[Value],
                        call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError,
      "log/new_file_logger expects (name, path)")
  requireLogNamed("log/new_file_logger", call,
                  ["payload", "format", "flush", "level"])
  requireStr("log/new_file_logger name", args[0])
  requireStr("log/new_file_logger path", args[1])
  let name = args[0].strVal
  if name != "app" and not name.startsWith("app/"):
    raise newException(GeneError,
      "log/new_file_logger names must be in the app/* namespace")
  if not validLoggerName(name):
    raise newException(GeneError, "log/new_file_logger invalid name: " & name)
  let formatValue = namedLogValue(call, "format", newStr("gene"))
  requireStr("log/new_file_logger ^format", formatValue)
  var format: LogFormat
  if not parseLogFormat(formatValue.strVal, format):
    raise newException(GeneError,
      "log/new_file_logger ^format must be gene, text, json, or jsonl")
  let flushValue = namedLogValue(call, "flush", newStr("error"))
  requireStr("log/new_file_logger ^flush", flushValue)
  var flush: LogFlush
  if not parseLogFlush(flushValue.strVal, flush):
    raise newException(GeneError,
      "log/new_file_logger ^flush must be always, error, or close")
  let levelValue = namedLogValue(call, "level", NIL)
  let level =
    if levelValue.kind == vkNil: llTrace
    else: logLevelFromValue("log/new_file_logger ^level", levelValue,
                            allowOff = true)
  let payload = normalizeLogPayload(namedLogPayload(call)).value
  when defined(geneWasm) or defined(emscripten):
    raise newException(GeneError,
      "log/new_file_logger is unavailable in wasm")
  else:
    try:
      let path = absolutePath(args[1].strVal)
      let file = open(path, fmAppend)
      let sink = newFileLogSinkFromHandle("direct:" & name,
        path, file, format, flush)
      newLogger(name, newDirectLogRoute(sink, level), payload)
    except CatchableError as e:
      raise newException(GeneError, "log/new_file_logger: " & e.msg)

proc biLoggerChild(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError, "Logger/child expects (Logger, name)")
  requireLogNamed("Logger/child", call, ["payload"])
  requireLogger("Logger/child", args[0])
  requireStr("Logger/child name", args[1])
  let name = args[0].loggerName & "/" & args[1].strVal
  if not validLoggerName(name):
    raise newException(GeneError, "Logger/child invalid name: " & name)
  let payload = normalizeLogPayload(namedLogPayload(call)).value
  newLogger(name, resolveRouteId(name),
    mergeLogPayload(args[0].loggerPayload, payload))

proc biLoggerWith(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError, "Logger/with expects (Logger, payload)")
  requireLogNamed("Logger/with", call, [])
  requireLogger("Logger/with", args[0])
  let payload = normalizeLogPayload(args[1]).value
  newLogger(args[0].loggerName, args[0].loggerRouteId,
    mergeLogPayload(args[0].loggerPayload, payload))

proc biLoggerEnabled(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError, "Logger/enabled? expects (Logger, LogLevel)")
  requireLogNamed("Logger/enabled?", call, [])
  requireLogger("Logger/enabled?", args[0])
  let level = logLevelFromValue("Logger/enabled?", args[1], allowOff = true)
  newBool(level != llOff and loggerEnabled(args[0].loggerRouteId, level))

proc biLoggerEmit(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 3:
    raise newException(GeneError,
      "Logger/emit expects (Logger, LogLevel, message)")
  requireLogNamed("Logger/emit", call, ["payload"])
  emitLogger("Logger/emit", args[0], logLevelFromValue("Logger/emit", args[1]),
             args[2], namedLogPayload(call), call)

template defineLoggerLevelProc(procName: untyped, publicName: string,
                               logLevel: LogLevel) =
  proc procName(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
    if args.len != 2:
      raise newException(GeneError, publicName & " expects (Logger, message)")
    requireLogNamed(publicName, call, ["payload"])
    emitLogger(publicName, args[0], logLevel, args[1], namedLogPayload(call), call)

defineLoggerLevelProc(biLoggerError, "Logger/error", llError)
defineLoggerLevelProc(biLoggerWarn, "Logger/warn", llWarn)
defineLoggerLevelProc(biLoggerInfo, "Logger/info", llInfo)
defineLoggerLevelProc(biLoggerDebug, "Logger/debug", llDebug)
defineLoggerLevelProc(biLoggerTrace, "Logger/trace", llTrace)


# --- serde: Gene-text serialization, data core -------------------------------
#
# Stage 1 of docs/stdlib.md: write_data / read_data / data?
# over the data bucket, riding the canonical printer/reader. Serialized text is
# a (serde_v1 <payload>) envelope of ordinary Gene source. Control tags are
# underscore-named plain symbols (serde_v1, serde_float, serde_sym, serde_map,
# serde_set, serde_range, serde_timezone, serde_duration, serde_data_node):
# slash tokens read back as (path ...) nodes, so slash-headed tags would not
# survive a print/read cycle. The design doc's serde/* names refer to these.
#
# Round-trip guarantee: (= v (read_data (write_data v))) under structural
# equality for every data-bucket value. Everything that would falsify it is
# either escaped (reserved heads, non-rereadable symbols and map keys, float
# specials) or rejected (cells and other identity/process-bound values).

const serdeReservedPrefix = "serde_"
const serdeDefaultMaxBytes = 10_485_760
const serdeDefaultMaxNodes = 100_000
const serdeDefaultMaxDepth = 1_000
const serdeDefaultMaxSymbols = 10_000

type SerdePolicyLimits = object
  maxBytes: int
  maxNodes: int
  maxDepth: int
  maxSymbols: int
  allowRestore: bool   # serde_hooked serde_restore runs user code; off by default

type SerdeWriter = object
  sb: string
  scope: Scope
  app: Application                  # nil unless allowRefs (origin resolution)
  allowRefs: bool                   # serde/write emits refs; write_data errors
  path: seq[string]
  onPath: HashSet[uint64]           # container identities on the current path
  shareCounts: Table[uint64, int]   # identity-bearing occurrence counts
  shareNames: Table[uint64, string] # generated simple snake_case ref names
  shareEmitted: HashSet[uint64]     # first occurrence already emitted as #Ref
  symCache: Table[string, bool]     # symbol text -> re-reads verbatim
  keyCache: Table[string, bool]     # prop key -> usable as ^key literal

type SerdeReader = object
  scope: Scope
  app: Application                  # nil unless resolveRefs
  resolveRefs: bool                 # serde/read resolves refs; read_data errors
  limits: SerdePolicyLimits
  nodes: int
  symbols: HashSet[string]
  path: seq[string]
  refs: Table[string, Value]        # local #Ref/#Deref serialization unit
  resolvingRefs: HashSet[string]

proc serdePathText(path: seq[string]): string =
  if path.len == 0: "payload" else: path.join("/")

proc raiseSerdeError(scope: Scope, message: string, path: seq[string] = @[]) =
  var full = message
  if path.len > 0:
    full = "at " & serdePathText(path) & ": " & message
  var props = initPropTable()
  props["message"] = newStr(full)
  props["path"] = newStr(serdePathText(path))
  var e: ref GeneError
  new(e)
  e.msg = full
  e.errVal = newNode(builtInTypeHead(scope, "SerdeError"), props = props)
  e.hasErrVal = true
  raise e

proc serdeFastBareName(s: string): bool =
  ## Common identifiers and property keys can be accepted without probing the
  ## reader. Unusual spellings still use the authoritative read-back check.
  if s.len == 0 or s in ["true", "false", "nil", "void"] or
      s.startsWith(serdeReservedPrefix) or s.endsWith("..."):
    return false
  if s[0] notin {'A'..'Z', 'a'..'z', '_'}:
    return false
  for c in s:
    if c notin {'A'..'Z', 'a'..'z', '0'..'9', '_', '-', '?', '!', '*'}:
      return false
  true

proc serdeSymbolRereads(w: var SerdeWriter, s: string): bool =
  ## A symbol is emitted verbatim only when its text reads back as the same
  ## symbol. Probing the real reader is authoritative — no second grammar.
  if s in w.symCache:
    return w.symCache[s]
  if serdeFastBareName(s):
    w.symCache[s] = true
    return true
  var ok = false
  if s.len > 0:
    try:
      let forms = readAll(s)
      ok = forms.len == 1 and forms[0].kind == vkSymbol and
           forms[0].symVal == s
    except CatchableError:
      ok = false
  w.symCache[s] = ok
  ok

proc serdePropKeyUsable(w: var SerdeWriter, k: string): bool =
  ## A prop key is emitted as `^key` only if that text reads back to the same
  ## single-entry map. Otherwise the whole container uses the serde_map escape.
  if k in w.keyCache:
    return w.keyCache[k]
  if serdeFastBareName(k):
    w.keyCache[k] = true
    return true
  var ok = false
  if k.len > 0:
    try:
      let forms = readAll("{^" & k & " 1}")
      if forms.len == 1 and forms[0].kind == vkMap:
        var count = 0
        var hit = false
        for key, val in forms[0].mapEntries:
          inc count
          if key == k and val.kind == vkInt and val.intVal == 1:
            hit = true
        ok = count == 1 and hit
    except CatchableError:
      ok = false
  w.keyCache[k] = ok
  ok

proc serdeEmitStrLit(w: var SerdeWriter, s: string) =
  w.sb.add print(newStr(s))

# --- origin index (stage 3): definition value -> (module, internal path) -----

proc serdeModuleRelPath(app: Application, absPath: string): string =
  ## Package-relative module identity without extension, '/'-separated.
  ## Matches what `resolveApplicationModulePath` accepts as a bare path, so
  ## refs resolve the same on any machine.
  app.applicationPackage.relativeModulePath(absPath)

proc serdeRecordOrigin(app: Application, v: Value, module, path: string) =
  ## First name wins for a given value, so a stable path is chosen across
  ## re-scans and alias bindings. The index keys by value bits and assumes
  ## module definitions stay rooted for the Application lifetime; collectible
  ## modules must invalidate these tables before value bits can be reused.
  if not app.serdeOrigins.hasKey(v.bits):
    app.serdeOrigins[v.bits] = (module: module, path: path)

proc serdeIndexScope(app: Application, scope: Scope, module: string,
                     prefix: string, visited: var HashSet[pointer])

proc serdeIndexBinding(app: Application, name: string, val: Value,
                       module, prefix: string, visited: var HashSet[pointer]) =
  let internal = if prefix.len == 0: name else: prefix & "/" & name
  case val.kind
  of vkType:
    serdeRecordOrigin(app, val, module, internal)
    if val.isEnumType:
      for variant in val.enumVariants:
        serdeRecordOrigin(app, variant, module,
                          internal & "/" & variant.enumVariantName)
  of vkProtocol, vkFunction, vkNativeFn:
    serdeRecordOrigin(app, val, module, internal)
  of vkNamespace:
    serdeRecordOrigin(app, val, module, internal)
    serdeIndexScope(app, val.nsScope, module, internal, visited)
  of vkNode:
    # A module-level typed instance is a candidate for a SerdeRef value ref.
    # Only nodes (heap objects, unique bits) are recorded — scalars would
    # collide with unrelated equal values.
    if val.head.kind == vkType and not app.serdeValueOrigins.hasKey(val.bits):
      app.serdeValueOrigins[val.bits] = (module: module, path: internal)
  else:
    discard

proc serdeIndexScope(app: Application, scope: Scope, module: string,
                     prefix: string, visited: var HashSet[pointer]) =
  if scope == nil:
    return
  let key = cast[pointer](scope)
  if key in visited:
    return
  visited.incl key
  scope.materializeMirroredVars()
  for name, val in scope.vars:
    serdeIndexBinding(app, name, val, module, prefix, visited)
  for i in 0 ..< scope.slots.len:
    if i < scope.slotNames.len and scope.slotDefined(i):
      serdeIndexBinding(app, scope.slotNames[i], scope.slots[i],
                        module, prefix, visited)

proc serdeEnsureOrigins(app: Application) =
  ## Build the reverse index lazily: builtins once, plus any module cached
  ## since the last call. Cheap re-scan (skips already-indexed modules).
  if app == nil:
    return
  var visited = initHashSet[pointer]()
  if not app.serdeOriginBuiltinsDone:
    serdeIndexScope(app, app.builtinsScope(), "", "", visited)
    app.serdeOriginBuiltinsDone = true
  # Keyed by §10 module identity; the Module value still carries the
  # filesystem path a serde ref is written against.
  for identity, modVal in app.moduleCache:
    if identity in app.serdeOriginModules:
      continue
    app.serdeOriginModules.incl identity
    if modVal.kind == vkModule:
      let rootNs = modVal.moduleRootNamespace
      if rootNs.kind == vkNamespace:
        serdeIndexScope(app, rootNs.nsScope,
                        serdeModuleRelPath(app, modVal.modulePath), "",
                        visited)

proc serdeOriginOf(w: var SerdeWriter, v: Value):
    tuple[found: bool, module, path: string] =
  if w.app == nil:
    return (false, "", "")
  serdeEnsureOrigins(w.app)
  if w.app.serdeOrigins.hasKey(v.bits):
    let o = w.app.serdeOrigins[v.bits]
    return (true, o.module, o.path)
  if v.kind == vkFunction and v.fnScope != nil and v.fnName.len > 0:
    # Retaining a weak module binding may produce a new function handle over
    # the same declaration and lexical scope. Its module origin survives that
    # ownership change; anonymous or genuinely captured functions still have
    # no indexed declaration and remain non-serializable.
    var declaration: Value
    if v.fnScope.lookupOptional(v.fnName, declaration) and
        declaration.kind == vkFunction and declaration.fnCode == v.fnCode and
        declaration.fnScope == v.fnScope and
        declaration.fnChecksErrors == v.fnChecksErrors and
        declaration.fnParams == v.fnParams and
        errorRowsEquivalent(declaration.fnErrorTypes, v.fnErrorTypes) and
        w.app.serdeOrigins.hasKey(declaration.bits):
      let origin = w.app.serdeOrigins[declaration.bits]
      return (true, origin.module, origin.path)
  (false, "", "")

proc serdeIdentityBearing(v: Value): bool {.inline.} =
  ## Module refs may explicitly name scalars, but generated serialization refs
  ## are useful only where Gene exposes object identity.
  v.kind in {vkList, vkMap, vkSet, vkHashMap, vkNode}

proc serdeCountSharing(w: var SerdeWriter, v: Value,
                       visited, onPath: var HashSet[uint64]) =
  if not serdeIdentityBearing(v):
    return
  if v.bits in onPath:
    raiseSerdeError(w.scope,
      "cycle detected (cyclic serialization is not supported yet)", w.path)
  w.shareCounts[v.bits] = w.shareCounts.getOrDefault(v.bits) + 1
  if visited.containsOrIncl(v.bits):
    return
  onPath.incl v.bits
  case v.kind
  of vkList:
    for item in v.listItems:
      serdeCountSharing(w, item, visited, onPath)
  of vkMap:
    for _, item in v.mapEntries:
      serdeCountSharing(w, item, visited, onPath)
  of vkSet:
    for item in v.setItems:
      serdeCountSharing(w, item, visited, onPath)
  of vkHashMap:
    for entry in v.hashMapEntries:
      serdeCountSharing(w, entry.key, visited, onPath)
      serdeCountSharing(w, entry.val, visited, onPath)
  of vkNode:
    serdeCountSharing(w, v.head, visited, onPath)
    for _, item in v.props:
      serdeCountSharing(w, item, visited, onPath)
    for item in v.body:
      serdeCountSharing(w, item, visited, onPath)
    for _, item in v.meta:
      serdeCountSharing(w, item, visited, onPath)
  else:
    discard
  onPath.excl v.bits

proc serdePrepareSharing(w: var SerdeWriter, v: Value) =
  var visited = initHashSet[uint64]()
  var onPath = initHashSet[uint64]()
  serdeCountSharing(w, v, visited, onPath)

proc serdeEmitSharedPrefix(w: var SerdeWriter, v: Value): bool =
  ## Returns true when this occurrence was completely emitted as #Deref.
  if not serdeIdentityBearing(v) or w.shareCounts.getOrDefault(v.bits) < 2:
    return false
  var name = w.shareNames.getOrDefault(v.bits)
  if name.len == 0:
    name = "serde_ref_" & $(w.shareNames.len + 1)
    w.shareNames[v.bits] = name
  if w.shareEmitted.containsOrIncl(v.bits):
    w.sb.add "#Deref " & name
    return true
  w.sb.add "#Ref " & name & " "
  false

proc serdeEmit(w: var SerdeWriter, v: Value)
proc pathIsSerializableData(v: Value): bool
proc serdeEmitInst(w: var SerdeWriter, v: Value)

proc serdeEmitRef(w: var SerdeWriter, tag, module, path: string) =
  w.sb.add "(" & tag
  if module.len > 0:
    w.sb.add " ^module "
    serdeEmitStrLit(w, module)
  w.sb.add " ^path "
  serdeEmitStrLit(w, path)
  w.sb.add ')'

proc serdeEmitDefRef(w: var SerdeWriter, v: Value, tag, kindLabel: string) =
  if not w.allowRefs:
    raiseSerdeError(w.scope,
      kindLabel & " values are not data (use serde/write to emit a reference)",
      w.path)
  let o = serdeOriginOf(w, v)
  if not o.found:
    raiseSerdeError(w.scope,
      kindLabel & " has no module origin and cannot be referenced " &
      "(defined at runtime, in a function body, or anonymously)", w.path)
  serdeEmitRef(w, tag, o.module, o.path)

proc serdeEnterContainer(w: var SerdeWriter, v: Value) =
  if v.bits in w.onPath:
    raiseSerdeError(w.scope, "cycle detected", w.path)
  w.onPath.incl v.bits

proc serdeLeaveContainer(w: var SerdeWriter, v: Value) =
  w.onPath.excl v.bits

proc serdeEmitMapBody(w: var SerdeWriter, entries: PropTable) =
  ## Emit `^k v` pairs; caller guarantees every key is usable.
  var first = true
  for k, val in entries:
    if not first: w.sb.add ' '
    first = false
    w.sb.add "^" & k & " "
    w.path.add k
    serdeEmit(w, val)
    discard w.path.pop()

proc serdeMapKeysUsable(w: var SerdeWriter, entries: PropTable): bool =
  for k, _ in entries:
    if not serdePropKeyUsable(w, k):
      return false
  true

proc serdeEmitEscapedMap(w: var SerdeWriter, entries: PropTable,
                         immutable: bool) =
  ## (serde_map <immutable> [k1 v1 k2 v2 ...]) — keys as strings.
  w.sb.add "(serde_map "
  w.sb.add (if immutable: "true" else: "false")
  w.sb.add " ["
  var first = true
  for k, val in entries:
    if not first: w.sb.add ' '
    first = false
    serdeEmitStrLit(w, k)
    w.sb.add ' '
    w.path.add k
    serdeEmit(w, val)
    discard w.path.pop()
  w.sb.add "])"

proc serdeEmitMapValue(w: var SerdeWriter, entries: PropTable,
                       immutable: bool) =
  if serdeMapKeysUsable(w, entries):
    w.sb.add (if immutable: "#{" else: "{")
    serdeEmitMapBody(w, entries)
    w.sb.add '}'
  else:
    serdeEmitEscapedMap(w, entries, immutable)

proc serdeNodeNeedsEscape(w: var SerdeWriter, v: Value): bool =
  if v.head.kind == vkSymbol and
      (v.head.symVal.startsWith(serdeReservedPrefix) or
       v.head.symVal in ["#Ref", "#Deref"]):
    return true
  for k, _ in v.props:
    if not serdePropKeyUsable(w, k):
      return true
  for k, _ in v.meta:
    if not serdePropKeyUsable(w, k):
      return true
  false

proc serdeEmit(w: var SerdeWriter, v: Value) =
  if v.isNil:
    w.sb.add "nil"
    return
  if serdeEmitSharedPrefix(w, v):
    return
  case v.kind
  of vkNil, vkVoid, vkBool, vkInt, vkString, vkBytes, vkChar,
     vkDate, vkTime, vkDateTime, vkRegex:
    w.sb.add print(v)
  of vkFloat:
    let f = v.floatVal
    if f != f:
      w.sb.add "(serde_float \"nan\")"
    elif f == Inf:
      w.sb.add "(serde_float \"+inf\")"
    elif f == NegInf:
      w.sb.add "(serde_float \"-inf\")"
    elif f == 0.0 and 1.0 / f == NegInf:
      w.sb.add "(serde_float \"-0.0\")"
    else:
      w.sb.add print(v)
  of vkSymbol:
    if serdeSymbolRereads(w, v.symVal):
      w.sb.add v.symVal
    else:
      w.sb.add "(serde_sym "
      serdeEmitStrLit(w, v.symVal)
      w.sb.add ')'
  of vkTimezone:
    w.sb.add "(serde_timezone "
    w.sb.add (if v.timezoneHasOffset: "true " else: "false ")
    w.sb.add $v.timezoneOffsetMinutes & " "
    serdeEmitStrLit(w, v.timezoneName)
    w.sb.add ')'
  of vkDuration:
    w.sb.add "(serde_duration " & $v.durationMicroseconds & ")"
  of vkRange:
    w.sb.add "(serde_range " & $v.rangeStart & " " & $v.rangeStop & " " &
             $v.rangeStep & " " &
             (if v.rangeInclusive: "true" else: "false") & ")"
  of vkSet:
    serdeEnterContainer(w, v)
    w.sb.add "(serde_set"
    for i, it in v.setItems:
      w.sb.add ' '
      w.path.add $i
      serdeEmit(w, it)
      discard w.path.pop()
    w.sb.add ')'
    serdeLeaveContainer(w, v)
  of vkList:
    serdeEnterContainer(w, v)
    w.sb.add (if v.listImmutable: "#[" else: "[")
    for i, it in v.listItems:
      if i > 0: w.sb.add ' '
      w.path.add $i
      serdeEmit(w, it)
      discard w.path.pop()
    w.sb.add ']'
    serdeLeaveContainer(w, v)
  of vkMap:
    serdeEnterContainer(w, v)
    serdeEmitMapValue(w, v.mapEntries, v.mapImmutable)
    serdeLeaveContainer(w, v)
  of vkHashMap:
    serdeEnterContainer(w, v)
    w.sb.add "{{"
    var first = true
    for entry in v.hashMapEntries:
      if not first: w.sb.add ' '
      first = false
      w.path.add "key"
      serdeEmit(w, entry.key)
      discard w.path.pop()
      w.sb.add " : "
      w.path.add "val"
      serdeEmit(w, entry.val)
      discard w.path.pop()
    w.sb.add "}}"
    serdeLeaveContainer(w, v)
  of vkNode:
    serdeEnterContainer(w, v)
    if v.isSelector and not pathIsSerializableData(v):
      raiseSerdeError(w.scope,
        "Path contains an executable segment", w.path)
    if v.head.kind == vkType or v.head.kind == vkEnumVariant:
      serdeEmitInst(w, v)
      serdeLeaveContainer(w, v)
      return
    if serdeNodeNeedsEscape(w, v):
      # (serde_data_node <immutable> <head> <props-map> <meta-map> <child>*)
      w.sb.add "(serde_data_node "
      w.sb.add (if v.nodeImmutable: "true " else: "false ")
      w.path.add "head"
      serdeEmit(w, v.head)
      discard w.path.pop()
      w.sb.add ' '
      serdeEmitEscapedMap(w, v.props, false)
      w.sb.add ' '
      serdeEmitEscapedMap(w, v.meta, false)
      for i, it in v.body:
        w.sb.add ' '
        w.path.add $i
        serdeEmit(w, it)
        discard w.path.pop()
      w.sb.add ')'
    else:
      w.sb.add (if v.nodeImmutable: "#(" else: "(")
      w.path.add "head"
      serdeEmit(w, v.head)
      discard w.path.pop()
      if v.meta.len > 0:
        w.sb.add ' '
        var first = true
        for k, val in v.meta:
          if not first: w.sb.add ' '
          first = false
          w.sb.add "@" & k & " "
          w.path.add k
          serdeEmit(w, val)
          discard w.path.pop()
      if v.props.len > 0:
        w.sb.add ' '
        serdeEmitMapBody(w, v.props)
      for i, it in v.body:
        w.sb.add ' '
        w.path.add $i
        serdeEmit(w, it)
        discard w.path.pop()
      w.sb.add ')'
    serdeLeaveContainer(w, v)
  of vkType:
    if v.isEnumType:
      serdeEmitDefRef(w, v, "serde_enum_ref", "enum")
    else:
      serdeEmitDefRef(w, v, "serde_type_ref", "type")
  of vkProtocol:
    serdeEmitDefRef(w, v, "serde_protocol_ref", "protocol")
  of vkEnumVariant:
    serdeEmitDefRef(w, v, "serde_variant_ref", "enum variant")
  of vkNamespace:
    serdeEmitDefRef(w, v, "serde_ns_ref", "namespace")
  of vkNativeFn:
    serdeEmitDefRef(w, v, "serde_fn_ref", "native function")
  of vkFunction:
    if w.allowRefs and serdeOriginOf(w, v).found:
      serdeEmitDefRef(w, v, "serde_fn_ref", "function")
    elif w.allowRefs:
      raiseSerdeError(w.scope,
        "functions with captured scope do not serialize (only module-level " &
        "named functions can be referenced)", w.path)
    else:
      raiseSerdeError(w.scope,
        "functions are not data (use serde/write to reference a module-level " &
        "function)", w.path)
  of vkCell:
    if w.allowRefs:
      # Snapshot only, and OUTSIDE the round-trip equality guarantee: identity
      # and sharing are not preserved (design §7). read_data still rejects it.
      w.sb.add "(serde_snapshot_cell "
      w.path.add "cell"
      serdeEmit(w, cellValue(v))
      discard w.path.pop()
      w.sb.add ')'
    else:
      raiseSerdeError(w.scope,
        "cells are not data (identity equality; serialize the contents via " &
        "Cell/get, or use serde/write for a snapshot)", w.path)
  of vkAtomicCell:
    raiseSerdeError(w.scope,
      "atomic cells do not serialize (shared-memory escape hatch; serialize " &
      "a loaded snapshot instead)", w.path)
  else:
    raiseSerdeError(w.scope,
      $v.kind & " values do not serialize (process-bound)", w.path)

proc serdeTypeIsSerdeRef(scope: Scope, typ: Value): bool =
  if scope == nil or typ.kind != vkType:
    return false
  var proto: Value
  if not scope.lookupOptional("SerdeRef", proto) or proto.kind != vkProtocol:
    return false
  typeImplementsProtocol(scope, typ, proto)

proc serdeEmitInst(w: var SerdeWriter, v: Value) =
  ## A typed instance: (serde_inst <head-ref> <props-serde-map> [body...]).
  ## Read-back uses direct typed-data construction (never ctor), so the head
  ## must be a resolvable type or enum variant.
  ##
  ## A module-level instance of a SerdeRef-marked type serializes by identity
  ## (serde_value_ref); a type with a `serde_state` type-direct message
  ## serializes its state (serde_hooked, ^allow_restore on read); otherwise
  ## fields (design §7).
  if not w.allowRefs:
    raiseSerdeError(w.scope,
      "typed instances are not data (use serde/write)", w.path)
  if v.head.kind == vkType and w.app != nil:
    serdeEnsureOrigins(w.app)
    if w.app.serdeValueOrigins.hasKey(v.bits) and
        serdeTypeIsSerdeRef(w.scope, v.head):
      let o = w.app.serdeValueOrigins[v.bits]
      serdeEmitRef(w, "serde_value_ref", o.module, o.path)
      return
  if v.head.kind == vkType:
    let stateFn = typeDirectMessage(v.head, "serde_state")
    if stateFn.kind != vkNil:
      let state = applyCall(stateFn, [v], NamedArgs(), w.scope)
      w.sb.add "(serde_hooked "
      w.path.add "type"
      serdeEmit(w, v.head)
      discard w.path.pop()
      w.sb.add ' '
      w.path.add "state"
      serdeEmit(w, state)
      discard w.path.pop()
      w.sb.add ')'
      return
  if v.head.isNativeWrapperType:
    # `serde_inst` reads back through direct construction, which a native
    # wrapper rejects (design §16.6) — so emitting one would write a blob that
    # can never be read. Fail where the mistake is, and point at the hook pair
    # above, which reopens the resource as user code instead of reconstructing
    # a handle as data.
    raiseSerdeError(w.scope,
      "cannot serialize " & v.head.typeName &
      ": a native wrapper reopens through serde_state/serde_restore messages, " &
      "not as data", w.path)
  if v.head.kind == vkEnumVariant and v.props.len > 0:
    raiseSerdeError(w.scope,
      "enum-variant value unexpectedly carries props", w.path)
  w.sb.add "(serde_inst "
  w.path.add "type"
  serdeEmit(w, v.head)              # emits serde_type_ref / serde_variant_ref
  discard w.path.pop()
  w.sb.add ' '
  serdeEmitEscapedMap(w, v.props, false)
  w.sb.add " ["
  for i, it in v.body:
    if i > 0: w.sb.add ' '
    w.path.add $i
    serdeEmit(w, it)
    discard w.path.pop()
  w.sb.add "])"

proc serdeDataValueP(v: Value): bool
proc serdeDataValueP(v: Value, onPath: var HashSet[uint64]): bool

proc pathIsSerializableData(v: Value, active: var HashSet[uint64]): bool =
  if not v.isSelector:
    return true
  if active.containsOrIncl(v.bits):
    return false
  defer: active.excl v.bits
  for segment in v.body:
    case segment.kind
    of vkInt, vkSymbol, vkString:
      if segment.kind == vkString and
          (segment.strVal.startsWith(".") or segment.strVal.startsWith("?.")):
        return false
    of vkNode:
      if segment.head.isSymbol("selector_key") and segment.body.len == 1:
        if not serdeDataValueP(segment.body[0], active):
          return false
      elif segment.isSelector:
        if not pathIsSerializableData(segment, active):
          return false
      else:
        # call_stage and arbitrary node stages execute behavior.
        return false
    else:
      # Callable stages execute behavior and retain runtime authority.
      return false
  true

proc pathIsSerializableData(v: Value): bool =
  var active = initHashSet[uint64]()
  pathIsSerializableData(v, active)

proc serdeDataValueP(v: Value, onPath: var HashSet[uint64]): bool =
  if v.isNil:
    return true
  case v.kind
  of vkNil, vkVoid, vkBool, vkInt, vkFloat, vkString, vkBytes, vkChar,
     vkDate, vkTime, vkDateTime, vkRegex, vkSymbol, vkTimezone, vkDuration,
     vkRange:
    true
  of vkList:
    if v.bits in onPath:
      return false
    onPath.incl v.bits
    for it in v.listItems:
      if not serdeDataValueP(it, onPath):
        onPath.excl v.bits
        return false
    onPath.excl v.bits
    true
  of vkMap:
    if v.bits in onPath:
      return false
    onPath.incl v.bits
    for _, val in v.mapEntries:
      if not serdeDataValueP(val, onPath):
        onPath.excl v.bits
        return false
    onPath.excl v.bits
    true
  of vkSet:
    if v.bits in onPath:
      return false
    onPath.incl v.bits
    for it in v.setItems:
      if not serdeDataValueP(it, onPath):
        onPath.excl v.bits
        return false
    onPath.excl v.bits
    true
  of vkHashMap:
    if v.bits in onPath:
      return false
    onPath.incl v.bits
    for entry in v.hashMapEntries:
      if not serdeDataValueP(entry.key, onPath) or
          not serdeDataValueP(entry.val, onPath):
        onPath.excl v.bits
        return false
    onPath.excl v.bits
    true
  of vkNode:
    if v.head.kind in {vkType, vkEnumVariant}:
      return false
    if v.isSelector and not pathIsSerializableData(v, onPath):
      return false
    if v.bits in onPath:
      return false
    onPath.incl v.bits
    if not serdeDataValueP(v.head, onPath):
      onPath.excl v.bits
      return false
    for _, val in v.props:
      if not serdeDataValueP(val, onPath):
        onPath.excl v.bits
        return false
    for _, val in v.meta:
      if not serdeDataValueP(val, onPath):
        onPath.excl v.bits
        return false
    for it in v.body:
      if not serdeDataValueP(it, onPath):
        onPath.excl v.bits
        return false
    onPath.excl v.bits
    true
  else:
    false

proc serdeDataValueP(v: Value): bool =
  var onPath = initHashSet[uint64]()
  serdeDataValueP(v, onPath)

proc serdeWriteDataText(v: Value, scope: Scope): string =
  var w = SerdeWriter(scope: scope)
  serdePrepareSharing(w, v)
  w.sb.add "(serde_v1 "
  serdeEmit(w, v)
  w.sb.add ')'
  w.sb

proc serdeWriteFullText(v: Value, scope: Scope): string =
  var w = SerdeWriter(scope: scope, allowRefs: true,
                      app: application(scope))
  serdePrepareSharing(w, v)
  w.sb.add "(serde_v1 "
  serdeEmit(w, v)
  w.sb.add ')'
  w.sb

proc serdePolicyInt(policy: Value, key: string, fallback: int,
                    scope: Scope): int =
  let entries =
    if policy.kind == vkNode: policy.props
    elif policy.kind == vkMap: policy.mapEntries
    else:
      raiseSerdeError(scope, "^policy expects a SerdePolicy or Map")
      return fallback
  let v = entries.getOrDefault(key, VOID)
  if v.kind == vkVoid:
    return fallback
  if v.kind != vkInt:
    raiseSerdeError(scope, "^policy " & key & " must be an Int")
  int(v.intVal)

proc serdePolicyBool(policy: Value, key: string, fallback: bool,
                     scope: Scope): bool =
  let entries =
    if policy.kind == vkNode: policy.props
    elif policy.kind == vkMap: policy.mapEntries
    else: return fallback
  let v = entries.getOrDefault(key, VOID)
  if v.kind == vkVoid:
    return fallback
  if v.kind != vkBool:
    raiseSerdeError(scope, "^policy " & key & " must be a Bool")
  v.boolVal

proc serdeLimitsFrom(policy: Value, scope: Scope): SerdePolicyLimits =
  result = SerdePolicyLimits(maxBytes: serdeDefaultMaxBytes,
                             maxNodes: serdeDefaultMaxNodes,
                             maxDepth: serdeDefaultMaxDepth,
                             maxSymbols: serdeDefaultMaxSymbols,
                             allowRestore: false)
  if policy.kind == vkNil or policy.kind == vkVoid:
    return
  result.maxBytes = serdePolicyInt(policy, "max_bytes", result.maxBytes, scope)
  result.maxNodes = serdePolicyInt(policy, "max_nodes", result.maxNodes, scope)
  result.maxDepth = serdePolicyInt(policy, "max_depth", result.maxDepth, scope)
  result.maxSymbols = serdePolicyInt(policy, "max_symbols",
                                     result.maxSymbols, scope)
  result.allowRestore = serdePolicyBool(policy, "allow_restore",
                                        result.allowRestore, scope)

proc serdeDecode(r: var SerdeReader, v: Value, depth: int): Value

proc serdeLocalRefName(r: var SerdeReader, v: Value, tag: string,
                       bodyLen: int): string =
  if v.props.len != 0 or v.meta.len != 0 or v.body.len != bodyLen or
      v.body[0].kind != vkSymbol:
    raiseSerdeError(r.scope, tag & " has an invalid reference shape", r.path)
  result = v.body[0].symVal

proc serdeDecodeLocalRef(r: var SerdeReader, v: Value, depth: int): Value =
  let tag = v.head.symVal
  if tag == "#Deref":
    let name = serdeLocalRefName(r, v, tag, 1)
    if r.refs.hasKey(name):
      return r.refs[name]
    if name in r.resolvingRefs:
      raiseSerdeError(r.scope,
        "cyclic #Ref/#Deref payloads are not supported yet", r.path)
    raiseSerdeError(r.scope, "unresolved #Deref: " & name, r.path)
  let name = serdeLocalRefName(r, v, tag, 2)
  if r.refs.hasKey(name) or name in r.resolvingRefs:
    raiseSerdeError(r.scope, "duplicate #Ref: " & name, r.path)
  r.resolvingRefs.incl name
  try:
    result = serdeDecode(r, v.body[1], depth + 1)
    r.refs[name] = result
  finally:
    r.resolvingRefs.excl name

proc serdeCountValue(r: var SerdeReader, depth: int) =
  inc r.nodes
  if r.nodes > r.limits.maxNodes:
    raiseSerdeError(r.scope, "payload exceeds max_nodes (" &
                    $r.limits.maxNodes & ")", r.path)
  if depth > r.limits.maxDepth:
    raiseSerdeError(r.scope, "payload exceeds max_depth (" &
                    $r.limits.maxDepth & ")", r.path)

proc serdeCountSymbol(r: var SerdeReader, s: string) =
  r.symbols.incl s
  if r.symbols.len > r.limits.maxSymbols:
    raiseSerdeError(r.scope, "payload exceeds max_symbols (" &
                    $r.limits.maxSymbols & ")", r.path)

proc serdeBodyLen(r: var SerdeReader, v: Value, tag: string, n: int) =
  if v.body.len != n or v.props.len > 0 or v.meta.len > 0:
    raiseSerdeError(r.scope, tag & " expects exactly " & $n &
                    " children and no props", r.path)

# --- reference resolution (stage 3): (module, path) -> definition value ------

proc serdeRefCoords(r: var SerdeReader, v: Value, tag: string):
    tuple[module, path: string] =
  ## Extract ^module (optional) + ^path (required) from a ref node. Any other
  ## prop — notably the reserved ^package/^version — is an error, so old
  ## readers reject payloads that start using them (design §5).
  if v.body.len > 0 or v.meta.len > 0:
    raiseSerdeError(r.scope, tag & " takes only ^module/^path props", r.path)
  var module = ""
  var path = ""
  var havePath = false
  for k, val in v.props:
    case k
    of "module":
      if val.kind != vkString:
        raiseSerdeError(r.scope, tag & " ^module must be a Str", r.path)
      module = val.strVal
    of "path":
      if val.kind != vkString:
        raiseSerdeError(r.scope, tag & " ^path must be a Str", r.path)
      path = val.strVal
      havePath = true
    else:
      raiseSerdeError(r.scope,
        tag & " has unsupported ref feature ^" & k &
        " (^package/^version are reserved for a later version)", r.path)
  if not havePath or path.len == 0:
    raiseSerdeError(r.scope, tag & " requires a non-empty ^path", r.path)
  (module, path)

proc serdeScopeLookupOwn(scope: Scope, name: string):
    tuple[found: bool, value: Value] =
  ## Look up a name in a scope's OWN bindings only (never parents), so module
  ## resolution cannot leak into builtins and vice versa.
  if scope == nil:
    return (false, NIL)
  # Slots first: on mirrored scopes the vars entry for a slot name may be
  # stale until the next materializeMirroredVars.
  for i in 0 ..< scope.slots.len:
    if i < scope.slotNames.len and scope.slotDefined(i) and
        scope.slotNames[i] == name:
      return (true, scope.slots[i])
  if scope.vars.hasKey(name):
    return (true, scope.vars.getOrDefault(name))
  (false, NIL)

proc serdeResolveModuleScope(r: var SerdeReader, module: string): Scope =
  ## The scope to resolve a ref path against. Builtins for module=="". For a
  ## named module, the module must already be loaded — resolution NEVER loads
  ## it (loading executes top-level code; design §6). Missing -> unresolved.
  if module.len == 0:
    return r.app.builtinsScope()
  var absPath: string
  try:
    absPath = r.app.resolveApplicationModulePath(module)
  except CatchableError as e:
    raiseSerdeError(r.scope, "cannot resolve module '" & module & "': " &
                    e.msg, r.path)
  let identity = r.app.moduleIdentityFor(absPath)
  if not r.app.moduleCache.hasKey(identity):
    raiseSerdeError(r.scope, "module not loaded: " & module &
      " (import it before deserializing references to it)", r.path)
  let modVal = r.app.moduleCache.getOrDefault(identity)
  if modVal.kind != vkModule:
    raiseSerdeError(r.scope, "module '" & module & "' is not a module", r.path)
  let rootNs = modVal.moduleRootNamespace
  if rootNs.kind != vkNamespace:
    raiseSerdeError(r.scope, "module '" & module & "' has no root namespace",
                    r.path)
  rootNs.nsScope

proc serdeLookupRefPath(r: var SerdeReader, startScope: Scope,
                        module, path: string): Value =
  let segs = path.split('/')
  var lookupIn = serdeScopeLookupOwn(startScope, segs[0])
  if not lookupIn.found:
    raiseSerdeError(r.scope, "unresolved reference: '" & path &
      "' in " & (if module.len == 0: "builtins" else: module), r.path)
  var cur = lookupIn.value
  for i in 1 ..< segs.len:
    let seg = segs[i]
    if cur.kind == vkNamespace:
      let nxt = serdeScopeLookupOwn(cur.nsScope, seg)
      if not nxt.found:
        raiseSerdeError(r.scope, "unresolved reference: '" & path & "'", r.path)
      cur = nxt.value
    elif cur.kind == vkType and cur.isEnumType and i == segs.len - 1:
      let variant = enumVariantDescriptor(cur, seg)
      if variant.kind == vkVoid:
        raiseSerdeError(r.scope, "unresolved enum variant: '" & path & "'",
                        r.path)
      cur = variant
    else:
      raiseSerdeError(r.scope, "unresolved reference: '" & path &
        "' (cannot descend into " & $cur.kind & ")", r.path)
  cur

proc serdeResolveRef(r: var SerdeReader, v: Value, tag: string): Value =
  if not r.resolveRefs:
    raiseSerdeError(r.scope,
      tag & " requires serde/read (serde/read_data accepts pure data only)",
      r.path)
  let coords = serdeRefCoords(r, v, tag)
  let startScope = serdeResolveModuleScope(r, coords.module)
  let resolved = serdeLookupRefPath(r, startScope, coords.module, coords.path)
  let ok =
    case tag
    of "serde_type_ref": resolved.kind == vkType and not resolved.isEnumType
    of "serde_enum_ref": resolved.kind == vkType and resolved.isEnumType
    of "serde_protocol_ref": resolved.kind == vkProtocol
    of "serde_variant_ref": resolved.kind == vkEnumVariant
    of "serde_ns_ref": resolved.kind == vkNamespace
    of "serde_fn_ref": resolved.kind in {vkFunction, vkNativeFn}
    else: false
  if not ok:
    raiseSerdeError(r.scope, tag & " resolved to a " & $resolved.kind &
      ", not the expected kind, at '" & coords.path & "'", r.path)
  resolved

proc serdeResolveValueRef(r: var SerdeReader, v: Value): Value =
  ## Resolve a module-level binding by identity — no kind check: it returns the
  ## module's own object (design §7 identity semantics).
  if not r.resolveRefs:
    raiseSerdeError(r.scope,
      "serde_value_ref requires serde/read (serde/read_data accepts pure " &
      "data only)", r.path)
  let coords = serdeRefCoords(r, v, "serde_value_ref")
  let startScope = serdeResolveModuleScope(r, coords.module)
  serdeLookupRefPath(r, startScope, coords.module, coords.path)

proc serdeDecodeControl(r: var SerdeReader, v: Value, tag: string,
                        depth: int): Value =
  case tag
  of "serde_type_ref", "serde_enum_ref", "serde_protocol_ref",
     "serde_variant_ref", "serde_ns_ref", "serde_fn_ref":
    return serdeResolveRef(r, v, tag)
  of "serde_value_ref":
    return serdeResolveValueRef(r, v)
  else: discard
  case tag
  of "serde_float":
    serdeBodyLen(r, v, tag, 1)
    if v.body[0].kind != vkString:
      raiseSerdeError(r.scope, "serde_float expects a Str", r.path)
    case v.body[0].strVal
    of "nan": newFloat(NaN)
    of "+inf": newFloat(Inf)
    of "-inf": newFloat(NegInf)
    of "-0.0": newFloat(-0.0)
    else:
      raiseSerdeError(r.scope, "unknown serde_float value: " &
                      v.body[0].strVal, r.path)
      NIL
  of "serde_sym":
    serdeBodyLen(r, v, tag, 1)
    if v.body[0].kind != vkString:
      raiseSerdeError(r.scope, "serde_sym expects a Str", r.path)
    serdeCountSymbol(r, v.body[0].strVal)
    newSym(v.body[0].strVal)
  of "serde_set":
    if v.props.len > 0 or v.meta.len > 0:
      raiseSerdeError(r.scope, "serde_set expects no props", r.path)
    var items: seq[Value]
    for i, it in v.body:
      r.path.add $i
      let item = serdeDecode(r, it, depth + 1)
      if not isHashStable(item):
        raiseSerdeError(r.scope,
          "serde_set element is not hash-stable", r.path)
      try:
        discard semanticHash(item)
      except GeneError as error:
        raiseSerdeError(r.scope,
          "serde_set element has no usable hash: " & error.msg, r.path)
      for existing in items:
        if semanticEqual(existing, item):
          raiseSerdeError(r.scope,
            "serde_set contains a duplicate element", r.path)
      items.add item
      discard r.path.pop()
    newSet(items)
  of "serde_range":
    serdeBodyLen(r, v, tag, 4)
    for i in 0 .. 2:
      if v.body[i].kind != vkInt:
        raiseSerdeError(r.scope, "serde_range expects Int bounds", r.path)
    if v.body[3].kind != vkBool:
      raiseSerdeError(r.scope, "serde_range expects a Bool inclusive flag",
                      r.path)
    try:
      newRange(v.body[0].intVal, v.body[1].intVal, v.body[2].intVal,
               v.body[3].boolVal)
    except GeneError as e:
      raiseSerdeError(r.scope, "serde_range: " & e.msg, r.path)
      NIL
  of "serde_timezone":
    serdeBodyLen(r, v, tag, 3)
    if v.body[0].kind != vkBool or v.body[1].kind != vkInt or
        v.body[2].kind != vkString:
      raiseSerdeError(r.scope,
        "serde_timezone expects (Bool Int Str)", r.path)
    try:
      newTimezone(v.body[0].boolVal, int(v.body[1].intVal), v.body[2].strVal)
    except GeneError as e:
      raiseSerdeError(r.scope, "serde_timezone: " & e.msg, r.path)
      NIL
  of "serde_duration":
    serdeBodyLen(r, v, tag, 1)
    if v.body[0].kind != vkInt:
      raiseSerdeError(r.scope, "serde_duration expects an Int", r.path)
    newDuration(v.body[0].intVal)
  of "serde_map":
    serdeBodyLen(r, v, tag, 2)
    if v.body[0].kind != vkBool or v.body[1].kind != vkList:
      raiseSerdeError(r.scope,
        "serde_map expects (Bool [k v ...])", r.path)
    let items = v.body[1].listItems
    if items.len mod 2 != 0:
      raiseSerdeError(r.scope, "serde_map expects an even k/v list", r.path)
    var entries = initPropTable()
    var i = 0
    while i < items.len:
      if items[i].kind != vkString:
        raiseSerdeError(r.scope, "serde_map keys must be Str", r.path)
      let key = items[i].strVal
      if entries.hasKey(key):
        raiseSerdeError(r.scope, "serde_map duplicate key: " & key, r.path)
      r.path.add key
      entries[key] = serdeDecode(r, items[i + 1], depth + 1)
      discard r.path.pop()
      inc i, 2
    newMap(entries, immutable = v.body[0].boolVal)
  of "serde_data_node":
    if v.body.len < 4 or v.props.len > 0 or v.meta.len > 0:
      raiseSerdeError(r.scope,
        "serde_data_node expects (Bool head props meta child*)", r.path)
    if v.body[0].kind != vkBool:
      raiseSerdeError(r.scope,
        "serde_data_node expects a Bool immutable flag", r.path)
    r.path.add "head"
    let head = serdeDecode(r, v.body[1], depth + 1)
    discard r.path.pop()
    r.path.add "props"
    let propsVal = serdeDecode(r, v.body[2], depth + 1)
    discard r.path.pop()
    r.path.add "meta"
    let metaVal = serdeDecode(r, v.body[3], depth + 1)
    discard r.path.pop()
    if propsVal.kind != vkMap or metaVal.kind != vkMap:
      raiseSerdeError(r.scope,
        "serde_data_node props/meta must decode to maps", r.path)
    var children: seq[Value]
    for i in 4 ..< v.body.len:
      r.path.add $(i - 4)
      children.add serdeDecode(r, v.body[i], depth + 1)
      discard r.path.pop()
    var props = initPropTable()
    for k, val in propsVal.mapEntries:
      props[k] = val
    var meta = initPropTable()
    for k, val in metaVal.mapEntries:
      meta[k] = val
    if head.isNativeWrapperType:
      # A blob is untrusted input, so it must not be able to stamp a native
      # wrapper's Type onto a decoded node — that is construction wearing a
      # data-node spelling (design §16.6). Typed instances take the
      # `serde_inst` arm, which funnels through the same rejection.
      raiseSerdeError(r.scope,
        "serde cannot construct " & head.typeName &
        ": it is a native wrapper", r.path)
    newNode(head, props = props, body = children, meta = meta,
            immutable = v.body[0].boolVal)
  of "serde_inst":
    if not r.resolveRefs:
      raiseSerdeError(r.scope,
        "serde_inst requires serde/read (serde/read_data accepts pure data " &
        "only)", r.path)
    for k, val in v.props:
      if k == "schema_version":
        if val.kind != vkInt:
          raiseSerdeError(r.scope,
            "serde_inst ^schema_version must be an Int", r.path)
      else:
        raiseSerdeError(r.scope,
          "serde_inst has unsupported prop ^" & k, r.path)
    if v.meta.len > 0:
      raiseSerdeError(r.scope, "serde_inst takes no meta", r.path)
    if v.body.len != 3:
      raiseSerdeError(r.scope,
        "serde_inst expects (head-ref props body)", r.path)
    r.path.add "type"
    let head = serdeDecode(r, v.body[0], depth + 1)
    discard r.path.pop()
    r.path.add "props"
    let propsVal = serdeDecode(r, v.body[1], depth + 1)
    discard r.path.pop()
    r.path.add "body"
    let bodyVal = serdeDecode(r, v.body[2], depth + 1)
    discard r.path.pop()
    if propsVal.kind != vkMap:
      raiseSerdeError(r.scope, "serde_inst props must decode to a map", r.path)
    if bodyVal.kind != vkList:
      raiseSerdeError(r.scope, "serde_inst body must decode to a list", r.path)
    if head.kind == vkType:
      var na: NamedArgs
      for k, val in propsVal.mapEntries:
        na.names.add k
        na.values.add val
      try:
        constructTypedInstance(head, bodyVal.listItems, na)
      except GeneError as e:
        raiseSerdeError(r.scope, "serde_inst construct: " & e.msg, r.path)
        NIL
    elif head.kind == vkEnumVariant:
      if propsVal.mapEntries.len > 0:
        raiseSerdeError(r.scope,
          "enum-variant instance must have no props", r.path)
      try:
        applyCall(head, bodyVal.listItems, NamedArgs())
      except GeneError as e:
        raiseSerdeError(r.scope, "serde_inst variant: " & e.msg, r.path)
        NIL
    else:
      raiseSerdeError(r.scope, "serde_inst head resolved to a " &
        $head.kind & ", not a type or variant", r.path)
      NIL
  of "serde_snapshot_cell":
    if not r.resolveRefs:
      raiseSerdeError(r.scope,
        "serde_snapshot_cell requires serde/read (serde/read_data accepts " &
        "pure data only)", r.path)
    serdeBodyLen(r, v, tag, 1)
    r.path.add "cell"
    let inner = serdeDecode(r, v.body[0], depth + 1)
    discard r.path.pop()
    newCell(inner)
  of "serde_hooked":
    if not r.resolveRefs:
      raiseSerdeError(r.scope,
        "serde_hooked requires serde/read (serde/read_data accepts pure " &
        "data only)", r.path)
    if not r.limits.allowRestore:
      raiseSerdeError(r.scope,
        "serde_hooked requires ^policy (SerdePolicy ^^allow_restore) — " &
        "restore hooks execute user code during deserialization", r.path)
    if v.props.len > 0 or v.meta.len > 0 or v.body.len != 2:
      raiseSerdeError(r.scope, "serde_hooked expects (type-ref state)", r.path)
    r.path.add "type"
    let head = serdeDecode(r, v.body[0], depth + 1)
    discard r.path.pop()
    if head.kind != vkType:
      raiseSerdeError(r.scope, "serde_hooked head must be a type", r.path)
    r.path.add "state"
    let state = serdeDecode(r, v.body[1], depth + 1)
    discard r.path.pop()
    let restoreFn = typeDirectMessage(head, "serde_restore")
    if restoreFn.kind == vkNil:
      raiseSerdeError(r.scope, "type " & head.typeName &
        " has a serde_state message but no serde_restore", r.path)
    try:
      # `self` is implicit in message bodies (design §10), so serde_restore's proto is
      # (self, state). It is a static factory, so pass the type as the implicit
      # self receiver; the body binds `state` from the second argument.
      applyCall(restoreFn, [head, state], NamedArgs(), r.scope)
    except GeneError as e:
      raiseSerdeError(r.scope, "serde_restore: " & e.msg, r.path)
      NIL
  else:
    raiseSerdeError(r.scope, "unknown serde control tag: " & tag, r.path)
    NIL

proc serdeDecode(r: var SerdeReader, v: Value, depth: int): Value =
  serdeCountValue(r, depth)
  case v.kind
  of vkNil, vkVoid, vkBool, vkInt, vkFloat, vkString, vkBytes, vkChar,
     vkDate, vkTime, vkDateTime, vkRegex:
    v
  of vkSymbol:
    serdeCountSymbol(r, v.symVal)
    v
  of vkList:
    var items: seq[Value]
    for i, it in v.listItems:
      r.path.add $i
      items.add serdeDecode(r, it, depth + 1)
      discard r.path.pop()
    newList(items, immutable = v.listImmutable)
  of vkMap:
    var entries = initPropTable()
    for k, val in v.mapEntries:
      r.path.add k
      entries[k] = serdeDecode(r, val, depth + 1)
      discard r.path.pop()
    newMap(entries, immutable = v.mapImmutable)
  of vkHashMap:
    var entries: seq[HashMapEntry]
    for entry in v.hashMapEntries:
      r.path.add "key"
      let k = serdeDecode(r, entry.key, depth + 1)
      discard r.path.pop()
      r.path.add "val"
      let value = serdeDecode(r, entry.val, depth + 1)
      discard r.path.pop()
      entries.add HashMapEntry(key: k, val: value)
    newHashMap(entries)
  of vkNode:
    if v.head.kind == vkSymbol and v.head.symVal in ["#Ref", "#Deref"]:
      return serdeDecodeLocalRef(r, v, depth)
    if v.head.kind == vkSymbol and
        v.head.symVal.startsWith(serdeReservedPrefix):
      return serdeDecodeControl(r, v, v.head.symVal, depth)
    r.path.add "head"
    let head = serdeDecode(r, v.head, depth + 1)
    discard r.path.pop()
    var props = initPropTable()
    for k, val in v.props:
      r.path.add k
      props[k] = serdeDecode(r, val, depth + 1)
      discard r.path.pop()
    var meta = initPropTable()
    for k, val in v.meta:
      r.path.add k
      meta[k] = serdeDecode(r, val, depth + 1)
      discard r.path.pop()
    var children: seq[Value]
    for i, it in v.body:
      r.path.add $i
      children.add serdeDecode(r, it, depth + 1)
      discard r.path.pop()
    newNode(head, props = props, body = children, meta = meta,
            immutable = v.nodeImmutable)
  else:
    raiseSerdeError(r.scope,
      "unsupported value kind in payload: " & $v.kind, r.path)
    NIL

proc biSerdeWriteData(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("serde/write_data", args)
  let scope = if call == nil: nil else: call[].dispatchScope
  newStr(serdeWriteDataText(args[0], scope))

proc biSerdeDataP(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("serde/data?", args)
  if serdeDataValueP(args[0]): TRUE else: FALSE

proc serdeReadEnvelope(name, text: string, scope: Scope, policy: Value,
                       resolveRefs: bool): Value =
  let limits = serdeLimitsFrom(policy, scope)
  if text.len > limits.maxBytes:
    raiseSerdeError(scope, "payload exceeds max_bytes (" &
                    $limits.maxBytes & ")")
  var forms: seq[Value]
  try:
    let readerMaxDepth =
      if limits.maxDepth <= 0: 0 else: limits.maxDepth + 1
    forms = readAll(text, "<serde>", ReadOptions(maxDepth: readerMaxDepth))
  except ReadError as e:
    raiseSerdeError(scope, "parse: " & e.msg)
  if forms.len != 1 or forms[0].kind != vkNode:
    raiseSerdeError(scope, "expected a single (serde_v1 ...) envelope")
  let envelope = forms[0]
  if envelope.head.kind != vkSymbol or envelope.head.symVal != "serde_v1":
    if envelope.head.kind == vkSymbol and
        envelope.head.symVal.startsWith(serdeReservedPrefix):
      raiseSerdeError(scope, "unsupported serde envelope version: " &
                      envelope.head.symVal)
    raiseSerdeError(scope, "expected a (serde_v1 ...) envelope")
  if envelope.body.len != 1 or envelope.props.len > 0 or
      envelope.meta.len > 0:
    raiseSerdeError(scope,
      "serde_v1 envelope expects exactly one payload form")
  var r = SerdeReader(scope: scope, limits: limits,
                      resolveRefs: resolveRefs,
                      app: (if resolveRefs: application(scope) else: nil))
  serdeDecode(r, envelope.body[0], 0)

proc biSerdeReadData(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 1:
    raise newException(GeneError,
      "serde/read_data expects a Str plus optional ^policy")
  requireStr("serde/read_data", args[0])
  let scope = if call == nil: nil else: call[].dispatchScope
  var policy = NIL
  if call != nil:
    for i, name in call[].namedNames:
      case name
      of "policy":
        policy = call[].namedValues[i]
      else:
        raiseSerdeError(scope,
          "serde/read_data got unexpected named argument: " & name)
  serdeReadEnvelope("serde/read_data", args[0].strVal, scope, policy,
                    resolveRefs = false)

proc biSerdeWrite(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("serde/write", args)
  let scope = if call == nil: nil else: call[].dispatchScope
  newStr(serdeWriteFullText(args[0], scope))

proc biSerdeRead(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 1:
    raise newException(GeneError,
      "serde/read expects a Str plus optional ^policy")
  requireStr("serde/read", args[0])
  let scope = if call == nil: nil else: call[].dispatchScope
  var policy = NIL
  if call != nil:
    for i, name in call[].namedNames:
      case name
      of "policy":
        policy = call[].namedValues[i]
      else:
        raiseSerdeError(scope,
          "serde/read got unexpected named argument: " & name)
  serdeReadEnvelope("serde/read", args[0].strVal, scope, policy,
                    resolveRefs = true)


# --- db backends: sqlite and postgres behind the shared Db protocol ---
#
# Both backends load their C client library at runtime through std/dynlib, so
# neither adds a link-time dependency; `open` raises DbError when the library
# is not present. Connections are nodes (`SqliteDb`/`PostgresDb`) whose
# ^handle prop is an owned C pointer wired to the library's close function,
# so dropping a connection eventually releases it and `close`/`closed?` are
# backend-agnostic.

proc raiseDbError(message: string, scope: Scope) =
  var props = initPropTable()
  props["message"] = newStr(message)
  var e: ref GeneError
  new(e)
  e.msg = message
  e.errVal = newNode(builtInTypeHead(scope, "DbError"), props = props)
  e.hasErrVal = true
  raise e

proc dbConnHandleValue(name: string, conn: Value, expectedType: string,
                       scope: Scope): Value =
  # Identity, not name: the one canonical Type for this backend, or a nominal
  # descendant of it — so a look-alike `SqliteDb` declared elsewhere cannot
  # reach a pointer dereference, while a Gene-side subtype of the real one
  # still works.
  if not nativeReceiverIs(scope, conn, expectedType):
    raiseDbError(name & " expects a " & expectedType & " connection", scope)
  let handle = conn.props.getOrDefault("handle", VOID)
  if handle.kind != vkCPtr:
    raiseDbError(name & ": connection has no native handle", scope)
  handle

proc dbConnHandle(name: string, conn: Value, expectedType: string,
                  scope: Scope): pointer =
  let handle = dbConnHandleValue(name, conn, expectedType, scope)
  if handle.cPtrClosed or handle.cPtrIsNull:
    raiseDbError(name & ": connection is closed", scope)
  handle.cPtrAddress

proc dbParamText(name: string, param: Value, scope: Scope): string =
  case param.kind
  of vkString: param.strVal
  of vkInt: $param.intVal
  of vkFloat: $param.floatVal
  of vkBool: (if param.boolVal: "true" else: "false")
  else:
    raiseDbError(name & ": unsupported parameter type " & $param.kind, scope)
    ""

# -- sqlite ------------------------------------------------------------------

when defined(macosx):
  const sqliteLibCandidates = ["libsqlite3.dylib", "/usr/lib/libsqlite3.dylib"]
elif defined(windows):
  const sqliteLibCandidates = ["sqlite3.dll"]
else:
  const sqliteLibCandidates = ["libsqlite3.so.0", "libsqlite3.so"]

const SQLITE_OK = 0
const SQLITE_ROW = 100
const SQLITE_DONE = 101
const SQLITE_ABORT = 4
let SQLITE_TRANSIENT = cast[pointer](-1)

type SqliteRowCallback = proc(context: pointer, columns: cint,
                              values, names: ptr UncheckedArray[cstring]): cint {.cdecl.}
type SqliteCommitCallback = proc(context: pointer): cint {.cdecl.}

type SqliteApi = object
  lib: LibHandle
  closeAddr: pointer      # sqlite3_close_v2, used as the owned-ptr release
  open: proc(filename: cstring, db: ptr pointer): cint {.cdecl.}
  openV2: proc(filename: cstring, db: ptr pointer, flags: cint,
               vfs: cstring): cint {.cdecl.}
  busyTimeout: proc(db: pointer, ms: cint): cint {.cdecl.}
  exec: proc(db: pointer, sql: cstring, callback: SqliteRowCallback,
             context: pointer, message: ptr cstring): cint {.cdecl.}
  errmsg: proc(db: pointer): cstring {.cdecl.}
  prepare: proc(db: pointer, sql: cstring, nBytes: cint, stmt: ptr pointer,
                tail: ptr cstring): cint {.cdecl.}
  step: proc(stmt: pointer): cint {.cdecl.}
  finalize: proc(stmt: pointer): cint {.cdecl.}
  changes: proc(db: pointer): cint {.cdecl.}
  bindParameterCount: proc(stmt: pointer): cint {.cdecl.}
  bindInt64: proc(stmt: pointer, idx: cint, v: int64): cint {.cdecl.}
  bindDouble: proc(stmt: pointer, idx: cint, v: cdouble): cint {.cdecl.}
  bindText: proc(stmt: pointer, idx: cint, s: cstring, n: cint,
                 destructor: pointer): cint {.cdecl.}
  bindBlob: proc(stmt: pointer, idx: cint, data: pointer, n: cint,
                 destructor: pointer): cint {.cdecl.}
  bindNull: proc(stmt: pointer, idx: cint): cint {.cdecl.}
  columnCount: proc(stmt: pointer): cint {.cdecl.}
  columnType: proc(stmt: pointer, i: cint): cint {.cdecl.}
  columnInt64: proc(stmt: pointer, i: cint): int64 {.cdecl.}
  columnDouble: proc(stmt: pointer, i: cint): cdouble {.cdecl.}
  columnText: proc(stmt: pointer, i: cint): cstring {.cdecl.}
  columnBlob: proc(stmt: pointer, i: cint): pointer {.cdecl.}
  columnBytes: proc(stmt: pointer, i: cint): cint {.cdecl.}
  columnName: proc(stmt: pointer, i: cint): cstring {.cdecl.}
  stmtReadonly: proc(stmt: pointer): cint {.cdecl.}
  getAutocommit: proc(db: pointer): cint {.cdecl.}
  commitHook: proc(db: pointer, callback: SqliteCommitCallback,
                   context: pointer): pointer {.cdecl.}
  serialize: proc(db: pointer, schema: cstring, size: ptr int64,
                  flags: cuint): pointer {.cdecl.}
  deserialize: proc(db: pointer, schema: cstring, data: pointer,
                    dbSize, bufferSize: int64, flags: cuint): cint {.cdecl.}
  malloc64: proc(size: uint64): pointer {.cdecl.}
  free: proc(data: pointer) {.cdecl.}

var gSqliteApi: SqliteApi
var activeSqliteVisits {.threadvar.}: seq[pointer]

proc loadSqliteApi(scope: Scope) =
  if gSqliteApi.lib != nil:
    return
  var lib: LibHandle
  for candidate in sqliteLibCandidates:
    lib = loadLib(candidate)
    if lib != nil:
      break
  if lib == nil:
    raiseDbError("sqlite/open: could not load the sqlite3 library", scope)
  template sym(name: string): pointer =
    block:
      let address = symAddr(lib, name)
      if address == nil:
        unloadLib(lib)
        raiseDbError("sqlite/open: missing symbol " & name, scope)
      address
  var api: SqliteApi
  api.open = cast[typeof(api.open)](sym"sqlite3_open")
  api.openV2 = cast[typeof(api.openV2)](sym"sqlite3_open_v2")
  api.busyTimeout = cast[typeof(api.busyTimeout)](sym"sqlite3_busy_timeout")
  api.exec = cast[typeof(api.exec)](sym"sqlite3_exec")
  api.closeAddr = sym"sqlite3_close_v2"
  api.errmsg = cast[typeof(api.errmsg)](sym"sqlite3_errmsg")
  api.prepare = cast[typeof(api.prepare)](sym"sqlite3_prepare_v2")
  api.step = cast[typeof(api.step)](sym"sqlite3_step")
  api.finalize = cast[typeof(api.finalize)](sym"sqlite3_finalize")
  api.changes = cast[typeof(api.changes)](sym"sqlite3_changes")
  api.bindParameterCount =
    cast[typeof(api.bindParameterCount)](sym"sqlite3_bind_parameter_count")
  api.bindInt64 = cast[typeof(api.bindInt64)](sym"sqlite3_bind_int64")
  api.bindDouble = cast[typeof(api.bindDouble)](sym"sqlite3_bind_double")
  api.bindText = cast[typeof(api.bindText)](sym"sqlite3_bind_text")
  api.bindBlob = cast[typeof(api.bindBlob)](sym"sqlite3_bind_blob")
  api.bindNull = cast[typeof(api.bindNull)](sym"sqlite3_bind_null")
  api.columnCount = cast[typeof(api.columnCount)](sym"sqlite3_column_count")
  api.columnType = cast[typeof(api.columnType)](sym"sqlite3_column_type")
  api.columnInt64 = cast[typeof(api.columnInt64)](sym"sqlite3_column_int64")
  api.columnDouble = cast[typeof(api.columnDouble)](sym"sqlite3_column_double")
  api.columnText = cast[typeof(api.columnText)](sym"sqlite3_column_text")
  api.columnBlob = cast[typeof(api.columnBlob)](sym"sqlite3_column_blob")
  api.columnBytes = cast[typeof(api.columnBytes)](sym"sqlite3_column_bytes")
  api.columnName = cast[typeof(api.columnName)](sym"sqlite3_column_name")
  api.stmtReadonly = cast[typeof(api.stmtReadonly)](sym"sqlite3_stmt_readonly")
  api.getAutocommit = cast[typeof(api.getAutocommit)](sym"sqlite3_get_autocommit")
  api.commitHook = cast[typeof(api.commitHook)](sym"sqlite3_commit_hook")
  api.serialize = cast[typeof(api.serialize)](sym"sqlite3_serialize")
  api.deserialize = cast[typeof(api.deserialize)](sym"sqlite3_deserialize")
  api.malloc64 = cast[typeof(api.malloc64)](sym"sqlite3_malloc64")
  api.free = cast[typeof(api.free)](sym"sqlite3_free")
  api.lib = lib
  gSqliteApi = api

proc sqliteHandle(name: string, conn: Value, scope: Scope): pointer =
  result = dbConnHandle(name, conn, "SqliteDb", scope)
  if result in activeSqliteVisits:
    raiseDbError(name & ": connection is active in a native row callback", scope)

proc sqliteError(db: pointer, where: string, scope: Scope) =
  let msg = if db == nil: "unknown sqlite error" else: $gSqliteApi.errmsg(db)
  raiseDbError(where & ": " & msg, scope)

proc sqliteColumnValue(stmt: pointer, i: cint): Value =
  ## SQLite's storage classes: 1 INTEGER, 2 FLOAT, 3 TEXT, 4 BLOB, 5 NULL.
  case gSqliteApi.columnType(stmt, i)
  of 1: newInt(gSqliteApi.columnInt64(stmt, i))
  of 2: newFloat(gSqliteApi.columnDouble(stmt, i))
  of 4:
    # A blob is Bytes, not a string. Reading it through `columnText` — which is
    # what the `else` branch below used to do — stops at the first NUL byte and
    # re-interprets the rest as UTF-8, so any binary payload came back
    # truncated and corrupted rather than raising.
    let n = int(gSqliteApi.columnBytes(stmt, i))
    if n <= 0:
      newBytes("")
    else:
      let data = gSqliteApi.columnBlob(stmt, i)
      if data == nil:
        newBytes("")
      else:
        var buf = newString(n)
        copyMem(addr buf[0], data, n)
        newBytes(buf)
  of 5: NIL
  else:
    let text = gSqliteApi.columnText(stmt, i)
    if text == nil: newStr("") else: newStr($text)

proc sqliteNoteCommit(context: pointer): cint {.cdecl, raises: [].} =
  # An internal, synchronous observer: no Gene code, allocation, or database
  # access runs in SQLite's hook. Publish after the statement finishes. COMMIT and
  # outer RELEASE are reported readonly by sqlite3_stmt_readonly, so that
  # predicate alone cannot establish a persistence boundary.
  cast[ptr bool](context)[] = true
  0

proc sqliteRunStmt(db: pointer, sql: string, params: openArray[Value],
                   where: string, scope: Scope,
                   afterStatement: proc(mutated: bool) = nil):
    tuple[rows: seq[Value], changes: int, mutated: bool] =
  var stmt: pointer
  var tail: cstring
  if gSqliteApi.prepare(db, sql.cstring, cint(sql.len), addr stmt,
                        addr tail) != SQLITE_OK:
    sqliteError(db, where, scope)
  if stmt == nil:
    raiseDbError(where & ": empty SQL statement", scope)
  var committed = false
  var completed = false
  var observing = false
  defer:
    discard gSqliteApi.finalize(stmt)
    if observing: discard gSqliteApi.commitHook(db, nil, nil)
    result.mutated = result.mutated or committed
    # OR FAIL can commit earlier rows even though step raises on a later row.
    # Publish that committed portion before transporting the SQL error.
    if afterStatement != nil and (completed or committed):
      afterStatement(result.mutated)
  result.mutated = gSqliteApi.stmtReadonly(stmt) == 0
  if tail != nil and ($tail).strip().len > 0:
    raiseDbError(where & " runs a single statement; use exec for scripts",
                 scope)
  let expected = int(gSqliteApi.bindParameterCount(stmt))
  if params.len != expected:
    raiseDbError(where & " expects " & $expected & " parameter(s), got " &
                 $params.len, scope)
  for i, param in params:
    let idx = cint(i + 1)
    let rc =
      case param.kind
      of vkNil: gSqliteApi.bindNull(stmt, idx)
      of vkBool: gSqliteApi.bindInt64(stmt, idx, if param.boolVal: 1 else: 0)
      of vkInt: gSqliteApi.bindInt64(stmt, idx, param.intVal)
      of vkFloat: gSqliteApi.bindDouble(stmt, idx, param.floatVal)
      of vkString:
        gSqliteApi.bindText(stmt, idx, param.strVal.cstring,
                            cint(param.strVal.len), SQLITE_TRANSIENT)
      of vkBytes:
        # Bound as a blob rather than text, so a NUL or a high byte survives.
        # `SQLITE_TRANSIENT` because sqlite must copy: the Value may be
        # collected before the statement is stepped.
        if param.bytesVal.len == 0:
          # A NULL data pointer binds SQL NULL and the length is ignored, so an
          # empty blob needs a non-NULL pointer with zero length — otherwise an
          # empty payload reads back as nil rather than as empty Bytes.
          gSqliteApi.bindBlob(stmt, idx, cast[pointer](cstring("")), 0,
                              SQLITE_TRANSIENT)
        else:
          gSqliteApi.bindBlob(stmt, idx, unsafeAddr param.bytesVal[0],
                              cint(param.bytesVal.len), SQLITE_TRANSIENT)
      else:
        raiseDbError(where & ": unsupported parameter type " & $param.kind,
                     scope)
        SQLITE_OK
    if rc != SQLITE_OK:
      sqliteError(db, where, scope)
  discard gSqliteApi.commitHook(db, sqliteNoteCommit, addr committed)
  observing = true
  while true:
    let rc = gSqliteApi.step(stmt)
    if rc == SQLITE_ROW:
      var entries = initPropTable()
      for i in 0 ..< gSqliteApi.columnCount(stmt):
        entries[$gSqliteApi.columnName(stmt, i)] = sqliteColumnValue(stmt, i)
      result.rows.add newMap(entries)
    elif rc == SQLITE_DONE:
      completed = true
      break
    else:
      sqliteError(db, where, scope)
  result.changes = int(gSqliteApi.changes(db))

proc sqliteExecScript(db: pointer, sql: string, where: string,
                      scope: Scope,
                      afterStatement: proc(mutated: bool) = nil): bool =
  ## Run a possibly multi-statement SQL script without parameters.
  var committed = false
  discard gSqliteApi.commitHook(db, sqliteNoteCommit, addr committed)
  defer: discard gSqliteApi.commitHook(db, nil, nil)
  var remaining = sql
  while remaining.strip().len > 0:
    var stmt: pointer
    var tail: cstring
    if gSqliteApi.prepare(db, remaining.cstring, cint(remaining.len),
                          addr stmt, addr tail) != SQLITE_OK:
      sqliteError(db, where, scope)
    let rest = if tail == nil: "" else: $tail
    if stmt != nil:
      let writes = gSqliteApi.stmtReadonly(stmt) == 0
      committed = false
      var completed = false
      try:
        while true:
          let rc = gSqliteApi.step(stmt)
          if rc == SQLITE_ROW:
            continue
          if rc != SQLITE_DONE:
            sqliteError(db, where, scope)
          completed = true
          break
      finally:
        discard gSqliteApi.finalize(stmt)
        let mutated = writes or committed
        result = result or mutated
        # Include OR FAIL's committed prefix on an error path. Never publish
        # uncommitted writes or serialize inside the C commit callback.
        if afterStatement != nil and (completed or committed):
          afterStatement(mutated)
    remaining = rest

proc sqliteFileBacked(conn: Value): bool =
  ## A connection from `sqlite/open_file`: SQLite's own pager and journal make
  ## each commit durable on disk, so there is no image to publish.
  let storage = conn.props.getOrDefault("storage", VOID)
  storage.kind == vkString and storage.strVal == "file"

proc sqlitePersist(conn: Value, db: pointer, call: ptr NativeCall,
                   scope: Scope) =
  let path = conn.props.getOrDefault("path", VOID)
  if path.kind != vkString or path.strVal == ":memory:" or
      sqliteFileBacked(conn):
    return
  var size: int64
  let data = gSqliteApi.serialize(db, "main".cstring, addr size, 0)
  if data == nil or size < 0:
    sqliteError(db, "sqlite persist", scope)
  defer: gSqliteApi.free(data)
  var content = newString(int(size))
  if size > 0:
    copyMem(addr content[0], data, int(size))
  let app = scope.application()
  try:
    fsWriteAtomic(path.strVal, content, ownerOnly = true)
  except CatchableError as error:
    raiseDbError("sqlite persist: " & error.msg, scope)

proc sqlitePersistIfCommitted(conn: Value, db: pointer, mutated: bool,
                              call: ptr NativeCall, scope: Scope) =
  if mutated and gSqliteApi.getAutocommit(db) != 0:
    sqlitePersist(conn, db, call, scope)

proc biSqliteOpen(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("sqlite/open", args)
  requireStr("sqlite/open path", args[0])
  let scope = if call == nil: nil else: call[].dispatchScope
  var databasePath = args[0].strVal
  var initialContent = ""
  if databasePath != ":memory:":
    databasePath = normalizedPath(absolutePath(databasePath))
    let directory = parentDir(databasePath)
    if fsPathExists(databasePath):
      discard fsRealPath(databasePath)
      initialContent = fsReadBytes(databasePath)
  loadSqliteApi(scope)
  var db: pointer
  if gSqliteApi.open(":memory:".cstring, addr db) != SQLITE_OK:
    let msg = if db == nil: "unknown sqlite error" else: $gSqliteApi.errmsg(db)
    if db != nil:
      type CloseProc = proc(p: pointer): cint {.cdecl.}
      discard cast[CloseProc](gSqliteApi.closeAddr)(db)
    raiseDbError("sqlite/open: " & msg, scope)
  if initialContent.len > 0:
    const sqliteDeserializeFreeOnClose = 1'u32
    const sqliteDeserializeResizable = 2'u32
    let buffer = gSqliteApi.malloc64(uint64(initialContent.len))
    if buffer == nil:
      type CloseProc = proc(p: pointer): cint {.cdecl.}
      discard cast[CloseProc](gSqliteApi.closeAddr)(db)
      raiseDbError("sqlite/open: could not allocate the provider-backed image",
                   scope)
    copyMem(buffer, unsafeAddr initialContent[0], initialContent.len)
    let rc = gSqliteApi.deserialize(db, "main".cstring, buffer,
      int64(initialContent.len), int64(initialContent.len),
      sqliteDeserializeFreeOnClose or sqliteDeserializeResizable)
    if rc != SQLITE_OK:
      let msg = $gSqliteApi.errmsg(db)
      type CloseProc = proc(p: pointer): cint {.cdecl.}
      discard cast[CloseProc](gSqliteApi.closeAddr)(db)
      raiseDbError("sqlite/open: " & msg, scope)
  let connection = newNativeWrapper(builtInTypeHead(scope, "SqliteDb"),
    {"handle": newCForeignOwnedPtr(db, gSqliteApi.closeAddr,
                                   targetType = newSym("sqlite3")),
     "backend": newStr("sqlite"),
     "path": newStr(databasePath)})
  connection

const sqliteOpenReadWrite = 0x00000002'i32
const sqliteOpenCreate = 0x00000004'i32

proc sqliteCreateOwnerOnly(path: string) =
  ## Create an empty database file readable only by its owner, before SQLite
  ## writes a byte. SQLite gives its journal and WAL files the database file's
  ## mode, so this also keeps them private. `O_EXCL` means a file that appeared
  ## since the caller looked is left alone rather than truncated.
  when defined(posix) and not defined(emscripten) and not defined(geneWasm):
    let fd = posix.open(path.cstring, O_WRONLY or O_CREAT or O_EXCL,
                        Mode(0o600))
    if fd < 0:
      if osLastError() == OSErrorCode(EEXIST):
        return
      raiseOSError(osLastError())
    discard posix.close(fd)
  else:
    if not fileExists(path):
      var file = open(path, fmWrite)
      file.close()
      setFilePermissions(path, {fpUserRead, fpUserWrite})

proc biSqliteOpenFile(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  ## (sqlite/open_file path ^!create ^busy_timeout_ms 5000) — an
  ## incremental, disk-backed connection. `sqlite/open` loads the file into
  ## memory and republishes the whole image on every commit; this opens the
  ## file itself, so a commit writes only its changed pages through SQLite's
  ## journal (or WAL, if the caller selects it) and nothing is republished.
  ## Durability pragmas are the caller's choice and record.
  requireOne("sqlite/open_file", args)
  requireStr("sqlite/open_file path", args[0])
  let scope = if call == nil: nil else: call[].dispatchScope
  var create = false
  var busyMs = 5000'i64
  if call != nil:
    for i, name in call[].namedNames:
      let value = call[].namedValues[i]
      case name
      of "create":
        if value.kind != vkBool:
          raiseDbError("sqlite/open_file ^create expects a Bool", scope)
        create = value.boolVal
      of "busy_timeout_ms":
        busyMs = requireInt64("sqlite/open_file ^busy_timeout_ms", value)
        if busyMs < 0 or busyMs > int64(high(int32)):
          raiseDbError("sqlite/open_file ^busy_timeout_ms is out of range", scope)
      else:
        raiseDbError("sqlite/open_file got unexpected named argument: " & name,
                     scope)
  let requested = args[0].strVal
  if requested.len == 0 or requested == ":memory:" or
      requested.startsWith("file:"):
    raiseDbError("sqlite/open_file needs a file path; use sqlite/open for " &
                 "an in-memory database", scope)
  let databasePath = normalizedPath(absolutePath(requested))
  let directory = parentDir(databasePath)
  if not dirExists(directory):
    raiseDbError("sqlite/open_file: no directory " & directory, scope)
  if dirExists(databasePath):
    raiseDbError("sqlite/open_file: " & databasePath & " is a directory", scope)
  if not fileExists(databasePath):
    if not create:
      raiseDbError("sqlite/open_file: no database at " & databasePath &
                   " (pass ^^create to make one)", scope)
    try:
      sqliteCreateOwnerOnly(databasePath)
    except CatchableError as error:
      raiseDbError("sqlite/open_file: could not create " & databasePath &
                   ": " & error.msg, scope)
  loadSqliteApi(scope)
  var db: pointer
  let flags = sqliteOpenReadWrite or (if create: sqliteOpenCreate else: 0'i32)
  if gSqliteApi.openV2(databasePath.cstring, addr db, cint(flags), nil) !=
      SQLITE_OK:
    let msg = if db == nil: "unknown sqlite error" else: $gSqliteApi.errmsg(db)
    if db != nil:
      type CloseProc = proc(p: pointer): cint {.cdecl.}
      discard cast[CloseProc](gSqliteApi.closeAddr)(db)
    raiseDbError("sqlite/open_file: " & msg, scope)
  discard gSqliteApi.busyTimeout(db, cint(busyMs))
  newNativeWrapper(builtInTypeHead(scope, "SqliteDb"),
    {"handle": newCForeignOwnedPtr(db, gSqliteApi.closeAddr,
                                   targetType = newSym("sqlite3")),
     "backend": newStr("sqlite"),
     "path": newStr(databasePath),
     "storage": newStr("file")})

proc biSqliteExec(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError, "Db/exec expects (conn, sql), got " & $args.len)
  requireStr("Db/exec sql", args[1])
  let scope = if call == nil: nil else: call[].dispatchScope
  let db = sqliteHandle("Db/exec", args[0], scope)
  let conn = args[0]
  discard sqliteExecScript(db, args[1].strVal, "Db/exec", scope,
    proc(mutated: bool) =
      sqlitePersistIfCommitted(conn, db, mutated, call, scope))
  NIL

type SqliteVisitContext = object
  callback: NativeSyncCallback
  rows: int64
  stopped: bool

proc sqliteVisitCallback(context: pointer, columns: cint,
                         values, names: ptr UncheckedArray[cstring]): cint {.cdecl, raises: [].} =
  # SQLite treats nonzero as abort. No C-owned array/string outlives this
  # invocation: allocate the two Gene Lists only after the owning-lane gate.
  result = 1
  if context == nil: return
  let visit = cast[ptr SqliteVisitContext](context)
  let callback {.cursor.} = visit.callback
  withNativeSyncCallback(callback):
    if columns < 0 or (columns > 0 and (values == nil or names == nil)):
      raise newException(GeneError, "SQLite callback supplied an invalid row")
    var columnNames, row: seq[Value]
    for i in 0 ..< int(columns):
      if names[i] == nil:
        raise newException(GeneError, "SQLite callback supplied an unnamed column")
      columnNames.add newStr($names[i])
      row.add(if values[i] == nil: NIL else: newStr($values[i]))
    inc visit.rows
    let keepGoing = invokeNativeSyncCallback(callback, [newList(columnNames), newList(row)])
    visit.stopped = not keepGoing.boolVal
    if not visit.stopped: result = 0

proc biSqliteVisitTextRows(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  const operation = "sqlite/visit_text_rows"
  if args.len != 3:
    raise newException(GeneError, operation & " expects (conn, sql, callback)")
  requireStr(operation & " sql", args[1])
  let scope = if call == nil: nil else: call[].dispatchScope
  let db = sqliteHandle(operation, args[0], scope)
  let signature = newNode(newSym("Callable"), body = @[
    newList(@[newNode(newSym("List"), body = @[newSym("Str")]),
              newNode(newSym("List"), body = @[
                newNode(newSym("?"), body = @[newSym("Str")])])]),
    newSym("Bool")])
  let callback = newNativeSyncCallback(args[2], scope, signature)
  var visit = SqliteVisitContext(callback: callback)
  var statement: pointer
  var tail: cstring
  var errorMessage: cstring
  let handle = dbConnHandleValue(operation, args[0], "SqliteDb", scope)
  borrowCPtr(handle)
  var active = false
  try:
    if gSqliteApi.prepare(db, args[1].strVal.cstring, cint(args[1].strVal.len),
                          addr statement, addr tail) != SQLITE_OK:
      sqliteError(db, operation, scope)
    if statement == nil:
      raiseDbError(operation & ": expected one read-only query", scope)
    if (tail != nil and ($tail).strip().len > 0) or
        gSqliteApi.stmtReadonly(statement) == 0 or
        gSqliteApi.columnCount(statement) == 0:
      raiseDbError(operation & ": expected one read-only query", scope)
    if gSqliteApi.bindParameterCount(statement) != 0:
      raiseDbError(operation & ": SQL parameters are not supported", scope)
    discard gSqliteApi.finalize(statement)
    statement = nil
    beginNativeCallbackCall(callback)
    activeSqliteVisits.add db
    active = true
    let status = gSqliteApi.exec(db, args[1].strVal.cstring,
      sqliteVisitCallback, addr visit, addr errorMessage)
    # C has returned. Release the connection borrow before transporting a
    # callback failure through the enclosing Gene boundary.
    discard activeSqliteVisits.pop()
    active = false
    finishNativeCallbackCall(callback)
    if status != SQLITE_OK and not (status == SQLITE_ABORT and visit.stopped):
      raiseDbError(operation & ": " &
        (if errorMessage == nil: $gSqliteApi.errmsg(db) else: $errorMessage), scope)
    result = newInt(visit.rows)
  finally:
    if active: discard activeSqliteVisits.pop()
    if statement != nil: discard gSqliteApi.finalize(statement)
    if errorMessage != nil: gSqliteApi.free(errorMessage)
    releaseCPtrBorrow(handle)
    finishNativeCallbackCall(callback)

proc biSqliteQuery(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len < 2:
    raise newException(GeneError, "Db/query expects (conn, sql, params...)")
  requireStr("Db/query sql", args[1])
  let scope = if call == nil: nil else: call[].dispatchScope
  let db = sqliteHandle("Db/query", args[0], scope)
  let conn = args[0]
  let resultSet = sqliteRunStmt(db, args[1].strVal, args[2..^1], "Db/query",
    scope, proc(mutated: bool) =
      sqlitePersistIfCommitted(conn, db, mutated, call, scope))
  newList(resultSet.rows)

proc biSqliteQueryOne(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len < 2:
    raise newException(GeneError, "Db/query_one expects (conn, sql, params...)")
  requireStr("Db/query_one sql", args[1])
  let scope = if call == nil: nil else: call[].dispatchScope
  let db = sqliteHandle("Db/query_one", args[0], scope)
  let conn = args[0]
  let resultSet = sqliteRunStmt(db, args[1].strVal, args[2..^1],
    "Db/query_one", scope, proc(mutated: bool) =
      sqlitePersistIfCommitted(conn, db, mutated, call, scope))
  if resultSet.rows.len == 0: NIL else: resultSet.rows[0]

proc biSqliteExecute(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len < 2:
    raise newException(GeneError, "Db/execute expects (conn, sql, params...)")
  requireStr("Db/execute sql", args[1])
  let scope = if call == nil: nil else: call[].dispatchScope
  let db = sqliteHandle("Db/execute", args[0], scope)
  let conn = args[0]
  let resultSet = sqliteRunStmt(db, args[1].strVal, args[2..^1], "Db/execute",
    scope, proc(mutated: bool) =
      sqlitePersistIfCommitted(conn, db, mutated, call, scope))
  newInt(resultSet.changes)

proc biDbClose(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("Db/close", args)
  let scope = if call == nil: nil else: call[].dispatchScope
  if args[0].kind != vkNode or args[0].head.kind != vkType:
    raiseDbError("Db/close expects a database connection", scope)
  let handle = args[0].props.getOrDefault("handle", VOID)
  if handle.kind != vkCPtr:
    raiseDbError("Db/close: connection has no native handle", scope)
  if nativeReceiverIs(scope, args[0], "SqliteDb") and handle.cPtrAddress in activeSqliteVisits:
    raiseDbError("Db/close: connection is active in a native row callback", scope)
  if nativeReceiverIs(scope, args[0], "SqliteDb") and
      not handle.cPtrClosed and
      args[0].props.getOrDefault("path", VOID).kind == vkString and
      args[0].props["path"].strVal != ":memory:":
    # Successful commits already publish the database image. Serializing here
    # would save an unfinished transaction, or let an older reader overwrite
    # a newer writer's commit.
    discard
  if not handle.cPtrClosed:
    closeCPtr(handle)
  NIL

proc biDbClosed(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("Db/closed?", args)
  let scope = if call == nil: nil else: call[].dispatchScope
  if args[0].kind != vkNode or args[0].head.kind != vkType:
    raiseDbError("Db/closed? expects a database connection", scope)
  let handle = args[0].props.getOrDefault("handle", VOID)
  if handle.kind != vkCPtr:
    raiseDbError("Db/closed?: connection has no native handle", scope)
  if handle.cPtrClosed: TRUE else: FALSE

proc dbRunTransaction(conn, callable: Value, scope: Scope,
                      execFn: proc(conn: Value, sql: string,
                                   scope: Scope)): Value =
  execFn(conn, "BEGIN", scope)
  try:
    var callArgs = [conn]
    result = applyCall(callable, callArgs, NamedArgs(), scope)
  except GeneError, GenePanic:
    try:
      execFn(conn, "ROLLBACK", scope)
    except GeneError:
      discard   # surface the original failure, not the rollback's
    raise
  execFn(conn, "COMMIT", scope)

proc biSqliteTransaction(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError, "Db/transaction expects (conn, fn)")
  let scope = if call == nil: nil else: call[].dispatchScope
  let transactionResult = dbRunTransaction(args[0], args[1], scope,
    proc(conn: Value, sql: string, scope: Scope) =
      discard sqliteExecScript(sqliteHandle("Db/transaction", conn, scope), sql,
                               "Db/transaction", scope))
  let db = sqliteHandle("Db/transaction", args[0], scope)
  sqlitePersist(args[0], db, call, scope)
  transactionResult

# -- postgres ----------------------------------------------------------------

when defined(macosx):
  const pgLibCandidates = ["libpq.dylib", "libpq.5.dylib",
                           "/opt/homebrew/opt/libpq/lib/libpq.5.dylib",
                           "/usr/local/opt/libpq/lib/libpq.5.dylib",
                           "/opt/homebrew/opt/postgresql@17/lib/libpq.5.dylib",
                           "/opt/homebrew/opt/postgresql@16/lib/libpq.5.dylib",
                           "/opt/homebrew/opt/postgresql@15/lib/libpq.5.dylib",
                           "/opt/homebrew/opt/postgresql@14/lib/libpq.5.dylib"]
elif defined(windows):
  const pgLibCandidates = ["libpq.dll"]
else:
  const pgLibCandidates = ["libpq.so.5", "libpq.so"]

const CONNECTION_OK = 0
const PGRES_COMMAND_OK = 1
const PGRES_TUPLES_OK = 2

type PgApi = object
  lib: LibHandle
  finishAddr: pointer     # PQfinish, used as the owned-ptr release
  connectdb: proc(conninfo: cstring): pointer {.cdecl.}
  status: proc(conn: pointer): cint {.cdecl.}
  errorMessage: proc(conn: pointer): cstring {.cdecl.}
  execParams: proc(conn: pointer, command: cstring, nParams: cint,
                   paramTypes: pointer, paramValues: ptr cstring,
                   paramLengths: pointer, paramFormats: pointer,
                   resultFormat: cint): pointer {.cdecl.}
  resultStatus: proc(res: pointer): cint {.cdecl.}
  resultErrorMessage: proc(res: pointer): cstring {.cdecl.}
  ntuples: proc(res: pointer): cint {.cdecl.}
  nfields: proc(res: pointer): cint {.cdecl.}
  fname: proc(res: pointer, i: cint): cstring {.cdecl.}
  ftype: proc(res: pointer, i: cint): cuint {.cdecl.}
  getisnull: proc(res: pointer, r, c: cint): cint {.cdecl.}
  getvalue: proc(res: pointer, r, c: cint): cstring {.cdecl.}
  cmdTuples: proc(res: pointer): cstring {.cdecl.}
  clear: proc(res: pointer) {.cdecl.}

var gPgApi: PgApi

proc loadPgApi(scope: Scope) =
  if gPgApi.lib != nil:
    return
  var lib: LibHandle
  let override = getEnv("GENE_LIBPQ")
  if override.len > 0:
    lib = loadLib(override)
    if lib == nil:
      raiseDbError("postgres/open: could not load GENE_LIBPQ=" & override,
                   scope)
  else:
    for candidate in pgLibCandidates:
      lib = loadLib(candidate)
      if lib != nil:
        break
  if lib == nil:
    raiseDbError("postgres/open: could not load the libpq library; set " &
                 "GENE_LIBPQ to its path", scope)
  template sym(name: string): pointer =
    block:
      let address = symAddr(lib, name)
      if address == nil:
        unloadLib(lib)
        raiseDbError("postgres/open: missing symbol " & name, scope)
      address
  var api: PgApi
  api.connectdb = cast[typeof(api.connectdb)](sym"PQconnectdb")
  api.finishAddr = sym"PQfinish"
  api.status = cast[typeof(api.status)](sym"PQstatus")
  api.errorMessage = cast[typeof(api.errorMessage)](sym"PQerrorMessage")
  api.execParams = cast[typeof(api.execParams)](sym"PQexecParams")
  api.resultStatus = cast[typeof(api.resultStatus)](sym"PQresultStatus")
  api.resultErrorMessage =
    cast[typeof(api.resultErrorMessage)](sym"PQresultErrorMessage")
  api.ntuples = cast[typeof(api.ntuples)](sym"PQntuples")
  api.nfields = cast[typeof(api.nfields)](sym"PQnfields")
  api.fname = cast[typeof(api.fname)](sym"PQfname")
  api.ftype = cast[typeof(api.ftype)](sym"PQftype")
  api.getisnull = cast[typeof(api.getisnull)](sym"PQgetisnull")
  api.getvalue = cast[typeof(api.getvalue)](sym"PQgetvalue")
  api.cmdTuples = cast[typeof(api.cmdTuples)](sym"PQcmdTuples")
  api.clear = cast[typeof(api.clear)](sym"PQclear")
  api.lib = lib
  gPgApi = api

proc pgHandle(name: string, conn: Value, scope: Scope): pointer =
  dbConnHandle(name, conn, "PostgresDb", scope)

proc pgCellValue(res: pointer, row, col: cint): Value =
  if gPgApi.getisnull(res, row, col) != 0:
    return NIL
  let raw = $gPgApi.getvalue(res, row, col)
  case gPgApi.ftype(res, col)
  of 16'u32:                                    # bool
    if raw == "t": TRUE else: FALSE
  of 20'u32, 21'u32, 23'u32, 26'u32:            # int8/int2/int4/oid
    try: newInt(parseBiggestInt(raw))
    except ValueError: newStr(raw)
  of 700'u32, 701'u32, 1700'u32:                # float4/float8/numeric
    try: newFloat(parseFloat(raw))
    except ValueError: newStr(raw)
  else:
    newStr(raw)

proc pgRun(conn: Value, sql: string, params: openArray[Value], where: string,
           scope: Scope): tuple[rows: seq[Value], changes: int] =
  let db = pgHandle(where, conn, scope)
  var backing = newSeq[string](params.len)
  var values = newSeq[cstring](params.len)
  for i, param in params:
    if param.kind == vkNil:
      values[i] = nil
    else:
      backing[i] = dbParamText(where, param, scope)
      values[i] = backing[i].cstring
  let res = gPgApi.execParams(db, sql.cstring, cint(params.len), nil,
                              (if params.len == 0: nil
                               else: addr values[0]),
                              nil, nil, 0)
  if res == nil:
    raiseDbError(where & ": " & $gPgApi.errorMessage(db), scope)
  defer: gPgApi.clear(res)
  case gPgApi.resultStatus(res)
  of PGRES_TUPLES_OK:
    for r in 0 ..< gPgApi.ntuples(res):
      var entries = initPropTable()
      for c in 0 ..< gPgApi.nfields(res):
        entries[$gPgApi.fname(res, c)] = pgCellValue(res, r, c)
      result.rows.add newMap(entries)
  of PGRES_COMMAND_OK:
    let affected = $gPgApi.cmdTuples(res)
    result.changes = if affected.len == 0: 0 else: parseInt(affected)
  else:
    raiseDbError(where & ": " & ($gPgApi.resultErrorMessage(res)).strip(),
                 scope)

proc biPostgresOpen(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("postgres/open", args)
  requireStr("postgres/open conninfo", args[0])
  let scope = if call == nil: nil else: call[].dispatchScope
  loadPgApi(scope)
  let db = gPgApi.connectdb(args[0].strVal.cstring)
  if db == nil:
    raiseDbError("postgres/open: connection allocation failed", scope)
  if gPgApi.status(db) != CONNECTION_OK:
    let msg = ($gPgApi.errorMessage(db)).strip()
    type FinishProc = proc(p: pointer) {.cdecl.}
    cast[FinishProc](gPgApi.finishAddr)(db)
    raiseDbError("postgres/open: " & msg, scope)
  let connection = newNativeWrapper(builtInTypeHead(scope, "PostgresDb"),
    {"handle": newCForeignOwnedPtr(db, gPgApi.finishAddr,
                                   targetType = newSym("PGconn")),
     "backend": newStr("postgres"),
     "conninfo": args[0]})
  connection

proc biPostgresExec(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError, "Db/exec expects (conn, sql), got " & $args.len)
  requireStr("Db/exec sql", args[1])
  let scope = if call == nil: nil else: call[].dispatchScope
  discard pgRun(args[0], args[1].strVal, [], "Db/exec", scope)
  NIL

proc biPostgresQuery(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len < 2:
    raise newException(GeneError, "Db/query expects (conn, sql, params...)")
  requireStr("Db/query sql", args[1])
  let scope = if call == nil: nil else: call[].dispatchScope
  newList(pgRun(args[0], args[1].strVal, args[2..^1], "Db/query", scope).rows)

proc biPostgresQueryOne(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len < 2:
    raise newException(GeneError, "Db/query_one expects (conn, sql, params...)")
  requireStr("Db/query_one sql", args[1])
  let scope = if call == nil: nil else: call[].dispatchScope
  let rows = pgRun(args[0], args[1].strVal, args[2..^1], "Db/query_one",
                   scope).rows
  if rows.len == 0: NIL else: rows[0]

proc biPostgresExecute(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len < 2:
    raise newException(GeneError, "Db/execute expects (conn, sql, params...)")
  requireStr("Db/execute sql", args[1])
  let scope = if call == nil: nil else: call[].dispatchScope
  newInt(pgRun(args[0], args[1].strVal, args[2..^1], "Db/execute",
               scope).changes)

proc biPostgresTransaction(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError, "Db/transaction expects (conn, fn)")
  let scope = if call == nil: nil else: call[].dispatchScope
  dbRunTransaction(args[0], args[1], scope,
    proc(conn: Value, sql: string, scope: Scope) =
      discard pgRun(conn, sql, [], "Db/transaction", scope))

# --- store: durable key -> serde text over sqlite or filesystem --------------

const storeDefaultTable = "store_records"
const storeDefaultKeyColumn = "key"
const storeDefaultDataColumn = "data"
const storeCheckpointSchema = 1
const storeCheckpointRetain = 3

const sha256RoundConstants: array[64, uint32] = [
  0x428a2f98'u32, 0x71374491'u32, 0xb5c0fbcf'u32, 0xe9b5dba5'u32,
  0x3956c25b'u32, 0x59f111f1'u32, 0x923f82a4'u32, 0xab1c5ed5'u32,
  0xd807aa98'u32, 0x12835b01'u32, 0x243185be'u32, 0x550c7dc3'u32,
  0x72be5d74'u32, 0x80deb1fe'u32, 0x9bdc06a7'u32, 0xc19bf174'u32,
  0xe49b69c1'u32, 0xefbe4786'u32, 0x0fc19dc6'u32, 0x240ca1cc'u32,
  0x2de92c6f'u32, 0x4a7484aa'u32, 0x5cb0a9dc'u32, 0x76f988da'u32,
  0x983e5152'u32, 0xa831c66d'u32, 0xb00327c8'u32, 0xbf597fc7'u32,
  0xc6e00bf3'u32, 0xd5a79147'u32, 0x06ca6351'u32, 0x14292967'u32,
  0x27b70a85'u32, 0x2e1b2138'u32, 0x4d2c6dfc'u32, 0x53380d13'u32,
  0x650a7354'u32, 0x766a0abb'u32, 0x81c2c92e'u32, 0x92722c85'u32,
  0xa2bfe8a1'u32, 0xa81a664b'u32, 0xc24b8b70'u32, 0xc76c51a3'u32,
  0xd192e819'u32, 0xd6990624'u32, 0xf40e3585'u32, 0x106aa070'u32,
  0x19a4c116'u32, 0x1e376c08'u32, 0x2748774c'u32, 0x34b0bcb5'u32,
  0x391c0cb3'u32, 0x4ed8aa4a'u32, 0x5b9cca4f'u32, 0x682e6ff3'u32,
  0x748f82ee'u32, 0x78a5636f'u32, 0x84c87814'u32, 0x8cc70208'u32,
  0x90befffa'u32, 0xa4506ceb'u32, 0xbef9a3f7'u32, 0xc67178f2'u32]

proc sha256RotateRight(value: uint32, amount: int): uint32 {.inline.} =
  (value shr amount) or (value shl (32 - amount))

proc sha256Hex(data: string): string =
  ## Small dependency-free SHA-256 used for checkpoint validation and durable
  ## artifact ids. This is off every VM/reader hot path.
  var bytes = newSeq[byte](data.len)
  for i, c in data:
    bytes[i] = byte(ord(c))
  let bitLen = uint64(bytes.len) * 8'u64
  bytes.add 0x80'u8
  while (bytes.len mod 64) != 56:
    bytes.add 0'u8
  for shift in countdown(56, 0, 8):
    bytes.add byte((bitLen shr shift) and 0xff'u64)

  var state = [0x6a09e667'u32, 0xbb67ae85'u32, 0x3c6ef372'u32,
               0xa54ff53a'u32, 0x510e527f'u32, 0x9b05688c'u32,
               0x1f83d9ab'u32, 0x5be0cd19'u32]
  var schedule: array[64, uint32]
  var offset = 0
  while offset < bytes.len:
    for i in 0 ..< 16:
      let j = offset + i * 4
      schedule[i] = (uint32(bytes[j]) shl 24) or
                    (uint32(bytes[j + 1]) shl 16) or
                    (uint32(bytes[j + 2]) shl 8) or uint32(bytes[j + 3])
    for i in 16 ..< 64:
      let s0 = sha256RotateRight(schedule[i - 15], 7) xor
               sha256RotateRight(schedule[i - 15], 18) xor
               (schedule[i - 15] shr 3)
      let s1 = sha256RotateRight(schedule[i - 2], 17) xor
               sha256RotateRight(schedule[i - 2], 19) xor
               (schedule[i - 2] shr 10)
      schedule[i] = schedule[i - 16] + s0 + schedule[i - 7] + s1
    var a = state[0]
    var b = state[1]
    var c = state[2]
    var d = state[3]
    var e = state[4]
    var f = state[5]
    var g = state[6]
    var h = state[7]
    for i in 0 ..< 64:
      let big1 = sha256RotateRight(e, 6) xor sha256RotateRight(e, 11) xor
                 sha256RotateRight(e, 25)
      let choose = (e and f) xor ((not e) and g)
      let temp1 = h + big1 + choose + sha256RoundConstants[i] + schedule[i]
      let big0 = sha256RotateRight(a, 2) xor sha256RotateRight(a, 13) xor
                 sha256RotateRight(a, 22)
      let majority = (a and b) xor (a and c) xor (b and c)
      let temp2 = big0 + majority
      h = g
      g = f
      f = e
      e = d + temp1
      d = c
      c = b
      b = a
      a = temp1 + temp2
    state[0] += a
    state[1] += b
    state[2] += c
    state[3] += d
    state[4] += e
    state[5] += f
    state[6] += g
    state[7] += h
    offset += 64
  result = ""
  for word in state:
    result.add toHex(word, 8).toLowerAscii()

proc biCryptoSha256(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("crypto/sha256", args)
  case args[0].kind
  of vkString: newStr(sha256Hex(args[0].strVal))
  of vkBytes: newStr(sha256Hex(args[0].bytesVal))
  else:
    raise newException(GeneError, "crypto/sha256 expects a Str or Bytes")

proc biCryptoRandomHex(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("crypto/random_hex", args)
  let size = requireInt64("crypto/random_hex", args[0])
  if size < 1 or size > 1024:
    raise newException(GeneError,
      "crypto/random_hex byte count must be between 1 and 1024")
  when not defined(emscripten) and not defined(geneWasm):
    try:
      let bytes = urandom(Natural(size))
      var encoded = newStringOfCap(bytes.len * 2)
      for value in bytes:
        encoded.add toHex(value, 2).toLowerAscii()
      newStr(encoded)
    except OSError as error:
      raise newException(GeneError,
        "crypto/random_hex could not read the operating-system random source: " &
        error.msg)
  else:
    raise newException(GeneError,
      "crypto/random_hex is unavailable on this target")

proc biCryptoSecureEqual(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError,
      "crypto/secure_equal? expects 2 arguments, got " & $args.len)
  requireStr("crypto/secure_equal? left", args[0])
  requireStr("crypto/secure_equal? right", args[1])
  let left = args[0].strVal
  let right = args[1].strVal
  var difference = left.len xor right.len
  for i in 0 ..< max(left.len, right.len):
    let a = if i < left.len: ord(left[i]) else: 0
    let b = if i < right.len: ord(right[i]) else: 0
    difference = difference or (a xor b)
  newBool(difference == 0)

proc storeGenerationName(generation: int64): string =
  align($generation, 20, '0')

proc storeCheckpointKey(generation: int64, name: string): string =
  "checkpoint/" & storeGenerationName(generation) & "/" & name

proc raiseStoreError(scope: Scope, kind, message: string, key = "") =
  var props = initPropTable()
  props["kind"] = newSym(kind)
  props["message"] = newStr(message)
  if key.len > 0:
    props["key"] = newStr(key)
  var e: ref GeneError
  new(e)
  e.msg = message
  e.errVal = newNode(builtInTypeHead(scope, "StoreError"), props = props)
  e.hasErrVal = true
  raise e

proc storeNamed(call: ptr NativeCall): NamedArgs =
  if call == nil:
    NamedArgs()
  else:
    NamedArgs(names: call[].namedNames, values: call[].namedValues)

proc storeNamedOr(named: NamedArgs, name: string, fallback: Value): Value =
  if named.hasArg(name): named.getArg(name) else: fallback

proc storeModeText(scope: Scope, value: Value, fallback = "data"): string =
  if value.kind == vkNil or value.kind == vkVoid:
    return fallback
  case value.kind
  of vkSymbol: result = value.symVal
  of vkString: result = value.strVal
  else:
    raiseStoreError(scope, "invalid_key",
      "store ^mode expects data or full")
  if result != "data" and result != "full":
    raiseStoreError(scope, "invalid_key",
      "store ^mode expects data or full, got " & result)

proc storeModeOf(store: Value, scope: Scope): string =
  storeModeText(scope, store.props.getOrDefault("mode", newSym("data")),
                "data")

proc storePolicyOf(store: Value): Value =
  store.props.getOrDefault("policy", NIL)

proc storeValidateKey(scope: Scope, key: string) =
  if key.len == 0:
    raiseStoreError(scope, "invalid_key", "store key must not be empty", key)

proc storeSqlIdent(scope: Scope, ident, label: string): string =
  if ident.len == 0:
    raiseStoreError(scope, "invalid_key", label & " must not be empty")
  if ident[0] notin {'A'..'Z', 'a'..'z', '_'}:
    raiseStoreError(scope, "invalid_key", "invalid SQL identifier for " & label)
  for c in ident:
    if c notin {'A'..'Z', 'a'..'z', '0'..'9', '_'}:
      raiseStoreError(scope, "invalid_key",
        "invalid SQL identifier for " & label)
  ident

proc storeRequire(scope: Scope, value: Value,
                  call: ptr NativeCall = nil): string =
  if value.kind != vkNode or value.head.kind != vkType:
    raiseStoreError(scope, "closed", "Store operation expects a Store")
  # Backend selection reads the name, but admission is by canonical Type
  # identity: a look-alike `SqliteStore` must not reach the sqlite backend.
  let name =
    if nativeReceiverIs(scope, value, "SqliteStore"): "SqliteStore"
    elif nativeReceiverIs(scope, value, "FsStore"): "FsStore"
    else: ""
  if name.len == 0:
    raiseStoreError(scope, "closed", "Store operation expects a Store")
  let closed = value.props.getOrDefault("closed", NIL)
  if closed.kind == vkCell and closed.cellValue.isTruthy:
    raiseStoreError(scope, "closed", "store is closed")
  name

proc storeClose(store: Value) =
  let closed = store.props.getOrDefault("closed", NIL)
  if closed.kind == vkCell:
    closed.setCellValue(TRUE)

proc storeEncode(scope: Scope, mode: string, value: Value): string =
  try:
    if mode == "full":
      result = serdeWriteFullText(value, scope)
    else:
      result = serdeWriteDataText(value, scope)
  except GeneError as e:
    raiseStoreError(scope, "serde", "store encode: " & e.msg)

proc storeDecode(scope: Scope, mode, text: string, policy: Value,
                 key: string): Value =
  try:
    result = serdeReadEnvelope("store/get", text, scope, policy,
                               resolveRefs = mode == "full")
  except GeneError as e:
    raiseStoreError(scope, "corrupt", "store decode for key '" & key &
      "': " & e.msg, key)

proc storeReadModePolicy(store: Value, call: ptr NativeCall, scope: Scope):
    tuple[mode: string, policy: Value] =
  let named = storeNamed(call)
  result.mode = storeModeOf(store, scope)
  if named.hasArg("mode"):
    result.mode = storeModeText(scope, named.getArg("mode"), result.mode)
  result.policy = storePolicyOf(store)
  if named.hasArg("policy"):
    result.policy = named.getArg("policy")

proc storeWriteMode(store: Value, call: ptr NativeCall, scope: Scope): string =
  result = storeModeOf(store, scope)
  let named = storeNamed(call)
  if named.hasArg("mode"):
    result = storeModeText(scope, named.getArg("mode"), result)
  for name in named.names:
    if name != "mode":
      raiseStoreError(scope, "invalid_key",
        "store/put got unexpected named argument: " & name)

proc storeSqliteDb(store: Value, scope: Scope): pointer =
  let dbVal = store.props.getOrDefault("db", NIL)
  sqliteHandle("Store/sqlite", dbVal, scope)

proc storeSqlitePersist(store: Value, db: pointer, mutated: bool,
                        call: ptr NativeCall, scope: Scope) =
  sqlitePersistIfCommitted(store.props["db"], db, mutated, call, scope)

proc storeSqliteTable(store: Value): tuple[tableName, keyColumn, dataColumn: string] =
  (store.props["table"].strVal,
   store.props["key_column"].strVal,
   store.props["data_column"].strVal)

proc storeSqliteEnsureSchema(db: pointer, tableName, keyColumn,
                             dataColumn: string, scope: Scope): bool =
  sqliteExecScript(db, "create table if not exists " & tableName &
    " (" & keyColumn & " text primary key, " & dataColumn & " text not null)",
    "store/sqlite/open", scope)

proc biStoreSqliteOpen(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("store/sqlite/open", args)
  let scope = if call == nil: nil else: call[].dispatchScope
  discard sqliteHandle("store/sqlite/open", args[0], scope)
  let named = storeNamed(call)
  let tableName = storeSqlIdent(scope,
    (if named.hasArg("table"): (requireStr("store/sqlite/open ^table",
      named.getArg("table")); named.getArg("table").strVal) else: storeDefaultTable),
    "table")
  let keyColumn = storeSqlIdent(scope,
    (if named.hasArg("key_column"): (requireStr("store/sqlite/open ^key_column",
      named.getArg("key_column")); named.getArg("key_column").strVal)
     else: storeDefaultKeyColumn), "key_column")
  let dataColumn = storeSqlIdent(scope,
    (if named.hasArg("data_column"): (requireStr("store/sqlite/open ^data_column",
      named.getArg("data_column")); named.getArg("data_column").strVal)
     else: storeDefaultDataColumn), "data_column")
  let mode = if named.hasArg("mode"):
      storeModeText(scope, named.getArg("mode"))
    else:
      "data"
  let policy = storeNamedOr(named, "policy", NIL)
  for name in named.names:
    if name notin ["table", "key_column", "data_column", "mode", "policy"]:
      raiseStoreError(scope, "invalid_key",
        "store/sqlite/open got unexpected named argument: " & name)
  let db = sqliteHandle("store/sqlite/open", args[0], scope)
  let schemaMutated = storeSqliteEnsureSchema(db, tableName, keyColumn,
                                               dataColumn, scope)
  sqlitePersistIfCommitted(args[0], db, schemaMutated, call, scope)
  newNativeWrapper(builtInTypeHead(scope, "SqliteStore"),
    {"db": args[0],
     "table": newStr(tableName),
     "key_column": newStr(keyColumn),
     "data_column": newStr(dataColumn),
     "mode": newSym(mode),
     "policy": policy,
     "closed": newCell(FALSE)})

proc biStorePut(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 3:
    raise newException(GeneError, "Store/put expects (store, key, value)")
  let scope = if call == nil: nil else: call[].dispatchScope
  let kind = storeRequire(scope, args[0], call)
  requireStr("Store/put key", args[1])
  let key = args[1].strVal
  storeValidateKey(scope, key)
  let mode = storeWriteMode(args[0], call, scope)
  let data = storeEncode(scope, mode, args[2])
  if kind == "SqliteStore":
    let db = storeSqliteDb(args[0], scope)
    let names = storeSqliteTable(args[0])
    let resultSet = sqliteRunStmt(db, "insert or replace into " & names.tableName &
      "(" & names.keyColumn & ", " & names.dataColumn & ") values (?, ?)",
      [newStr(key), newStr(data)], "Store/put", scope)
    storeSqlitePersist(args[0], db, resultSet.mutated, call, scope)
  else:
    let root = args[0].props["root"].strVal
    let path = root / (urlEncodeComponent(key) & ".gene")
    try:
      fsWriteAtomic(path, data, ownerOnly = true)
    except IOError as e:
      raiseStoreError(scope, "io", "Store/put: " & e.msg, key)
    except OSError as e:
      raiseStoreError(scope, "io", "Store/put: " & e.msg, key)
  NIL

proc biStoreGet(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError, "Store/get expects (store, key)")
  let scope = if call == nil: nil else: call[].dispatchScope
  let kind = storeRequire(scope, args[0], call)
  requireStr("Store/get key", args[1])
  let key = args[1].strVal
  storeValidateKey(scope, key)
  let named = storeNamed(call)
  for name in named.names:
    if name notin ["mode", "policy", "default"]:
      raiseStoreError(scope, "invalid_key",
        "Store/get got unexpected named argument: " & name, key)
  let opts = storeReadModePolicy(args[0], call, scope)
  var text = ""
  var found = false
  if kind == "SqliteStore":
    let db = storeSqliteDb(args[0], scope)
    let names = storeSqliteTable(args[0])
    let row = sqliteRunStmt(db, "select " & names.dataColumn & " from " &
      names.tableName & " where " & names.keyColumn & " = ?",
      [newStr(key)], "Store/get", scope).rows
    if row.len > 0:
      text = row[0].mapEntries[names.dataColumn].strVal
      found = true
  else:
    let root = args[0].props["root"].strVal
    let path = root / (urlEncodeComponent(key) & ".gene")
    try:
      if fsPathExists(path):
        text = fsReadBytes(path)
        found = true
    except CatchableError as e:
      raiseStoreError(scope, "io", "Store/get: " & e.msg, key)
  if not found:
    if named.hasArg("default"):
      return named.getArg("default")
    raiseStoreError(scope, "missing", "store key not found: " & key, key)
  storeDecode(scope, opts.mode, text, opts.policy, key)

proc biStoreHas(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError, "Store/has? expects (store, key)")
  let scope = if call == nil: nil else: call[].dispatchScope
  let kind = storeRequire(scope, args[0], call)
  requireStr("Store/has? key", args[1])
  let key = args[1].strVal
  storeValidateKey(scope, key)
  if kind == "SqliteStore":
    let db = storeSqliteDb(args[0], scope)
    let names = storeSqliteTable(args[0])
    let row = sqliteRunStmt(db, "select 1 as found from " & names.tableName &
      " where " & names.keyColumn & " = ?", [newStr(key)], "Store/has?",
      scope).rows
    if row.len > 0: TRUE else: FALSE
  else:
    let path = args[0].props["root"].strVal / (urlEncodeComponent(key) & ".gene")
    newBool(fsPathExists(path))

proc biStoreDelete(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError, "Store/delete expects (store, key)")
  let scope = if call == nil: nil else: call[].dispatchScope
  let kind = storeRequire(scope, args[0], call)
  requireStr("Store/delete key", args[1])
  let key = args[1].strVal
  storeValidateKey(scope, key)
  if kind == "SqliteStore":
    let db = storeSqliteDb(args[0], scope)
    let names = storeSqliteTable(args[0])
    let resultSet = sqliteRunStmt(db, "delete from " & names.tableName & " where " &
      names.keyColumn & " = ?", [newStr(key)], "Store/delete", scope)
    storeSqlitePersist(args[0], db, resultSet.mutated, call, scope)
  else:
    let path = args[0].props["root"].strVal / (urlEncodeComponent(key) & ".gene")
    try:
      if fsPathExists(path):
        fsRemoveFile(path)
    except CatchableError as e:
      raiseStoreError(scope, "io", "Store/delete: " & e.msg, key)
  NIL

proc storeKeyFromFsName(scope: Scope, name: string): tuple[ok: bool, key: string] =
  if not name.endsWith(".gene") or name.len <= ".gene".len:
    return (false, "")
  let encoded = name[0 ..< name.len - ".gene".len]
  try:
    let key = urlDecodeComponent(encoded, plusIsSpace = false, scope)
    if key.len == 0 or urlEncodeComponent(key) != encoded:
      return (false, "")
    (true, key)
  except GeneError:
    (false, "")

proc biStoreKeys(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("Store/keys", args)
  let scope = if call == nil: nil else: call[].dispatchScope
  let kind = storeRequire(scope, args[0], call)
  var keys: seq[Value]
  if kind == "SqliteStore":
    let db = storeSqliteDb(args[0], scope)
    let names = storeSqliteTable(args[0])
    let rows = sqliteRunStmt(db, "select " & names.keyColumn & " from " &
      names.tableName & " order by " & names.keyColumn, [], "Store/keys",
      scope).rows
    for row in rows:
      keys.add row.mapEntries[names.keyColumn]
  else:
    let root = args[0].props["root"].strVal
    try:
      for path in fsListDir(root):
        let decoded = storeKeyFromFsName(scope, path)
        if decoded.ok:
          keys.add newStr(decoded.key)
    except CatchableError as e:
      raiseStoreError(scope, "io", "Store/keys: " & e.msg)
  newList(keys)

proc biStoreClear(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("Store/clear", args)
  let scope = if call == nil: nil else: call[].dispatchScope
  let kind = storeRequire(scope, args[0], call)
  if kind == "SqliteStore":
    let db = storeSqliteDb(args[0], scope)
    let names = storeSqliteTable(args[0])
    let resultSet = sqliteRunStmt(db, "delete from " & names.tableName, [],
                                  "Store/clear", scope)
    storeSqlitePersist(args[0], db, resultSet.mutated, call, scope)
  else:
    let root = args[0].props["root"].strVal
    try:
      for path in fsListDir(root):
        let decoded = storeKeyFromFsName(scope, path)
        if decoded.ok:
          fsRemoveFile(root / path)
    except CatchableError as e:
      raiseStoreError(scope, "io", "Store/clear: " & e.msg)
  NIL

proc storeCheckpointManifest(scope: Scope, generation: int64,
                             encoded: seq[(string, string)]): string =
  var hashes = initPropTable()
  for (name, data) in encoded:
    hashes[name] = newStr("sha256:" & sha256Hex(data))
  var manifest = initPropTable()
  manifest["schema"] = newInt(storeCheckpointSchema)
  manifest["generation"] = newInt(generation)
  manifest["hashes"] = newMap(hashes)
  storeEncode(scope, "data", newMap(manifest))

proc storeDecodeCheckpoint(scope: Scope, store: Value, generation: int64,
                           manifestText: string,
                           encoded: Table[string, string]): Value =
  let manifest = storeDecode(scope, "data", manifestText, NIL, "manifest")
  if manifest.kind != vkMap or
      manifest.mapEntries.getOrDefault("schema", VOID).kind != vkInt or
      manifest.mapEntries["schema"].intVal != storeCheckpointSchema or
      manifest.mapEntries.getOrDefault("generation", VOID).kind != vkInt or
      manifest.mapEntries["generation"].intVal != generation:
    return VOID
  let hashes = manifest.mapEntries.getOrDefault("hashes", VOID)
  if hashes.kind != vkMap:
    return VOID
  var records = initPropTable()
  let mode = storeModeOf(store, scope)
  let policy = storePolicyOf(store)
  for name, expected in hashes.mapEntries:
    if expected.kind != vkString or name notin encoded:
      return VOID
    let data = encoded[name]
    if expected.strVal != "sha256:" & sha256Hex(data):
      return VOID
    records[name] = storeDecode(scope, mode, data, policy, name)
  var resultProps = initPropTable()
  resultProps["generation"] = newInt(generation)
  resultProps["schema"] = newInt(storeCheckpointSchema)
  resultProps["records"] = newMap(records)
  newMap(resultProps)

proc storeFilesystemCheckpoint(scope: Scope, store: Value, generation: int64,
                               encoded: seq[(string, string)],
                               manifestText: string,
                               call: ptr NativeCall) =
  let root = store.props["root"].strVal
  let generations = root / "generations"
  let generationName = storeGenerationName(generation)
  let finalDir = generations / generationName
  when not defined(emscripten) and not defined(geneWasm):
    var publicationLock: ProcessFileLock
    try:
      publicationLock = acquireProcessFileLock(root / ".checkpoint.lock")
    except CatchableError as e:
      raiseStoreError(scope, "io", "Store/checkpoint: " & e.msg)
    defer:
      try:
        publicationLock.release()
      except CatchableError:
        discard

  var generationComplete = false
  var generationIncomplete = false
  var publishedGeneration = int64(0)
  try:
    fsMakeDir(generations)
    let currentPath = root / "CURRENT"
    if fsPathExists(currentPath):
      let currentName = fsReadBytes(currentPath).strip()
      if currentName.len != 20 or
          not currentName.allCharsInSet({'0'..'9'}):
        raiseStoreError(scope, "corrupt",
          "checkpoint CURRENT is not a generation")
      try:
        publishedGeneration = parseBiggestInt(currentName)
      except ValueError:
        raiseStoreError(scope, "corrupt",
          "checkpoint CURRENT is not a generation")
    if fsPathExists(finalDir):
      generationComplete = fsPathExists(finalDir / "MANIFEST.gene")
      generationIncomplete = not generationComplete
  except GeneError:
    raise
  except CatchableError as e:
    raiseStoreError(scope, "io", "Store/checkpoint: " & e.msg)
  if generation != publishedGeneration + 1:
    raiseStoreError(scope, "conflict",
      "checkpoint generation must follow CURRENT: " & $generation)
  if generationComplete:
    # A complete directory above CURRENT was never published. The process lock
    # proves its writer is gone; reclaim it exactly like an incomplete one.
    generationIncomplete = true
  if generationIncomplete:
    # The short-lived publication lock proves no live writer owns this
    # directory. An incomplete generation can only be crash debris, so reclaim
    # it before retrying the same CAS generation.
    try:
      for entry in fsListDir(finalDir):
        fsRemoveFile(finalDir / entry)
      fsRemoveDir(finalDir)
    except CatchableError as e:
      raiseStoreError(scope, "io", "Store/checkpoint: " & e.msg)
  try:
    # A generation becomes complete when MANIFEST.gene is written and becomes
    # authoritative only when CURRENT advances. Building directly in the
    # generation-unique directory keeps interrupted writes recoverable without
    # a path-level directory rename.
    fsMakeDir(finalDir)
    for (name, data) in encoded:
      fsWriteAtomic(finalDir / (urlEncodeComponent(name) & ".gene"), data,
                    ownerOnly = true)
    fsWriteAtomic(finalDir / "MANIFEST.gene", manifestText, ownerOnly = true)
    fsWriteAtomic(root / "CURRENT", generationName & "\n", ownerOnly = true)
  except CatchableError as e:
    raiseStoreError(scope, "io", "Store/checkpoint: " & e.msg)

  var complete: seq[string]
  try:
    for name in fsListDir(generations):
      if name.len == 20 and name.allCharsInSet({'0'..'9'}) and
          fsPathExists(generations / name / "MANIFEST.gene"):
        complete.add name
  except CatchableError as e:
    raiseStoreError(scope, "io", "Store/checkpoint: " & e.msg)
  complete.sort(SortOrder.Descending)
  if complete.len > storeCheckpointRetain:
    for name in complete[storeCheckpointRetain .. ^1]:
      let oldDir = generations / name
      try:
        for entry in fsListDir(oldDir):
          fsRemoveFile(oldDir / entry)
        fsRemoveDir(oldDir)
      except CatchableError:
        # Retention is best effort. A concurrent reader or an unexpected entry
        # may keep an old, complete generation alive without harming CURRENT.
        discard

proc storeSqliteCheckpoint(scope: Scope, store: Value, generation: int64,
                           encoded: seq[(string, string)],
                           manifestText: string,
                           call: ptr NativeCall) =
  let db = storeSqliteDb(store, scope)
  let names = storeSqliteTable(store)
  discard sqliteExecScript(db, "BEGIN IMMEDIATE", "Store/checkpoint", scope)
  try:
    let currentRows = sqliteRunStmt(db, "select " & names.dataColumn & " from " &
      names.tableName & " where " & names.keyColumn & " = ?",
      [newStr("checkpoint/CURRENT")], "Store/checkpoint", scope).rows
    if currentRows.len > 0:
      try:
        let current = parseBiggestInt(
          currentRows[0].mapEntries[names.dataColumn].strVal)
        if generation != current + 1:
          raiseStoreError(scope, "conflict",
            "checkpoint generation must follow CURRENT: " & $generation)
      except ValueError:
        raiseStoreError(scope, "corrupt",
          "checkpoint CURRENT is not a generation")
    elif generation != 1:
      raiseStoreError(scope, "conflict",
        "first checkpoint generation must be 1")
    let manifestKey = storeCheckpointKey(generation, "manifest")
    let existing = sqliteRunStmt(db, "select " & names.keyColumn & " from " &
      names.tableName & " where " & names.keyColumn & " = ?",
      [newStr(manifestKey)], "Store/checkpoint", scope).rows
    if existing.len > 0:
      raiseStoreError(scope, "conflict",
        "checkpoint generation already exists: " & $generation)
    for (name, data) in encoded:
      discard sqliteRunStmt(db, "insert into " & names.tableName &
        "(" & names.keyColumn & ", " & names.dataColumn & ") values (?, ?)",
        [newStr(storeCheckpointKey(generation, "record/" & name)), newStr(data)],
        "Store/checkpoint", scope)
    discard sqliteRunStmt(db, "insert into " & names.tableName &
      "(" & names.keyColumn & ", " & names.dataColumn & ") values (?, ?)",
      [newStr(manifestKey), newStr(manifestText)],
      "Store/checkpoint", scope)
    discard sqliteRunStmt(db, "insert or replace into " & names.tableName &
      "(" & names.keyColumn & ", " & names.dataColumn & ") values (?, ?)",
      [newStr("checkpoint/CURRENT"), newStr(storeGenerationName(generation))],
      "Store/checkpoint", scope)
    discard sqliteExecScript(db, "COMMIT", "Store/checkpoint", scope)
    storeSqlitePersist(store, db, true, call, scope)
  except GeneError, GenePanic:
    try: discard sqliteExecScript(db, "ROLLBACK", "Store/checkpoint", scope)
    except GeneError: discard
    raise

  let manifests = sqliteRunStmt(db, "select " & names.keyColumn & " from " &
    names.tableName & " where " & names.keyColumn & " like ? order by " &
    names.keyColumn & " desc", [newStr("checkpoint/%/manifest")],
    "Store/checkpoint", scope).rows
  if manifests.len > storeCheckpointRetain:
    for row in manifests[storeCheckpointRetain .. ^1]:
      let manifestKey = row.mapEntries[names.keyColumn].strVal
      let prefix = manifestKey[0 ..< manifestKey.len - "manifest".len]
      discard sqliteRunStmt(db, "delete from " & names.tableName & " where " &
        names.keyColumn & " like ?", [newStr(prefix & "%")],
        "Store/checkpoint", scope)
    storeSqlitePersist(store, db, true, call, scope)

proc biStoreCheckpoint(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 3:
    raise newException(GeneError,
      "Store/checkpoint expects (store, generation, records)")
  let scope = if call == nil: nil else: call[].dispatchScope
  let kind = storeRequire(scope, args[0], call)
  if args[1].kind != vkInt or args[1].intVal < 1:
    raiseStoreError(scope, "invalid_key",
      "Store/checkpoint generation must be a positive Int")
  if args[2].kind != vkMap:
    raiseStoreError(scope, "invalid_key",
      "Store/checkpoint records must be a Map")
  let generation = args[1].intVal
  let mode = storeModeOf(args[0], scope)
  var encoded: seq[(string, string)]
  for name, value in args[2].mapEntries:
    storeValidateKey(scope, name)
    encoded.add (name, storeEncode(scope, mode, value))
  let manifestText = storeCheckpointManifest(scope, generation, encoded)
  if kind == "SqliteStore":
    storeSqliteCheckpoint(scope, args[0], generation, encoded, manifestText,
                          call)
  else:
    storeFilesystemCheckpoint(scope, args[0], generation, encoded,
                              manifestText, call)
  newInt(generation)

proc storeLoadFilesystemCheckpoint(scope: Scope, store: Value,
                                   call: ptr NativeCall): Value =
  let root = store.props["root"].strVal
  let generations = root / "generations"
  var candidates: seq[string]
  var publishedGeneration = int64(0)
  try:
    let currentPath = root / "CURRENT"
    if not fsPathExists(currentPath):
      return NIL
    let currentName = fsReadBytes(currentPath).strip()
    if currentName.len != 20 or
        not currentName.allCharsInSet({'0'..'9'}):
      raiseStoreError(scope, "corrupt",
        "Store/load_checkpoint: CURRENT is not a generation")
    try:
      publishedGeneration = parseBiggestInt(currentName)
    except ValueError:
      raiseStoreError(scope, "corrupt",
        "Store/load_checkpoint: CURRENT is not a generation")
    if not fsPathExists(generations):
      raiseStoreError(scope, "corrupt",
        "Store/load_checkpoint: CURRENT references missing generations")
    for name in fsListDir(generations):
      if name.len == 20 and name.allCharsInSet({'0'..'9'}):
        try:
          if parseBiggestInt(name) <= publishedGeneration:
            candidates.add name
        except ValueError:
          discard
  except GeneError:
    raise
  except CatchableError as e:
    raiseStoreError(scope, "io", "Store/load_checkpoint: " & e.msg)
  candidates.sort(SortOrder.Descending)
  for name in candidates:
    var generation: int64
    try: generation = parseBiggestInt(name)
    except ValueError: continue
    let dir = generations / name
    let manifestPath = dir / "MANIFEST.gene"
    try:
      if not fsPathExists(manifestPath):
        continue
      let manifestText = fsReadBytes(manifestPath)
      let manifest = storeDecode(scope, "data", manifestText, NIL, "manifest")
      if manifest.kind != vkMap:
        continue
      let hashes = manifest.mapEntries.getOrDefault("hashes", VOID)
      if hashes.kind != vkMap:
        continue
      var encoded = initTable[string, string]()
      var complete = true
      for recordName, _ in hashes.mapEntries:
        let path = dir / (urlEncodeComponent(recordName) & ".gene")
        if not fsPathExists(path):
          complete = false
          break
        encoded[recordName] = fsReadBytes(path)
      if complete:
        let loaded = storeDecodeCheckpoint(scope, store, generation,
                                           manifestText, encoded)
        if loaded.kind != vkVoid:
          return loaded
    except GeneError, IOError, OSError:
      discard
  NIL

proc storeLoadSqliteCheckpoint(scope: Scope, store: Value): Value =
  let db = storeSqliteDb(store, scope)
  let names = storeSqliteTable(store)
  let currentRows = sqliteRunStmt(db, "select " & names.dataColumn & " from " &
    names.tableName & " where " & names.keyColumn & " = ?",
    [newStr("checkpoint/CURRENT")], "Store/load_checkpoint", scope).rows
  if currentRows.len == 0:
    return NIL
  var publishedGeneration: int64
  try:
    publishedGeneration = parseBiggestInt(
      currentRows[0].mapEntries[names.dataColumn].strVal)
  except ValueError:
    raiseStoreError(scope, "corrupt",
      "Store/load_checkpoint: CURRENT is not a generation")
  let manifests = sqliteRunStmt(db, "select " & names.keyColumn & ", " &
    names.dataColumn & " from " & names.tableName & " where " &
    names.keyColumn & " like ? order by " & names.keyColumn & " desc",
    [newStr("checkpoint/%/manifest")], "Store/load_checkpoint", scope).rows
  for row in manifests:
    let key = row.mapEntries[names.keyColumn].strVal
    let parts = key.split('/')
    if parts.len != 3:
      continue
    var generation: int64
    try: generation = parseBiggestInt(parts[1])
    except ValueError: continue
    if generation > publishedGeneration:
      continue
    let manifestText = row.mapEntries[names.dataColumn].strVal
    try:
      let manifest = storeDecode(scope, "data", manifestText, NIL, "manifest")
      if manifest.kind != vkMap:
        continue
      let hashes = manifest.mapEntries.getOrDefault("hashes", VOID)
      if hashes.kind != vkMap:
        continue
      var encoded = initTable[string, string]()
      var complete = true
      for recordName, _ in hashes.mapEntries:
        let record = sqliteRunStmt(db, "select " & names.dataColumn & " from " &
          names.tableName & " where " & names.keyColumn & " = ?",
          [newStr(storeCheckpointKey(generation, "record/" & recordName))],
          "Store/load_checkpoint", scope).rows
        if record.len == 0:
          complete = false
          break
        encoded[recordName] = record[0].mapEntries[names.dataColumn].strVal
      if complete:
        let loaded = storeDecodeCheckpoint(scope, store, generation,
                                           manifestText, encoded)
        if loaded.kind != vkVoid:
          return loaded
    except GeneError:
      discard
  NIL

proc biStoreLoadCheckpoint(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("Store/load_checkpoint", args)
  let scope = if call == nil: nil else: call[].dispatchScope
  let kind = storeRequire(scope, args[0], call)
  if kind == "SqliteStore":
    storeLoadSqliteCheckpoint(scope, args[0])
  else:
    storeLoadFilesystemCheckpoint(scope, args[0], call)

proc biStoreClose(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  requireOne("Store/close", args)
  let scope = if call == nil: nil else: call[].dispatchScope
  let kind = storeRequire(scope, args[0])
  storeClose(args[0])
  NIL

proc biStoreFsOpen(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 0:
    raise newException(GeneError, "store/fs/open expects no positional arguments")
  let scope = if call == nil: nil else: call[].dispatchScope
  let named = storeNamed(call)
  if not named.hasArg("root"):
    raiseStoreError(scope, "invalid_key", "store/fs/open requires ^root")
  let rootVal = named.getArg("root")
  requireStr("store/fs/open ^root", rootVal)
  let root = rootVal.strVal
  let mode = if named.hasArg("mode"):
      storeModeText(scope, named.getArg("mode"))
    else:
      "data"
  let policy = storeNamedOr(named, "policy", NIL)
  for name in named.names:
    if name notin ["root", "mode", "policy"]:
      raiseStoreError(scope, "invalid_key",
        "store/fs/open got unexpected named argument: " & name)
  try:
    fsMakeDir(root)
    fsRestrictDirToOwner(root)
  except CatchableError as e:
    raiseStoreError(scope, "io", "store/fs/open: " & e.msg)
  let store = newNativeWrapper(builtInTypeHead(scope, "FsStore"),
    {"root": newStr(root),
     "mode": newSym(mode),
     "policy": policy,
     "closed": newCell(FALSE)})
  store

## typed_native AOT loading (docs/workflows.md).
##
## `aot_runtime.nim` exports the C helpers a generated module calls; this is
## the other half — opening such a module and binding its entries so ordinary
## Gene code can call natively compiled functions.

type AotEntryBinding = object
  ## The entry pointer plus the library's requirement set, so dispatch can
  ## check the ABI epoch without a second lookup.
  entry: AotEntryProc
  module: AotModuleRequirements

var aotEntries: Table[string, AotEntryBinding]
var aotModuleHandles: seq[LibHandle]

proc aotEntryDispatch(args: openArray[Value], call: ptr NativeCall): Value
                     {.nimcall.} =
  ## One dispatcher for every AOT entry. `NativeCallProc` is `nimcall` and
  ## cannot capture the entry pointer, so entries are keyed by the same name
  ## the VM reports back as `calleeName`.
  let name = call.calleeName
  if not aotEntries.hasKey(name):
    raise newException(GeneError,
      "no AOT entry registered for '" & name.rsplit('\x1f', 1)[^1] & "'")
  let binding = aotEntries[name]
  ## The ABI guard, and the single chokepoint for it: every callable `aot/load`
  ## hands out is bound to this proc. Load-time validation is a snapshot, so a
  ## Type re-registered afterwards — same identity, different ABI or policy —
  ## would otherwise leave compiled code reading stale offsets or calling a
  ## superseded `^copy`. Raising here means native code never runs.
  let stale = ensureAotModuleValid(binding.module)
  if stale.len > 0:
    raise newException(GeneError,
      "AOT library is no longer compatible with the loaded native types: " &
      stale)
  let entry = binding.entry
  var ctx = AotContext(scope: call.dispatchScope)
  var aotCall = AotCall(
    args: if args.len > 0: cast[ptr UncheckedArray[Value]](addr args[0])
          else: nil,
    len: csize_t(args.len))
  var value = NIL
  let status = entry(addr ctx, addr aotCall, addr value)
  if status != 0:
    if ctx.panicked or status == 2:
      raise newException(GenePanic, ctx.message)
    if ctx.error != nil:
      raise ctx.error
    raise newException(GeneError,
      if ctx.message.len > 0: ctx.message
      else: "AOT entry '" & name & "' failed with status " & $status)
  value

proc biAotLoad(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  ## `(aot/load "path")` — open a typed_native AOT library and return a map of
  ## `name -> callable` for every function that carries a `^native_entry`
  ## adapter. Functions compiled without one are present in the manifest but
  ## have no dynamic boundary, so they are not callable from Gene and are
  ## skipped.
  if args.len != 1 or args[0].kind != vkString:
    raise newException(GeneError, "aot/load expects one Str path")
  let path = args[0].strVal
  let handle = loadLib(path)
  if handle == nil:
    raise newException(GeneError, "could not load AOT library: " & path)
  let manifest = cast[ptr UncheckedArray[AotModuleFunctionC]](
    symAddr(handle, "gene_aot_module"))
  let countAddr = cast[ptr csize_t](symAddr(handle, "gene_aot_module_count"))
  let ffiManifest = cast[ptr UncheckedArray[AotFfiFnInfoC]](
    symAddr(handle, "gene_ffi_fns"))
  let ffiCountAddr = cast[ptr csize_t](symAddr(handle, "gene_ffi_fns_count"))
  ## Either manifest alone is a valid library: a module of typed functions has
  ## no ffi/fns, and a pure binding module has no module functions.
  if (manifest == nil or countAddr == nil) and
      (ffiManifest == nil or ffiCountAddr == nil):
    unloadLib(handle)
    raise newException(GeneError,
      "AOT library exports no manifest; was it built from " &
      "`gene compile --target c` with -DGENE_AOT_DYNAMIC_ENTRIES=1? " & path)
  ## Everything below validates and *stages*; nothing mutable is touched until
  ## every check has passed. The proc used to register the handle and then bind
  ## entries in a loop that could raise partway through, leaving a live handle
  ## and a half-filled entry table behind.
  ##
  ## `unloadLib` on a failed load is correct and safe precisely because nothing
  ## escaped: no callable was handed out and no release shim is reachable. That
  ## is the exact opposite of the policy for a *successful* load, where the
  ## library is pinned for the process lifetime.
  var stagedEntries: seq[(string, AotEntryProc)]
  var moduleRequirements: AotModuleRequirements
  var entries = initPropTable()

  proc rejectLoad(message: string) =
    unloadLib(handle)
    raise newException(GeneError, message & ": " & path)

  ## The manifest version is emitted unconditionally, so its absence means the
  ## library predates ABI validation — not that it has no native types. A stale
  ## library is exactly what this check exists to catch, so a missing marker is
  ## a hard error rather than implicit trust.
  let versionAddr = cast[ptr csize_t](
    symAddr(handle, "gene_aot_manifest_version"))
  if versionAddr == nil:
    rejectLoad("AOT library predates ABI validation and must be rebuilt " &
      "with `gene compile --target c`")
  if int(versionAddr[]) != AotManifestVersion:
    rejectLoad("AOT library manifest version " & $int(versionAddr[]) &
      " does not match this runtime's " & $AotManifestVersion &
      "; rebuild it")

  ## Every native Type the compiled code depends on, transitively — so a type
  ## whose layout is only ever reached by dereferencing a pointer field is
  ## checked too, even though it never crosses the boundary.
  let typeManifest = cast[ptr UncheckedArray[AotNativeTypeC]](
    symAddr(handle, "gene_aot_native_types"))
  let typeCountAddr = cast[ptr csize_t](
    symAddr(handle, "gene_aot_native_types_count"))
  var requirements: seq[AotTypeRequirement]
  if typeManifest != nil and typeCountAddr != nil:
    for i in 0 ..< int(typeCountAddr[]):
      let row = typeManifest[i]
      requirements.add AotTypeRequirement(
        typeIdentity: $row.typeIdentity,
        abiIdentity: $row.abiIdentity,
        abiFingerprint: $row.abiFingerprint,
        contractFingerprint: $row.contractFingerprint)
  let mismatch = validateAotTypeRequirements(requirements)
  if mismatch.len > 0:
    rejectLoad(mismatch)

  ## Measured layouts, compared across libraries. Two libraries declaring the
  ## same layout identity must agree on what the C compiler actually laid out.
  let layoutManifest = cast[ptr UncheckedArray[AotAbiLayoutC]](
    symAddr(handle, "gene_aot_abi_layouts"))
  let layoutCountAddr = cast[ptr csize_t](
    symAddr(handle, "gene_aot_abi_layouts_count"))
  let fieldManifest = cast[ptr UncheckedArray[AotAbiLayoutFieldC]](
    symAddr(handle, "gene_aot_abi_layout_fields"))
  let fieldCountAddr = cast[ptr csize_t](
    symAddr(handle, "gene_aot_abi_layout_fields_count"))
  var measured: seq[AotMeasuredLayout]
  if layoutManifest != nil and layoutCountAddr != nil:
    for i in 0 ..< int(layoutCountAddr[]):
      let row = layoutManifest[i]
      var entry = AotMeasuredLayout(
        abiIdentity: $row.abiIdentity,
        fingerprint: $row.fingerprint,
        size: int(row.measuredSize),
        align: int(row.measuredAlign))
      if fieldManifest != nil and fieldCountAddr != nil:
        for j in 0 ..< int(fieldCountAddr[]):
          let field = fieldManifest[j]
          if $field.abiIdentity == entry.abiIdentity:
            entry.offsets[$field.fieldName] = int(field.measuredOffset)
      measured.add entry
  let layoutMismatch = checkAotMeasuredLayouts(measured)
  if layoutMismatch.len > 0:
    rejectLoad(layoutMismatch)

  proc stageEntry(geneName, symbol: string): string =
    let entry = cast[AotEntryProc](symAddr(handle, symbol.cstring))
    if entry == nil:
      return "AOT entry symbol not found: " & symbol
    ## Key by library *and* name. `NativeCallProc` is nimcall and cannot carry
    ## the entry pointer, so dispatch goes through the callable's own name — and
    ## a bare Gene name is not unique. Two libraries exporting `make` would
    ## otherwise share one slot, so loading the second silently retargeted every
    ## callable already handed out by the first.
    let key = path & "\x1f" & geneName
    stagedEntries.add (key, entry)
    entries[geneName] = newNativeCallFn(key, aotEntryDispatch,
      acceptsNamed = false)
    ""

  if manifest != nil and countAddr != nil:
    for i in 0 ..< int(countAddr[]):
      let row = manifest[i]
      if row.entrySymbol == nil or row.entrySymbol[0] == '\0':
        continue
      let failure = stageEntry($row.geneName, $row.entrySymbol)
      if failure.len > 0:
        rejectLoad(failure)

  ## Generated ffi/fn wrappers share the entry signature, so they bind the same
  ## way. This is what routes a foreign call through compiled marshalling code
  ## rather than the VM's dynamic FFI path.
  if ffiManifest != nil and ffiCountAddr != nil:
    for i in 0 ..< int(ffiCountAddr[]):
      let row = ffiManifest[i]
      if row.wrapperName == nil or row.wrapperName[0] == '\0':
        continue
      let failure = stageEntry($row.name, $row.wrapperName)
      if failure.len > 0:
        rejectLoad(failure)

  ## Commit. Past this point the library is visible and pinned: it cannot safely
  ## unload while its callables, entry pointers, or release shims may still
  ## escape — and a release shim is reachable from an owned `CPtr` with
  ## arbitrary lifetime, long after the callable that produced it is gone.
  ## Unloading then would turn a live pointer's release into a jump into
  ## unmapped memory. Revisit only alongside a real unload story, not as an
  ## isolated fix.
  commitAotMeasuredLayouts(measured)
  moduleRequirements = registerAotModuleRequirements(path, requirements)
  for (key, entry) in stagedEntries:
    aotEntries[key] = AotEntryBinding(entry: entry,
      module: moduleRequirements)
  aotModuleHandles.add handle
  newMap(entries)

proc biIoWriteAll(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2 or args[1].kind != vkBytes:
    raise newException(GeneError, "io/write_all expects a writer and Bytes")
  let scope = if call == nil: nil else: call[].dispatchScope
  if currentEventLane() != schedulerForScope(scope).rootLane:
    raiseValueSemanticError("RuntimeLaneError", "io/write_all requires the root lane")
  let app = if scope == nil: currentApplication() else: scope.application()
  result = applyCall(app.ioWriteAllHelper, args, NamedArgs(), scope)
  if result.kind != vkTask:
    raise newException(GeneError, "io/write_all helper did not return a Task")
  scope.registerIoTask(result)

proc biIoRetainCleanup(args: openArray[Value],
                       call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 1 or args[0].kind != vkTask:
    raise newException(GeneError, "io/_retain_cleanup expects one Task")
  let scope = if call == nil: nil else: call[].dispatchScope
  if scope == nil or currentEventLane() != schedulerForScope(scope).rootLane:
    raiseValueSemanticError("RuntimeLaneError",
      "io/_retain_cleanup requires the root lane")
  scope.registerIoCleanupTask(args[0])
  args[0]

proc biIoCopy(args: openArray[Value], call: ptr NativeCall): Value {.nimcall.} =
  if args.len != 2:
    raise newException(GeneError, "io/copy expects a reader and writer")
  let scope = if call == nil: nil else: call[].dispatchScope
  if currentEventLane() != schedulerForScope(scope).rootLane:
    raiseValueSemanticError("RuntimeLaneError", "io/copy requires the root lane")
  let app = if scope == nil: currentApplication() else: scope.application()
  let named = if call == nil: NamedArgs()
              else: NamedArgs(names: call[].namedNames,
                              values: call[].namedValues)
  result = applyCall(app.ioCopyHelper, args, named, scope)
  if result.kind != vkTask:
    raise newException(GeneError, "io/copy helper did not return a Task")
  scope.registerIoTask(result)

proc biNativeIngressOpen(args: openArray[Value],
                         call: ptr NativeCall): Value {.nimcall.} =
  if nativeIngressAdapter.open == nil:
    raise newException(GeneError, "native ingress adapter is unavailable")
  nativeIngressAdapter.open(args, call)

proc biNativeIngressClose(args: openArray[Value],
                          call: ptr NativeCall): Value {.nimcall.} =
  if nativeIngressAdapter.close == nil:
    raise newException(GeneError, "native ingress adapter is unavailable")
  nativeIngressAdapter.close(args, call)

proc biNativeIngressWaitClosed(args: openArray[Value],
                               call: ptr NativeCall): Value {.nimcall.} =
  if nativeIngressAdapter.waitClosed == nil:
    raise newException(GeneError, "native ingress adapter is unavailable")
  nativeIngressAdapter.waitClosed(args, call)

proc biNativeIngressStatus(args: openArray[Value],
                           call: ptr NativeCall): Value {.nimcall.} =
  if nativeIngressAdapter.status == nil:
    raise newException(GeneError, "native ingress adapter is unavailable")
  nativeIngressAdapter.status(args, call)

proc biNativeModuleModule(args: openArray[Value],
                          call: ptr NativeCall): Value {.nimcall.} =
  if nativeModuleAdapter.module == nil:
    raise newException(GeneError, "managed native module adapter is unavailable")
  nativeModuleAdapter.module(args, call)

proc biNativeModuleClose(args: openArray[Value],
                         call: ptr NativeCall): Value {.nimcall.} =
  if nativeModuleAdapter.close == nil:
    raise newException(GeneError, "managed native module adapter is unavailable")
  nativeModuleAdapter.close(args, call)

proc biNativeModuleWaitClosed(args: openArray[Value],
                              call: ptr NativeCall): Value {.nimcall.} =
  if nativeModuleAdapter.waitClosed == nil:
    raise newException(GeneError, "managed native module adapter is unavailable")
  nativeModuleAdapter.waitClosed(args, call)

proc biNativeModuleStatus(args: openArray[Value],
                          call: ptr NativeCall): Value {.nimcall.} =
  if nativeModuleAdapter.status == nil:
    raise newException(GeneError, "managed native module adapter is unavailable")
  nativeModuleAdapter.status(args, call)

const syncGateSource = staticRead("lib/sync.gene")

proc registerStdlibNamespaces(root: Scope) =
  let app = root.application()
  ## Define the importable stdlib namespaces (gene/*, str, html, url, net/http,
  ## db, db/sqlite, db/postgres) and their error types on the built-ins root
  ## scope. Every namespace is also reachable under the `gene` root registered
  ## at the end of this proc.
  let errorProtocol = root.vars["Error"]
  let urlError = newType("UrlError", NIL,
                         @[TypeField(name: "message", optional: false,
                                     typeExpr: newSym("Str"), scope: root)],
                         @[errorProtocol], root)
  root.define("UrlError", urlError)
  root.impls.add ProtocolImpl(protocol: errorProtocol,
                                receiver: urlError)
  let httpError = newType("HttpError", NIL,
                          @[TypeField(name: "message", optional: false,
                                      typeExpr: newSym("Str"), scope: root)],
                          @[errorProtocol], root)
  root.define("HttpError", httpError)
  root.impls.add ProtocolImpl(protocol: errorProtocol,
                                receiver: httpError)
  proc defineErrorType(name: string): Value =
    result = newType(name, NIL,
                     @[TypeField(name: "message", optional: false,
                                 typeExpr: newSym("Str"), scope: root)],
                     @[errorProtocol], root)
    root.define(name, result)
    root.impls.add ProtocolImpl(protocol: errorProtocol, receiver: result)
  let osError = defineErrorType("OsError")
  let pathError = defineErrorType("PathError")
  let packageResourceError = defineErrorType("PackageResourceError")
  var materializedMessages = initTable[string, Value]()
  materializedMessages["path"] = builtinNativeCallFn(
    "MaterializedResource/path", biMaterializedPath, acceptsNamed = false)
  materializedMessages["close"] = builtinNativeCallFn(
    "MaterializedResource/close", biMaterializedClose, acceptsNamed = false)
  let materializedType = newType("MaterializedResource", NIL, @[], @[], root,
    messages = materializedMessages, repr = trNativeWrapper)
  root.define("MaterializedResource", materializedType)
  let fsError = defineErrorType("FsError")
  let fsLimitError = newType("FsLimitError", fsError, @[], @[], root)
  root.define("FsLimitError", fsLimitError)
  let csvError = newType("CsvError", NIL,
    @[TypeField(name: "message", optional: false, typeExpr: newSym("Str"), scope: root),
      TypeField(name: "offset", optional: false, typeExpr: newSym("Int"), scope: root),
      TypeField(name: "record", optional: false, typeExpr: newSym("Int"), scope: root),
      TypeField(name: "field", optional: false, typeExpr: newSym("Int"), scope: root)],
    @[errorProtocol], root)
  root.define("CsvError", csvError)
  root.impls.add ProtocolImpl(protocol: errorProtocol, receiver: csvError)
  let terminalError = defineErrorType("TerminalError")
  let cursesError = defineErrorType("CursesError")
  let httpClientError = defineErrorType("HttpClientError")
  let jsonError = defineErrorType("JsonError")
  let serdeError = defineErrorType("SerdeError")
  let watcherClosed = defineErrorType("WatcherClosed")
  let fsChangeType = newType("FsChange", NIL,
    @[TypeField(name: "kind", optional: false,
                typeExpr: newSym("Sym"), scope: root),
      TypeField(name: "path", optional: true,
                typeExpr: newSym("Str"), scope: root),
      TypeField(name: "from", optional: true,
                typeExpr: newSym("Str"), scope: root)],
    @[], root)
  root.define("FsChange", fsChangeType)
  var fsWatcherMessages = initTable[string, Value]()
  fsWatcherMessages["recv"] =
    builtinNativeCallFn("FsWatcher/recv", biFsWatcherRecv,
                    acceptsNamed = false)
  fsWatcherMessages["close"] =
    builtinNativeCallFn("FsWatcher/close", biFsWatcherClose,
                    acceptsNamed = false)
  let fsWatcherType = newType("FsWatcher", NIL, @[], @[], root,
                              messages = fsWatcherMessages)
  root.define("FsWatcher", fsWatcherType)
  var fsFileLockMessages = initTable[string, Value]()
  fsFileLockMessages["close"] = builtinNativeCallFn("FsFileLock/close",
    biFsFileLockClose, acceptsNamed = false)
  let fsFileLockType = newType("FsFileLock", NIL, @[], @[], root,
    messages = fsFileLockMessages)
  root.define("FsFileLock", fsFileLockType)
  # Structured diagnostic logging (docs/stdlib.md). Logger methods
  # are receiver-dispatched through builtinReceiverMessage; lazy `*!` forms
  # are compiler-known macros selected from this same namespace.
  let logLevel = newEnum("LogLevel", @[],
    [(name: "error", payloadTypes: newSeq[Value](),
      hasBacking: false, backing: NIL),
     (name: "warn", payloadTypes: newSeq[Value](),
      hasBacking: false, backing: NIL),
     (name: "info", payloadTypes: newSeq[Value](),
      hasBacking: false, backing: NIL),
     (name: "debug", payloadTypes: newSeq[Value](),
      hasBacking: false, backing: NIL),
     (name: "trace", payloadTypes: newSeq[Value](),
      hasBacking: false, backing: NIL),
     (name: "off", payloadTypes: newSeq[Value](),
      hasBacking: false, backing: NIL)],
    NIL, root)
  let logScope = newScope(root)
  logScope.define("LogLevel", logLevel)
  logScope.define("Logger", newSym("Logger"))
  logScope.define("new_logger", builtinNativeCallFn("log/new_logger",
                                                biLogNewLogger))
  logScope.define("new_file_logger",
    builtinNativeCallFn("log/new_file_logger", biLogNewFileLogger))
  logScope.define("enabled?", builtinNativeCallFn("Logger/enabled?",
                                               biLoggerEnabled,
                                               acceptsNamed = false))
  logScope.define("emit", builtinNativeCallFn("Logger/emit", biLoggerEmit))
  logScope.define("child", builtinNativeCallFn("Logger/child", biLoggerChild))
  logScope.define("with", builtinNativeCallFn("Logger/with", biLoggerWith,
                                           acceptsNamed = false))
  logScope.define("error", builtinNativeCallFn("Logger/error", biLoggerError))
  logScope.define("warn", builtinNativeCallFn("Logger/warn", biLoggerWarn))
  logScope.define("info", builtinNativeCallFn("Logger/info", biLoggerInfo))
  logScope.define("debug", builtinNativeCallFn("Logger/debug", biLoggerDebug))
  logScope.define("trace", builtinNativeCallFn("Logger/trace", biLoggerTrace))
  root.define("log", newNamespace("log", logScope))
  # Importable stdlib namespaces (docs/stdlib.md): mostly re-exports of the
  # built-ins above under stable module paths, so source programs can write
  # `(import std/stream [map])` / `(import str [join])` today and swap in
  # file-backed modules later without changing call sites.
  let stdStreamScope = newScope(root)
  stdStreamScope.define("to_stream",
    builtinNativeCallFn("to_stream", biToStream, acceptsNamed = false))
  stdStreamScope.define("to_pairs_stream",
                        builtinNativeFn("to_pairs_stream", biToPairsStream))
  # The generic collection operations (§6.2) must bind the same process-wide
  # dispatchers the root and the type tables hold — `sharedBuiltinNative`
  # returns those instances; the fresh values built here are discarded.
  stdStreamScope.define("map",
    sharedBuiltinNative("map", builtinNativeCallFn("map", biMap, acceptsNamed = false)))
  stdStreamScope.define("filter_map",
    sharedBuiltinNative("filter_map", builtinNativeCallFn("filter_map", biFilterMap, acceptsNamed = false)))
  stdStreamScope.define("filter",
    sharedBuiltinNative("filter", builtinNativeCallFn("filter", biFilter, acceptsNamed = false)))
  stdStreamScope.define("take",
    sharedBuiltinNative("take", builtinNativeCallFn("take", biTake, acceptsNamed = false)))
  stdStreamScope.define("into",
    sharedBuiltinNative("into", builtinNativeCallFn("into", biInto, acceptsNamed = false)))
  # `each` has no bare root binding, so the `Stream` type takes it from this
  # namespace. It must be the process-wide instance or the type singleton
  # would hold the first application's copy.
  stdStreamScope.define("each",
    sharedBuiltinNative("each", builtinNativeCallFn("each", biEach, acceptsNamed = false)))
  let stdNodeScope = newScope(root)
  stdNodeScope.define("head", builtinNativeFn("head", biHead))
  stdNodeScope.define("props", builtinNativeFn("props", biProps))
  stdNodeScope.define("body", builtinNativeFn("body", biBody))
  stdNodeScope.define("meta", builtinNativeFn("meta", biMeta))
  stdNodeScope.define("rebuild", builtinNativeCallFn("node/rebuild", biNodeRebuild))
  stdNodeScope.define("declarations",
                      builtinNativeFn("declarations", biDeclarations))
  let stdParseScope = newScope(root)
  stdParseScope.define("parse_int", builtinNativeCallFn("parse_int", biParseInt,
                                                    acceptsNamed = false))
  stdParseScope.define("read_all",
                       builtinNativeCallFn("parse/read_all", biParseReadAll))
  stdParseScope.define("incomplete?", builtinNativeFn("parse/incomplete?", biReadIncomplete))
  # `format` was removed from the runtime: canonical formatting is a tool
  # surface, not a language one, and it was the only thing linking fmt.nim
  # (and transitively lsp/analysis.nim) into every Gene binary. Use the
  # `gene fmt` CLI, which delegates to the separately built gene-fmt.
  stdParseScope.define("ParseError", root.vars["ParseError"])
  # The former `std/*` namespaces are registered bare at the root — like `str`,
  # `net`, etc. — so buildBuiltins' `gene` root reaches them as `gene/stream`,
  # `gene/node`, `gene/parse`. The `std` root itself is dropped.
  root.define("stream", newNamespace("stream", stdStreamScope))
  root.define("node", newNamespace("node", stdNodeScope))
  root.define("parse", newNamespace("parse", stdParseScope))
  # Ordinary Gene wrappers use private native acquisition and unwind ownership.
  # Their bookkeeping must survive an exhausted execution budget.
  let syncScope = newScope(root)
  let gateScope = newScope(root)
  gateScope.define("gate_owner", builtinNativeCallFn("sync/gate_owner",
    biSyncGateOwner, acceptsNamed = false))
  gateScope.define("gate_acquire", builtinNativeCallFn("sync/gate_acquire",
    biSyncGateAcquire, acceptsNamed = false))
  gateScope.define("track_enter", builtinNativeCallFn("sync/track_enter",
    biSyncTrackEnter, acceptsNamed = false))
  let syncProtos = compileSource(syncGateSource, "<builtin gene/sync>").functions
  for index, name in ["gate", "track"]:
    let proto = syncProtos[index]
    syncScope.define(name, newFunction("sync/" & name, proto.params, proto, gateScope))
  root.define("sync", newNamespace("sync", syncScope))
  # `gene/bit` and `gene/bytes` — the primitives a binary format needs.
  let bitScope = newScope(root)
  bitScope.define("and", builtinNativeFn("bit/and", biBitAnd))
  bitScope.define("or", builtinNativeFn("bit/or", biBitOr))
  bitScope.define("xor", builtinNativeFn("bit/xor", biBitXor))
  bitScope.define("not", builtinNativeFn("bit/not", biBitNot))
  bitScope.define("shl", builtinNativeFn("bit/shl", biBitShl))
  bitScope.define("shr", builtinNativeFn("bit/shr", biBitShr))
  root.define("bit", newNamespace("bit", bitScope))
  let orderScope = newScope(root)
  orderScope.define("compare", builtinNativeFn("order/compare", biOrderCompare))
  orderScope.define("sort", builtinNativeCallFn("order/sort", biOrderSort))
  orderScope.define("sort_by", builtinNativeCallFn("order/sort_by", biOrderSortBy))
  root.define("order", newNamespace("order", orderScope))
  let bytesScope = newScope(root)
  bytesScope.define("from_list", builtinNativeFn("binary/from_list", biBytesFromList))
  bytesScope.define("to_list", builtinNativeFn("binary/to_list", biBytesToList))
  bytesScope.define("to_buffer",
                    builtinNativeFn("binary/to_buffer", biBytesToBuffer))
  bytesScope.define("size", builtinNativeFn("binary/size", biBytesSize))
  bytesScope.define("get", builtinNativeFn("binary/get", biBytesGet))
  bytesScope.define("concat", builtinNativeFn("binary/concat", biBytesConcat))
  bytesScope.define("slice", builtinNativeFn("binary/slice", biBytesSlice))
  bytesScope.define("from_str", builtinNativeFn("binary/from_str", biBytesFromStr))
  bytesScope.define("to_str", builtinNativeFn("binary/to_str", biBytesToStr))
  bytesScope.define("decode_utf8", builtinNativeFn("binary/decode_utf8", biBytesDecodeUtf8))
  # Number codecs, all little-endian at a byte offset (design.md §D7.3).
  bytesScope.define("get_u16", builtinNativeFn("binary/get_u16", biBytesGetU16))
  bytesScope.define("get_u32", builtinNativeFn("binary/get_u32", biBytesGetU32))
  bytesScope.define("get_i32", builtinNativeFn("binary/get_i32", biBytesGetI32))
  bytesScope.define("get_f32", builtinNativeFn("binary/get_f32", biBytesGetF32))
  bytesScope.define("get_f64", builtinNativeFn("binary/get_f64", biBytesGetF64))
  bytesScope.define("put_u8", builtinNativeFn("binary/put_u8", biBytesPutU8))
  bytesScope.define("put_u16", builtinNativeFn("binary/put_u16", biBytesPutU16))
  bytesScope.define("put_u32", builtinNativeFn("binary/put_u32", biBytesPutU32))
  bytesScope.define("put_i32", builtinNativeFn("binary/put_i32", biBytesPutI32))
  bytesScope.define("put_f32", builtinNativeFn("binary/put_f32", biBytesPutF32))
  bytesScope.define("put_f64", builtinNativeFn("binary/put_f64", biBytesPutF64))
  root.define("binary", newNamespace("binary", bytesScope))
  let base64Scope = newScope(root)
  base64Scope.define("encode", builtinNativeFn("base64/encode", biBase64Encode))
  base64Scope.define("decode", builtinNativeFn("base64/decode", biBase64Decode))
  root.define("base64", newNamespace("base64", base64Scope))
  # `gene/math`, reachable as `$math/floor` like every other root namespace.
  let mathScope = newScope(root)
  mathScope.define("floor", builtinNativeFn("math/floor", biMathFloor))
  mathScope.define("ceil", builtinNativeFn("math/ceil", biMathCeil))
  mathScope.define("trunc", builtinNativeFn("math/trunc", biMathTrunc))
  mathScope.define("round", builtinNativeFn("math/round", biMathRound))
  mathScope.define("abs", builtinNativeFn("math/abs", biMathAbs))
  mathScope.define("sign", builtinNativeFn("math/sign", biMathSign))
  mathScope.define("sqrt", builtinNativeFn("math/sqrt", biMathSqrt))
  mathScope.define("exp", builtinNativeFn("math/exp", biMathExp))
  mathScope.define("log", builtinNativeFn("math/log", biMathLog))
  mathScope.define("log2", builtinNativeFn("math/log2", biMathLog2))
  mathScope.define("log10", builtinNativeFn("math/log10", biMathLog10))
  mathScope.define("sin", builtinNativeFn("math/sin", biMathSin))
  mathScope.define("cos", builtinNativeFn("math/cos", biMathCos))
  mathScope.define("tan", builtinNativeFn("math/tan", biMathTan))
  mathScope.define("asin", builtinNativeFn("math/asin", biMathAsin))
  mathScope.define("acos", builtinNativeFn("math/acos", biMathAcos))
  mathScope.define("atan", builtinNativeFn("math/atan", biMathAtan))
  mathScope.define("atan2", builtinNativeFn("math/atan2", biMathAtan2))
  mathScope.define("pow", builtinNativeFn("math/pow", biMathPow))
  mathScope.define("hypot", builtinNativeFn("math/hypot", biMathHypot))
  mathScope.define("min", builtinNativeFn("math/min", biMathMin))
  mathScope.define("max", builtinNativeFn("math/max", biMathMax))
  mathScope.define("clamp", builtinNativeFn("math/clamp", biMathClamp))
  mathScope.define("pi", newFloat(PI))
  mathScope.define("e", newFloat(E))
  mathScope.define("tau", newFloat(TAU))
  root.define("math", newNamespace("math", mathScope))
  let strScope = newScope(root)
  strScope.define("join", builtinNativeFn("str/join", biStrJoin))
  strScope.define("split", builtinNativeFn("str/split", biStrSplit))
  strScope.define("trim", builtinNativeFn("str/trim", biStrTrim))
  strScope.define("lower", builtinNativeFn("str/lower", biStrLower))
  strScope.define("upper", builtinNativeFn("str/upper", biStrUpper))
  strScope.define("byte_size", builtinNativeFn("str/byte_size", biStrByteSize))
  strScope.define("slice_bytes", builtinNativeFn("str/slice_bytes", biStrSliceBytes))
  strScope.define("to_utf8", builtinNativeFn("str/to_utf8", biStrToUtf8))
  strScope.define("from_utf8", builtinNativeFn("str/from_utf8", biStrFromUtf8))
  strScope.define("starts_with?", builtinNativeFn("str/starts_with?",
                                              biStrStartsWith))
  strScope.define("ends_with?", builtinNativeFn("str/ends_with?", biStrEndsWith))
  strScope.define("contains?", builtinNativeFn("str/contains?", biStrContains))
  root.define("str", newNamespace("str", strScope))
  let aotScope = newScope(root)
  aotScope.define("load", builtinNativeCallFn("aot/load", biAotLoad,
                                           acceptsNamed = false))
  root.define("aot", newNamespace("aot", aotScope))
  let htmlScope = newScope(root)
  htmlScope.define("escape", builtinNativeFn("html/escape", biHtmlEscape))
  htmlScope.define("attr_escape", builtinNativeFn("html/attr_escape", biHtmlEscape))
  htmlScope.define("render", builtinNativeCallFn("html/render", biHtmlRender,
                                              acceptsNamed = false))
  root.define("html", newNamespace("html", htmlScope))
  when not defined(geneWasm):
    let webScope = newScope(root)
    webScope.define("script", builtinNativeCallFn("web/script", biWebScript))
    webScope.define("load", builtinNativeCallFn("web/load", biWebLoad,
                                            acceptsNamed = false))
    webScope.define("stylesheet", builtinNativeCallFn("web/stylesheet",
                                                  biWebStylesheet,
                                                  acceptsNamed = false))
    webScope.define("asset_base", builtinNativeCallFn("web/asset_base",
                                                  biWebAssetBase,
                                                  acceptsNamed = false))
    webScope.define("set_asset_base", builtinNativeCallFn("web/set_asset_base",
                                                      biWebSetAssetBase,
                                                      acceptsNamed = false))
    webScope.define("set_source_maps", builtinNativeCallFn("web/set_source_maps",
                                                       biWebSetSourceMaps,
                                                       acceptsNamed = false))
    webScope.define("published_routes", builtinNativeCallFn("web/published_routes",
                                                        biWebPublishedRoutes,
                                                        acceptsNamed = false))
    root.define("web", newNamespace("web", webScope))
  let cssScope = newScope(root)
  cssScope.define("css", builtinNativeFn("css/css", biCss))
  cssScope.define("rule", builtinNativeFn("css/rule", biCssRule))
  cssScope.define("decl_value", builtinNativeFn("css/decl_value", biCssDeclValue))
  cssScope.define("media", builtinNativeFn("css/media", biCssMedia))
  cssScope.define("keyframes", builtinNativeFn("css/keyframes", biCssKeyframes))
  cssScope.define("frame", builtinNativeFn("css/frame", biCssFrame))
  cssScope.define("scoped", builtinNativeFn("css/scoped", biCssScoped))
  cssScope.define("class_name", builtinNativeFn("css/class_name", biCssClassName))
  cssScope.define("render", builtinNativeCallFn("css/render", biCssRender,
                                             acceptsNamed = false))
  root.define("css", newNamespace("css", cssScope))
  let pkgScope = newScope(root)
  pkgScope.define("application", builtinNativeCallFn("pkg/application",
                   biPkgApplication, acceptsNamed = false))
  pkgScope.define("canonical_digest", builtinNativeFn("pkg/canonical_digest",
                   biPkgCanonicalDigest))
  pkgScope.define("read_bytes", builtinNativeCallFn("pkg/read_bytes",
                   biPkgReadBytes))
  pkgScope.define("read_text", builtinNativeCallFn("pkg/read_text",
                   biPkgReadText))
  pkgScope.define("dependency", builtinNativeCallFn("pkg/dependency",
                   biPkgDependency, acceptsNamed = false))
  pkgScope.define("materialize", builtinNativeCallFn("pkg/materialize",
                   biPkgMaterialize, acceptsNamed = false))
  pkgScope.define("native_binary", builtinNativeCallFn("pkg/native_binary",
                   biPkgNativeBinary, acceptsNamed = false))
  pkgScope.define("native_module", builtinNativeCallFn("pkg/native_module",
                   biPkgNativeModule, acceptsNamed = false))
  pkgScope.define("MaterializedResource", materializedType)
  pkgScope.define("PackageResourceError", packageResourceError)
  root.define("pkg", newNamespace("pkg", pkgScope))
  let csvScope = newScope(root)
  csvScope.define("parse_rows", builtinNativeCallFn("csv/parse_rows",
                    biCsvParseRows))
  csvScope.define("encode_row", builtinNativeCallFn("csv/encode_row",
                    biCsvEncodeRow))
  csvScope.define("reader", builtinNativeCallFn("csv/reader", biCsvReader))
  csvScope.define("_feed", builtinNativeCallFn("csv/_feed", biCsvReaderFeed,
                    acceptsNamed = false))
  csvScope.define("_step", builtinNativeCallFn("csv/_step", biCsvReaderStep,
                    acceptsNamed = false))
  csvScope.define("_finish_next", builtinNativeCallFn("csv/_finish_next",
                    biCsvReaderFinishNext, acceptsNamed = false))
  csvScope.define("_source_closed", builtinNativeCallFn("csv/_source_closed",
                    biCsvReaderSourceClosed, acceptsNamed = false))
  csvScope.define("CsvError", csvError)
  let csvReaderType = newType("CsvReader", NIL, @[], @[], root,
                              repr = trNativeWrapper)
  root.define("CsvReader", csvReaderType)
  csvScope.define("CsvReader", csvReaderType)
  var csvReaderMessages = initTable[string, Value]()
  csvReaderMessages["next"] = builtinNativeCallFn("CsvReader/next",
    biCsvReaderNext, acceptsNamed = false)
  csvReaderType.setTypeOwnMessages(csvReaderMessages, NIL)
  root.define("csv", newNamespace("csv", csvScope))
  let pathScope = newScope(root)
  pathScope.define("join", builtinNativeCallFn("path/join", biPathJoin,
                                                  acceptsNamed = false))
  pathScope.define("normalize", builtinNativeCallFn("path/normalize",
                        biPathNormalize, acceptsNamed = false))
  pathScope.define("parent", builtinNativeCallFn("path/parent", biPathParent,
                                                  acceptsNamed = false))
  pathScope.define("name", builtinNativeCallFn("path/name", biPathName,
                                                acceptsNamed = false))
  pathScope.define("extension", builtinNativeCallFn("path/extension",
                        biPathExtension, acceptsNamed = false))
  pathScope.define("relative", builtinNativeCallFn("path/relative",
                        biPathRelative, acceptsNamed = false))
  pathScope.define("PathError", pathError)
  root.define("path", newNamespace("path", pathScope))
  let temporalScope = newScope(root)
  temporalScope.define("add_days", builtinNativeFn("temporal/add_days",
    biTemporalAddDays))
  temporalScope.define("add", builtinNativeFn("temporal/add", biTemporalAdd))
  temporalScope.define("difference", builtinNativeFn("temporal/difference",
    biTemporalDifference))
  temporalScope.define("to_utc", builtinNativeFn("temporal/to_utc",
    biTemporalToUtc))
  temporalScope.define("parse_rfc3339", builtinNativeFn(
    "temporal/parse_rfc3339", biTemporalParseRfc3339))
  temporalScope.define("format_rfc3339", builtinNativeFn(
    "temporal/format_rfc3339", biTemporalFormatRfc3339))
  temporalScope.define("_tzif_to_local", builtinNativeFn(
    "temporal/_tzif_to_local", biTemporalTzifToLocal))
  temporalScope.define("_tzif_resolve_local", builtinNativeFn(
    "temporal/_tzif_resolve_local", biTemporalTzifResolveLocal))
  root.define("temporal", newNamespace("temporal", temporalScope))
  let ioError = newType("IoError", NIL,
    @[TypeField(name: "message", typeExpr: newSym("Str"), scope: root),
      TypeField(name: "operation", typeExpr: newSym("Str"), scope: root),
      TypeField(name: "resource_id", optional: true,
                typeExpr: newSym("Int"), scope: root),
      TypeField(name: "cause", optional: true,
                typeExpr: newSym("Any"), scope: root),
      TypeField(name: "bytes_transferred", optional: true,
                typeExpr: newSym("Int"), scope: root)],
    @[errorProtocol], root)
  root.define("IoError", ioError)
  root.impls.add ProtocolImpl(protocol: errorProtocol, receiver: ioError)
  let ioBusy = newType("IoBusy", ioError, @[], @[], root)
  let ioClosed = newType("IoClosed", ioError, @[], @[], root)
  let ioBackpressure = newType("IoBackpressure", ioError, @[], @[], root)
  root.define("IoBusy", ioBusy)
  root.define("IoClosed", ioClosed)
  root.define("IoBackpressure", ioBackpressure)
  let ioScope = newScope(root)
  proc ioRequirement(name, source: string): Value =
    let proto = compileSource(source, "<builtin gene/io " & name & ">").functions[0]
    newFunction(name, proto.params, proto, ioScope)
  let asyncReader = newProtocol("AsyncReader", ["read"], signatures = [
    ioRequirement("AsyncReader:read",
      "(fn read [self max_bytes : Int] : (Task Bytes? Error) nil)")],
    scope = ioScope)
  let asyncWriter = newProtocol("AsyncWriter", ["write", "flush"],
    signatures = [
      ioRequirement("AsyncWriter:write",
        "(fn write [self data : Bytes] : (Task Int Error) nil)"),
      ioRequirement("AsyncWriter:flush",
        "(fn flush [self] : (Task Nil Error) nil)")],
    scope = ioScope)
  let ioResource = newProtocol("IoResource", ["close", "wait_closed"],
    signatures = [
      ioRequirement("IoResource:close",
        "(fn close [self] : Nil nil)"),
      ioRequirement("IoResource:wait_closed",
        "(fn wait_closed [self] : (Task Nil Error) nil)")],
    scope = ioScope)
  ioScope.define("AsyncReader", asyncReader)
  ioScope.define("AsyncWriter", asyncWriter)
  ioScope.define("IoResource", ioResource)
  ioScope.define("flush_stdout", builtinNativeFn("io/flush_stdout", biIoFlushStdout))
  csvScope.define("AsyncReader", asyncReader)
  csvScope.define("IoResource", ioResource)
  root.impls.add ProtocolImpl(protocol: ioResource,
    receiver: csvReaderType,
    messages: @[
      ImplMessage(message: ioResource.protocolMessages["close"],
        fn: builtinNativeCallFn("IoResource/close", biCsvReaderClose,
                                acceptsNamed = false)),
      ImplMessage(message: ioResource.protocolMessages["wait_closed"],
        fn: builtinNativeCallFn("IoResource/wait_closed", biCsvReaderWaitClosed,
                                acceptsNamed = false))])
  for name in ["IoError", "IoBusy", "IoClosed", "IoBackpressure"]:
    ioScope.define(name, root.vars[name])
  proc ioFunction(name, source: string): Value =
    let proto = compileSource(source, "<builtin gene/io " & name & ">").functions[0]
    functionForScopeStorage(newFunction(name, proto.params, proto, ioScope),
                            ioScope, binding = true)
  app.ioWriteAllHelper = ioFunction("write_all", """
    (fn write_all [writer data : Bytes]
      (spawn ^lane root
        (do
          (let total ($binary/size data))
          (var offset 0)
          (while (< offset total)
            (let left (- total offset))
            (let want (if (< left 1048576) left 1048576))
            (let part ($binary/slice data offset want))
            (let accepted (await (writer .AsyncWriter:write part)))
            (if (<= accepted 0)
              (fail (IoError ^message "writer made no progress"
                               ^operation "write_all"
                               ^bytes_transferred offset)))
            (if (> accepted want)
              (fail (IoError ^message "writer accepted more than offered"
                               ^operation "write_all"
                               ^bytes_transferred offset)))
            (set offset (+ offset accepted)))
          offset)))
  """)
  app.ioCopyHelper = ioFunction("copy", """
    (fn copy [reader writer, ^limit : Int, ^chunk_bytes : Int = 65536]
      (if (< limit 0)
        (fail (IoError ^message "copy limit must be nonnegative"
                         ^operation "copy")))
      (if (< chunk_bytes 1)
        (fail (IoError ^message "copy chunk_bytes must be positive"
                         ^operation "copy")))
      (if (> chunk_bytes 1048576)
        (fail (IoError ^message "copy chunk_bytes exceeds 1 MiB"
                         ^operation "copy")))
      (spawn ^lane root
        (do
          (var transferred 0)
          (while (< transferred limit)
            (let left (- limit transferred))
            (let want (if (< left chunk_bytes) left chunk_bytes))
            (let part (await (reader .AsyncReader:read want)))
            (if ($nil? part) (break))
            (let got ($binary/size part))
            (if (== got 0)
              (fail (IoError ^message "reader returned empty Bytes"
                               ^operation "copy"
                               ^bytes_transferred transferred)))
            (if (> got want)
              (fail (IoError ^message "reader exceeded requested chunk"
                               ^operation "copy"
                               ^bytes_transferred transferred)))
            (let written (await (write_all writer part)))
            (set transferred (+ transferred written)))
          transferred)))
  """)
  ioScope.define("write_all", builtinNativeCallFn("io/write_all", biIoWriteAll,
                     acceptsNamed = false))
  ioScope.define("copy", builtinNativeCallFn("io/copy", biIoCopy))
  ioScope.define("_retain_cleanup", builtinNativeCallFn(
    "io/_retain_cleanup", biIoRetainCleanup, acceptsNamed = false))
  let ioFileReaderType = newType("IoFileReader", NIL, @[], @[], root,
                                 repr = trNativeWrapper)
  root.define("IoFileReader", ioFileReaderType)
  ioScope.define("FileReader", ioFileReaderType)
  root.impls.add ProtocolImpl(protocol: asyncReader,
    receiver: ioFileReaderType,
    messages: @[ImplMessage(message: asyncReader.protocolMessages["read"],
      fn: builtinNativeCallFn("AsyncReader/read", biIoFileRead,
                              acceptsNamed = false))])
  root.impls.add ProtocolImpl(protocol: ioResource,
    receiver: ioFileReaderType,
    messages: @[
      ImplMessage(message: ioResource.protocolMessages["close"],
        fn: builtinNativeCallFn("IoResource/close", biIoFileClose,
                                acceptsNamed = false)),
      ImplMessage(message: ioResource.protocolMessages["wait_closed"],
        fn: builtinNativeCallFn("IoResource/wait_closed", biIoFileWaitClosed,
                                acceptsNamed = false))])
  ioScope.define("open_read", builtinNativeCallFn("io/open_read", biIoOpenRead,
                     acceptsNamed = false))
  let ioFileWriterType = newType("IoFileWriter", NIL, @[], @[], root,
                                 repr = trNativeWrapper)
  root.define("IoFileWriter", ioFileWriterType)
  ioScope.define("FileWriter", ioFileWriterType)
  root.impls.add ProtocolImpl(protocol: asyncWriter,
    receiver: ioFileWriterType,
    messages: @[
      ImplMessage(message: asyncWriter.protocolMessages["write"],
        fn: builtinNativeCallFn("AsyncWriter/write", biIoFileWrite,
                                acceptsNamed = false)),
      ImplMessage(message: asyncWriter.protocolMessages["flush"],
        fn: builtinNativeCallFn("AsyncWriter/flush", biIoFileFlush,
                                acceptsNamed = false))])
  root.impls.add ProtocolImpl(protocol: ioResource,
    receiver: ioFileWriterType,
    messages: @[
      ImplMessage(message: ioResource.protocolMessages["close"],
        fn: builtinNativeCallFn("IoResource/close", biIoFileClose,
                                acceptsNamed = false)),
      ImplMessage(message: ioResource.protocolMessages["wait_closed"],
        fn: builtinNativeCallFn("IoResource/wait_closed", biIoFileWaitClosed,
                                acceptsNamed = false))])
  ioScope.define("open_write", builtinNativeCallFn("io/open_write", biIoOpenWrite))
  let ioPipeReaderType = newType("IoPipeReader", NIL, @[], @[], root,
                                 repr = trNativeWrapper)
  let ioPipeWriterType = newType("IoPipeWriter", NIL, @[], @[], root,
                                 repr = trNativeWrapper)
  root.define("IoPipeReader", ioPipeReaderType)
  root.define("IoPipeWriter", ioPipeWriterType)
  ioScope.define("PipeReader", ioPipeReaderType)
  ioScope.define("PipeWriter", ioPipeWriterType)
  root.impls.add ProtocolImpl(protocol: asyncReader,
    receiver: ioPipeReaderType,
    messages: @[ImplMessage(message: asyncReader.protocolMessages["read"],
      fn: builtinNativeCallFn("AsyncReader/read", biIoFileRead,
                              acceptsNamed = false))])
  root.impls.add ProtocolImpl(protocol: asyncWriter,
    receiver: ioPipeWriterType,
    messages: @[
      ImplMessage(message: asyncWriter.protocolMessages["write"],
        fn: builtinNativeCallFn("AsyncWriter/write", biIoFileWrite,
                                acceptsNamed = false)),
      ImplMessage(message: asyncWriter.protocolMessages["flush"],
        fn: builtinNativeCallFn("AsyncWriter/flush", biIoFileFlush,
                                acceptsNamed = false))])
  for typ in [ioPipeReaderType, ioPipeWriterType]:
    root.impls.add ProtocolImpl(protocol: ioResource, receiver: typ,
      messages: @[
        ImplMessage(message: ioResource.protocolMessages["close"],
          fn: builtinNativeCallFn("IoResource/close", biIoFileClose,
                                  acceptsNamed = false)),
        ImplMessage(message: ioResource.protocolMessages["wait_closed"],
          fn: builtinNativeCallFn("IoResource/wait_closed", biIoFileWaitClosed,
                                  acceptsNamed = false))])
  ioScope.define("pipe", builtinNativeCallFn("io/pipe", biIoPipe,
                   acceptsNamed = false))
  let ioTcpStreamType = newType("IoTcpStream", NIL, @[], @[], root,
                                repr = trNativeWrapper)
  root.define("IoTcpStream", ioTcpStreamType)
  ioScope.define("TcpStream", ioTcpStreamType)
  root.impls.add ProtocolImpl(protocol: asyncReader,
    receiver: ioTcpStreamType,
    messages: @[ImplMessage(message: asyncReader.protocolMessages["read"],
      fn: builtinNativeCallFn("AsyncReader/read", biIoFileRead,
                              acceptsNamed = false))])
  root.impls.add ProtocolImpl(protocol: asyncWriter,
    receiver: ioTcpStreamType,
    messages: @[
      ImplMessage(message: asyncWriter.protocolMessages["write"],
        fn: builtinNativeCallFn("AsyncWriter/write", biIoFileWrite,
                                acceptsNamed = false)),
      ImplMessage(message: asyncWriter.protocolMessages["flush"],
        fn: builtinNativeCallFn("AsyncWriter/flush", biIoFileFlush,
                                acceptsNamed = false))])
  root.impls.add ProtocolImpl(protocol: ioResource,
    receiver: ioTcpStreamType,
    messages: @[
      ImplMessage(message: ioResource.protocolMessages["close"],
        fn: builtinNativeCallFn("IoResource/close", biIoFileClose,
                                acceptsNamed = false)),
      ImplMessage(message: ioResource.protocolMessages["wait_closed"],
        fn: builtinNativeCallFn("IoResource/wait_closed", biIoFileWaitClosed,
                                acceptsNamed = false))])
  ioScope.define("tcp_connect", builtinNativeCallFn("io/tcp_connect",
                   biIoTcpConnect))
  let ioTcpListenerType = newType("IoTcpListener", NIL, @[], @[], root,
                                  repr = trNativeWrapper)
  root.define("IoTcpListener", ioTcpListenerType)
  ioScope.define("TcpListener", ioTcpListenerType)
  var tcpListenerMessages = initTable[string, Value]()
  tcpListenerMessages["accept"] = builtinNativeCallFn("TcpListener/accept",
    biIoTcpAccept, acceptsNamed = false)
  tcpListenerMessages["local_port"] = builtinNativeCallFn(
    "TcpListener/local_port", biIoTcpLocalPort, acceptsNamed = false)
  ioTcpListenerType.setTypeOwnMessages(tcpListenerMessages, NIL)
  root.impls.add ProtocolImpl(protocol: ioResource,
    receiver: ioTcpListenerType,
    messages: @[
      ImplMessage(message: ioResource.protocolMessages["close"],
        fn: builtinNativeCallFn("IoResource/close", biIoFileClose,
                                acceptsNamed = false)),
      ImplMessage(message: ioResource.protocolMessages["wait_closed"],
        fn: builtinNativeCallFn("IoResource/wait_closed", biIoFileWaitClosed,
                                acceptsNamed = false))])
  ioScope.define("tcp_listen", builtinNativeCallFn("io/tcp_listen",
                   biIoTcpListen))
  # Deterministic native adapter for protocol and close/cancel conformance.
  # Its completion is controlled by gene/io/testing, so tests can hold an OS-
  # shaped operation past user Task cancellation without a timing race.
  let ioTestType = newType("IoTestResource", NIL, @[], @[], root,
                           repr = trNativeWrapper)
  root.define("IoTestResource", ioTestType)
  root.impls.add ProtocolImpl(protocol: asyncReader, receiver: ioTestType,
    messages: @[ImplMessage(message: asyncReader.protocolMessages["read"],
      fn: builtinNativeCallFn("AsyncReader/read", biIoTestingRead,
                              acceptsNamed = false))])
  root.impls.add ProtocolImpl(protocol: asyncWriter, receiver: ioTestType,
    messages: @[
      ImplMessage(message: asyncWriter.protocolMessages["write"],
        fn: builtinNativeCallFn("AsyncWriter/write", biIoTestingWrite,
                                acceptsNamed = false)),
      ImplMessage(message: asyncWriter.protocolMessages["flush"],
        fn: builtinNativeCallFn("AsyncWriter/flush", biIoTestingFlush,
                                acceptsNamed = false))])
  root.impls.add ProtocolImpl(protocol: ioResource, receiver: ioTestType,
    messages: @[
      ImplMessage(message: ioResource.protocolMessages["close"],
        fn: builtinNativeCallFn("IoResource/close", biIoTestingClose,
                                acceptsNamed = false)),
      ImplMessage(message: ioResource.protocolMessages["wait_closed"],
        fn: builtinNativeCallFn("IoResource/wait_closed",
                                biIoTestingWaitClosed,
                                acceptsNamed = false))])
  let ioTestingScope = newScope(ioScope)
  ioTestingScope.define("new", builtinNativeCallFn("io/testing/new",
                         biIoTestingNew))
  ioTestingScope.define("complete_read", builtinNativeCallFn(
    "io/testing/complete_read", biIoTestingCompleteRead,
    acceptsNamed = false))
  ioTestingScope.define("complete_write", builtinNativeCallFn(
    "io/testing/complete_write", biIoTestingCompleteWrite,
    acceptsNamed = false))
  ioTestingScope.define("written", builtinNativeCallFn("io/testing/written",
                         biIoTestingWritten, acceptsNamed = false))
  ioTestingScope.define("fail_close", builtinNativeCallFn(
    "io/testing/fail_close", biIoTestingFailClose, acceptsNamed = false))
  ioTestingScope.define("state", builtinNativeCallFn("io/testing/state",
                         biIoTestingState, acceptsNamed = false))
  ioTestingScope.define("socket_buffer", builtinNativeCallFn(
    "io/testing/socket_buffer", biIoTestingSocketBuffer,
    acceptsNamed = false))
  ioScope.define("testing", newNamespace("io/testing", ioTestingScope))
  root.define("io", newNamespace("io", ioScope))
  proc csvFunction(name, source: string): Value =
    let proto = compileSource(source, "<builtin gene/csv " & name & ">").functions[0]
    functionForScopeStorage(newFunction(name, proto.params, proto, csvScope),
                            csvScope, binding = true)
  app.csvNextHelper = csvFunction("next", """
    (fn next [reader source]
      (spawn ^lane root
        (try
          (do
            (var step ($csv/_step reader))
            (while (== step/0 0)
              (let chunk (await (source .AsyncReader:read 65536)))
              ($csv/_feed reader chunk)
              (set step ($csv/_step reader)))
            step/1)
          ensure ($csv/_finish_next reader))))
  """)
  app.csvWaitClosedHelper = csvFunction("wait_closed", """
    (fn wait_closed [reader signal]
      (spawn ^lane root
        (do
          (signal .join)
          (let source_closed ($csv/_source_closed reader))
          (if ($nil? source_closed)
            nil
            (match (source_closed .join)
              (when (TaskOutcome/ok _) nil)
              (when (TaskOutcome/error error) (fail error))
              (when (TaskOutcome/cancelled)
                (fail (CsvError ^message "upstream close was cancelled")))
              (else (fail (CsvError ^message "upstream close did not complete")))))
          nil)))
  """)
  let urlScope = newScope(root)
  urlScope.define("encode_component",
                  builtinNativeFn("url/encode_component", biUrlEncodeComponent))
  urlScope.define("decode_component",
                  builtinNativeCallFn("url/decode_component", biUrlDecodeComponent,
                                  acceptsNamed = false))
  urlScope.define("parse_query",
                  builtinNativeCallFn("url/parse_query", biUrlParseQuery,
                                  acceptsNamed = false))
  urlScope.define("format_query",
                  builtinNativeFn("url/format_query", biUrlFormatQuery))
  urlScope.define("UrlError", root.vars["UrlError"])
  root.define("url", newNamespace("url", urlScope))
  let httpScope = newScope(root)
  let strField = proc (name: string): TypeField =
    TypeField(name: name, optional: false, typeExpr: newSym("Str"),
              scope: root)
  let requestType = newType("Request", NIL,
                            @[strField("method"), strField("path"),
                              strField("query"),
                              TypeField(name: "params", optional: false,
                                        typeExpr: newSym("Map"), scope: root),
                              TypeField(name: "headers", optional: false,
                                        typeExpr: newSym("Map"), scope: root),
                              strField("body")],
                            @[], root)
  httpScope.define("Request", requestType)
  let streamRequestType = newType("StreamRequest", NIL,
    @[strField("method"), strField("path"), strField("query"),
      TypeField(name: "params", optional: false,
                typeExpr: newSym("Map"), scope: root),
      TypeField(name: "headers", optional: false,
                typeExpr: newSym("Map"), scope: root),
      TypeField(name: "body", optional: false,
                typeExpr: asyncReader, scope: root)], @[], root)
  httpScope.define("StreamRequest", streamRequestType)
  let responseType = newType("Response", NIL,
                             @[TypeField(name: "status", optional: false,
                                         typeExpr: newSym("Int"),
                                         scope: root),
                               TypeField(name: "headers", optional: true,
                                         typeExpr: newSym("Map"),
                                         scope: root),
                               TypeField(name: "body", optional: true,
                                         typeExpr: newSym("Str"),
                                         scope: root)],
                             @[], root)
  httpScope.define("Response", responseType)
  let streamResponseType = newType("StreamResponse", NIL,
    @[TypeField(name: "status", typeExpr: newSym("Int"), scope: root),
      TypeField(name: "headers", typeExpr: newSym("Map"), scope: root),
      TypeField(name: "body", typeExpr: asyncReader, scope: root),
      TypeField(name: "content_length", optional: true,
                typeExpr: newSym("Int"), scope: root),
      TypeField(name: "max_bytes", typeExpr: newSym("Int"), scope: root),
      TypeField(name: "own_reader", typeExpr: newSym("Bool"), scope: root)],
    @[], root)
  httpScope.define("StreamResponse", streamResponseType)
  var serverMessages = initTable[string, Value]()
  serverMessages["reload_tls"] = builtinNativeCallFn(
    "Server/reload_tls", biHttpReloadTls, acceptsNamed = false)
  let serverType = newType("Server", NIL,
                           @[TypeField(name: "host", optional: true,
                                       typeExpr: newSym("Str"), scope: root),
                             TypeField(name: "port", optional: false,
                                       typeExpr: newSym("Int"), scope: root),
                             TypeField(name: "tls", optional: true,
                                       typeExpr: newSym("Map"), scope: root)],
                           @[], root, messages = serverMessages)
  httpScope.define("Server", serverType)
  let requestMsgType = newType("RequestMsg", NIL,
                               @[TypeField(name: "req", optional: false,
                                           typeExpr: newSym("Any"),
                                           scope: root),
                                 TypeField(name: "reply", optional: false,
                                           typeExpr: newSym("Any"),
                                           scope: root)],
                               @[], root)
  httpScope.define("RequestMsg", requestMsgType)
  httpScope.define("serve", builtinNativeCallFn("http/serve", biHttpServe))
  httpScope.define("listen", builtinNativeCallFn("http/listen", biHttpListen))
  httpScope.define("stop", builtinNativeCallFn("http/stop", biHttpStop))
  httpScope.define("status", builtinNativeCallFn("http/status", biHttpStatus))
  httpScope.define("route", builtinNativeCallFn("http/route", biHttpRoute))
  httpScope.define("actor_pool", builtinNativeCallFn("http/actor_pool",
                                                 biHttpActorPool))
  httpScope.define("supervisor_policy",
                   builtinNativeCallFn("http/supervisor_policy",
                                   biHttpSupervisorPolicy))
  httpScope.define("bytes", builtinNativeCallFn("http/bytes", biHttpBytes,
                                            acceptsNamed = false))
  httpScope.define("stream", builtinNativeCallFn("http/stream", biHttpStream))
  httpScope.define("text", builtinNativeCallFn("http/text", biHttpText,
                                           acceptsNamed = false))
  httpScope.define("html", builtinNativeCallFn("http/html", biHttpHtml,
                                           acceptsNamed = false))
  httpScope.define("json", builtinNativeCallFn("http/json", biHttpJson,
                                           acceptsNamed = false))
  httpScope.define("redirect", builtinNativeCallFn("http/redirect", biHttpRedirect,
                                               acceptsNamed = false))
  httpScope.define("not_found", builtinNativeCallFn("http/not_found",
                                                biHttpNotFound,
                                                acceptsNamed = false))
  httpScope.define("ws_accept", builtinNativeCallFn("http/ws_accept",
                                                biHttpWsAccept))
  httpScope.define("ws_send", builtinNativeCallFn("http/ws_send", biHttpWsSend,
                                              acceptsNamed = false))
  httpScope.define("ws_close", builtinNativeCallFn("http/ws_close", biHttpWsClose,
                                               acceptsNamed = false))
  httpScope.define("ws_queued", builtinNativeCallFn("http/ws_queued",
                                                biHttpWsQueued,
                                                acceptsNamed = false))
  httpScope.define("HttpError", root.vars["HttpError"])
  let httpClientScope = newScope(root)
  httpClientScope.define("request",
    builtinNativeCallFn("net/http_client/request", biHttpClientRequest))
  httpClientScope.define("stream",
    builtinNativeCallFn("net/http_client/stream", biHttpClientStream))
  httpClientScope.define("HttpClientError", httpClientError)
  let ownedHttpClientType = newType("OwnedHttpClient", NIL, @[], @[], root,
                                    repr = trNativeWrapper)
  root.define("OwnedHttpClient", ownedHttpClientType)
  httpClientScope.define("Client", ownedHttpClientType)
  var ownedHttpMethods = initTable[string, Value]()
  ownedHttpMethods["request"] = builtinNativeCallFn("Client/request",
    biOwnedHttpClientRequest)
  ownedHttpMethods["stream"] = builtinNativeCallFn("Client/stream",
    biOwnedHttpClientStream)
  ownedHttpClientType.setTypeOwnMessages(ownedHttpMethods, NIL)
  let ownedHttpBodyType = newType("OwnedHttpBody", NIL, @[], @[], root,
                                  repr = trNativeWrapper)
  root.define("OwnedHttpBody", ownedHttpBodyType)
  httpClientScope.define("BodyReader", ownedHttpBodyType)
  root.impls.add ProtocolImpl(protocol: asyncReader,
    receiver: ownedHttpBodyType,
    messages: @[ImplMessage(message: asyncReader.protocolMessages["read"],
      fn: builtinNativeCallFn("AsyncReader/read", biOwnedHttpBodyRead,
                              acceptsNamed = false))])
  root.impls.add ProtocolImpl(protocol: ioResource,
    receiver: ownedHttpBodyType,
    messages: @[
      ImplMessage(message: ioResource.protocolMessages["close"],
        fn: builtinNativeCallFn("IoResource/close", biOwnedHttpBodyClose,
                                acceptsNamed = false)),
      ImplMessage(message: ioResource.protocolMessages["wait_closed"],
        fn: builtinNativeCallFn("IoResource/wait_closed",
                                biOwnedHttpBodyWaitClosed,
                                acceptsNamed = false))])
  httpClientScope.define("open", builtinNativeCallFn("net/http_client/open",
    biOwnedHttpClientOpen))
  root.impls.add ProtocolImpl(protocol: ioResource,
    receiver: ownedHttpClientType,
    messages: @[
      ImplMessage(message: ioResource.protocolMessages["close"],
        fn: builtinNativeCallFn("IoResource/close",
                                biOwnedHttpClientClose,
                                acceptsNamed = false)),
      ImplMessage(message: ioResource.protocolMessages["wait_closed"],
        fn: builtinNativeCallFn("IoResource/wait_closed",
                                biOwnedHttpClientWaitClosed,
                                acceptsNamed = false))])
  let ingressType = newType("NativeIngressSubscription", NIL, @[], @[], root,
                            repr = trNativeWrapper)
  root.define("NativeIngressSubscription", ingressType)
  let ingressScope = newScope(root)
  ingressScope.define("Subscription", ingressType)
  ingressScope.define("open", builtinNativeCallFn("native/ingress/open",
    biNativeIngressOpen))
  let nativeScope = newScope(root)
  nativeScope.define("ingress", newNamespace("native/ingress", ingressScope))
  root.define("native", newNamespace("native", nativeScope))
  var ingressMethods = initTable[string, Value]()
  ingressMethods["status"] = builtinNativeCallFn(
    "NativeIngressSubscription/status", biNativeIngressStatus,
    acceptsNamed = false)
  ingressType.setTypeOwnMessages(ingressMethods, NIL)
  root.impls.add ProtocolImpl(protocol: ioResource,
    receiver: ingressType,
    messages: @[
      ImplMessage(message: ioResource.protocolMessages["close"],
        fn: builtinNativeCallFn("IoResource/close", biNativeIngressClose,
                                acceptsNamed = false)),
      ImplMessage(message: ioResource.protocolMessages["wait_closed"],
        fn: builtinNativeCallFn("IoResource/wait_closed",
                                biNativeIngressWaitClosed,
                                acceptsNamed = false))])
  let nativeModuleType = newType("NativeModule", NIL, @[], @[], root,
                                 repr = trNativeWrapper)
  root.define("NativeModule", nativeModuleType)
  var nativeModuleMethods = initTable[string, Value]()
  nativeModuleMethods["module"] = builtinNativeCallFn(
    "NativeModule/module", biNativeModuleModule, acceptsNamed = false)
  nativeModuleMethods["status"] = builtinNativeCallFn(
    "NativeModule/status", biNativeModuleStatus, acceptsNamed = false)
  nativeModuleType.setTypeOwnMessages(nativeModuleMethods, NIL)
  root.impls.add ProtocolImpl(protocol: ioResource,
    receiver: nativeModuleType,
    messages: @[
      ImplMessage(message: ioResource.protocolMessages["close"],
        fn: builtinNativeCallFn("IoResource/close", biNativeModuleClose,
                                acceptsNamed = false)),
      ImplMessage(message: ioResource.protocolMessages["wait_closed"],
        fn: builtinNativeCallFn("IoResource/wait_closed",
                                biNativeModuleWaitClosed,
                                acceptsNamed = false))])
  # Extend the `net` namespace buildBuiltins already created (the raw TCP ops)
  # instead of rebinding the name, so the TCP ops and `net/http` are members
  # of one namespace.
  let netLowerScope = root.vars["net"].nsScope
  netLowerScope.define("http", newNamespace("net/http", httpScope))
  netLowerScope.define("http_client",
                       newNamespace("net/http_client", httpClientScope))

  # db: shared protocol + error type; sqlite/postgres backends implement it.
  # DbError lives at the root so native raise sites resolve the type head and
  # `catch DbError` matches and `$err/message` reads the detail; backend impls live on their
  # namespace scopes so only importing programs pay protocol-dispatch cost.
  let dbError = newType("DbError", NIL,
                        @[TypeField(name: "message", optional: false,
                                    typeExpr: newSym("Str"), scope: root)],
                        @[errorProtocol], root)
  root.define("DbError", dbError)
  root.impls.add ProtocolImpl(protocol: errorProtocol, receiver: dbError)
  let dbProtocol = newProtocol("Db", ["exec", "query", "query_one", "execute",
                                      "transaction", "close", "closed?"])
  let dbMessages = dbProtocol.protocolMessages
  let dbScope = newScope(root)
  dbScope.define("Db", dbProtocol)
  dbScope.define("DbError", dbError)
  # Native wrappers (design §16.6): the props hold an owned connection pointer,
  # so only the backend's `open` may create one. The marker is what rejects
  # `(SqliteDb)`, a value that would pass the nominal boundary and fail only at
  # its first query.
  #
  # The schema is declared rather than empty, and the backends build instances
  # through `newNativeWrapper`, so the shipped surfaces satisfy the same
  # invariant an out-of-tree binding does — including the exact owned-pointer
  # flavour and target, which is what stops a postgres handle from being
  # installed in a SqliteDb.
  let sqliteDbType = newType("SqliteDb", NIL,
    @[ownedHandleField(root, "sqlite3"),
      TypeField(name: "backend", optional: false, typeExpr: newSym("Str"),
                scope: root),
      TypeField(name: "path", optional: false, typeExpr: newSym("Str"),
                scope: root),
      # "file" for an `open_file` connection; absent for the whole-image one.
      TypeField(name: "storage", optional: true, typeExpr: newSym("Str"),
                scope: root)],
    @[dbProtocol], root, repr = trNativeWrapper)
  root.define("SqliteDb", sqliteDbType)
  let postgresDbType = newType("PostgresDb", NIL,
    @[ownedHandleField(root, "PGconn"),
      TypeField(name: "backend", optional: false, typeExpr: newSym("Str"),
                scope: root),
      TypeField(name: "conninfo", optional: false, typeExpr: newSym("Str"),
                scope: root)],
    @[dbProtocol], root, repr = trNativeWrapper)
  root.define("PostgresDb", postgresDbType)
  let dbSqliteScope = newScope(root)
  dbSqliteScope.define("open", builtinNativeCallFn("sqlite/open", biSqliteOpen,
                                               acceptsNamed = false))
  dbSqliteScope.define("open_file", builtinNativeCallFn("sqlite/open_file",
                                                    biSqliteOpenFile))
  dbSqliteScope.define("visit_text_rows",
    builtinNativeCallFn("sqlite/visit_text_rows", biSqliteVisitTextRows, acceptsNamed = false))
  dbSqliteScope.define("SqliteDb", sqliteDbType)
  dbSqliteScope.define("Db", dbProtocol)
  dbSqliteScope.define("DbError", dbError)
  root.impls.add ProtocolImpl(
    protocol: dbProtocol, receiver: sqliteDbType,
    messages: @[
      ImplMessage(message: dbMessages["exec"],
                  fn: builtinNativeCallFn("Db/exec", biSqliteExec,
                                      acceptsNamed = false)),
      ImplMessage(message: dbMessages["query"],
                  fn: builtinNativeCallFn("Db/query", biSqliteQuery,
                                      acceptsNamed = false)),
      ImplMessage(message: dbMessages["query_one"],
                  fn: builtinNativeCallFn("Db/query_one", biSqliteQueryOne,
                                      acceptsNamed = false)),
      ImplMessage(message: dbMessages["execute"],
                  fn: builtinNativeCallFn("Db/execute", biSqliteExecute,
                                      acceptsNamed = false)),
      ImplMessage(message: dbMessages["transaction"],
                  fn: builtinNativeCallFn("Db/transaction", biSqliteTransaction,
                                      acceptsNamed = false)),
      ImplMessage(message: dbMessages["close"],
                  fn: builtinNativeCallFn("Db/close", biDbClose,
                                      acceptsNamed = false)),
      ImplMessage(message: dbMessages["closed?"],
                  fn: builtinNativeCallFn("Db/closed?", biDbClosed,
                                      acceptsNamed = false))])
  let dbPostgresScope = newScope(root)
  dbPostgresScope.define("open", builtinNativeCallFn("postgres/open",
                                                 biPostgresOpen,
                                                 acceptsNamed = false))
  dbPostgresScope.define("PostgresDb", postgresDbType)
  dbPostgresScope.define("Db", dbProtocol)
  dbPostgresScope.define("DbError", dbError)
  root.impls.add ProtocolImpl(
    protocol: dbProtocol, receiver: postgresDbType,
    messages: @[
      ImplMessage(message: dbMessages["exec"],
                  fn: builtinNativeCallFn("Db/exec", biPostgresExec,
                                      acceptsNamed = false)),
      ImplMessage(message: dbMessages["query"],
                  fn: builtinNativeCallFn("Db/query", biPostgresQuery,
                                      acceptsNamed = false)),
      ImplMessage(message: dbMessages["query_one"],
                  fn: builtinNativeCallFn("Db/query_one", biPostgresQueryOne,
                                      acceptsNamed = false)),
      ImplMessage(message: dbMessages["execute"],
                  fn: builtinNativeCallFn("Db/execute", biPostgresExecute,
                                      acceptsNamed = false)),
      ImplMessage(message: dbMessages["transaction"],
                  fn: builtinNativeCallFn("Db/transaction", biPostgresTransaction,
                                      acceptsNamed = false)),
      ImplMessage(message: dbMessages["close"],
                  fn: builtinNativeCallFn("Db/close", biDbClose,
                                      acceptsNamed = false)),
      ImplMessage(message: dbMessages["closed?"],
                  fn: builtinNativeCallFn("Db/closed?", biDbClosed,
                                      acceptsNamed = false))])
  dbScope.define("sqlite", newNamespace("db/sqlite", dbSqliteScope))
  dbScope.define("postgres", newNamespace("db/postgres", dbPostgresScope))
  root.define("db", newNamespace("db", dbScope))

  # store: durable key -> serde text over interchangeable backends
  # (docs/stdlib.md). Backend namespaces mirror db/sqlite.
  let storeError = newType("StoreError", NIL,
                           @[TypeField(name: "kind", optional: false,
                                       typeExpr: newSym("Sym"), scope: root),
                             TypeField(name: "message", optional: false,
                                       typeExpr: newSym("Str"), scope: root),
                             TypeField(name: "key", optional: true,
                                       typeExpr: newSym("Str"), scope: root)],
                           @[errorProtocol], root)
  root.define("StoreError", storeError)
  root.impls.add ProtocolImpl(protocol: errorProtocol, receiver: storeError)
  let storeProtocol = newProtocol("Store", ["put", "get", "has?", "delete",
                                            "keys", "clear", "checkpoint",
                                            "load_checkpoint", "close"])
  let storeMessages = storeProtocol.protocolMessages
  let storeField = proc (name, typ: string): TypeField =
    TypeField(name: name, optional: false, typeExpr: newSym(typ), scope: root)
  let sqliteStoreType = newType("SqliteStore", NIL,
    @[storeField("db", "SqliteDb"), storeField("table", "Str"),
      storeField("key_column", "Str"), storeField("data_column", "Str"),
      storeField("mode", "Sym"), storeField("policy", "Any"),
      storeField("closed", "Any")],
    @[storeProtocol], root, repr = trNativeWrapper)
  let fsStoreType = newType("FsStore", NIL,
    @[storeField("root", "Str"),
      storeField("mode", "Sym"), storeField("policy", "Any"),
      storeField("closed", "Any")],
    @[storeProtocol], root, repr = trNativeWrapper)
  root.define("SqliteStore", sqliteStoreType)
  root.define("FsStore", fsStoreType)
  let storeScope = newScope(root)
  storeScope.define("Store", storeProtocol)
  storeScope.define("StoreError", storeError)
  let storeSqliteScope = newScope(root)
  storeSqliteScope.define("open", builtinNativeCallFn("store/sqlite/open",
                                                  biStoreSqliteOpen))
  storeSqliteScope.define("Store", storeProtocol)
  storeSqliteScope.define("StoreError", storeError)
  storeSqliteScope.define("SqliteStore", sqliteStoreType)
  root.impls.add ProtocolImpl(
    protocol: storeProtocol, receiver: sqliteStoreType,
    messages: @[
      ImplMessage(message: storeMessages["put"],
                  fn: builtinNativeCallFn("Store/put", biStorePut)),
      ImplMessage(message: storeMessages["get"],
                  fn: builtinNativeCallFn("Store/get", biStoreGet)),
      ImplMessage(message: storeMessages["has?"],
                  fn: builtinNativeCallFn("Store/has?", biStoreHas,
                                      acceptsNamed = false)),
      ImplMessage(message: storeMessages["delete"],
                  fn: builtinNativeCallFn("Store/delete", biStoreDelete,
                                      acceptsNamed = false)),
      ImplMessage(message: storeMessages["keys"],
                  fn: builtinNativeCallFn("Store/keys", biStoreKeys,
                                      acceptsNamed = false)),
      ImplMessage(message: storeMessages["clear"],
                  fn: builtinNativeCallFn("Store/clear", biStoreClear,
                                      acceptsNamed = false)),
      ImplMessage(message: storeMessages["checkpoint"],
                  fn: builtinNativeCallFn("Store/checkpoint", biStoreCheckpoint,
                                      acceptsNamed = false)),
      ImplMessage(message: storeMessages["load_checkpoint"],
                  fn: builtinNativeCallFn("Store/load_checkpoint",
                                      biStoreLoadCheckpoint,
                                      acceptsNamed = false)),
      ImplMessage(message: storeMessages["close"],
                  fn: builtinNativeCallFn("Store/close", biStoreClose,
                                      acceptsNamed = false))])
  let storeFsScope = newScope(root)
  storeFsScope.define("open", builtinNativeCallFn("store/fs/open", biStoreFsOpen))
  storeFsScope.define("Store", storeProtocol)
  storeFsScope.define("StoreError", storeError)
  storeFsScope.define("FsStore", fsStoreType)
  root.impls.add ProtocolImpl(
    protocol: storeProtocol, receiver: fsStoreType,
    messages: @[
      ImplMessage(message: storeMessages["put"],
                  fn: builtinNativeCallFn("Store/put", biStorePut)),
      ImplMessage(message: storeMessages["get"],
                  fn: builtinNativeCallFn("Store/get", biStoreGet)),
      ImplMessage(message: storeMessages["has?"],
                  fn: builtinNativeCallFn("Store/has?", biStoreHas,
                                      acceptsNamed = false)),
      ImplMessage(message: storeMessages["delete"],
                  fn: builtinNativeCallFn("Store/delete", biStoreDelete,
                                      acceptsNamed = false)),
      ImplMessage(message: storeMessages["keys"],
                  fn: builtinNativeCallFn("Store/keys", biStoreKeys,
                                      acceptsNamed = false)),
      ImplMessage(message: storeMessages["clear"],
                  fn: builtinNativeCallFn("Store/clear", biStoreClear,
                                      acceptsNamed = false)),
      ImplMessage(message: storeMessages["checkpoint"],
                  fn: builtinNativeCallFn("Store/checkpoint", biStoreCheckpoint,
                                      acceptsNamed = false)),
      ImplMessage(message: storeMessages["load_checkpoint"],
                  fn: builtinNativeCallFn("Store/load_checkpoint",
                                      biStoreLoadCheckpoint,
                                      acceptsNamed = false)),
      ImplMessage(message: storeMessages["close"],
                  fn: builtinNativeCallFn("Store/close", biStoreClose,
                                      acceptsNamed = false))])
  storeScope.define("sqlite", newNamespace("store/sqlite", storeSqliteScope))
  storeScope.define("fs", newNamespace("store/fs", storeFsScope))
  root.define("store", newNamespace("store", storeScope))

  let cryptoScope = newScope(root)
  cryptoScope.define("sha256", builtinNativeCallFn("crypto/sha256",
                                               biCryptoSha256,
                                               acceptsNamed = false))
  cryptoScope.define("random_hex", builtinNativeCallFn("crypto/random_hex",
                                                   biCryptoRandomHex,
                                                   acceptsNamed = false))
  cryptoScope.define("secure_equal?", builtinNativeCallFn("crypto/secure_equal?",
                                                      biCryptoSecureEqual,
                                                      acceptsNamed = false))
  root.define("crypto", newNamespace("crypto", cryptoScope))

  # os: env, subprocess, line input (docs/stdlib.md "Module Layout"). 
  let osScope = newScope(root)
  osScope.define("get_env", builtinNativeCallFn("os/get_env", biOsGetEnv,
                 acceptsNamed = false))
  osScope.define("env?", builtinNativeCallFn("os/env?", biOsEnvOpt,
                 acceptsNamed = false))
  osScope.define("executable_path",
                 builtinNativeCallFn("os/executable_path", biOsExecutablePath,
                                 acceptsNamed = false))
  osScope.define("launch_dir",
                 builtinNativeCallFn("os/launch_dir", biOsLaunchDir,
                                 acceptsNamed = false))
  osScope.define("set_cwd", builtinNativeCallFn("os/set_cwd", biOsSetCwd,
                                              acceptsNamed = false))
  osScope.define("exec", builtinNativeCallFn("os/exec", biOsExec))
  osScope.define("exec_stream", builtinNativeCallFn("os/exec_stream", biOsExecStream))
  osScope.define("exec_stdio", builtinNativeCallFn("os/exec_stdio", biOsExecStdio))
  osScope.define("exec_async", builtinNativeCallFn("os/exec_async", biOsExecAsync))
  osScope.define("exec_stream_async",
                 builtinNativeCallFn("os/exec_stream_async", biOsExecStreamAsync))
  osScope.define("exec_stdio_async",
                 builtinNativeCallFn("os/exec_stdio_async", biOsExecStdioAsync))
  osScope.define("begin_interrupt",
                 builtinNativeFn("os/begin_interrupt", biOsBeginInterrupt))
  osScope.define("take_interrupt",
                 builtinNativeFn("os/take_interrupt", biOsTakeInterrupt))
  osScope.define("end_interrupt",
                 builtinNativeFn("os/end_interrupt", biOsEndInterrupt))
  osScope.define("monotonic_ms",
                 builtinNativeCallFn("os/monotonic_ms", biOsMonotonicMs,
                                 acceptsNamed = false))
  osScope.define("wall_ms",
                 builtinNativeCallFn("os/wall_ms", biOsWallMs,
                                 acceptsNamed = false))
  osScope.define("process_id",
                 builtinNativeCallFn("os/process_id", biOsProcessId,
                                 acceptsNamed = false))
  osScope.define("exit", builtinNativeCallFn("os/exit", biOsExit,
                                            acceptsNamed = false))
  osScope.define("stdin_tty?", builtinNativeFn("os/stdin_tty?", biOsStdinTty))
  osScope.define("stdout_tty?", builtinNativeFn("os/stdout_tty?", biOsStdoutTty))
  osScope.define("read_line", builtinNativeCallFn("os/read_line", biOsReadLine,
                                            acceptsNamed = false))
  osScope.define("read_input", builtinNativeCallFn("os/read_input", biOsReadInput))
  osScope.define("refresh_input", builtinNativeCallFn("os/refresh_input", biOsRefreshInput))
  osScope.define("close_input", builtinNativeFn("os/close_input", biOsCloseInput))
  osScope.define("OsError", osError)
  root.define("os", newNamespace("os", osScope))

  # Local interactive terminal authority. The Session owns a PTY process and
  # a libvterm state machine; only attributed cells are exposed to curses.
  # A native wrapper: `id` addresses a PTY process in the session table, so a
  # forged Session would reach native state the program never opened.
  let terminalSessionType = newType("TerminalSession", NIL,
    @[TypeField(name: "id", optional: false, typeExpr: newSym("Int"),
                scope: root),
      TypeField(name: "closed", optional: false, typeExpr: newSym("Any"),
                scope: root)], @[], root, repr = trNativeWrapper)
  root.define("TerminalSession", terminalSessionType)
  let terminalScope = newScope(root)
  terminalScope.define("Session", terminalSessionType)
  terminalScope.define("TerminalError", terminalError)
  terminalScope.define("open", builtinNativeCallFn("terminal/open", biTerminalOpen))
  terminalScope.define("pump", builtinNativeCallFn("terminal/pump", biTerminalPump))
  terminalScope.define("next_update",
    builtinNativeCallFn("terminal/next_update", biTerminalNextUpdate))
  terminalScope.define("snapshot",
    builtinNativeCallFn("terminal/snapshot", biTerminalSnapshot,
                    acceptsNamed = false))
  terminalScope.define("capture_text",
    builtinNativeCallFn("terminal/capture_text", biTerminalCaptureText))
  terminalScope.define("write",
    builtinNativeCallFn("terminal/write", biTerminalWrite))
  terminalScope.define("key", builtinNativeCallFn("terminal/key", biTerminalKey))
  terminalScope.define("paste",
    builtinNativeCallFn("terminal/paste", biTerminalPaste))
  terminalScope.define("focus",
    builtinNativeCallFn("terminal/focus", biTerminalFocus))
  terminalScope.define("mouse",
    builtinNativeCallFn("terminal/mouse", biTerminalMouse))
  terminalScope.define("resize",
    builtinNativeCallFn("terminal/resize", biTerminalResize))
  terminalScope.define("signal",
    builtinNativeCallFn("terminal/signal", biTerminalSignal))
  terminalScope.define("stop",
    builtinNativeCallFn("terminal/stop", biTerminalStop,
                    acceptsNamed = false))
  terminalScope.define("request_stop",
    builtinNativeCallFn("terminal/request_stop", biTerminalRequestStop))
  terminalScope.define("close",
    builtinNativeCallFn("terminal/close", biTerminalClose,
                    acceptsNamed = false))
  root.define("terminal", newNamespace("terminal", terminalScope))

  # Public owned terminal surface. `os/read_input` remains a compatibility
  # wrapper; new code owns a Screen explicitly and closes it from ensure.
  let cursesScreenType = newType("CursesScreen", NIL,
    @[TypeField(name: "id", optional: false, typeExpr: newSym("Int"),
                scope: root),
      TypeField(name: "closed", optional: false, typeExpr: newSym("Any"),
                scope: root)], @[], root, repr = trNativeWrapper)
  root.define("CursesScreen", cursesScreenType)
  let cursesScope = newScope(root)
  cursesScope.define("Screen", cursesScreenType)
  cursesScope.define("CursesError", cursesError)
  cursesScope.define("open", builtinNativeCallFn("curses/open", biCursesOpen))
  cursesScope.define("close", builtinNativeCallFn("curses/close", biCursesClose,
                                               acceptsNamed = false))
  cursesScope.define("dimensions",
    builtinNativeCallFn("curses/dimensions", biCursesDimensions,
                    acceptsNamed = false))
  cursesScope.define("draw", builtinNativeCallFn("curses/draw", biCursesDraw))
  cursesScope.define("read_input",
    builtinNativeCallFn("curses/read_input", biCursesReadInput))
  cursesScope.define("refresh_input",
    builtinNativeCallFn("curses/refresh_input", biCursesRefreshInput))
  cursesScope.define("escape_pressed?",
    builtinNativeCallFn("curses/escape_pressed?", biCursesEscapePressed,
                    acceptsNamed = false))
  cursesScope.define("next_event",
    builtinNativeCallFn("curses/next_event", biCursesNextEvent,
                    acceptsNamed = false))
  root.define("curses", newNamespace("curses", cursesScope))

  # repl: shared declaration-persistent REPL loop used by the CLI wrapper and
  # interactive programs that need a scoped sub-REPL.
  let replSessionType = newType("ReplSession", NIL,
    @[TypeField(name: "id", optional: false, typeExpr: newSym("Int"),
                scope: root),
      TypeField(name: "closed", optional: false, typeExpr: newSym("Any"),
                scope: root)], @[], root, repr = trNativeWrapper)
  root.define("ReplSession", replSessionType)
  let replScope = newScope(root)
  replScope.define("Session", replSessionType)
  replScope.define("open", builtinNativeCallFn("repl/open", biReplOpen,
                                            acceptsNamed = false))
  replScope.define("eval", builtinNativeCallFn("repl/eval", biReplEvalFrame,
                                            acceptsNamed = false))
  replScope.define("bind", builtinNativeCallFn("repl/bind", biReplBind,
                                            acceptsNamed = false))
  replScope.define("format", builtinNativeFn("repl/format", biReplFormat))
  replScope.define("eval_source",
    builtinNativeCallFn("repl/eval_source", biReplEval,
                    acceptsNamed = false))
  replScope.define("discard_pending",
    builtinNativeCallFn("repl/discard_pending", biReplDiscardPending,
                    acceptsNamed = false))
  replScope.define("eval_guard_begin",
    builtinNativeCallFn("repl/eval_guard_begin", biReplEvalGuardBegin,
                    acceptsNamed = false))
  replScope.define("eval_guard_end",
    builtinNativeCallFn("repl/eval_guard_end", biReplEvalGuardEnd,
                    acceptsNamed = false))
  replScope.define("close", builtinNativeCallFn("repl/close", biReplClose,
                                             acceptsNamed = false))
  replScope.define("run", builtinNativeCallFn("repl/run", biReplRun))
  root.define("repl", newNamespace("repl", replScope))

  # Extend the existing `fs` namespace (built in vm.nim) with sync helpers the
  # agent file tools need.
  let fsNs = root.vars.getOrDefault("fs", VOID)
  if fsNs.kind == vkNamespace:
    fsNs.nsScope.define("FsFileLock", fsFileLockType)
    fsNs.nsScope.define("try_lock",
      builtinNativeCallFn("fs/try_lock", biFsTryLock, acceptsNamed = false))
    fsNs.nsScope.define("FsWatcher", fsWatcherType)
    fsNs.nsScope.define("FsChange", fsChangeType)
    fsNs.nsScope.define("WatcherClosed", watcherClosed)
    fsNs.nsScope.define("watch",
      builtinNativeCallFn("fs/watch", biFsWatch))
    fsNs.nsScope.define("read_text",
      builtinNativeCallFn("fs/read_text", biFsReadTextSync, acceptsNamed = false))
    fsNs.nsScope.define("write_text",
      builtinNativeCallFn("fs/write_text", biFsWriteTextSync, acceptsNamed = false))
    fsNs.nsScope.define("write_text_atomic",
      builtinNativeCallFn("fs/write_text_atomic", biFsWriteTextAtomicSync))
    fsNs.nsScope.define("write_bytes",
      builtinNativeCallFn("fs/write_bytes", biFsWriteBytesSync, acceptsNamed = false))
    fsNs.nsScope.define("write_bytes_atomic",
      builtinNativeCallFn("fs/write_bytes_atomic", biFsWriteBytesAtomicSync,
                          acceptsNamed = false))
    fsNs.nsScope.define("read_bytes",
      builtinNativeCallFn("fs/read_bytes", biFsReadBytesSync, acceptsNamed = false))
    fsNs.nsScope.define("exists?",
      builtinNativeCallFn("fs/exists?", biFsExists, acceptsNamed = false))
    fsNs.nsScope.define("list_dir",
      builtinNativeCallFn("fs/list_dir", biFsListDir, acceptsNamed = false))
    fsNs.nsScope.define("info",
      builtinNativeCallFn("fs/info", biFsInfo))
    fsNs.nsScope.define("set_mode", builtinNativeCallFn("fs/set_mode", biFsSetMode, acceptsNamed = false))
    fsNs.nsScope.define("create_symlink", builtinNativeCallFn("fs/create_symlink", biFsCreateSymlink, acceptsNamed = false))
    fsNs.nsScope.define("read_text_page", builtinNativeCallFn("fs/read_text_page", biFsReadTextPage))
    fsNs.nsScope.define("make_dir",
      builtinNativeCallFn("fs/make_dir", biFsMakeDir, acceptsNamed = false))
    fsNs.nsScope.define("remove",
      builtinNativeCallFn("fs/remove", biFsRemove, acceptsNamed = false))
    fsNs.nsScope.define("remove_dir",
      builtinNativeCallFn("fs/remove_dir", biFsRemoveDir, acceptsNamed = false))
    fsNs.nsScope.define("rename",
      builtinNativeCallFn("fs/rename", biFsRename, acceptsNamed = false))
    fsNs.nsScope.define("real_path",
      builtinNativeCallFn("fs/real_path", biFsRealPath, acceptsNamed = false))
    fsNs.nsScope.define("walk", builtinNativeCallFn("fs/walk", biFsWalk))
    fsNs.nsScope.define("FsError", fsError)
    fsNs.nsScope.define("FsLimitError", fsLimitError)

  # json: parse/stringify over Gene value kinds (docs/stdlib.md "Module Layout").
  let jsonScope = newScope(root)
  jsonScope.define("parse", builtinNativeCallFn("json/parse", biJsonParse))
  jsonScope.define("stringify", builtinNativeCallFn("json/stringify",
                                                biJsonStringify,
                                                acceptsNamed = false))
  osScope.define("read_line_async", builtinNativeCallFn("os/read_line_async", biOsReadLineAsync,
                                                       acceptsNamed = false))
  jsonScope.define("JsonError", jsonError)
  root.define("json", newNamespace("json", jsonScope))

  # serde: Gene-text serialization data core (docs/stdlib.md
  # stage 1).
  let serdeScope = newScope(root)
  serdeScope.define("write_data",
    builtinNativeCallFn("serde/write_data", biSerdeWriteData,
                    acceptsNamed = false))
  serdeScope.define("read_data",
    builtinNativeCallFn("serde/read_data", biSerdeReadData))
  serdeScope.define("write",
    builtinNativeCallFn("serde/write", biSerdeWrite, acceptsNamed = false))
  serdeScope.define("read",
    builtinNativeCallFn("serde/read", biSerdeRead))
  serdeScope.define("data?",
    builtinNativeCallFn("serde/data?", biSerdeDataP, acceptsNamed = false))
  serdeScope.define("SerdeError", serdeError)
  serdeScope.define("SerdeRef", root.vars["SerdeRef"])
  let intField = proc (name: string): TypeField =
    TypeField(name: name, optional: true, typeExpr: newSym("Int"),
              scope: root)
  let serdePolicyType = newType("SerdePolicy", NIL,
                                @[intField("max_bytes"),
                                  intField("max_nodes"),
                                  intField("max_depth"),
                                  intField("max_symbols"),
                                  TypeField(name: "allow_restore",
                                            optional: true,
                                            typeExpr: newSym("Bool"),
                                            scope: root)],
                                @[], root)
  serdeScope.define("SerdePolicy", serdePolicyType)
  root.define("serde", newNamespace("serde", serdeScope))
