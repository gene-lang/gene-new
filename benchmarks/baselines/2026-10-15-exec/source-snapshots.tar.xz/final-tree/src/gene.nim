## Gene language CLI entry point.
##
## Subcommands (a subset of design Section 18):
##   gene eval "<src>"   evaluate a source string, print the result
##   gene repl           read/eval/print source lines from stdin
##   gene run  <file>    load and execute a .gene file, then call main if present
##   gene runurl <url>   (experimental) run a remote entry module (design §15.9)
##   gene parse <file>   read and print canonical forms (no execution)
##   gene fmt <file>     format source through the canonical printer
##   gene compile <file> print compiled GIR bytecode (no execution)
##   gene compile --target c <file> print experimental typed_native C
##   gene doc <file>     print module metadata, imports, and declarations

import std/[algorithm, os, osproc, sets, streams, strutils, tables]
import gene/[build, build_info, diagnostics, gir, install, native_managed, package,
             printer, reader, registry_config, registry_publish, repl,
             system_dependency, types, vm, web]
# native_managed installs the owned byte-ingress adapter for this executable.
import gene/ext/[logging, logging_config]
# Imported for its side effect: the typed_native AOT boundary helpers are
# {.exportc, dynlib.}, and importing the module is what puts them in this
# executable's dynamic symbol table for a dlopened AOT library to resolve.
import gene/aot_runtime

when defined(posix) and not defined(emscripten) and not defined(geneWasm):
  import gene/process_launch

when defined(posix):
  import std/posix

proc delegateToTool(tool: string, args: openArray[string]) =
  ## `gene fmt|lsp|view` are separate executables. The formatter, language
  ## server, and structural viewer are tools rather than runtime, and keeping
  ## them out of this binary is what removes fmt.nim, the LSP analyzer, the
  ## structural index, and the viewer from every Gene process.
  ##
  ## execv rather than spawn-and-wait: the tool *replaces* this process, so it
  ## inherits stdio, the controlling terminal, and signal disposition directly.
  ## That is what the stdio JSON-RPC server and the full-screen viewer both
  ## need, and it makes the exit code the tool's by construction rather than by
  ## translation.
  let sibling = getAppDir() / tool
  var exe = if fileExists(sibling): sibling else: findExe(tool)
  if exe.len == 0:
    stderr.writeLine "Error: '" & tool & "' was not found next to " &
      getAppFilename() & " or on PATH."
    stderr.writeLine "  It is built separately from `gene`: run `nimble tools`."
    quit(1)
  when defined(posix):
    var argv = @[exe]
    for a in args: argv.add a
    var cargs = allocCStringArray(argv)
    discard execv(exe.cstring, cargs)
    # execv returns only on failure.
    deallocCStringArray(cargs)
    stderr.writeLine "Error: failed to exec " & exe
    quit(1)
  else:
    let p = startProcess(exe, args = @args, options = {poParentStreams})
    quit(p.waitForExit())

proc usage() =
  echo "Gene — a homoiconic general purpose language"
  echo ""
  echo "Usage:"
  echo "  gene --version         print version, build mode and runtime check settings"
  echo "  gene eval \"<source>\"   evaluate a source string from cwd, with imports"
  echo "  gene eval --errors-mode dynamic|warn|strict \"<source>\""
  echo "  gene repl              read/eval/print source lines from stdin"
  echo "  gene run [--log-config path] [--package-root dir] [--debug]"
  echo "           [--report_tail_fallbacks]"
  echo "           [--errors-mode dynamic|warn|strict]"
  echo "           [--snapshot] execute captured package sources with build provenance"
  echo "           <file.gene> [--] [args...]     execute a file and call main"
  echo "  gene runurl <https-url> [args...]  (experimental) run a remote entry module;"
  echo "                              relative imports resolve against the module's URL"
  echo "  gene parse <file.gene>  print canonical parsed forms"
  echo "  gene fmt <file.gene>    human-friendly format: sugar restored, comments kept"
  echo "  gene compile <file.gene> print compiled GIR bytecode"
  echo "  gene compile --target c <file.gene> print experimental typed_native C"
  echo "  gene compile --c-header           print the standalone checked C ABI header"
  echo "  gene build [target] [options] build a package product"
  echo "  gene build --all [options] build every workspace product"
  echo "  gene install [target] --prefix dir [--package-root dir] [--registry-config path]"
  echo "                              install a locked app"
  echo "  gene pkg publish --registry-config path --signing-key file"
  echo "                              sign and publish a local package release"
  echo "  gene uninstall owner/name:target --prefix dir remove an installed app"
  echo "  gene build --target web [--out-dir dir] <file.gene> emit web ESM + types"
  echo "  gene test [files/dirs...] [--name text] run *_spec.gene examples"
  echo "  gene test --package [selector] build and run package test targets"
  echo "  gene clean               remove project build views and sandboxes"
  echo "  gene doc <file.gene>    print module metadata, imports, and declarations"
  echo "  gene pkg <command>      init/add/remove/resolve/update/sync/vendor/members/tree/why"
  echo "  gene view [options] <file.gene> browse source structure and edit externally"
  echo "  gene lsp                run the language server over stdio (docs/workflows.md)"

proc readSourceFile(path: string): string =
  if not fileExists(path):
    stderr.writeLine "Error: file not found: " & path
    quit(1)
  readFile(path)

proc readErrorLoc(e: ref ReadError): SourceLoc =
  SourceLoc(sourceName: e.sourceName, line: e.line, col: e.col)

proc replOnErrorEnabled(): bool =
  let value = getEnv("REPL_ON_ERROR").strip().toLowerAscii()
  value in ["1", "true", "yes", "on"]

proc replFallbackScope(scope: Scope, app: Application = nil): Scope =
  if scope != nil:
    return scope
  if app != nil:
    return newGlobalScope(app)
  newGlobalScope(newApplication(singlePackageGraph(newAdHocPackage(getCurrentDir()))))

proc maybeReplOnError(scope: Scope, app: Application = nil) =
  if replOnErrorEnabled():
    stderr.writeLine "REPL_ON_ERROR=1: entering Gene REPL (:quit to exit)."
    let code = runRepl(replFallbackScope(scope, app))
    if code != 0:
      quit(code)

proc reportPipelineWarnings(chunk: Chunk) =
  for diagnostic in chunk.compilerDiagnostics:
    if diagnostic.message.startsWith("unused lazy pipeline:") or
        diagnostic.message.startsWith("error checking:") or
        diagnostic.message.startsWith("deprecated impl-level ^override:"):
      stderr.writeLine formatDiagnostic("Warning", diagnostic.message,
                                         diagnostic.loc)

proc cmdEval(src: string, errorsMode = "") =
  let app = newApplication(singlePackageGraph(newAdHocPackage(getCurrentDir())))
  if errorsMode.len > 0: app.setErrorCheckingMode(errorsMode)
  let scope = newGlobalScope(app)
  try:
    let chunk = app.compileEvalModuleSource(src)
    reportPipelineWarnings(chunk)
    echo run(chunk, scope).print()
  except ReadError as e:
    stderr.writeLine formatDiagnostic("Read error", e.msg, e.readErrorLoc)
    maybeReplOnError(scope, app)
    quit(1)
  except GenePanic as e:
    stderr.writeLine "Panic: " & e.msg
    quit(1)
  except GeneError as e:
    stderr.writeLine formatDiagnostic("Error", errorDiagnosticMessage(e, scope), e.loc)
    maybeReplOnError(scope, app)
    quit(1)

proc cmdRepl(errorsMode = "") =
  let app = newApplication(getCurrentDir())
  if errorsMode.len > 0: app.setErrorCheckingMode(errorsMode)
  let scope = newGlobalScope(app)
  let code = runRepl(scope)
  if code != 0:
    quit(code)

proc argsValue(args: openArray[string]): Value =
  # Preserve positional argv compatibility through node body indexes while
  # exposing the whole shell argument tail for future script-level parsing.
  var props = initPropTable()
  props["raw"] = newStr(args.join(" "))
  var values = newSeq[Value](args.len)
  for i, arg in args:
    values[i] = newStr(arg)
  newNode(newSym("args"), props = props, body = values)

proc commandArgs(first: int): seq[string] =
  if first <= paramCount():
    for i in first .. paramCount():
      result.add paramStr(i)

type RunCli = object
  path: string
  args: seq[string]
  logConfig: string
  packageRoot: string
  registryConfig: string
  debugging: bool
  reportTailFallbacks: bool
  targetTriple: string
  profile: string
  mode: BuildMode
  sealed: bool
  open: bool
  debugInfo: string
  locked: bool
  offline: bool
  preferBinary: bool
  sourceOnly: bool
  snapshot: bool
  rebuild: bool
  explain: bool
  jobs: int
  errorsMode: string

proc parseRunCli(label = "run", pathNoun = "a file path",
                 pathRequired = true): RunCli =
  result.profile = "dev"
  result.mode = bmVm
  var profileExplicit = false
  var release = false
  var i = 2
  while i <= paramCount() and result.path.len == 0:
    let arg = paramStr(i)
    case arg
    of "--log-config", "--package-root", "--registry-config", "--target", "--profile", "--mode",
       "--debug_info", "--jobs", "--errors-mode":
      inc i
      if i > paramCount():
        raise newException(ValueError, arg & " expects a value")
      let value = paramStr(i)
      case arg
      of "--log-config": result.logConfig = value
      of "--package-root": result.packageRoot = value
      of "--registry-config": result.registryConfig = value
      of "--errors-mode":
        if value notin ["dynamic", "warn", "strict"]:
          raise newException(ValueError, "--errors-mode expects dynamic, warn, or strict")
        result.errorsMode = value
      of "--target": result.targetTriple = value
      of "--profile":
        result.profile = value
        profileExplicit = true
      of "--mode":
        case value
        of "vm": result.mode = bmVm
        of "mixed": result.mode = bmMixed
        else: raise newException(ValueError, "--mode expects vm or mixed")
      of "--debug_info": result.debugInfo = value
      of "--jobs": result.jobs = parseInt(value)
      else: discard
    of "--debug":
      result.debugging = true
    of "--report_tail_fallbacks":
      result.reportTailFallbacks = true
    of "--sealed": result.sealed = true
    of "--open": result.open = true
    of "--locked": result.locked = true
    of "--offline": result.offline = true
    of "--prefer_binary": result.preferBinary = true
    of "--source": result.sourceOnly = true
    of "--snapshot": result.snapshot = true
    of "--rebuild": result.rebuild = true
    of "--explain": result.explain = true
    of "--release": release = true
    else:
      if arg.startsWith("--log-config="):
        result.logConfig = arg[13 .. ^1]
      elif arg.startsWith("--package-root="):
        result.packageRoot = arg[15 .. ^1]
      elif arg.startsWith("--registry-config="):
        result.registryConfig = arg[18 .. ^1]
      elif arg.startsWith("--errors-mode="):
        result.errorsMode = arg[14..^1]
        if result.errorsMode notin ["dynamic", "warn", "strict"]:
          raise newException(ValueError, "--errors-mode expects dynamic, warn, or strict")
      elif arg.startsWith("--target="):
        result.targetTriple = arg[9 .. ^1]
      elif arg.startsWith("--profile="):
        result.profile = arg[10 .. ^1]
        profileExplicit = true
      elif arg.startsWith("--mode="):
        case arg[7 .. ^1]
        of "vm": result.mode = bmVm
        of "mixed": result.mode = bmMixed
        else: raise newException(ValueError, "--mode expects vm or mixed")
      elif arg.startsWith("--debug_info="):
        result.debugInfo = arg[13 .. ^1]
      elif arg.startsWith("--jobs="):
        result.jobs = parseInt(arg[7 .. ^1])
      elif arg.startsWith("-"):
        raise newException(ValueError, "unknown run option: " & arg)
      else:
        result.path = arg
    inc i
  if result.sealed and result.open:
    raise newException(ValueError, "--sealed and --open conflict")
  if result.preferBinary and result.sourceOnly:
    raise newException(ValueError, "--prefer_binary and --source conflict")
  if release and profileExplicit:
    raise newException(ValueError, "--release conflicts with --profile")
  if release:
    result.profile = "release"
  if result.jobs < 0:
    raise newException(ValueError, "--jobs cannot be negative")
  if pathRequired and result.path.len == 0:
    raise newException(ValueError, "'" & label & "' needs " & pathNoun)
  result.args = commandArgs(i)

proc configureRunLogging(options: RunCli) =
  setReportTailFallbacks(options.reportTailFallbacks)
  var config =
    if options.logConfig.len > 0:
      loadLoggingConfig(options.logConfig)
    else:
      defaultLoggingConfig()
  if options.debugging:
    config.overrides.add LogRouteOverride(name: "gene", hasLevel: true,
                                           level: llDebug)
  installLoggingConfig(config)

proc parseInteractiveCli(label: string, needsSource: bool): RunCli =
  let args = commandArgs(2)
  var index = 0
  while index < args.len:
    let argument = args[index]
    let at = argument.find('=')
    let name = if at < 0: argument else: argument[0 ..< at]
    if name == "--errors-mode":
      var value: string
      if at >= 0: value = argument[at + 1 .. ^1]
      else:
        inc index
        if index >= args.len: raise newException(ValueError, name & " requires a value")
        value = args[index]
      if value notin ["dynamic", "warn", "strict"]:
        raise newException(ValueError, "--errors-mode expects dynamic, warn, or strict")
      result.errorsMode = value
    elif needsSource and argument == "--":
      inc index
      if index >= args.len or index + 1 != args.len:
        raise newException(ValueError, "eval requires one source string")
      result.path = args[index]
    elif argument.startsWith("--"):
      raise newException(ValueError, "unknown " & label & " option: " & argument)
    elif needsSource and result.path.len == 0:
      result.path = argument
      if index + 1 != args.len:
        raise newException(ValueError, "eval requires one source string after its options")
    else:
      raise newException(ValueError, "unexpected " & label & " argument: " & argument)
    inc index
  if needsSource and result.path.len == 0:
    raise newException(ValueError, "eval requires a source string")

proc raiseMainReturnTypeError(scope: Scope, value: Value) =
  let message = "main return expected Nil or Int, got " & $value.kind
  var props = initPropTable()
  props["message"] = newStr(message)
  props["where"] = newStr("main return")
  props["expected"] = newStr("Nil or Int")
  props["actual"] = newStr($value.kind)
  var head = newSym("TypeError")
  var typeError: Value
  if scope.lookupOptional("TypeError", typeError) and typeError.kind == vkType:
    head = typeError
  var e: ref GeneError
  new(e)
  e.msg = "TypeError: " & message
  e.errVal = newNode(head, props = props)
  e.hasErrVal = true
  raise e

proc raiseMainReturnRangeError(scope: Scope) =
  let message = "main return Int must fit in int64"
  var props = initPropTable()
  props["message"] = newStr(message)
  props["where"] = newStr("main return")
  props["expected"] = newStr("int64-range Int")
  props["actual"] = newStr("Int")
  var head = newSym("TypeError")
  var typeError: Value
  if scope.lookupOptional("TypeError", typeError) and typeError.kind == vkType:
    head = typeError
  var e: ref GeneError
  new(e)
  e.msg = "TypeError: " & message
  e.errVal = newNode(head, props = props)
  e.hasErrVal = true
  raise e

proc exitFromMain(scope: Scope, value: Value) =
  scope.application().waitApplicationIoCleanup()
  case value.kind
  of vkNil:
    discard
  of vkInt:
    if not value.intFitsInt64:
      raiseMainReturnRangeError(scope)
    quit(int(value.intVal))
  else:
    raiseMainReturnTypeError(scope, value)

proc invokeEntryMain(scope: Scope, args: openArray[string]) =
  var mainBinding: Value
  if scope.lookupOptional("main", mainBinding):
    var programArgs = @args
    if programArgs.len > 0 and programArgs[0] == "--":
      programArgs.delete(0)
    let positional =
      if mainBinding.kind == vkFunction and mainBinding.fnParams.len == 0:
        newSeq[Value]()
      else:
        @[argsValue(programArgs)]
    let result = mainBinding.call(positional, newSeq[string](),
                                  newSeq[Value](), scope)
    exitFromMain(scope, result)

proc applicationForEntry(absPath, packageRootOverride: string): Application =
  ## Package discovery for a file-oriented command (proposal §4). An explicit
  ## `--package-root` replaces the discovery start directory; it never changes
  ## the process working directory, and the entry file must be inside it.
  ## Without an override the root is an ancestor of the entry's directory by
  ## construction, so the containment check only bites here and on `import`.
  if packageRootOverride.len == 0:
    return newApplicationForEntryFile(absPath)
  let root = normalizedPath(absolutePath(packageRootOverride))
  if not dirExists(root):
    raise newException(GeneError, "--package-root is not a directory: " &
                       packageRootOverride)
  result = newApplication(root)
  result.requireEntryWithinPackage(absPath)

proc projectBuildEngine(): BuildEngine

proc cmdRun(path: string, args: openArray[string] = [],
            packageRootOverride = "", options = RunCli()) =
  if not fileExists(path):
    stderr.writeLine "Error: file not found: " & path
    quit(1)
  var app: Application = nil
  var replScope: Scope = nil
  try:
    var absPath = normalizedPath(absolutePath(path))
    let runtimeDigest = if options.snapshot: runningRuntimeDigest() else: ""
    app = applicationForEntry(absPath, packageRootOverride)
    if options.snapshot:
      let originalRoot = app.packageRoot()
      let entry = relativePath(absPath, originalRoot)
      let graph = projectBuildEngine().snapshotSources(app.materializedGraph())
      let provenance = executionProvenance(graph, entry, runtimeDigest = runtimeDigest)
      app = newApplication(graph)
      app.setExecutionProvenance(provenance, originalRoot)
      absPath = app.packageRoot() / entry
    if options.errorsMode.len > 0: app.setErrorCheckingMode(options.errorsMode)
    reportPipelineWarnings(app.compileFileModule(absPath))
    let entryModule = app.loadFileModule(absPath)
    let scope = entryModule.moduleRootNamespace.nsScope
    replScope = scope
    invokeEntryMain(scope, args)
    app.waitApplicationIoCleanup()
  except ReadError as e:
    if app != nil:
      try: app.waitApplicationIoCleanup()
      except CatchableError as cleanup:
        stderr.writeLine "Cleanup error: " & cleanup.msg
    stderr.writeLine formatDiagnostic("Read error", e.msg, e.readErrorLoc)
    maybeReplOnError(replScope, app)
    quit(1)
  except GenePanic as e:
    if app != nil:
      try: app.waitApplicationIoCleanup()
      except CatchableError as cleanup:
        stderr.writeLine "Cleanup error: " & cleanup.msg
    stderr.writeLine "Panic: " & e.msg
    quit(1)
  except GeneError as e:
    if app != nil:
      try: app.waitApplicationIoCleanup()
      except CatchableError as cleanup:
        stderr.writeLine "Cleanup error: " & cleanup.msg
    stderr.writeLine formatDiagnostic("Error",
      errorDiagnosticMessage(e, replFallbackScope(replScope, app)), e.loc)
    maybeReplOnError(replScope, app)
    quit(1)

proc cmdRunUrl(url: string, args: openArray[string] = [],
               packageRootOverride = "", options = RunCli()) =
  if options.snapshot:
    raise newException(ValueError, "--snapshot requires a local package entry")
  ## Experimental URL entry (design §15.9): run a remote module graph. URL
  ## sources are enabled only for this entry; `gene run` never fetches, and
  ## package resolution never fetches for either entry. A URL entry has no
  ## entry file, so its application package is discovered from the launch
  ## working directory (proposal §4, §13).
  if not (url.startsWith("https://") or url.startsWith("http://")):
    stderr.writeLine "Error: 'runurl' needs an https:// (or localhost http://) URL"
    quit(1)
  var app: Application = nil
  var replScope: Scope = nil
  try:
    app = newApplication(if packageRootOverride.len > 0: packageRootOverride
                         else: getCurrentDir())
    if options.errorsMode.len > 0: app.setErrorCheckingMode(options.errorsMode)
    app.allowUrlModules = true
    let entryModule = app.loadUrlModule(url)
    let scope = entryModule.moduleRootNamespace.nsScope
    replScope = scope
    invokeEntryMain(scope, args)
  except ReadError as e:
    stderr.writeLine formatDiagnostic("Read error", e.msg, e.readErrorLoc)
    maybeReplOnError(replScope, app)
    quit(1)
  except GenePanic as e:
    stderr.writeLine "Panic: " & e.msg
    quit(1)
  except GeneError as e:
    stderr.writeLine formatDiagnostic("Error",
      errorDiagnosticMessage(e, replFallbackScope(replScope, app)), e.loc)
    maybeReplOnError(replScope, app)
    quit(1)

proc cmdParse(path: string) =
  let src = readSourceFile(path)
  try:
    for f in readAll(src, normalizedPath(absolutePath(path))):
      echo f.print()
  except ReadError as e:
    stderr.writeLine formatDiagnostic("Read error", e.msg, e.readErrorLoc)
    quit(1)

proc cmdCompile(path: string) =
  let absPath = normalizedPath(absolutePath(path))
  try:
    let app = newApplicationForEntryFile(absPath)
    echo app.compileFileModule(absPath).disassemble()
  except ReadError as e:
    stderr.writeLine formatDiagnostic("Read error", e.msg, e.readErrorLoc)
    quit(1)
  except GenePanic as e:
    stderr.writeLine "Panic: " & e.msg
    quit(1)
  except GeneError as e:
    stderr.writeLine formatDiagnostic("Error", e.msg, e.loc)
    quit(1)

proc cmdCompileC(path: string) =
  let absPath = normalizedPath(absolutePath(path))
  try:
    let app = newApplicationForEntryFile(absPath)
    echo app.compileFileModule(absPath).emitExperimentalC()
  except ReadError as e:
    stderr.writeLine formatDiagnostic("Read error", e.msg, e.readErrorLoc)
    quit(1)
  except GenePanic as e:
    stderr.writeLine "Panic: " & e.msg
    quit(1)
  except GeneError as e:
    stderr.writeLine formatDiagnostic("Error", e.msg, e.loc)
    quit(1)

type BuildWebCli = object
  path: string
  outDir: string

proc parseBuildWebCli(): BuildWebCli =
  result.outDir = "dist"
  var target = ""
  var i = 2
  while i <= paramCount():
    let arg = paramStr(i)
    case arg
    of "--target", "--out-dir":
      inc i
      if i > paramCount():
        raise newException(ValueError, arg & " expects a value")
      if arg == "--target": target = paramStr(i)
      else: result.outDir = paramStr(i)
    else:
      if arg.startsWith("--target="):
        target = arg[9 .. ^1]
      elif arg.startsWith("--out-dir="):
        result.outDir = arg[10 .. ^1]
      elif arg.startsWith("-"):
        raise newException(ValueError, "unknown build option: " & arg)
      elif result.path.len == 0:
        result.path = arg
      else:
        raise newException(ValueError, "build accepts one entry file")
    inc i
  if target != "web":
    raise newException(ValueError, "unsupported build target: " & target)
  if result.path.len == 0:
    raise newException(ValueError, "'build --target web' needs a file path")

proc cmdBuildWeb(options: BuildWebCli) =
  try:
    let outputs = buildWebModule(options.path, options.outDir)
    for output in outputs:
      echo normalizedPath(output)
  except ReadError as e:
    stderr.writeLine formatDiagnostic("Read error", e.msg, e.readErrorLoc)
    quit(1)
  except WebProfileError as e:
    stderr.writeLine "Error: " & e.msg
    quit(1)
  except CatchableError as e:
    stderr.writeLine "Error: " & e.msg
    quit(1)

type ProjectBuildCli = object
  product: string
  packageRoot: string
  registryConfig: string
  targetTriple: string
  profile: string
  profileExplicit: bool
  mode: BuildMode
  debugInfo: string
  all: bool
  sealed: bool
  open: bool
  locked: bool
  offline: bool
  preferBinary: bool
  sourceOnly: bool
  rebuild: bool
  explain: bool
  verifyReproducible: bool
  jobs: int

proc isDirectWebBuild(): bool =
  var i = 2
  while i <= paramCount():
    let arg = paramStr(i)
    if arg == "--target" and i < paramCount() and paramStr(i + 1) == "web":
      return true
    if arg == "--target=web":
      return true
    inc i

proc parseProjectBuildCli(label = "build", first = 2): ProjectBuildCli =
  result.profile = "dev"
  result.mode = bmVm
  var profileExplicit = false
  var release = false
  var i = first
  while i <= paramCount():
    let arg = paramStr(i)
    case arg
    of "--target", "--profile", "--mode", "--debug_info", "--jobs",
       "--package-root", "--registry-config":
      inc i
      if i > paramCount():
        raise newException(ValueError, arg & " expects a value")
      let value = paramStr(i)
      case arg
      of "--target": result.targetTriple = value
      of "--profile":
        result.profile = value
        profileExplicit = true
        result.profileExplicit = true
      of "--mode":
        case value
        of "vm": result.mode = bmVm
        of "mixed": result.mode = bmMixed
        else: raise newException(ValueError, "--mode expects vm or mixed")
      of "--debug_info": result.debugInfo = value
      of "--jobs": result.jobs = parseInt(value)
      of "--package-root": result.packageRoot = value
      of "--registry-config": result.registryConfig = value
      else: discard
    of "--all": result.all = true
    of "--sealed": result.sealed = true
    of "--open": result.open = true
    of "--locked": result.locked = true
    of "--offline": result.offline = true
    of "--prefer_binary": result.preferBinary = true
    of "--source": result.sourceOnly = true
    of "--rebuild": result.rebuild = true
    of "--explain": result.explain = true
    of "--verify_reproducible": result.verifyReproducible = true
    of "--release": release = true
    else:
      if arg.startsWith("--target="):
        result.targetTriple = arg[9 .. ^1]
      elif arg.startsWith("--profile="):
        result.profile = arg[10 .. ^1]
        profileExplicit = true
        result.profileExplicit = true
      elif arg.startsWith("--mode="):
        let value = arg[7 .. ^1]
        case value
        of "vm": result.mode = bmVm
        of "mixed": result.mode = bmMixed
        else: raise newException(ValueError, "--mode expects vm or mixed")
      elif arg.startsWith("--debug_info="):
        result.debugInfo = arg[13 .. ^1]
      elif arg.startsWith("--jobs="):
        result.jobs = parseInt(arg[7 .. ^1])
      elif arg.startsWith("--package-root="):
        result.packageRoot = arg[15 .. ^1]
      elif arg.startsWith("--registry-config="):
        result.registryConfig = arg[18 .. ^1]
      elif arg.startsWith("-"):
        raise newException(ValueError, "unknown " & label & " option: " & arg)
      elif result.product.len == 0:
        result.product = arg
      else:
        raise newException(ValueError,
          label & " accepts at most one target or selector")
    inc i
  if result.all and result.product.len > 0:
    raise newException(ValueError, "--all conflicts with a product target")
  if result.sealed and result.open:
    raise newException(ValueError, "--sealed and --open conflict")
  if result.preferBinary and result.sourceOnly:
    raise newException(ValueError, "--prefer_binary and --source conflict")
  if release and profileExplicit:
    raise newException(ValueError, "--release conflicts with --profile")
  if release:
    result.profile = "release"
    result.profileExplicit = true
  if result.jobs < 0:
    raise newException(ValueError, "--jobs cannot be negative")

proc materializeProject(start: string, locked, offline,
                        includeDevelopment: bool,
                        registryConfig = ""): MaterializedGraph =
  let root = workspaceRootFor(start)
  if root.kind == pkAdHoc:
    raise newException(ValueError,
      "project build requires a package.gene; use gene run for an ad-hoc file")
  let manager = packageManagerFromRegistryConfig(registryConfig)
  let resolution =
    if locked:
      manager.loadResolutionLock(start)
    else:
      let solved = manager.resolve(ResolveRequest(
        startDir: start, includeDevelopment: includeDevelopment,
        offline: offline))
      discard solved.writeResolutionLock()
      solved
  result = manager.sync(resolution, SyncPolicy(offline: offline,
                                               locked: locked))
  result.includeDevelopment = includeDevelopment
  result.includeBuild = false

proc projectBuildEngine(): BuildEngine =
  let installedArtifacts = getEnv("GENE_INSTALLED_ARTIFACTS")
  var systemPolicy = defaultSystemDependencyPolicy()
  let configuredPkgConfig = getEnv("GENE_PKG_CONFIG_PATH")
  if configuredPkgConfig.len > 0:
    for path in configuredPkgConfig.split(PathSep):
      if path.len == 0 or not path.isAbsolute or not dirExists(path):
        raise newException(ValueError,
          "GENE_PKG_CONFIG_PATH requires existing absolute directories")
      systemPolicy.pkgConfig.searchPaths.add normalizedPath(path)
  var sources: seq[ArtifactSource]
  if installedArtifacts.len > 0:
    sources.add ArtifactSource(name: "installed_generation",
      root: normalizedPath(absolutePath(installedArtifacts)),
      required: true)
  newBuildEngine(BuildEnvironment(
    artifactStore: newLocalArtifactStore(userArtifactStoreDir()),
    toolchains: newToolchainSet(runningCompilerIdentity(),
                               hostCPU & "-" & hostOS,
                               getEnv("GENE_C_COMPILER"),
                               (if installedArtifacts.len > 0:
                                 getEnv("GENE_C_COMPILER_EVIDENCE")
                                else: "")),
    artifactSources: sources,
    systemDependencyProviders: newSystemDependencyResolver(systemPolicy)))

proc buildRequest(options: ProjectBuildCli, packageId, target: string):
                  BuildRequest =
  BuildRequest(rootPackageId: packageId, target: target,
    targetTriple: options.targetTriple, profile: options.profile,
    mode: options.mode, sealed: options.sealed, open: options.open,
    debugInfo: options.debugInfo, preferBinary: options.preferBinary,
    sourceOnly: options.sourceOnly, rebuild: options.rebuild,
    verifyReproducible: options.verifyReproducible,
    maxParallelism: options.jobs)

proc declaredTargets(pkg: Package): seq[string] =
  if pkg.hasLibrary:
    result.add "library"
  for application in pkg.applications:
    result.add application.name

proc childBuildArgs(options: ProjectBuildCli, packageRoot,
                    target: string): seq[string] =
  result = @["build", target, "--package-root", packageRoot, "--locked",
             "--profile", options.profile, "--mode", $options.mode,
             "--jobs", "1"]
  if options.targetTriple.len > 0:
    result.add @["--target", options.targetTriple]
  if options.registryConfig.len > 0:
    result.add @["--registry-config",
                 normalizedPath(absolutePath(options.registryConfig))]
  if options.debugInfo.len > 0:
    result.add @["--debug_info", options.debugInfo]
  if options.sealed: result.add "--sealed"
  if options.open: result.add "--open"
  if options.offline: result.add "--offline"
  if options.preferBinary: result.add "--prefer_binary"
  if options.sourceOnly: result.add "--source"
  if options.rebuild: result.add "--rebuild"
  if options.explain: result.add "--explain"
  if options.verifyReproducible: result.add "--verify_reproducible"

proc runParallelBuilds(options: ProjectBuildCli, graph: MaterializedGraph,
                       work: seq[tuple[packageId, target: string]]) =
  ## Pure-Gene compiler actions are process-isolated so independent workspace
  ## products can build concurrently without sharing VM heaps. Outputs are
  ## collected and emitted in plan order for deterministic logs.
  let requested = if options.jobs > 0: options.jobs else: countProcessors()
  let parallelism = max(1, min(requested, work.len))
  when defined(posix) and not defined(emscripten) and not defined(geneWasm):
    type BuildProcess = ProcessHandle
  else:
    type BuildProcess = Process
  type RunningBuild = object
    index: int
    process: BuildProcess
  var running: seq[RunningBuild]
  var outputs = newSeq[string](work.len)
  var statuses = newSeq[int](work.len)
  var next = 0
  while next < work.len or running.len > 0:
    while next < work.len and running.len < parallelism:
      let item = work[next]
      let packageRoot = graph.packagesById[item.packageId].root
      let process =
        when defined(posix) and not defined(emscripten) and not defined(geneWasm):
          launchProcess(getAppFilename(),
            childBuildArgs(options, packageRoot, item.target),
            graph.workspaceRoot, mergeStderr = true)
        else:
          startProcess(getAppFilename(), graph.workspaceRoot,
            args = childBuildArgs(options, packageRoot, item.target),
            options = {poStdErrToStdOut})
      running.add RunningBuild(index: next, process: process)
      inc next
    let current = running[0]
    outputs[current.index] = current.process.outputStream.readAll()
    statuses[current.index] = current.process.waitForExit()
    current.process.close()
    running.delete(0)
  var failed = false
  for i, output in outputs:
    stdout.write output
    if statuses[i] != 0:
      failed = true
  if failed:
    raise newException(ValueError,
      "one or more workspace products failed to build")

proc cmdProjectBuild(options: ProjectBuildCli) =
  let start =
    if options.packageRoot.len > 0: options.packageRoot else: getCurrentDir()
  let graph = materializeProject(start, options.locked, options.offline, false,
                                 options.registryConfig)
  let engine = projectBuildEngine()
  var work: seq[tuple[packageId, target: string]]
  if options.all:
    var roots = graph.rootPackageIds
    roots.sort(proc (a, b: string): int =
      cmp(graph.packagesById[a].root, graph.packagesById[b].root))
    for id in roots:
      for target in declaredTargets(graph.packagesById[id]):
        work.add (id, target)
  else:
    work.add (graph.activePackageId, options.product)
  if work.len == 0:
    raise newException(ValueError, "workspace declares no build targets")
  if options.all and work.len > 1 and options.jobs != 1:
    runParallelBuilds(options, graph, work)
    return
  for item in work:
    let built = engine.build(options.buildRequest(item.packageId, item.target),
                             graph)
    let artifact = built.rootArtifact
    echo "Built " & artifact.packageName & ":" & artifact.target & " -> " &
      built.projectView
    if options.explain:
      echo built.explanation

proc selectedApplication(pkg: Package, name: string): ApplicationTarget =
  if name.len == 0:
    if pkg.applications.len != 1:
      raise newException(ValueError,
        "run requires an application name unless the package declares exactly one")
    return pkg.applications[0]
  for application in pkg.applications:
    if application.name == name:
      return application
  raise newException(ValueError,
    "package has no application target named " & name)

proc cmdProjectRun(options: RunCli) =
  let runtimeDigest = runningRuntimeDigest()
  let start =
    if options.packageRoot.len > 0: options.packageRoot else: getCurrentDir()
  var reportingScope: Scope
  try:
    if options.errorsMode.len > 0:
      raise newException(ValueError,
        "--errors-mode currently requires a source entry path; pass the application's .gene entry file")
    let graph = materializeProject(start, options.locked, options.offline,
                                   false, options.registryConfig)
    let pkg = graph.packagesById[graph.activePackageId]
    let application = selectedApplication(pkg, options.path)
    let engine = projectBuildEngine()
    let built = engine.build(BuildRequest(rootPackageId: pkg.id,
      target: application.name, targetTriple: options.targetTriple,
      profile: options.profile, mode: options.mode, sealed: options.sealed,
      open: options.open, debugInfo: options.debugInfo,
      preferBinary: options.preferBinary, sourceOnly: options.sourceOnly,
      rebuild: options.rebuild, maxParallelism: options.jobs), graph)
    if options.explain:
      echo built.explanation
    let executionGraph = built.executionGraph
    let executionPackage = executionGraph.packagesById[pkg.id]
    let app = newApplication(executionGraph, executionPackage.root)
    app.setExecutionProvenance(
      executionProvenance(executionGraph, application.entry, built.artifacts, runtimeDigest), pkg.root)
    reportingScope = newGlobalScope(app)
    for artifact in built.artifacts:
      for resource in artifact.resources:
        app.installPackageResource(artifact.packageId, resource.path,
          resource.digest, resource.size,
          (if resource.builtRelative.len > 0: artifact.objectPath else: ""),
          (if resource.builtRelative.len > 0:
            artifact.objectPath / resource.builtRelative else: ""))
        if resource.nativeAlias.len > 0:
          app.installPackageNativeBinary(artifact.packageId,
            resource.nativeAlias, resource.nativeTarget,
            resource.path, resource.digest,
            resource.abiKind, resource.runtimeIdentity,
            resource.abiVersion)
      app.installCompiledModules(artifact.compiledModules)
    let chunk = built.rootArtifact.compiledChunk
    if chunk == nil:
      raise newException(ValueError,
        "build produced no executable GIR artifact")
    let entry = app.loadCompiledFileModule(
      executionPackage.root / application.entry, chunk)
    reportingScope = entry.moduleRootNamespace.nsScope
    invokeEntryMain(entry.moduleRootNamespace.nsScope, options.args)
  except ReadError as error:
    stderr.writeLine formatDiagnostic("Read error", error.msg,
                                      error.readErrorLoc)
    quit(1)
  except GenePanic as error:
    stderr.writeLine "Panic: " & error.msg
    quit(1)
  except GeneError as error:
    stderr.writeLine formatDiagnostic("Error",
      errorDiagnosticMessage(error, replFallbackScope(reportingScope)), error.loc)
    quit(1)
  except CatchableError as error:
    stderr.writeLine "Error: " & error.msg
    quit(1)

proc cmdInstall() =
  var prefix = ""
  var packageRoot = ""
  var registryConfig = ""
  var target = ""
  var i = 2
  while i <= paramCount():
    let arg = paramStr(i)
    case arg
    of "--prefix", "--package-root", "--registry-config":
      inc i
      if i > paramCount():
        raise newException(ValueError, arg & " expects a directory")
      if arg == "--prefix": prefix = paramStr(i)
      elif arg == "--package-root": packageRoot = paramStr(i)
      else: registryConfig = paramStr(i)
    of "--locked", "--offline":
      discard # Both are mandatory for the initial local install profile.
    else:
      if arg.startsWith("-") or target.len > 0:
        raise newException(ValueError, "invalid gene install argument: " & arg)
      target = arg
    inc i
  if prefix.len == 0:
    raise newException(ValueError, "gene install requires --prefix")
  let start = if packageRoot.len > 0: packageRoot else: getCurrentDir()
  let graph = materializeProject(start, locked = true, offline = true,
                                 includeDevelopment = false,
                                 registryConfig = registryConfig)
  let pkg = graph.packagesById[graph.activePackageId]
  let application = selectedApplication(pkg, target)
  let built = projectBuildEngine().build(BuildRequest(
    rootPackageId: pkg.id, target: application.name,
    profile: "release", mode: bmVm), graph)
  let receipt = installLocal(graph, built, application, prefix,
                             getAppFilename())
  echo "Installed " & receipt.packageName & ":" & receipt.target &
    " -> " & receipt.launcher

proc cmdUninstall() =
  var prefix = ""
  var coordinate = ""
  var i = 2
  while i <= paramCount():
    let arg = paramStr(i)
    if arg == "--prefix":
      inc i
      if i > paramCount():
        raise newException(ValueError, "--prefix expects a directory")
      prefix = paramStr(i)
    elif arg.startsWith("-") or coordinate.len > 0:
      raise newException(ValueError, "invalid gene uninstall argument: " & arg)
    else:
      coordinate = arg
    inc i
  let sep = coordinate.rfind(':')
  if prefix.len == 0 or sep < 0:
    raise newException(ValueError,
      "gene uninstall requires owner/name:target and --prefix")
  let name = coordinate[0 ..< sep]
  let target = coordinate[sep + 1 .. ^1]
  let receipt = uninstallLocal(name, target, prefix)
  echo "Uninstalled " & coordinate & " (" & $receipt.removedGenerations &
    " generation(s) removed, " & $receipt.retainedGenerations &
    " still in use)"

proc cmdProjectTest(options: ProjectBuildCli) =
  var reportingScope: Scope
  try:
    if options.all:
      raise newException(ValueError, "gene test does not accept --all")
    let start =
      if options.packageRoot.len > 0: options.packageRoot else: getCurrentDir()
    let graph = materializeProject(start, options.locked, options.offline, true,
                                   options.registryConfig)
    let pkg = graph.packagesById[graph.activePackageId]
    if not pkg.hasTests:
      raise newException(ValueError, pkg.name & " has no ^tests target")
    let testRoot = pkg.root / pkg.tests.root
    if not dirExists(testRoot):
      raise newException(ValueError, "test root does not exist: " & testRoot)
    var paths: seq[string]
    let selector = options.product
    for path in walkDirRec(testRoot, yieldFilter = {pcFile}):
      let relative = relativePath(path, pkg.root).replace('\\', '/')
      if path.endsWith(".gene") and
          (selector.len == 0 or selector in relative):
        paths.add relative
    paths.sort()
    if paths.len == 0:
      raise newException(ValueError, "no package tests matched: " & selector)
    let engine = projectBuildEngine()
    for relative in paths:
      var request = options.buildRequest(pkg.id, "test")
      request.testEntry = relative
      if not options.profileExplicit:
        request.profile = "test"
      let built = engine.build(request, graph)
      if options.explain:
        echo built.explanation
      let executionGraph = built.executionGraph
      let executionPackage = executionGraph.packagesById[pkg.id]
      let app = newApplication(executionGraph, executionPackage.root)
      app.setExecutionProvenance(
        executionProvenance(executionGraph, relative, built.artifacts), pkg.root)
      reportingScope = newGlobalScope(app)
      for artifact in built.artifacts:
        for resource in artifact.resources:
          app.installPackageResource(artifact.packageId, resource.path,
            resource.digest, resource.size,
            (if resource.builtRelative.len > 0: artifact.objectPath else: ""),
            (if resource.builtRelative.len > 0:
              artifact.objectPath / resource.builtRelative else: ""))
          if resource.nativeAlias.len > 0:
            app.installPackageNativeBinary(artifact.packageId,
              resource.nativeAlias, resource.nativeTarget,
              resource.path, resource.digest,
              resource.abiKind, resource.runtimeIdentity,
              resource.abiVersion)
        app.installCompiledModules(artifact.compiledModules)
      let chunk = built.rootArtifact.compiledChunk
      if chunk == nil:
        raise newException(ValueError,
          "build produced no executable GIR artifact")
      let entry = app.loadCompiledFileModule(
        executionPackage.root / relative, chunk)
      reportingScope = entry.moduleRootNamespace.nsScope
      invokeEntryMain(entry.moduleRootNamespace.nsScope, @[])
      echo "[OK] " & relative
  except ReadError as error:
    stderr.writeLine formatDiagnostic("Read error", error.msg,
                                      error.readErrorLoc)
    quit(1)
  except GenePanic as error:
    stderr.writeLine "Panic: " & error.msg
    quit(1)
  except GeneError as error:
    stderr.writeLine formatDiagnostic("Error",
      errorDiagnosticMessage(error, replFallbackScope(reportingScope)), error.loc)
    quit(1)
  except CatchableError as error:
    stderr.writeLine "Error: " & error.msg
    quit(1)

type SpecTestCli = object
  paths: seq[string]
  name: string
  host: RunCli

proc parseSpecTestCli(): SpecTestCli =
  var i = 2
  var positionalOnly = false
  while i <= paramCount():
    let arg = paramStr(i)
    if positionalOnly:
      result.paths.add arg
    elif arg == "--":
      positionalOnly = true
    elif arg.startsWith("--"):
      let at = arg.find('=')
      let option = if at < 0: arg else: arg[0..<at]
      if option notin ["--name", "--package-root", "--errors-mode"]:
        raise newException(ValueError, "unknown test option: " & option)
      var value: string
      if at >= 0:
        value = arg[at+1..^1]
      else:
        inc i
        if i > paramCount():
          raise newException(ValueError, option & " expects a value")
        value = paramStr(i)
      case option
      of "--name": result.name = value
      of "--package-root": result.host.packageRoot = value
      of "--errors-mode":
        if value notin ["dynamic", "warn", "strict"]:
          raise newException(ValueError, "--errors-mode expects dynamic, warn, or strict")
        result.host.errorsMode = value
      else: discard
    elif arg.startsWith("-"):
      raise newException(ValueError, "unknown test option: " & arg)
    else:
      result.paths.add arg
    inc i

proc discoverSpecFiles(app: Application, inputs: seq[string]): seq[string] =
  var files, directories = initHashSet[string]()
  proc visit(path: string, explicitFile = false) =
    if not explicitFile and not dirExists(path) and
        not path.endsWith("_spec.gene"):
      return
    let canonical = canonicalPath(path)
    app.requireEntryWithinPackage(canonical)
    if dirExists(canonical):
      if canonical in directories: return
      directories.incl canonical
      for _, entry in walkDir(canonical, relative = true):
        visit(canonical / entry)
    elif fileExists(canonical):
      if explicitFile or path.endsWith("_spec.gene"):
        if not canonical.endsWith(".gene"):
          raise newException(ValueError, "test files must end in .gene: " & path)
        files.incl canonical
    elif explicitFile:
      raise newException(ValueError, "test path does not exist: " & path)
  if inputs.len == 0:
    if dirExists("tests"): visit("tests")
  else:
    for path in inputs: visit(path, true)
  for path in files: result.add path
  result.sort()

proc cmdSpecTest(options: SpecTestCli) =
  var reportingScope: Scope
  try:
    let start = if options.host.packageRoot.len > 0:
                  options.host.packageRoot
                else: getCurrentDir()
    if not dirExists(start):
      raise newException(ValueError, "--package-root is not a directory: " & start)
    let app = newApplication(start)
    if options.host.errorsMode.len > 0:
      app.setErrorCheckingMode(options.host.errorsMode)
    let files = discoverSpecFiles(app, options.paths)
    let scope = newGlobalScope(app)
    reportingScope = scope
    scope.beginTestCollection()
    try:
      for path in files:
        discard app.loadFileModule(path)
    except ReadError as error:
      let failure = newException(GeneError, error.msg)
      failure.loc = error.readErrorLoc
      scope.recordTestCollectionError(failure)
    except GeneError as error:
      scope.recordTestCollectionError(error)
    finally:
      scope.finishTestCollection()
    let result = runTests(scope, options.name)
    quit(int(result.props["exit_code"].intVal))
  except ValueError as error:
    stderr.writeLine "Error: " & error.msg
    quit(2)
  except GenePanic as error:
    stderr.writeLine "Panic: " & error.msg
    quit(1)
  except GeneCancel as error:
    stderr.writeLine "Cancelled: " & error.msg
    quit(1)
  except GeneError as error:
    stderr.writeLine formatDiagnostic("Error",
      errorDiagnosticMessage(error, replFallbackScope(reportingScope)), error.loc)
    quit(1)
  except CatchableError as error:
    stderr.writeLine "Error: " & error.msg
    quit(1)

proc cmdClean() =
  let root = workspaceRootFor(getCurrentDir()).root
  var removed: seq[string]
  for path in [root / ".gene" / "build", root / ".gene" / "sandboxes"]:
    if dirExists(path):
      removeDir(path)
      removed.add path
  if removed.len == 0:
    echo "Project build view is already clean"
  else:
    for path in removed:
      echo "Removed " & path

proc unavailableBuildFeature(command: string) =
  stderr.writeLine "Error: BUILD_FEATURE_UNAVAILABLE: 'gene " & command &
    "' has not passed its demand gate"
  quit(1)

proc docDeclarationNames(scope: Scope, includeThisModule = false): seq[string] =
  scope.materializeMirroredVars()
  for name in scope.vars.keys:
    if includeThisModule or name notin ["this_mod", "this_pkg"]:
      result.add name
  result.sort()

proc writeDocDeclarations(scope: Scope, includeThisModule = false) =
  var declarations = initTable[string, string]()
  for name in docDeclarationNames(scope, includeThisModule):
    if not name.startsWith(BlockBindingPrefix):
      declarations[name] = declarationKind(scope.vars[name])
  if scope.compilerMacros != nil and scope.compilerMacros of MacroBindings:
    let context = MacroBindings(scope.compilerMacros)
    for name in context.ownedNames:
      if '/' notin name and context.definitions.hasKey(name):
        declarations[name] = "Macro"
  var names: seq[string]
  for name in declarations.keys: names.add name
  names.sort()
  for name in names:
    echo "- " & name & " : " & declarations[name]

proc collectDocNamespaces(ns: Value, prefix: string,
                          namespaces: var seq[tuple[path: string, ns: Value]]) =
  for name in docDeclarationNames(ns.nsScope):
    let value = ns.nsScope.vars[name]
    if value.kind == vkNamespace:
      let path = if prefix.len == 0: name else: prefix & "/" & name
      namespaces.add (path: path, ns: value)
      collectDocNamespaces(value, path, namespaces)

proc collectDocImports(chunk: Chunk, imports: var seq[ImportSpec]) =
  if chunk == nil:
    return
  for spec in chunk.imports:
    imports.add spec
  for subchunk in chunk.subchunks:
    collectDocImports(subchunk, imports)
  for fn in chunk.functions:
    collectDocImports(fn.chunk, imports)
  for loop in chunk.forLoops:
    collectDocImports(loop.body, imports)
  for match in chunk.matches:
    for clause in match.clauses:
      collectDocImports(clause.body, imports)
    collectDocImports(match.elseBody, imports)
  for attempt in chunk.tries:
    collectDocImports(attempt.body, imports)
    for clause in attempt.catches:
      collectDocImports(clause.body, imports)
    collectDocImports(attempt.ensureBody, imports)

proc docSelectionText(sel: ImportSelection): string =
  if sel.name == sel.local:
    sel.name
  else:
    sel.name & " : " & sel.local

proc docImportText(app: Application, spec: ImportSpec): string =
  if spec.fromModule:
    result = "- from \"" & spec.modulePath & "\""
    if spec.pkgName.len > 0:
      result.add " ^pkg \"" & spec.pkgName & "\""
    result.add " -> " & app.resolveModuleRef(spec.modulePath, spec.pkgName)
  else:
    result = "- " & spec.nsSegments.join("/")
  if spec.alias.len > 0:
    result.add " : " & spec.alias
  elif spec.wildcard:
    result.add " *"
  if spec.selections.len > 0:
    var selections: seq[string]
    for sel in spec.selections:
      selections.add docSelectionText(sel)
    result.add " [" & selections.join(", ") & "]"

proc writeDocImports(app: Application, chunk: Chunk) =
  var imports: seq[ImportSpec]
  collectDocImports(chunk, imports)
  if imports.len > 0:
    echo "Imports:"
    for spec in imports:
      echo docImportText(app, spec)

proc cmdDoc(path: string) =
  if not fileExists(path):
    stderr.writeLine "Error: file not found: " & path
    quit(1)
  try:
    let absPath = normalizedPath(absolutePath(path))
    let app = newApplicationForEntryFile(absPath)
    let chunk = app.compileFileModule(absPath)
    let module = app.loadFileModule(absPath)
    echo "Module: " & module.moduleName
    echo "Path: " & module.modulePath
    let meta = module.moduleMeta
    if meta.hasKey("doc") and meta["doc"].kind == vkString:
      echo "Doc: " & meta["doc"].strVal
    writeDocImports(app, chunk)
    echo "Declarations:"
    let rootScope = module.moduleRootNamespace.nsScope
    writeDocDeclarations(rootScope)
    var namespaces: seq[tuple[path: string, ns: Value]]
    collectDocNamespaces(module.moduleRootNamespace, "", namespaces)
    if namespaces.len > 0:
      echo "Namespaces:"
      for item in namespaces:
        echo "Namespace " & item.path & ":"
        writeDocDeclarations(item.ns.nsScope)
  except ReadError as e:
    stderr.writeLine formatDiagnostic("Read error", e.msg, e.readErrorLoc)
    quit(1)
  except GenePanic as e:
    stderr.writeLine "Panic: " & e.msg
    quit(1)
  except GeneError as e:
    stderr.writeLine formatDiagnostic("Error", e.msg, e.loc)
    quit(1)

# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# gene pkg (docs/workflows.md)
# ---------------------------------------------------------------------------

type PkgCli = object
  action: string
  arguments: seq[string]
  packageRoot: string
  locked: bool
  offline: bool
  workspace: bool
  dependencyPath: string
  registryConfig: string
  signingKey: string
  publishSigner: string
  publishRegistry: string
  initKind: string

proc parsePkgCli(): PkgCli =
  var i = 2
  while i <= paramCount():
    let arg = paramStr(i)
    case arg
    of "--package-root":
      inc i
      if i > paramCount():
        raise newException(ValueError, "--package-root expects a path")
      result.packageRoot = paramStr(i)
    of "--path":
      inc i
      if i > paramCount():
        raise newException(ValueError, "--path expects a path")
      result.dependencyPath = paramStr(i)
    of "--registry-config":
      inc i
      if i > paramCount():
        raise newException(ValueError, "--registry-config expects a path")
      result.registryConfig = paramStr(i)
    of "--signing-key", "--signer", "--registry":
      inc i
      if i > paramCount():
        raise newException(ValueError, arg & " expects a value")
      case arg
      of "--signing-key": result.signingKey = paramStr(i)
      of "--signer": result.publishSigner = paramStr(i)
      else: result.publishRegistry = paramStr(i)
    of "--locked": result.locked = true
    of "--offline": result.offline = true
    of "--workspace": result.workspace = true
    of "--lib", "--app", "--mixed":
      if result.initKind.len > 0:
        raise newException(ValueError,
          "choose exactly one of --lib, --app, or --mixed")
      result.initKind = arg[2 .. ^1]
    else:
      if arg.startsWith("--package-root="):
        result.packageRoot = arg[15 .. ^1]
      elif arg.startsWith("--path="):
        result.dependencyPath = arg[7 .. ^1]
      elif arg.startsWith("--registry-config="):
        result.registryConfig = arg[18 .. ^1]
      elif arg.startsWith("--signing-key="):
        result.signingKey = arg[14 .. ^1]
      elif arg.startsWith("--signer="):
        result.publishSigner = arg[9 .. ^1]
      elif arg.startsWith("--registry="):
        result.publishRegistry = arg[11 .. ^1]
      elif arg.startsWith("-"):
        raise newException(ValueError, "unknown pkg option: " & arg)
      elif result.action.len == 0:
        result.action = arg
      else:
        result.arguments.add arg
    inc i
  if result.action.len == 0:
    raise newException(ValueError,
      "'pkg' needs a subcommand: init, add, remove, resolve, update, sync, " &
      "vendor, members, tree, why, publish, or cache")

proc pkgStart(options: PkgCli): string =
  if options.packageRoot.len > 0: options.packageRoot else: getCurrentDir()

proc pkgManager(options: PkgCli): PackageManager =
  packageManagerFromRegistryConfig(options.registryConfig)

proc pkgResolution(manager: PackageManager, start: string): Resolution =
  let lockPath = packageLockPathFor(start)
  if fileExists(lockPath): manager.loadResolutionLock(start)
  else: manager.resolve(ResolveRequest(startDir: start))

proc cmdPkgResolve(options: PkgCli) =
  let start = options.pkgStart()
  let manager = pkgManager(options)
  if options.action == "resolve" and options.arguments.len > 0:
    raise newException(ValueError, "'pkg resolve' accepts no arguments")
  if options.action == "update" and options.arguments.len > 1:
    raise newException(ValueError, "'pkg update' accepts at most one alias")
  if options.action == "update" and options.locked:
    raise newException(ValueError, "--locked forbids dependency updates")
  if options.locked:
    let resolution = manager.loadResolutionLock(start)
    echo "Lock is current: " & packageLockPathFor(start)
    echo "Instances: " & $resolution.packagesById.len
    return
  let unlocked =
    if options.action == "update": options.arguments
    else: @[]
  let resolution = manager.resolve(ResolveRequest(startDir: start,
                                                  unlockAliases: unlocked,
                                                  unlockAll:
                                                    options.action == "update" and
                                                    unlocked.len == 0,
                                                  offline: options.offline))
  let lockPath = resolution.writeResolutionLock()
  echo "Resolved " & $resolution.packagesById.len & " package instance(s)"
  echo "Lock: " & lockPath

proc cmdPkgSync(options: PkgCli): MaterializedGraph =
  let start = options.pkgStart()
  let manager = pkgManager(options)
  let resolution = manager.loadResolutionLock(start)
  result = manager.sync(resolution,
    SyncPolicy(offline: options.offline, locked: options.locked))
  echo "Synchronized " & $result.packagesById.len & " package instance(s)"

proc cmdPkgVendor(options: PkgCli) =
  let graph = cmdPkgSync(options)
  let manager = pkgManager(options)
  let receipt = manager.vendor(graph, VendorRequest())
  echo "Vendored " & $receipt.packagePaths.len & " immutable package object(s)"
  echo "Vendor root: " & receipt.root

proc cmdPkgPublish(options: PkgCli) =
  if options.arguments.len != 0 or options.registryConfig.len == 0 or
      options.signingKey.len == 0 or options.offline:
    raise newException(ValueError,
      "usage: gene pkg publish --registry-config <path> --signing-key <raw-32-byte-file> [--signer owner|registry] [--registry name] [--package-root path]")
  let root = findManifestDir(options.pkgStart())
  if root.len == 0:
    raise newException(ValueError, "pkg publish needs a package.gene")
  let keyPath = normalizedPath(absolutePath(options.signingKey))
  if not fileExists(keyPath) or symlinkExists(keyPath) or
      getFileInfo(keyPath, followSymlink = false).isSpecial or
      getFileSize(keyPath) != 32:
    raise newException(ValueError,
      "pkg publish signing key must be a regular raw 32-byte file")
  let registry = configuredRegistryForPublish(options.registryConfig,
                                              options.publishRegistry)
  let pkg = loadPackageAt(root, poEntry)
  let digest = publishPackage(registry, pkg, readFile(keyPath),
    if options.publishSigner.len > 0: options.publishSigner else: "owner")
  echo "Published " & pkg.name & "@" & pkg.version & " " & digest

proc cmdPkgMembers(options: PkgCli) =
  let start = options.pkgStart()
  let root = workspaceRootFor(start)
  echo root.name & " " & root.root
  for member in workspaceMembers(start):
    echo member.name & " " & member.root

proc cmdPkgTree(options: PkgCli) =
  let start = options.pkgStart()
  let manager = pkgManager(options)
  let resolution = manager.pkgResolution(start)
  var ids: seq[string]
  for id in resolution.packagesById.keys:
    ids.add id
  ids.sort()
  for id in ids:
    let pkg = resolution.packagesById[id]
    let marker = if id == resolution.activePackageId: "* " else: "  "
    echo marker & pkg.name & " " & pkg.version & " [" & id & "]"
    var aliases: seq[string]
    for alias in pkg.dependencyEdges.keys:
      aliases.add alias
    aliases.sort()
    for alias in aliases:
      echo "    " & alias & " -> " & pkg.dependencyEdges[alias]

proc cmdPkgWhy(options: PkgCli) =
  if options.arguments.len != 1:
    raise newException(ValueError, "'pkg why' needs one package name or id")
  let needle = options.arguments[0]
  let manager = pkgManager(options)
  let resolution = manager.pkgResolution(options.pkgStart())
  type PathItem = tuple[id, path: string]
  var pending: seq[PathItem]
  var seen = initHashSet[string]()
  pending.add (resolution.activePackageId,
               resolution.packagesById[resolution.activePackageId].name)
  var found = false
  while pending.len > 0:
    let item = pending[0]
    pending.delete(0)
    if item.id in seen:
      continue
    seen.incl item.id
    let pkg = resolution.packagesById[item.id]
    if item.id == needle or pkg.name == needle:
      echo item.path & " [" & item.id & "]"
      found = true
    var aliases: seq[string]
    for alias in pkg.dependencyEdges.keys:
      aliases.add alias
    aliases.sort()
    for alias in aliases:
      let target = pkg.dependencyEdges[alias]
      pending.add (target, item.path & " --" & alias & "--> " &
        resolution.packagesById[target].name)
  if not found:
    raise newException(ValueError, "package is not present in the graph: " & needle)

proc localPackageName(path: string): string =
  var name = extractFilename(normalizedPath(absolutePath(path))).toLowerAscii()
  for ch in name.mitems:
    if ch notin {'a' .. 'z', '0' .. '9', '_'}:
      ch = '_'
  while name.len > 0 and name[0] == '_':
    name = if name.len == 1: "" else: name[1 .. ^1]
  if name.len == 0:
    name = "package"
  "local/" & name

proc registerWorkspaceMember(memberRoot: string):
    tuple[manifestPath, original: string, changed: bool] =
  let parentManifestRoot = findManifestDir(parentDir(memberRoot))
  if parentManifestRoot.len == 0:
    return
  let workspaceRoot = workspaceRootFor(parentDir(memberRoot))
  if workspaceRoot.kind != pkRegular or workspaceRoot.root == memberRoot or
      not containsPath(workspaceRoot.realRoot, canonicalPath(memberRoot)):
    return
  result.manifestPath = workspaceRoot.manifestPath
  result.original = readFile(result.manifestPath)
  let forms = readAll(result.original, result.manifestPath,
                      ReadOptions(rejectDuplicateProps: true))
  if forms.len != 1 or forms[0].kind != vkMap:
    raise newException(ValueError, "workspace package.gene must contain one map")
  var manifest = initPropTable()
  for key, value in forms[0].mapEntries:
    manifest[key] = value
  var workspace = initPropTable()
  var members: seq[Value]
  if manifest.hasKey("workspace"):
    if manifest["workspace"].kind != vkMap:
      raise newException(ValueError, "^workspace must be a map")
    for key, value in manifest["workspace"].mapEntries:
      workspace[key] = value
    if workspace.hasKey("members"):
      if workspace["members"].kind != vkList:
        raise newException(ValueError, "^workspace.^members must be a list")
      members = workspace["members"].listItems
  let relative = relativePath(memberRoot, workspaceRoot.root).replace('\\', '/')
  for value in members:
    if value.kind == vkString and
        workspaceMemberMatches(value.strVal, relative):
      return
  members.add newStr(relative)
  workspace["members"] = newList(members)
  manifest["workspace"] = newMap(workspace)
  writeFile(result.manifestPath, newMap(manifest).print() & "\n")
  result.changed = true

proc cmdPkgInit(options: PkgCli) =
  if options.initKind.len == 0:
    raise newException(ValueError,
      "'pkg init' requires exactly one of --lib, --app, or --mixed")
  if options.arguments.len > 1:
    raise newException(ValueError, "'pkg init' accepts at most one directory")
  let root = normalizedPath(absolutePath(
    if options.arguments.len == 1: options.arguments[0]
    else: options.pkgStart()))
  let manifestPath = root / ManifestFileName
  if fileExists(manifestPath):
    raise newException(ValueError, "package already exists: " & manifestPath)
  createDir(root)
  let name = localPackageName(root)
  var manifest = "{^format 1 ^name \"" & name & "\" ^version \"0.1.0\""
  if options.initKind in ["lib", "mixed"]:
    manifest.add " ^library {^entry \"src/index.gene\"}"
    createDir(root / "src")
    writeFile(root / "src/index.gene", "")
  if options.initKind in ["app", "mixed"]:
    manifest.add " ^applications [(application \"" & name.split('/')[1] &
      "\" ^entry \"src/main.gene\")]"
    createDir(root / "src")
    writeFile(root / "src/main.gene", "(fn main [] 0)\n")
  if options.initKind == "mixed":
    createDir(root / "packages")
  manifest.add "}\n"
  writeFile(manifestPath, manifest)
  let registration = registerWorkspaceMember(root)
  try:
    let resolution = newPackageManager().resolve(ResolveRequest(startDir: root))
    discard resolution.writeResolutionLock()
  except CatchableError:
    if registration.changed:
      writeFile(registration.manifestPath, registration.original)
    raise
  echo "Initialized " & name & " at " & root

proc parseDependencyCoordinate(text: string): tuple[alias, name, constraint: string] =
  let equals = text.find('=')
  let at = text.rfind('@')
  if equals <= 0 or at <= equals + 1 or at == text.high:
    raise newException(ValueError,
      "dependency must be <alias>=<owner/name>@<constraint>")
  result.alias = text[0 ..< equals]
  result.name = text[equals + 1 ..< at]
  result.constraint = text[at + 1 .. ^1]

proc rewriteDependencies(options: PkgCli, remove: bool) =
  if options.locked:
    raise newException(ValueError, "--locked forbids manifest and lock rewrites")
  if options.arguments.len != 1:
    raise newException(ValueError,
      "'pkg " & options.action & "' needs one dependency argument")
  let start = options.pkgStart()
  let packageRoot = findManifestDir(start)
  if packageRoot.len == 0:
    raise newException(ValueError, "no package.gene found from " & start)
  let manifestPath = packageRoot / ManifestFileName
  let original = readFile(manifestPath)
  let forms = readAll(original, manifestPath,
                      ReadOptions(rejectDuplicateProps: true))
  if forms.len != 1 or forms[0].kind != vkMap:
    raise newException(ValueError, "package.gene must contain one map")
  var manifestEntries = initPropTable()
  for key, value in forms[0].mapEntries:
    manifestEntries[key] = value
  var dependencies = initPropTable()
  if manifestEntries.hasKey("dependencies"):
    if manifestEntries["dependencies"].kind != vkMap:
      raise newException(ValueError, "^dependencies must be a map")
    for key, value in manifestEntries["dependencies"].mapEntries:
      dependencies[key] = value
  let alias =
    if remove: options.arguments[0]
    else: parseDependencyCoordinate(options.arguments[0]).alias
  if remove:
    if not dependencies.hasKey(alias):
      raise newException(ValueError, "dependency alias is not declared: " & alias)
    dependencies.del(alias)
  else:
    let coordinate = parseDependencyCoordinate(options.arguments[0])
    if dependencies.hasKey(coordinate.alias):
      raise newException(ValueError,
        "dependency alias is already declared: " & coordinate.alias)
    var props = initPropTable()
    if options.workspace:
      props["workspace"] = TRUE
    if options.dependencyPath.len > 0:
      props["path"] = newStr(options.dependencyPath)
    if options.workspace and options.dependencyPath.len > 0:
      raise newException(ValueError, "--workspace and --path are mutually exclusive")
    dependencies[coordinate.alias] = newNode(newSym("dep"), props,
      @[newStr(coordinate.name), newStr(coordinate.constraint)])
  manifestEntries["dependencies"] = newMap(dependencies)
  writeFile(manifestPath, newMap(manifestEntries).print() & "\n")
  try:
    let resolution = pkgManager(options).resolve(
      ResolveRequest(startDir: packageRoot))
    discard resolution.writeResolutionLock()
  except CatchableError:
    writeFile(manifestPath, original)
    raise
  echo (if remove: "Removed " else: "Added ") & alias

proc cmdPkg() =
  var options: PkgCli
  try:
    options = parsePkgCli()
    case options.action
    of "init": cmdPkgInit(options)
    of "add": rewriteDependencies(options, false)
    of "remove": rewriteDependencies(options, true)
    of "resolve", "update": cmdPkgResolve(options)
    of "sync": discard cmdPkgSync(options)
    of "vendor": cmdPkgVendor(options)
    of "members": cmdPkgMembers(options)
    of "tree": cmdPkgTree(options)
    of "why": cmdPkgWhy(options)
    of "publish": cmdPkgPublish(options)
    of "cache":
      if options.arguments != @["gc"]:
        raise newException(ValueError, "usage: gene pkg cache gc")
      let collected = newPackageManager().cacheGc()
      echo "Package cache GC: kept " & $collected.keptObjects &
        ", removed " & $collected.removedObjects &
        " object(s); removed " & $collected.removedRootReceipts &
        " stale root receipt(s)"
    else:
      raise newException(ValueError,
        "unknown pkg subcommand: " & options.action)
  except GeneError as e:
    stderr.writeLine formatDiagnostic("Error", e.msg, e.loc)
    quit(1)
  except CatchableError as e:
    stderr.writeLine "Error: " & e.msg
    quit(1)

proc main() =
  resetLogging()
  defer: shutdownLogging()
  if paramCount() == 0:
    usage()
    quit(0)
  let cmd = paramStr(1)
  case cmd
  of "--version", "version":
    echo geneBuildInfo()
  of "eval":
    let options = parseInteractiveCli("eval", true)
    cmdEval(options.path, options.errorsMode)
  of "repl":
    let options = parseInteractiveCli("repl", false)
    cmdRepl(options.errorsMode)
  of "run":
    var options: RunCli
    try:
      options = parseRunCli(pathRequired = false)
      configureRunLogging(options)
    except CatchableError as e:
      stderr.writeLine "Error: " & e.msg
      quit(1)
    if options.path.len > 0 and fileExists(options.path):
      cmdRun(options.path, options.args, options.packageRoot, options)
    elif options.path.endsWith(".gapp"):
      stderr.writeLine "Error: BUILD_FEATURE_UNAVAILABLE: portable .gapp " &
        "execution is not implemented"
      quit(1)
    elif options.path.endsWith(".gene") or options.path.isAbsolute or
        '/' in options.path or '\\' in options.path:
      stderr.writeLine "Error: file not found: " & options.path
      quit(1)
    else:
      cmdProjectRun(options)
  of "runurl":
    var options: RunCli
    try:
      options = parseRunCli(label = "runurl", pathNoun = "an https:// URL")
      configureRunLogging(options)
    except CatchableError as e:
      stderr.writeLine "Error: " & e.msg
      quit(1)
    cmdRunUrl(options.path, options.args, options.packageRoot, options)
  of "parse":
    if paramCount() < 2:
      stderr.writeLine "Error: 'parse' needs a file path"
      quit(1)
    cmdParse(paramStr(2))
  of "fmt":
    delegateToTool("gene-fmt", commandArgs(2))
  of "compile":
    if paramCount() < 2:
      stderr.writeLine "Error: 'compile' needs a file path"
      quit(1)
    if paramStr(2) == "--c-header":
      if paramCount() != 2:
        stderr.writeLine "Error: 'compile --c-header' takes no file path"
        quit(1)
      stdout.write emitNativeCHeader()
    elif paramStr(2) == "--target":
      if paramCount() < 4:
        stderr.writeLine "Error: 'compile --target' needs a target and file path"
        quit(1)
      if paramStr(3) != "c":
        stderr.writeLine "Error: unsupported compile target: " & paramStr(3)
        quit(1)
      cmdCompileC(paramStr(4))
    elif paramStr(2) == "--c":
      if paramCount() < 3:
        stderr.writeLine "Error: 'compile --c' needs a file path"
        quit(1)
      cmdCompileC(paramStr(3))
    else:
      cmdCompile(paramStr(2))
  of "build":
    try:
      if isDirectWebBuild():
        cmdBuildWeb(parseBuildWebCli())
      else:
        cmdProjectBuild(parseProjectBuildCli())
    except GeneError as e:
      stderr.writeLine formatDiagnostic("Error", e.msg, e.loc)
      quit(1)
    except CatchableError as e:
      stderr.writeLine "Error: " & e.msg
      quit(1)
  of "test":
    try:
      if paramCount() >= 2 and paramStr(2) == "--package":
        cmdProjectTest(parseProjectBuildCli("test", first = 3))
      else:
        cmdSpecTest(parseSpecTestCli())
    except ValueError as e:
      stderr.writeLine "Error: " & e.msg
      quit(2)
    except GeneError as e:
      stderr.writeLine formatDiagnostic("Error", e.msg, e.loc)
      quit(1)
    except CatchableError as e:
      stderr.writeLine "Error: " & e.msg
      quit(1)
  of "clean":
    if paramCount() != 1:
      stderr.writeLine "Error: 'clean' accepts no arguments"
      quit(1)
    cmdClean()
  of "install":
    try:
      cmdInstall()
    except GeneError as e:
      stderr.writeLine formatDiagnostic("Error", e.msg, e.loc)
      quit(1)
    except CatchableError as e:
      stderr.writeLine "Error: " & e.msg
      quit(1)
  of "uninstall":
    try:
      cmdUninstall()
    except GeneError as e:
      stderr.writeLine formatDiagnostic("Error", e.msg, e.loc)
      quit(1)
    except CatchableError as e:
      stderr.writeLine "Error: " & e.msg
      quit(1)
  of "pack", "bundle", "inspect", "verify", "sign",
     "rollback", "installed":
    unavailableBuildFeature(cmd)
  of "doc":
    if paramCount() < 2:
      stderr.writeLine "Error: 'doc' needs a file path"
      quit(1)
    cmdDoc(paramStr(2))
  of "pkg":
    cmdPkg()
  of "view":
    delegateToTool("gene-viewer", commandArgs(2))
  of "lsp":
    delegateToTool("gene-lsp", commandArgs(2))
  of "-h", "--help", "help":
    usage()
  else:
    # Back-compat: a bare path argument is treated as `run`.
    if fileExists(cmd):
      cmdRun(cmd, commandArgs(2))
    else:
      stderr.writeLine "Unknown command: " & cmd
      usage()
      quit(1)

try:
  main()
except CatchableError as error:
  stderr.writeLine "Error: " & error.msg
  quit(1)
